"""Historical command wrapper for the Structural Manifold benchmark.

Canonical implementation:
``gold_line.structural_manifold.pqd16c_benchmark``.
"""

from gold_line.structural_manifold.pqd16c_benchmark import *  # noqa: F401,F403
from gold_line.structural_manifold.pqd16c_benchmark import main


if __name__ == "__main__":
    main()
