#!/usr/bin/env python3
"""Deliberately regenerate the immutable fixed-subset DMREDA golden vectors.

This command is not part of ordinary test execution.  A write requires both
``--write`` and a non-empty ``--reason`` so the fixture records why its oracle
values changed.  Reviewers must inspect the resulting fixture diff and run the
independent C fixture test before accepting it.
"""

from __future__ import annotations

import argparse
from datetime import date
import json
from pathlib import Path
import subprocess
import sys
from typing import Any

import numpy as np


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from tests.golden_support import (  # noqa: E402
    GOLDEN_PATH,
    GOLDEN_SHA256_PATH,
    compute_fixed_python,
    configuration_sha256,
    encode_runs,
    fixed_configuration,
    generate_signal,
    sha256_bytes,
    signal_sha256,
)


FIXTURE_DEFINITIONS: tuple[dict[str, Any], ...] = (
    {
        "fixture_name": "constant_signal",
        "purpose": "constant-signal initialization and quiet authority",
        "warmup_samples": 92,
        "mode": "D_OR_G",
        "input": {"generator": "constant", "length": 128, "value": 0.0},
        "checkpoints": [0, 1, 3, 4, 6, 7, 15, 16, 31, 63, 91, 92, 127],
    },
    {
        "fixture_name": "anomaly_entirely_inside_warmup",
        "purpose": "representation inheritance with no pre-warmup event authority",
        "warmup_samples": 92,
        "mode": "D_OR_G",
        "input": {
            "generator": "piecewise_constant",
            "length": 160,
            "base": 0.0,
            "segments": [[20, 35, 1.0]],
        },
        "checkpoints": [0, 6, 15, 19, 20, 24, 34, 35, 50, 91, 92, 93, 159],
    },
    {
        "fixture_name": "post_warmup_step",
        "purpose": "post-warmup step and canonical first-event authority",
        "warmup_samples": 92,
        "mode": "D_ONLY",
        "input": {
            "generator": "piecewise_constant",
            "length": 220,
            "base": 0.0,
            "segments": [[120, 220, 1.0]],
        },
        "checkpoints": [0, 15, 91, 92, 119, 120, 124, 125, 126, 136, 219],
    },
    {
        "fixture_name": "impulse_followed_by_ramp",
        "purpose": "impulse, finite-lag growth, and sustained ramp response",
        "warmup_samples": 92,
        "mode": "G_ONLY",
        "input": {
            "generator": "impulse_then_ramp",
            "length": 260,
            "base": 0.0,
            "impulse_index": 105,
            "impulse_value": 2.0,
            "ramp_start": 150,
            "ramp_length": 70,
            "ramp_first": 0.0,
            "ramp_last": 1.2,
        },
        "checkpoints": [0, 91, 92, 104, 105, 109, 110, 120, 149, 150, 153, 160, 219, 259],
    },
    {
        "fixture_name": "alternating_sign_signal",
        "purpose": "even/odd median behavior and repeated ring-buffer wrapping",
        "warmup_samples": 0,
        "mode": "D_OR_G",
        "input": {
            "generator": "alternating_sign",
            "length": 180,
            "amplitude": 0.4,
            "offset": 0.0,
        },
        "checkpoints": [0, 1, 3, 4, 6, 7, 15, 16, 17, 31, 63, 95, 127, 179],
    },
    {
        "fixture_name": "confirmation_length_boundary",
        "purpose": "20-sample pending timeout boundary followed by later confirmation",
        "warmup_samples": 0,
        "mode": "D_OR_G",
        "input": {
            "generator": "periodic_pulses",
            "length": 180,
            "base": 0.0,
            "start": 20,
            "period": 60,
            "width": 15,
            "amplitude": 1.0,
        },
        "checkpoints": [0, 19, 20, 24, 25, 26, 104, 105, 123, 124, 125, 139, 140, 145, 146, 147, 179],
    },
    {
        "fixture_name": "refractory_boundary",
        "purpose": "new pending authority begins exactly when refractory expires",
        "warmup_samples": 0,
        "mode": "D_OR_G",
        "input": {
            "generator": "periodic_pulses",
            "length": 260,
            "base": 0.0,
            "start": 20,
            "period": 40,
            "width": 15,
            "amplitude": 1.0,
        },
        "checkpoints": [0, 19, 20, 24, 25, 26, 104, 105, 112, 113, 114, 194, 195, 213, 214, 221, 222, 232, 233, 259],
    },
    {
        "fixture_name": "ring_buffer_wrap_boundary",
        "purpose": "w1, w2, and m ring wrap arithmetic across mixed disturbances",
        "warmup_samples": 0,
        "mode": "D_OR_G",
        "input": {
            "generator": "repeated_pattern_with_overrides",
            "length": 100,
            "pattern": [0.0, 0.1, -0.2, 0.3, -0.4, 0.5, -0.6, 0.7, -0.8],
            "overrides": [[31, 1.5], [64, -1.25], [95, 0.9]],
        },
        "checkpoints": [0, 1, 3, 4, 6, 7, 8, 15, 16, 17, 31, 32, 63, 64, 65, 95, 96, 99],
    },
)


def source_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=REPOSITORY_ROOT,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def build_fixture(definition: dict[str, Any], *, reason: str, commit: str | None) -> dict[str, object]:
    input_specification = dict(definition["input"])
    signal = generate_signal(input_specification)
    configuration = fixed_configuration(
        trace_length=int(signal.size),
        warmup_samples=int(definition["warmup_samples"]),
        mode=str(definition["mode"]),
    )
    result = compute_fixed_python(signal, configuration)
    indices = sorted(
        {
            int(index)
            for index in definition["checkpoints"]
            if 0 <= int(index) < signal.size
        }
        | {
            index
            for event in result.event_times
            for index in (event - 1, event, event + 1)
            if 0 <= index < signal.size
        }
    )
    selected = [
        {
            "index": index,
            "mu": float(result.mu[index]),
            "E1": float(result.e1[index]),
            "D": float(result.d[index]),
            "G": float(result.g[index]),
        }
        for index in indices
    ]
    return {
        "fixture_name": definition["fixture_name"],
        "purpose": definition["purpose"],
        "input": {
            "generator_definition": input_specification,
            "float64_little_endian_sha256": signal_sha256(signal),
        },
        "configuration": configuration,
        "configuration_sha256": configuration_sha256(configuration),
        "expected_warmup_samples": int(definition["warmup_samples"]),
        "expected": {
            "event_indices": list(result.event_times),
            "state_trace_rle": encode_runs(result.state),
            "pending_trace_rle": encode_runs(result.pending),
            "confirmation_trace_rle": encode_runs(result.confirmed),
            "event_active_trace_rle": encode_runs(result.event_active),
            "selected_float_trace": selected,
        },
        "numeric_tolerance": {
            "absolute": 5e-12,
            "relative": 0.0,
            "scope": "selected mu, E1, D, and G values",
        },
        "provenance": {
            "generated_by": "tools/regenerate_dmreda_golden.py",
            "generation_date": date.today().isoformat(),
            "source_commit_before_fixture_commit": commit,
            "oracle": (
                "canonical Python fixed subset, then independently checked "
                "against gold_line/core/dmreda_streaming_fixed.c"
            ),
            "change_reason": reason,
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true", help="write the fixture and checksum")
    parser.add_argument("--reason", help="specific scientific or engineering reason for regeneration")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    reason = "" if args.reason is None else args.reason.strip()
    if args.write and not reason:
        raise SystemExit("--write requires a non-empty --reason")
    if not reason:
        reason = "dry-run inspection; no fixture write requested"

    commit = source_commit()
    payload = {
        "schema_version": 1,
        "fixture_set": "dmreda-fixed-subset-v1",
        "ordinary_test_regeneration": "forbidden",
        "fixtures": [
            build_fixture(definition, reason=reason, commit=commit)
            for definition in FIXTURE_DEFINITIONS
        ],
    }
    # The repository fixture is intentionally pretty-printed for line-level
    # human review; nested configuration hashes still use canonical JSON.
    serialized = (
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")
    digest = sha256_bytes(serialized)

    if not args.write:
        print(f"dry-run fixture sha256: {digest}")
        print("no files written; use --write --reason '...' deliberately")
        return 0

    GOLDEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    GOLDEN_PATH.write_bytes(serialized)
    GOLDEN_SHA256_PATH.write_text(
        f"{digest}  {GOLDEN_PATH.name}\n", encoding="ascii"
    )
    print(f"wrote {GOLDEN_PATH}")
    print(f"wrote {GOLDEN_SHA256_PATH}")
    print(f"fixture sha256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
