#!/usr/bin/env python3
"""Build and report fixed-subset DMREDA host memory evidence."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import subprocess
import tempfile
from typing import Any, Sequence


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
CORE_SOURCE = REPOSITORY_ROOT / "gold_line/core/dmreda_streaming_fixed.c"
CORE_HEADER = REPOSITORY_ROOT / "gold_line/core/dmreda_streaming_fixed.h"
CLI_SOURCE = REPOSITORY_ROOT / "gold_line/support/dmreda_streaming_fixed_cli.c"
REPORTER_SOURCE = REPOSITORY_ROOT / "gold_line/support/dmreda_memory_report.c"
DEFAULT_FLAGS = ("-std=c99", "-O2", "-Wall", "-Wextra", "-Werror")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65_536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def checked(command: Sequence[str], *, cwd: Path = REPOSITORY_ROOT) -> str:
    return subprocess.run(
        list(command),
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
    ).stdout


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=path.parent,
            delete=False,
        ) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
            temporary = Path(handle.name)
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def parse_stack_usage(paths: Sequence[Path]) -> dict[str, dict[str, int | str]]:
    functions: dict[str, dict[str, int | str]] = {}
    for path in paths:
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            match = re.match(r"^.+?:\d+:(?P<name>[^\t]+)\t(?P<bytes>\d+)\t(?P<kind>.+)$", line)
            if match is None:
                continue
            functions[match.group("name")] = {
                "bytes": int(match.group("bytes")),
                "classification": match.group("kind"),
            }
    return dict(sorted(functions.items()))


def parse_macho_size(path: Path) -> dict[str, Any]:
    size_tool = shutil.which("size")
    if size_tool is None:
        return {"measurable": False, "reason": "size utility not found"}
    output = checked([size_tool, "-m", str(path)])
    sections: dict[str, int] = {}
    for line in output.splitlines():
        match = re.search(
            r"Section(?: \([^,]+,\s*)?\s*(?P<name>__[^):]+)\)?\s*:\s*(?P<size>\d+)",
            line,
        )
        if match is not None:
            sections[match.group("name")] = int(match.group("size"))
    return {
        "measurable": True,
        "format": "Mach-O size -m sections",
        "sections": dict(sorted(sections.items())),
        "text_bytes": sections.get("__text", 0),
        "data_bytes": sections.get("__data", 0),
        "bss_bytes": sections.get("__bss", 0),
        "const_bytes": sections.get("__const", 0)
        + sections.get("__literal8", 0)
        + sections.get("__literal16", 0),
    }


def parse_size(path: Path) -> dict[str, Any]:
    if platform.system() == "Darwin":
        return parse_macho_size(path)
    size_tool = shutil.which("size")
    if size_tool is None:
        return {"measurable": False, "reason": "size utility not found"}
    output = checked([size_tool, "-A", str(path)])
    sections: dict[str, int] = {}
    for line in output.splitlines():
        fields = line.split()
        if len(fields) >= 2 and fields[0].startswith(".") and fields[1].isdigit():
            sections[fields[0]] = int(fields[1])
    return {
        "measurable": True,
        "format": "size -A sections",
        "sections": dict(sorted(sections.items())),
        "text_bytes": sections.get(".text", 0),
        "data_bytes": sections.get(".data", 0),
        "bss_bytes": sections.get(".bss", 0),
        "const_bytes": sections.get(".rodata", 0),
    }


def git_metadata() -> dict[str, object]:
    try:
        commit = checked(["git", "rev-parse", "HEAD"]).strip()
        dirty = bool(checked(["git", "status", "--porcelain"]).strip())
        return {"commit": commit, "dirty": dirty}
    except (OSError, subprocess.CalledProcessError):
        return {"commit": None, "dirty": None}


def build_report(compiler: str, flags: Sequence[str]) -> dict[str, Any]:
    compiler_path = Path(shutil.which(compiler) or compiler).resolve()
    with tempfile.TemporaryDirectory(prefix="dmreda-memory-report-") as directory:
        build_dir = Path(directory)
        core_object = build_dir / "dmreda_streaming_fixed.o"
        cli_binary = build_dir / "dmreda_streaming_fixed_cli"
        reporter_binary = build_dir / "dmreda_memory_report"

        checked(
            [
                str(compiler_path),
                *flags,
                "-fstack-usage",
                "-c",
                str(CORE_SOURCE),
                "-o",
                str(core_object),
            ]
        )
        checked(
            [
                str(compiler_path),
                *flags,
                "-fstack-usage",
                str(CORE_SOURCE),
                str(CLI_SOURCE),
                "-lm",
                "-o",
                str(cli_binary),
            ]
        )
        checked(
            [
                str(compiler_path),
                *flags,
                str(CORE_SOURCE),
                str(REPORTER_SOURCE),
                "-lm",
                "-o",
                str(reporter_binary),
            ]
        )
        structure_sizes = json.loads(checked([str(reporter_binary)]))
        stack_usage = parse_stack_usage(sorted(build_dir.glob("*.su")))
        core_sections = parse_size(core_object)
        cli_sections = parse_size(cli_binary)

    architecture = platform.machine()
    persistent_state = int(structure_sizes["sizeof_dmreda_fixed_state"])
    if architecture == "arm64" and persistent_state == 984:
        allowed_claim = (
            "The verified persistent runtime state structure occupies 984 bytes "
            "on the tested arm64 ABI."
        )
    else:
        allowed_claim = (
            f"The verified persistent runtime state structure occupies "
            f"{persistent_state} bytes on the tested {architecture} ABI."
        )

    return {
        "schema_version": 1,
        "measurement_time_utc": datetime.now(timezone.utc).isoformat(),
        "host": {
            "operating_system": platform.platform(),
            "architecture": architecture,
            "python": platform.python_version(),
        },
        "compiler": {
            "path": str(compiler_path),
            "version": checked([str(compiler_path), "--version"]).splitlines()[0],
            "target": checked([str(compiler_path), "-dumpmachine"]).strip(),
            "flags": list(flags),
        },
        "source": {
            "git": git_metadata(),
            "sha256": {
                str(path.relative_to(REPOSITORY_ROOT)): sha256_file(path)
                for path in (CORE_SOURCE, CORE_HEADER, CLI_SOURCE, REPORTER_SOURCE)
            },
        },
        "structures_and_known_scratch": structure_sizes,
        "compiler_static_stack_usage": stack_usage,
        "core_object_sections": core_sections,
        "linked_cli_sections": cli_sections,
        "allowed_claim": allowed_claim,
        "interpretation_limits": [
            "ABI alignment and compiler choices can change structure sizes.",
            "sizeof(DmredaFixedState) is persistent state, not total runtime RAM.",
            "Local stack, caller-owned input/output buffers, C runtime, and link-time overhead are not included in sizeof(state).",
            "The sorted[DMREDA_FIXED_MAX_W1] median array is known local scratch; compiler stack-usage values are build-specific static estimates.",
            "MCU peak stack, WCET, energy, interrupt interaction, and target linker sections remain unmeasured.",
        ],
    }


def markdown_report(report: dict[str, Any]) -> str:
    structures = report["structures_and_known_scratch"]
    stack = report["compiler_static_stack_usage"]
    core = report["core_object_sections"]
    linked = report["linked_cli_sections"]
    lines = [
        "# DMREDA fixed-subset host memory report",
        "",
        f"Measured: `{report['measurement_time_utc']}`",
        "",
        f"Compiler: `{report['compiler']['version']}`",
        f"Target: `{report['compiler']['target']}`",
        f"Flags: `{' '.join(report['compiler']['flags'])}`",
        "",
        "## Structures and scratch",
        "",
        f"- `sizeof(DmredaFixedConfig)`: {structures['sizeof_dmreda_fixed_config']} bytes",
        f"- `sizeof(DmredaFixedState)`: {structures['sizeof_dmreda_fixed_state']} bytes",
        f"- `sizeof(DmredaFixedOutput)`: {structures['sizeof_dmreda_fixed_output']} bytes",
        f"- known median `sorted[]` scratch: {structures['known_local_scratch_arrays']['trailing_median_sorted_bytes']} bytes",
        "",
        "## Static stack estimates",
        "",
    ]
    for function, details in stack.items():
        lines.append(
            f"- `{function}`: {details['bytes']} bytes ({details['classification']})"
        )
    lines.extend(
        [
            "",
            "## Binary sections",
            "",
            f"- core object `.text`/`__text`: {core.get('text_bytes')} bytes",
            f"- core object `.data`/`__data`: {core.get('data_bytes')} bytes",
            f"- core object `.bss`/`__bss`: {core.get('bss_bytes')} bytes",
            f"- linked CLI `.text`/`__text`: {linked.get('text_bytes')} bytes",
            f"- linked CLI `.data`/`__data`: {linked.get('data_bytes')} bytes",
            f"- linked CLI `.bss`/`__bss`: {linked.get('bss_bytes')} bytes",
            "",
            "## Claim boundary",
            "",
            report["allowed_claim"],
            "",
        ]
    )
    lines.extend(f"- {item}" for item in report["interpretation_limits"])
    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cc", default=os.environ.get("CC", "clang"))
    parser.add_argument(
        "--cflags",
        default=" ".join(DEFAULT_FLAGS),
        help="shell-like compiler flag string (no shell is invoked)",
    )
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-markdown", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    flags = tuple(shlex.split(args.cflags))
    report = build_report(args.cc, flags)
    serialized = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output_json is not None:
        atomic_write(args.output_json, serialized)
    if args.output_markdown is not None:
        atomic_write(args.output_markdown, markdown_report(report))
    if args.output_json is None and args.output_markdown is None:
        print(serialized, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
