from __future__ import annotations

import ctypes
import json
import math
from pathlib import Path
import subprocess
import tempfile
import unittest

import numpy as np

from current_claim.core.dmreda_minimal_streaming import (
    CONFIGURATION_SHA256,
    MAX_ABS_INPUT,
    MinimalStreamingDetector,
)
from experimental.finalization.run_development_ablation import (
    compute_representation,
    consecutive_run_grid,
    fixed_profiles,
)
from tests.golden_support import generate_signal, load_golden_set


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
C_SOURCE = REPOSITORY_ROOT / "current_claim/core/dmreda_minimal_streaming.c"


class CState(ctypes.Structure):
    _fields_ = [
        ("x_ring", ctypes.c_double * 7),
        ("e_ring", ctypes.c_double * 16),
        ("e_sum", ctypes.c_double),
        ("e_baseline", ctypes.c_double),
        ("sample_index", ctypes.c_uint64),
        ("x_count", ctypes.c_uint32),
        ("x_position", ctypes.c_uint32),
        ("e_count", ctypes.c_uint32),
        ("e_position", ctypes.c_uint32),
        ("consecutive_count", ctypes.c_uint32),
        ("refractory_remaining", ctypes.c_uint32),
    ]


class COutput(ctypes.Structure):
    _fields_ = [
        ("sample_index", ctypes.c_uint64),
        ("median", ctypes.c_double),
        ("residual", ctypes.c_double),
        ("residual_sum", ctypes.c_double),
        ("energy_baseline", ctypes.c_double),
        ("normalized_deviation", ctypes.c_double),
        ("authority_enabled", ctypes.c_uint32),
        ("consecutive_count", ctypes.c_uint32),
        ("refractory_remaining", ctypes.c_uint32),
        ("confirmed", ctypes.c_uint32),
    ]


class CCheckpoint(ctypes.Structure):
    _fields_ = [
        ("magic", ctypes.c_uint32),
        ("version", ctypes.c_uint32),
        ("state", CState),
    ]


def python_outputs(signal: np.ndarray):
    detector = MinimalStreamingDetector()
    return [detector.step(float(sample)) for sample in signal]


class MinimalStreamingFinalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temporary_directory = tempfile.TemporaryDirectory()
        library_path = Path(cls.temporary_directory.name) / "libdmreda_minimal.dylib"
        subprocess.run(
            [
                "clang",
                "-std=c99",
                "-pedantic-errors",
                "-Wall",
                "-Wextra",
                "-Werror",
                "-fPIC",
                "-shared",
                str(C_SOURCE),
                "-o",
                str(library_path),
                "-lm",
            ],
            check=True,
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
        )
        cls.library = ctypes.CDLL(str(library_path))
        cls.library.dmreda_minimal_reset.argtypes = [ctypes.POINTER(CState)]
        cls.library.dmreda_minimal_reset.restype = None
        cls.library.dmreda_minimal_step.argtypes = [
            ctypes.POINTER(CState),
            ctypes.c_double,
            ctypes.POINTER(COutput),
        ]
        cls.library.dmreda_minimal_step.restype = ctypes.c_int
        cls.library.dmreda_minimal_export_checkpoint.argtypes = [
            ctypes.POINTER(CState),
            ctypes.POINTER(CCheckpoint),
        ]
        cls.library.dmreda_minimal_export_checkpoint.restype = ctypes.c_int
        cls.library.dmreda_minimal_import_checkpoint.argtypes = [
            ctypes.POINTER(CState),
            ctypes.POINTER(CCheckpoint),
        ]
        cls.library.dmreda_minimal_import_checkpoint.restype = ctypes.c_int
        cls.library.dmreda_minimal_state_size.argtypes = []
        cls.library.dmreda_minimal_state_size.restype = ctypes.c_uint64
        cls.library.dmreda_minimal_checkpoint_size.argtypes = []
        cls.library.dmreda_minimal_checkpoint_size.restype = ctypes.c_uint64
        cls.library.dmreda_minimal_configuration_sha256.argtypes = []
        cls.library.dmreda_minimal_configuration_sha256.restype = ctypes.c_char_p

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temporary_directory.cleanup()

    def c_outputs(self, signal: np.ndarray):
        state = CState()
        self.library.dmreda_minimal_reset(ctypes.byref(state))
        outputs = []
        for sample in signal:
            output = COutput()
            status = self.library.dmreda_minimal_step(
                ctypes.byref(state), float(sample), ctypes.byref(output)
            )
            self.assertEqual(status, 0)
            outputs.append(output)
        return outputs, state

    def assert_python_c_equal(self, signal: np.ndarray) -> None:
        python_rows = python_outputs(signal)
        c_rows, _ = self.c_outputs(signal)
        self.assertEqual(len(python_rows), len(c_rows))
        for python_row, c_row in zip(python_rows, c_rows):
            self.assertEqual(python_row.sample_index, c_row.sample_index)
            self.assertEqual(python_row.median, c_row.median)
            self.assertEqual(python_row.residual, c_row.residual)
            self.assertEqual(python_row.residual_sum, c_row.residual_sum)
            self.assertEqual(python_row.energy_baseline, c_row.energy_baseline)
            self.assertEqual(
                python_row.normalized_deviation, c_row.normalized_deviation
            )
            self.assertEqual(python_row.authority_enabled, bool(c_row.authority_enabled))
            self.assertEqual(python_row.consecutive_count, c_row.consecutive_count)
            self.assertEqual(
                python_row.refractory_remaining, c_row.refractory_remaining
            )
            self.assertEqual(python_row.confirmed, bool(c_row.confirmed))

    def test_configuration_hash_and_abi_sizes_are_bound(self) -> None:
        self.assertEqual(
            self.library.dmreda_minimal_configuration_sha256().decode("ascii"),
            CONFIGURATION_SHA256,
        )
        self.assertEqual(self.library.dmreda_minimal_state_size(), ctypes.sizeof(CState))
        self.assertEqual(
            self.library.dmreda_minimal_checkpoint_size(),
            ctypes.sizeof(CCheckpoint),
        )

    def test_python_c_exact_parity_on_historical_golden_inputs(self) -> None:
        golden = load_golden_set()
        for fixture in golden["fixtures"]:
            with self.subTest(fixture=fixture["fixture_name"]):
                signal = generate_signal(fixture["input"]["generator_definition"])
                self.assert_python_c_equal(signal)

    def test_python_c_exact_parity_on_random_and_boundary_inputs(self) -> None:
        rng = np.random.default_rng(20260814)
        signals = [
            np.zeros(256, dtype=np.float64),
            np.ones(256, dtype=np.float64),
            np.resize(np.array([-2.0, 0.0, 2.0]), 600),
            np.r_[np.zeros(100), np.ones(200) * 8.0, np.zeros(200)],
            rng.normal(0.0, 1.0, 2048),
            rng.uniform(-50.0, 50.0, 1024),
        ]
        for index, signal in enumerate(signals):
            with self.subTest(signal=index):
                self.assert_python_c_equal(np.asarray(signal, dtype=np.float64))

    def test_drained_residual_window_clamps_cancellation_to_zero(self) -> None:
        signal = np.array([0.0, 0.15, 0.3] + [0.3] * 40, dtype=np.float64)
        python_rows = python_outputs(signal)
        c_rows, _ = self.c_outputs(signal)
        self.assertEqual(python_rows[19].residual_sum, 0.0)
        self.assertEqual(c_rows[19].residual_sum, 0.0)
        self.assert_python_c_equal(signal)

    def test_streaming_candidate_matches_frozen_variant_H_first_authority(self) -> None:
        rng = np.random.default_rng(1337)
        for seed in range(40):
            signal = rng.normal(0.0, 0.2 + 0.03 * seed, 500)
            if seed % 3 == 0:
                signal[180:] += 1.0 + seed * 0.1
            trace = compute_representation(
                signal,
                profiles=fixed_profiles(),
                transitions={},
            )
            expected = int(
                consecutive_run_grid(trace, np.array([4.0], dtype=np.float64))[0]
            )
            observed_events = [
                row.sample_index for row in python_outputs(signal) if row.confirmed
            ]
            observed = observed_events[0] if observed_events else -1
            self.assertEqual(observed, expected)

    def test_python_checkpoint_and_reset_are_deterministic(self) -> None:
        rng = np.random.default_rng(77)
        signal = rng.normal(0.0, 1.0, 700)
        uninterrupted = python_outputs(signal)
        detector = MinimalStreamingDetector()
        for sample in signal[:237]:
            detector.step(float(sample))
        serialized = json.loads(json.dumps(detector.checkpoint(), allow_nan=False))
        resumed = MinimalStreamingDetector.from_checkpoint(serialized)
        resumed_tail = [resumed.step(float(sample)) for sample in signal[237:]]
        self.assertEqual(resumed_tail, uninterrupted[237:])
        resumed.reset()
        self.assertEqual(
            [resumed.step(float(sample)) for sample in signal],
            uninterrupted,
        )

    def test_invalid_python_input_does_not_mutate_state(self) -> None:
        detector = MinimalStreamingDetector()
        detector.step(1.0)
        before = detector.checkpoint()
        for invalid in (float("nan"), float("inf"), -float("inf"), MAX_ABS_INPUT * 2.0):
            with self.subTest(invalid=invalid):
                with self.assertRaises(ValueError):
                    detector.step(invalid)
                self.assertEqual(detector.checkpoint(), before)

    def test_c_checkpoint_resume_and_invalid_input_are_atomic(self) -> None:
        rng = np.random.default_rng(99)
        signal = rng.normal(0.0, 1.0, 600)
        reference_rows, _ = self.c_outputs(signal)
        state = CState()
        self.library.dmreda_minimal_reset(ctypes.byref(state))
        for sample in signal[:311]:
            output = COutput()
            self.assertEqual(
                self.library.dmreda_minimal_step(
                    ctypes.byref(state), float(sample), ctypes.byref(output)
                ),
                0,
            )
        checkpoint = CCheckpoint()
        self.assertEqual(
            self.library.dmreda_minimal_export_checkpoint(
                ctypes.byref(state), ctypes.byref(checkpoint)
            ),
            0,
        )
        resumed = CState()
        self.assertEqual(
            self.library.dmreda_minimal_import_checkpoint(
                ctypes.byref(resumed), ctypes.byref(checkpoint)
            ),
            0,
        )
        for expected, sample in zip(reference_rows[311:], signal[311:]):
            output = COutput()
            self.assertEqual(
                self.library.dmreda_minimal_step(
                    ctypes.byref(resumed), float(sample), ctypes.byref(output)
                ),
                0,
            )
            self.assertEqual(output.normalized_deviation, expected.normalized_deviation)
            self.assertEqual(output.confirmed, expected.confirmed)

        before = bytes(resumed)
        output = COutput()
        self.assertEqual(
            self.library.dmreda_minimal_step(
                ctypes.byref(resumed), float("nan"), ctypes.byref(output)
            ),
            -2,
        )
        self.assertEqual(bytes(resumed), before)
        checkpoint.magic = 0
        other = CState()
        self.assertEqual(
            self.library.dmreda_minimal_import_checkpoint(
                ctypes.byref(other), ctypes.byref(checkpoint)
            ),
            -4,
        )

    def test_locked_gate_is_blocked_and_fault_holdout_remains_sealed(self) -> None:
        gate = json.loads(
            (
                REPOSITORY_ROOT
                / "current_claim/evidence/locked_gate_status.json"
            ).read_text(encoding="utf-8")
        )
        self.assertEqual(gate["status"], "BLOCKED_FRESH_NORMAL_REQUIRED")
        self.assertFalse(gate["phase_8_executed"])
        self.assertFalse(gate["phase_9_permitted"])
        self.assertFalse(gate["faulty_testing"]["opened_in_finalization"])
        rule = gate["required_fresh_normal_bank"]["admission_rule"]
        self.assertEqual(rule["equivalent_maximum_authority_count"], 38)
        probability = 0.05
        cdf_38 = sum(
            math.comb(1000, count)
            * probability**count
            * (1.0 - probability) ** (1000 - count)
            for count in range(39)
        )
        cdf_39 = cdf_38 + (
            math.comb(1000, 39)
            * probability**39
            * (1.0 - probability) ** 961
        )
        self.assertLessEqual(cdf_38, 0.05)
        self.assertGreater(cdf_39, 0.05)

    def test_historical_forensics_remain_bound_to_the_negative_rows(self) -> None:
        report = json.loads(
            (
                REPOSITORY_ROOT
                / "current_claim/evidence/historical_negative_forensics.json"
            ).read_text(encoding="utf-8")
        )
        self.assertFalse(report["claim_grade"])
        self.assertFalse(report["faulty_testing_opened"])
        self.assertTrue(
            report["historical_binding"]["D_OR_G_replay_exact_event_indices_equal"]
        )
        self.assertEqual(
            report["channels"]["D_OR_G"]["trajectory_with_authority_count"],
            42,
        )
        self.assertEqual(
            report["first_confirmation_mechanism"]["opening_branch_counts"],
            {
                "D_AND_G": 12,
                "D_ONLY": 3,
                "G_ONLY": 27,
                "UNRESOLVED_PUBLIC_PENDING_SEGMENT": 0,
            },
        )


if __name__ == "__main__":
    unittest.main()
