from __future__ import annotations

import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    EventGateConfig,
    calibrate_baseline_suite_to_run_risk,
    calibrate_threshold_to_run_risk,
    finite_horizon_alarm_statistics,
    signal_bank_hash,
)


class ExactRunRiskThresholdTests(unittest.TestCase):
    def test_frozen_stage3_target_is_represented_by_exact_integer_sum(self) -> None:
        score_runs = [np.zeros(500, dtype=np.float64) for _ in range(100)]
        expected_alarm_indices = (200, 290, 293)
        for run, alarm_index in zip(score_runs[-3:], expected_alarm_indices):
            run[alarm_index - 19 : alarm_index + 1] = 2.0

        result = calibrate_threshold_to_run_risk(
            score_runs,
            gate=EventGateConfig(92, 20, 80),
            target_false_positive_count=3,
            target_restricted_time_sum=49_283,
        )
        self.assertEqual(result.threshold, 0.0)
        self.assertEqual(result.achieved_false_positive_count, 3)
        self.assertEqual(result.achieved_restricted_time_sum, 49_283)
        self.assertEqual(result.target_restricted_mean_time_to_alarm, 492.83)
        self.assertEqual(
            tuple(
                alarm
                for alarm in result.achieved_statistics.first_confirmed_alarm_times
                if alarm is not None
            ),
            expected_alarm_indices,
        )

    def test_strict_equality_and_candidate_extremes_cover_alarm_and_censoring(
        self,
    ) -> None:
        score_runs = [np.full(4, 2.0), np.full(4, 2.0)]
        gate = EventGateConfig(warmup_samples=0, persistence=2, refractory=0)

        all_alarm = calibrate_threshold_to_run_risk(
            score_runs,
            gate=gate,
            target_false_positive_count=2,
            target_restricted_time_sum=2,
        )
        self.assertEqual(all_alarm.candidate_count, 2)
        self.assertEqual(all_alarm.selected_candidate_index, 0)
        self.assertEqual(all_alarm.threshold, np.nextafter(2.0, -np.inf))
        self.assertEqual(all_alarm.achieved_false_positive_count, 2)
        self.assertEqual(
            all_alarm.achieved_statistics.first_confirmed_alarm_times,
            (1, 1),
        )

        all_censored = calibrate_threshold_to_run_risk(
            score_runs,
            gate=gate,
            target_false_positive_count=0,
            target_restricted_time_sum=8,
        )
        self.assertEqual(all_censored.selected_candidate_index, 1)
        self.assertEqual(all_censored.threshold, 2.0)
        self.assertEqual(all_censored.achieved_false_positive_count, 0)
        self.assertEqual(
            all_censored.achieved_statistics.first_confirmed_alarm_times,
            (None, None),
        )
        equality_replay = finite_horizon_alarm_statistics(score_runs, 2.0, gate)
        self.assertEqual(equality_replay.observed_alarm_count, 0)

    def test_false_positive_count_is_the_primary_objective(self) -> None:
        score_runs = [
            np.array([1.0, 0.0, 0.0, 0.0]),
            np.array([2.0, 0.0, 0.0, 0.0]),
        ]
        result = calibrate_threshold_to_run_risk(
            score_runs,
            gate=EventGateConfig(0, 1, 0),
            target_false_positive_count=1,
            target_restricted_time_sum=0,
        )
        self.assertEqual(result.threshold, 1.0)
        self.assertEqual(result.achieved_false_positive_count, 1)
        self.assertEqual(result.achieved_restricted_time_sum, 4)
        self.assertEqual(result.selection_objective[:2], (0, 4))

    def test_restricted_time_sum_is_the_secondary_objective(self) -> None:
        score_runs = [
            np.array([0.0, 2.0, 0.0, 0.0]),
            np.array([0.0, 2.0, 0.0, 0.0]),
        ]
        result = calibrate_threshold_to_run_risk(
            score_runs,
            gate=EventGateConfig(0, 1, 0),
            target_false_positive_count=1,
            target_restricted_time_sum=2,
        )
        self.assertEqual(result.threshold, 0.0)
        self.assertEqual(result.achieved_false_positive_count, 2)
        self.assertEqual(result.achieved_restricted_time_sum, 2)
        self.assertEqual(result.selection_objective[:2], (1, 0))

    def test_higher_threshold_is_the_tertiary_objective(self) -> None:
        result = calibrate_threshold_to_run_risk(
            [np.array([3.0, 1.0, 2.0])],
            gate=EventGateConfig(0, 1, 0),
            target_false_positive_count=1,
            target_restricted_time_sum=0,
        )
        self.assertEqual(result.candidate_count, 4)
        self.assertEqual(result.selected_candidate_index, 2)
        self.assertEqual(result.threshold, 2.0)
        self.assertEqual(result.selection_objective, (0, 0, -2.0))
        self.assertEqual(
            result.tie_break_path,
            (
                "absolute_false_positive_count_deviation",
                "absolute_restricted_time_sum_deviation",
                "higher_threshold",
            ),
        )


class FixedPostAffineBaselineSuiteTests(unittest.TestCase):
    def setUp(self) -> None:
        self.bank = [
            np.linspace(-0.25, 0.50, 40, dtype=np.float64),
            np.concatenate((np.zeros(20), np.full(20, 1.25))),
            np.array([(-1.0) ** index * 0.75 for index in range(40)]),
        ]
        self.gate = EventGateConfig(
            warmup_samples=2,
            persistence=2,
            refractory=3,
        )

    def _calibrate(self):
        return calibrate_baseline_suite_to_run_risk(
            self.bank,
            gate=self.gate,
            target_false_positive_count=1,
            target_restricted_time_sum=80,
        )

    def test_bank_configuration_and_score_hashes_are_deterministic(self) -> None:
        first = self._calibrate()
        second = self._calibrate()
        self.assertEqual(set(first), {"rms", "cusum", "ewma"})
        expected_bank_hash = signal_bank_hash(self.bank)

        for name in first:
            left = first[name]
            right = second[name]
            self.assertEqual(left.calibration_bank_hash, expected_bank_hash)
            self.assertEqual(left.calibration_bank_hash, right.calibration_bank_hash)
            self.assertEqual(left.configuration_hash, right.configuration_hash)
            self.assertEqual(left.score_definition_hash, right.score_definition_hash)
            self.assertEqual(
                left.calibration.candidate_set_sha256,
                right.calibration.candidate_set_sha256,
            )
            self.assertEqual(
                left.calibration.score_trace_bank_sha256,
                right.calibration.score_trace_bank_sha256,
            )
            self.assertEqual(
                left.calibration.calibration_result_sha256,
                right.calibration.calibration_result_sha256,
            )
            self.assertEqual(len(left.configuration_hash), 64)
            self.assertEqual(len(left.score_definition_hash), 64)

    def test_only_threshold_is_fitted_after_the_common_affine_transform(self) -> None:
        suite = self._calibrate()
        self.assertEqual(dict(suite["rms"].frozen_parameters), {"window": 32})
        self.assertEqual(
            dict(suite["cusum"].frozen_parameters),
            {
                "allowance": 0.5,
                "allowance_sigma": 0.5,
                "center": 0.0,
                "scale": 1.0,
            },
        )
        self.assertEqual(
            dict(suite["ewma"].frozen_parameters),
            {
                "alpha": 2.0 / 33.0,
                "center": 0.0,
                "scale": 1.0,
            },
        )

    def test_selected_threshold_replays_through_the_existing_gate(self) -> None:
        suite = self._calibrate()
        for baseline in suite.values():
            score_runs = [baseline.score(run) for run in self.bank]
            replay = finite_horizon_alarm_statistics(
                score_runs,
                baseline.threshold,
                baseline.gate,
            )
            self.assertEqual(
                replay.first_confirmed_alarm_times,
                baseline.calibration.achieved_statistics.first_confirmed_alarm_times,
            )
            self.assertEqual(
                replay.observed_alarm_count,
                baseline.calibration.achieved_false_positive_count,
            )
            self.assertEqual(
                sum(replay.restricted_times_to_alarm),
                baseline.calibration.achieved_restricted_time_sum,
            )
            self.assertEqual(
                baseline.event_contract.threshold_comparison,
                "score > threshold",
            )


if __name__ == "__main__":
    unittest.main()
