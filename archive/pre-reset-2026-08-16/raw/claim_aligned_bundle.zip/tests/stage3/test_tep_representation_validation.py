from __future__ import annotations

import unittest

from stage3.admission.serialization import canonical_sha256
from stage3.tep.representation_validation import (
    FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
    FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256,
    REPRESENTATION_EXPECTATIONS_V1,
    build_representation_fixtures,
    render_representation_report,
    representation_fixture_contract,
    run_representation_validation,
)


class TepRepresentationValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result = run_representation_validation()

    def test_required_signal_families_are_present(self) -> None:
        fixtures = build_representation_fixtures()
        names = {fixture.name for fixture in fixtures}
        required = {
            "impulse",
            "short_burst",
            "finite_step",
            "persistent_step",
            "ramp",
            "slow_drift",
            "oscillation",
            "alternating",
            "repeated_intermittent",
            "normal_noise",
            "prefix_pair_step_suffix",
            "prefix_pair_ramp_suffix",
        }
        self.assertTrue(required.issubset(names))
        self.assertEqual(sum(family.family == "same_energy" for family in fixtures), 3)
        self.assertEqual(sum(family.family == "equal_peak" for family in fixtures), 3)

    def test_hard_contracts_pass(self) -> None:
        self.assertEqual(self.result["status"], "passed")
        self.assertTrue(all(self.result["hard_contract_checks"].values()))

    def test_expectations_are_frozen_before_results(self) -> None:
        self.assertEqual(
            self.result["expectations_sha256"],
            FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
        )
        self.assertEqual(
            canonical_sha256(REPRESENTATION_EXPECTATIONS_V1),
            FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
        )
        self.assertEqual(
            canonical_sha256(representation_fixture_contract()),
            FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256,
        )
        self.assertEqual(
            REPRESENTATION_EXPECTATIONS_V1["forbidden_success_definition"],
            "every signal has a unique fingerprint",
        )

    def test_same_energy_inputs_have_equal_energy_without_forced_separation(self) -> None:
        rows = {
            row["fixture_name"]: row
            for row in self.result["fixture_rows"]
            if row["family"] == "same_energy"
        }
        self.assertEqual(len(rows), 3)
        for row in rows.values():
            self.assertAlmostEqual(row["squared_energy"], 8.0, places=12)
        matrix = self.result["same_energy_separation_matrix"]
        self.assertEqual(set(matrix), set(rows))
        for name in rows:
            self.assertEqual(matrix[name][name], 0.0)

    def test_equal_peak_inputs_have_equal_peaks(self) -> None:
        rows = [row for row in self.result["fixture_rows"] if row["family"] == "equal_peak"]
        self.assertEqual(len(rows), 3)
        self.assertEqual({row["peak_absolute_input"] for row in rows}, {2.0})

    def test_constant_reference_and_trace_distance_contract(self) -> None:
        self.assertTrue(
            self.result["hard_contract_checks"]["constant_zero_reference_behavior"]
        )
        self.assertEqual(
            self.result["pairwise_fingerprint_distance_definition"],
            "sqrt(mean(((D_i-D_j)/10)^2 + ((G_i-G_j)/20)^2))",
        )

    def test_result_hash_and_report_are_deterministic(self) -> None:
        repeated = run_representation_validation()
        self.assertEqual(self.result, repeated)
        self.assertEqual(self.result["result_sha256"], repeated["result_sha256"])
        report = render_representation_report(self.result)
        self.assertIn("characterization", report.lower())
        self.assertIn(self.result["result_sha256"], report)


if __name__ == "__main__":
    unittest.main()
