"""Stage 3 blocked-gate contract tests.

Repository-wide ``unittest`` discovery imports this directory as the top-level
``stage3`` package. Extend that package path to the implementation namespace so
``stage3.admission`` resolves identically in focused and full-suite runs.
"""

from pathlib import Path


_IMPLEMENTATION_PACKAGE = Path(__file__).resolve().parents[2] / "stage3"
if str(_IMPLEMENTATION_PACKAGE) not in __path__:
    __path__.append(str(_IMPLEMENTATION_PACKAGE))
