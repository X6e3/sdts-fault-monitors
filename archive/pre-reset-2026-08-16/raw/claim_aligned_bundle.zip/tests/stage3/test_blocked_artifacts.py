from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import unittest


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
STAGE3_ROOT = REPOSITORY_ROOT / "stage3"


def _reject_nonfinite(value: str) -> None:
    raise ValueError(f"non-finite JSON token: {value}")


def _load_strict_json(relative_path: str) -> dict[str, object]:
    path = REPOSITORY_ROOT / relative_path
    payload = json.loads(
        path.read_text(encoding="utf-8"), parse_constant=_reject_nonfinite
    )
    if not isinstance(payload, dict):
        raise TypeError(f"expected an object in {relative_path}")
    return payload


def _sha256(relative_path: str) -> str:
    return hashlib.sha256((REPOSITORY_ROOT / relative_path).read_bytes()).hexdigest()


class BlockedStage3ArtifactTests(unittest.TestCase):
    def test_all_stage3_json_is_strict_and_versioned(self) -> None:
        paths = sorted(STAGE3_ROOT.rglob("*.json")) + sorted(
            (REPOSITORY_ROOT / "repro" / "stage3").rglob("*.json")
        )
        self.assertGreaterEqual(len(paths), 10)
        for path in paths:
            with self.subTest(path=path.relative_to(REPOSITORY_ROOT)):
                payload = json.loads(
                    path.read_text(encoding="utf-8"),
                    parse_constant=_reject_nonfinite,
                )
                self.assertEqual(payload["schema_version"], "1.0.0")

    def test_authority_failure_keeps_every_bank_sealed(self) -> None:
        provenance = _load_strict_json(
            "stage3/datasets/dataset-provenance.json"
        )
        self.assertEqual(provenance["status"], "blocked")
        self.assertFalse(provenance["authority_gate"]["passed"])
        self.assertEqual(
            provenance["authority_gate"]["authentic_file_candidate_count"], 1
        )
        self.assertEqual(
            provenance["authority_gate"]["full_gate_passing_candidate_count"], 0
        )
        self.assertIsNone(provenance["selected_dataset"])

        split = _load_strict_json("stage3/datasets/split-manifest.json")
        self.assertFalse(split["authority_gate_passed"])
        for bank_name in ("A", "B", "C", "D"):
            bank = split["banks"][bank_name]
            self.assertFalse(bank["opened"])
            self.assertEqual(bank["member_count"], 0)
            self.assertEqual(bank["members"], [])
            self.assertIsNone(bank["bank_hash"])
        self.assertFalse(split["evaluation_bank_opened"])
        self.assertFalse(split["detector_results_generated"])

    def test_x63r_discovery_does_not_open_the_scientific_gate(self) -> None:
        discovery = _load_strict_json(
            "stage3/datasets/x63r-discovery.json"
        )
        self.assertEqual(discovery["mount"]["volume_name"], "X63-R")
        self.assertEqual(discovery["mount"]["mount_path"], "/Volumes/X63-R")
        self.assertFalse(discovery["access_contract"]["external_disk_modified"])
        self.assertFalse(
            discovery["access_contract"]["external_disk_write_command_run"]
        )
        self.assertFalse(
            discovery["access_contract"]["archive_extracted_in_place"]
        )
        self.assertFalse(
            discovery["access_contract"]["detector_execution_on_candidates"]
        )
        self.assertEqual(discovery["access_contract"]["banks_opened"], [])
        self.assertFalse(discovery["central_resolution"]["authority_gate_passed"])
        self.assertTrue(
            discovery["central_resolution"]["authentic_dataset_file_available"]
        )
        self.assertFalse(
            discovery["central_resolution"][
                "authentic_full_stage3_dataset_available"
            ]
        )

        screening = discovery["authority_screening"]
        self.assertFalse(screening["x63r_skab_v090_valve1_0"]["full_gate_passed"])
        self.assertFalse(
            screening["x63r_nasa_ims_test2_bearing1_derived_rms"][
                "full_gate_passed"
            ]
        )
        self.assertFalse(screening["x63r_pqd16c_dummy_cache"]["full_gate_passed"])

        copies = discovery["isolated_audit_copies"]
        self.assertFalse(copies["committed_to_git"])
        self.assertEqual(len(copies["files"]), 8)
        self.assertTrue(all(item["byte_equal"] for item in copies["files"]))

    def test_protocol_and_configurations_are_explicitly_unfrozen(self) -> None:
        configuration = _load_strict_json(
            "stage3/protocol/detector-configurations.json"
        )
        self.assertEqual(configuration["configuration_status"], "not_frozen")
        self.assertIsNone(configuration["protocol_freeze_commit"])
        self.assertIsNone(configuration["scientific_configuration_hash"])
        self.assertIsNone(configuration["threshold_grid"])
        self.assertIsNone(configuration["operating_risk_targets"])
        self.assertFalse(configuration["bank_c_opened"])
        self.assertFalse(configuration["bank_d_opened"])

        seeds = _load_strict_json("stage3/protocol/seed-manifest.json")
        self.assertEqual(seeds["status"], "not_frozen")
        self.assertEqual(seeds["scientific_seed_schedule"], [])
        self.assertIsNone(seeds["bootstrap_seed"])
        self.assertIsNone(seeds["split_seed"])

    def test_blocked_outputs_contain_no_synthetic_performance_credit(self) -> None:
        status = _load_strict_json("stage3/outputs/execution-status.json")
        self.assertEqual(status["status"], "blocked")
        self.assertFalse(status["scientific_results_generated"])
        self.assertFalse(status["bank_d_opened"])
        self.assertEqual(status["execution_counts"]["detector_rankings"], 0)

        risk = _load_strict_json("stage3/outputs/operating-risk-results.json")
        self.assertEqual(risk["status"], "not_run")
        self.assertFalse(risk["bank_c_opened"])
        self.assertEqual(risk["risk_match_verdict"], "not_assessed")
        self.assertFalse(risk["primary_comparison_authorized"])
        for detector in risk["detectors"].values():
            self.assertIsNone(detector["threshold"])
            self.assertIsNone(detector["censoring_rate"])
            self.assertIsNone(detector["achieved_operating_value"])
            self.assertIsNone(detector["target_deviation"])

        disturbed = _load_strict_json(
            "stage3/outputs/disturbed-evaluation-results.json"
        )
        self.assertEqual(disturbed["status"], "not_run")
        self.assertFalse(disturbed["bank_d_opened"])
        self.assertEqual(disturbed["outcomes"], [])
        self.assertEqual(disturbed["detector_rankings"], [])
        self.assertFalse(disturbed["scientific_validation"])

        with (STAGE3_ROOT / "outputs" / "per-run-outcomes.csv").open(
            encoding="utf-8", newline=""
        ) as handle:
            rows = list(csv.reader(handle))
        self.assertEqual(len(rows), 1)
        self.assertIn("outcome", rows[0])
        self.assertIn("delay_samples", rows[0])

    def test_blocked_artifact_hash_bindings_match_bytes(self) -> None:
        status = _load_strict_json("stage3/outputs/execution-status.json")
        bindings = status["blocked_artifact_bindings"]
        expected = {
            "draft_protocol_sha256": "docs/stage3/DMREDA_STAGE3_PREREGISTRATION.md",
            "dataset_provenance_file_sha256": "stage3/datasets/dataset-provenance.json",
            "x63r_discovery_file_sha256": "stage3/datasets/x63r-discovery.json",
            "empty_split_manifest_file_sha256": "stage3/datasets/split-manifest.json",
            "unfrozen_configuration_file_sha256": "stage3/protocol/detector-configurations.json",
            "unfrozen_seed_manifest_file_sha256": "stage3/protocol/seed-manifest.json",
        }
        for field, relative_path in expected.items():
            with self.subTest(field=field):
                self.assertEqual(bindings[field], _sha256(relative_path))
        self.assertEqual(
            status["environment_hash"], _sha256("repro/stage3/requirements.lock")
        )

    def test_stage3_artifacts_contain_no_absolute_user_paths(self) -> None:
        roots = (
            REPOSITORY_ROOT / "docs" / "stage3",
            REPOSITORY_ROOT / "stage3",
            REPOSITORY_ROOT / "repro" / "stage3",
        )
        forbidden = ("/Users/", "/home/", "file://")
        for root in roots:
            for path in sorted(item for item in root.rglob("*") if item.is_file()):
                with self.subTest(path=path.relative_to(REPOSITORY_ROOT)):
                    text = path.read_text(encoding="utf-8")
                    self.assertFalse(
                        any(value in text for value in forbidden),
                        f"machine-specific path found in {path}",
                    )

    def test_stage3_checksum_manifest_matches_tracked_artifacts(self) -> None:
        manifest = REPOSITORY_ROOT / "repro" / "stage3" / "SHA256SUMS"
        entries: dict[str, str] = {}
        for line in manifest.read_text(encoding="ascii").splitlines():
            digest, relative_path = line.split("  ", maxsplit=1)
            self.assertNotIn(relative_path, entries)
            self.assertFalse(Path(relative_path).is_absolute())
            self.assertNotIn("..", Path(relative_path).parts)
            entries[relative_path] = digest
        self.assertEqual(len(entries), 18)
        for relative_path, expected_digest in entries.items():
            with self.subTest(relative_path=relative_path):
                self.assertEqual(_sha256(relative_path), expected_digest)


if __name__ == "__main__":
    unittest.main()
