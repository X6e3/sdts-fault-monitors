from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from stage3.admission.serialization import canonical_sha256, load_strict_json
from stage3.tep.campaign import (
    CampaignPaths,
    SOURCE_FILES,
    _assert_bank_d_unopened,
    _assert_fault_free_testing_open_is_not_reconstructed,
    _assert_testing_unopened_before_freeze,
    _blocked_artifact_allowlist,
    _enforce_worker_memory_limit,
    _final_artifact_allowlist,
    _validate_artifact_allowlist,
    classify_final_evidence,
    detectors_from_protocol,
    ensure_output_layout,
    evaluate_boundary_coequal_reference_evidence,
    finalize_campaign_state,
    publish_json,
    run_ablations,
    run_bank_d_primary,
    run_full_campaign,
    run_normal_gate,
    run_prefreeze,
    run_reproduction,
    update_progress_ledger,
)
from tests.stage3.test_tep_protocol import build_v2


class CampaignContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.repository = self.root / "repository"
        self.dataset = self.root / "dataset"
        self.output = self.root / "output"
        self.recovery = self.root / "recovery"
        for path in (self.repository, self.dataset, self.output, self.recovery):
            path.mkdir()
        (self.repository / ".git").mkdir()
        self.paths = CampaignPaths(
            self.repository, self.dataset, self.output, self.recovery
        )
        ensure_output_layout(self.paths)

    def test_paths_and_publication_are_external_immutable_and_resumable(self) -> None:
        first = {"schema_version": "1.0.0", "status": "passed"}
        digest = publish_json(self.paths, "logs/example.json", first)
        self.assertEqual(digest, publish_json(self.paths, "logs/example.json", first))
        self.assertEqual(load_strict_json(self.output / "logs/example.json"), first)
        with self.assertRaises(FileExistsError):
            publish_json(
                self.paths,
                "logs/example.json",
                {"schema_version": "1.0.0", "status": "changed"},
            )
        with self.assertRaises(PermissionError):
            CampaignPaths(
                self.repository, self.dataset, self.repository, self.recovery
            )
        with self.assertRaises(PermissionError):
            CampaignPaths(
                self.repository, self.dataset, self.output, self.dataset
            )

    def test_final_json_path_leak_is_rejected(self) -> None:
        payload = {
            "schema_version": "1.0.0",
            "path": "/" + "Users/example/private",
        }
        with self.assertRaisesRegex(ValueError, "machine-specific path"):
            publish_json(self.paths, "logs/private_path.json", payload)

        # The final packaging audit must still reject an artifact that bypassed
        # the safe publication path, so both preventive and detective controls
        # remain covered.
        destination = self.output / "logs/private_path.json"
        destination.write_text(
            json.dumps(payload, sort_keys=True) + "\n", encoding="utf-8"
        )
        with self.assertRaisesRegex(ValueError, "absolute user path"):
            _validate_artifact_allowlist(self.paths, ("logs/private_path.json",))

    def test_progress_ledger_is_atomic_self_hashed_and_append_only_logical(self) -> None:
        first_hash = update_progress_ledger(
            self.paths,
            phase="synthetic",
            status="started",
            source_commit="a" * 40,
        )
        second_hash = update_progress_ledger(
            self.paths,
            phase="synthetic",
            status="completed",
            source_commit="a" * 40,
            details={"result_sha256": "b" * 64},
        )
        self.assertNotEqual(first_hash, second_hash)
        ledger = load_strict_json(self.output / "logs/STAGE3_3_PROGRESS_LEDGER.json")
        without_hash = dict(ledger)
        stored = without_hash.pop("ledger_payload_sha256")
        self.assertEqual(stored, canonical_sha256(without_hash))
        self.assertEqual(ledger["event_count"], 2)
        self.assertEqual([item["sequence"] for item in ledger["events"]], [1, 2])

    def test_testing_and_bank_d_chronology_fail_closed(self) -> None:
        marker = self.output / "authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json"
        marker.write_text("{}\n", encoding="utf-8")
        with self.assertRaises(PermissionError):
            _assert_testing_unopened_before_freeze(self.paths)
        marker.unlink()
        bank_marker = self.output / "bank_d/primary/checkpoints/fault_01.checkpoint.json"
        bank_marker.write_text("{}\n", encoding="utf-8")
        with self.assertRaises(PermissionError):
            _assert_bank_d_unopened(self.paths)

    def test_missing_fault_free_marker_cannot_redeem_orphan_results(self) -> None:
        orphan = self.output / "normal_gate/dmreda_normal_summary.json"
        orphan.write_text("{}\n", encoding="utf-8")
        with self.assertRaisesRegex(PermissionError, "marker"):
            _assert_fault_free_testing_open_is_not_reconstructed(self.paths)

    def test_partial_protocol_triplet_is_not_treated_as_frozen(self) -> None:
        (self.output / "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json").write_text(
            "{}\n", encoding="utf-8"
        )
        with self.assertRaisesRegex(RuntimeError, "partial"):
            run_prefreeze(self.paths)

    def test_production_parity_cannot_be_claimed_with_one_worker(self) -> None:
        with self.assertRaisesRegex(ValueError, "2..8"):
            run_normal_gate(self.paths, workers=1)
        with self.assertRaisesRegex(ValueError, "2..8"):
            run_bank_d_primary(self.paths, workers=1)
        with self.assertRaisesRegex(ValueError, "2..8"):
            run_ablations(self.paths, workers=1)
        with self.assertRaisesRegex(ValueError, "2..8"):
            run_reproduction(self.paths, workers=1)

    def test_worker_memory_bound_is_durable_and_fail_closed(self) -> None:
        publish_json(
            self.paths,
            "environment/worker_memory_probe_stage3_3.json",
            {
                "schema_version": "1.0.0",
                "document_type": "dmreda.stage3_3.worker_memory_probe",
                "status": "measured",
                "source_commit": "a" * 40,
                "protocol_sha256": "b" * 64,
                "probe_workers": 1,
                "conservative_rss_bytes": 1,
                "host": {
                    "system": __import__("platform").system(),
                    "release": __import__("platform").release(),
                    "machine": __import__("platform").machine(),
                },
                "maximum_campaign_workers": 3,
            },
        )
        accepted = _enforce_worker_memory_limit(
            self.paths,
            source_commit="a" * 40,
            protocol_sha256="b" * 64,
            workers=3,
        )
        self.assertEqual(accepted["maximum_campaign_workers"], 3)
        with self.assertRaises(MemoryError):
            _enforce_worker_memory_limit(
                self.paths,
                source_commit="a" * 40,
                protocol_sha256="b" * 64,
                workers=4,
            )

    def test_frozen_detectors_reconstruct_exactly(self) -> None:
        protocol = build_v2()
        detectors = detectors_from_protocol(protocol)
        self.assertEqual(
            {item.name for item in detectors},
            {"dmreda_core_d_or_g", "rms", "cusum", "ewma"},
        )
        primary = next(item for item in detectors if item.name == "dmreda_core_d_or_g")
        self.assertEqual(primary.dmreda_mode, "D_OR_G")

    def test_evidence_category_has_no_unregistered_coverage_cutoff(self) -> None:
        common = {
            "layer_a_passed": True,
            "layer_b_passed": True,
            "normal_passed": True,
            "admitted_reference_count": 1,
            "boundary_coequal_holm_added_value_supported": False,
        }
        self.assertEqual(
            classify_final_evidence(
                **common,
                valid_authority_count_159=0,
                valid_authority_count_160=1,
            ),
            "conservative_but_low_coverage_assurance_channel",
        )
        self.assertEqual(
            classify_final_evidence(
                **common,
                valid_authority_count_159=1,
                valid_authority_count_160=1,
            ),
            "insufficient_evidence_for_added_value",
        )

    def test_added_value_requires_holm_support_under_both_boundaries(self) -> None:
        reference = "rms"
        pairwise: dict[str, object] = {}
        families: dict[str, object] = {}
        adjusted = {f"fault_{fault:02d}": 0.01 for fault in range(1, 21)}
        nonsignificant = {f"fault_{fault:02d}": 1.0 for fault in range(1, 21)}
        for onset in (159, 160):
            pairwise[f"onset_{onset}"] = {
                f"fault_{fault:02d}": {
                    reference: {
                        "non_fp_detection_discordance": {
                            "dmreda_detects_reference_misses": 2,
                            "reference_detects_dmreda_misses": 0,
                        },
                        "early_false_authority_discordance": {
                            "dmreda_only": 0,
                            "reference_only": 0,
                        },
                        "paired_valid_detection_delay": {
                            "mean_dmreda_minus_reference": 0.0,
                        },
                    }
                }
                for fault in range(1, 21)
            }
            for endpoint, values in (
                ("non_fp_authority", adjusted),
                ("early_false_authority", nonsignificant),
                ("paired_latency", nonsignificant),
            ):
                families[f"onset_{onset}/{reference}/{endpoint}"] = {
                    "holm_adjusted_p_values": dict(values)
                }
        statistical = {
            "holm_families": families,
            "coequal_non_fp_added_value_family": {
                "holm_adjusted_p_values": {
                    f"fault_{fault:02d}/{reference}": 0.01
                    for fault in range(1, 21)
                }
            },
        }
        self.assertEqual(
            evaluate_boundary_coequal_reference_evidence(
                pairwise,
                statistical,
                admitted_references=(reference,),
            ),
            (True, True),
        )
        for onset in (159, 160):
            for fault in range(1, 21):
                pairwise[f"onset_{onset}"][f"fault_{fault:02d}"][reference][
                    "early_false_authority_discordance"
                ]["dmreda_only"] = 1
        self.assertEqual(
            evaluate_boundary_coequal_reference_evidence(
                pairwise,
                statistical,
                admitted_references=(reference,),
            ),
            (False, True),
        )
        for onset in (159, 160):
            for fault in range(1, 21):
                pairwise[f"onset_{onset}"][f"fault_{fault:02d}"][reference][
                    "early_false_authority_discordance"
                ]["dmreda_only"] = 0
        families[f"onset_160/{reference}/non_fp_authority"] = {
            "holm_adjusted_p_values": dict(nonsignificant)
        }
        self.assertEqual(
            evaluate_boundary_coequal_reference_evidence(
                pairwise,
                statistical,
                admitted_references=(reference,),
            ),
            (False, False),
        )

    def test_source_and_final_allowlist_are_portable_and_unique(self) -> None:
        repository_root = Path(__file__).resolve().parents[2]
        self.assertTrue(all((repository_root / relative).is_file() for relative in SOURCE_FILES))
        allowlist = _final_artifact_allowlist()
        self.assertEqual(len(allowlist), len(set(allowlist)))
        blocked_allowlist = _blocked_artifact_allowlist()
        self.assertEqual(len(blocked_allowlist), len(set(blocked_allowlist)))
        source = (repository_root / "stage3/tep/campaign.py").read_text(encoding="utf-8")
        self.assertNotIn("/Users/x6e3", source)

    def test_cli_help_does_not_open_data_or_require_campaign_roots(self) -> None:
        repository_root = Path(__file__).resolve().parents[2]
        run = subprocess.run(
            [
                __import__("sys").executable,
                str(repository_root / "scripts/stage3/run_stage3_3_campaign.py"),
                "--help",
            ],
            cwd=repository_root,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("prefreeze", run.stdout)

    def test_full_campaign_packages_denied_gate_without_bank_d(self) -> None:
        denied = {"bank_d_decision": "denied"}
        with (
            patch("stage3.tep.campaign.run_prefreeze", return_value={"frozen": True}),
            patch("stage3.tep.campaign.require_clean_source", return_value="a" * 40),
            patch(
                "stage3.tep.campaign.run_normal_gate",
                return_value=({"status": "failed"}, denied),
            ),
            patch(
                "stage3.tep.campaign.finalize_stopped_campaign",
                return_value={"status": "stopped"},
            ) as finalize_stopped,
            patch("stage3.tep.campaign.run_bank_d_primary") as bank_d,
        ):
            result = run_full_campaign(self.paths, workers=2)
        self.assertEqual(result, {"status": "stopped"})
        finalize_stopped.assert_called_once_with(self.paths)
        bank_d.assert_not_called()

    def test_standalone_finalize_dispatches_from_verified_seal(self) -> None:
        with (
            patch("stage3.tep.campaign.require_clean_source", return_value="a" * 40),
            patch(
                "stage3.tep.campaign.validate_frozen_protocol_v2",
                return_value={"status": "frozen"},
            ),
            patch(
                "stage3.tep.campaign._load_verified_bank_d_seal",
                return_value=({"bank_d_decision": "denied"}, "b" * 64),
            ),
            patch(
                "stage3.tep.campaign.finalize_stopped_campaign",
                return_value={"status": "blocked_complete"},
            ) as blocked,
            patch("stage3.tep.campaign.finalize_campaign") as admitted,
        ):
            result = finalize_campaign_state(self.paths)
        self.assertEqual(result, {"status": "blocked_complete"})
        blocked.assert_called_once_with(self.paths)
        admitted.assert_not_called()

    def test_full_campaign_skips_completed_normal_gate_and_resumes_later_phases(self) -> None:
        (self.output / "protocol/BANK_D_ADMISSION_SEAL_V2.json").write_text(
            "{}\n", encoding="utf-8"
        )
        admitted = {"bank_d_decision": "admitted"}
        with (
            patch("stage3.tep.campaign.run_prefreeze", return_value={"frozen": True}),
            patch("stage3.tep.campaign.require_clean_source", return_value="a" * 40),
            patch(
                "stage3.tep.campaign._load_verified_bank_d_seal",
                return_value=(admitted, "b" * 64),
            ),
            patch("stage3.tep.campaign.run_normal_gate") as normal_gate,
            patch("stage3.tep.campaign.run_bank_d_primary") as bank_d,
            patch("stage3.tep.campaign.run_ablations") as ablations,
            patch("stage3.tep.campaign.run_reproduction") as reproduction,
            patch(
                "stage3.tep.campaign.finalize_campaign",
                return_value={"status": "complete"},
            ) as finalize,
        ):
            result = run_full_campaign(self.paths, workers=2)
        self.assertEqual(result, {"status": "complete"})
        normal_gate.assert_not_called()
        bank_d.assert_called_once_with(self.paths, workers=2)
        ablations.assert_called_once_with(self.paths, workers=2)
        reproduction.assert_called_once_with(self.paths, workers=2)
        finalize.assert_called_once_with(self.paths)


if __name__ == "__main__":
    unittest.main()
