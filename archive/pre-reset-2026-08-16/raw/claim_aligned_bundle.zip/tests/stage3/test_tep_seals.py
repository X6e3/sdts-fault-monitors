from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from stage3.admission.serialization import atomic_write_json
from stage3.tep.seals import (
    ArtifactReference,
    evaluate_bank_d_admission,
    open_bank_d_once,
    validate_bank_d_open_event,
    write_admission_record,
)


COMMIT = "a" * 40
IDENTITY = (
    "causal_deterministic_bounded_state_temporal_evidence_representation_and_arbitration_core"
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class TepBankSealTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        payloads = {
            "protocol": {
                "status": "frozen",
                "source_commit": COMMIT,
                "scientific_identity": {"primary": IDENTITY},
            },
            "normal_gate": {"dmreda": {"passed": True}},
            "baseline_admission": {
                "all_references_admitted": True,
                "scalar_evidence_references": {
                    name: {"admitted": True} for name in ("rms", "cusum", "ewma")
                },
            },
            "onset_mapping": {"status": "resolved", "python_onset_index": 159},
            "test_report": {"status": "passed"},
            "output_guard": {"status": "passed"},
            "dmreda_configuration": {"status": "frozen"},
            "baseline_configurations": {"status": "frozen"},
        }
        self.references = {}
        for name, payload in payloads.items():
            path = self.root / f"{name}.json"
            atomic_write_json(path, payload)
            self.references[name] = ArtifactReference(path, digest(path))

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_admission_is_derived_from_verified_artifacts(self) -> None:
        record = evaluate_bank_d_admission(
            self.references, source_commit=COMMIT, no_retuning_declared=True
        )
        self.assertEqual(record["status"], "admitted")
        self.assertEqual(record["reasons"], [])

    def test_failed_gate_or_missing_reference_denies_without_manual_override(self) -> None:
        path = self.references["normal_gate"].path
        atomic_write_json(path, {"dmreda": {"passed": False}})
        refs = dict(self.references)
        refs["normal_gate"] = ArtifactReference(path, digest(path))
        record = evaluate_bank_d_admission(
            refs, source_commit=COMMIT, no_retuning_declared=True
        )
        self.assertEqual(record["status"], "denied")
        self.assertIn("dmreda_normal_generalization_gate_failed", record["reasons"])

    def test_hash_mismatch_fails_before_scientific_decision(self) -> None:
        self.references["protocol"].path.write_text("{}\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            evaluate_bank_d_admission(
                self.references, source_commit=COMMIT, no_retuning_declared=True
            )

    def test_opening_is_one_time_hash_bound_and_tamper_evident(self) -> None:
        record = evaluate_bank_d_admission(
            self.references, source_commit=COMMIT, no_retuning_declared=True
        )
        admission_path = self.root / "admission.json"
        write_admission_record(admission_path, record)
        event_path = self.root / "opened.json"
        event = open_bank_d_once(
            admission_record_path=admission_path,
            admission_file_sha256=digest(admission_path),
            open_event_path=event_path,
            opened_at_utc="2026-08-05T12:00:00Z",
        )
        self.assertEqual(event["action"], "open_bank_d")
        validate_bank_d_open_event(event_path)
        with self.assertRaises(FileExistsError):
            open_bank_d_once(
                admission_record_path=admission_path,
                admission_file_sha256=digest(admission_path),
                open_event_path=event_path,
                opened_at_utc="2026-08-05T12:01:00Z",
            )
        changed = json.loads(event_path.read_text())
        changed["opened_at_utc"] = "2026-08-05T12:02:00Z"
        event_path.write_text(json.dumps(changed), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            validate_bank_d_open_event(event_path)


if __name__ == "__main__":
    unittest.main()
