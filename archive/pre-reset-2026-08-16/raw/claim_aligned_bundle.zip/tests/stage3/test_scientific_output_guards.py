from __future__ import annotations

import unittest

from gold_line.evaluation.alarm_metrics import (
    RunOutcome,
    classify_run_outcome,
    summarize_finite_horizon_alarms,
)
from stage3.admission.contracts import AdmissionLevel
from stage3.admission.guards import (
    authorize_detector_ranking,
    authorize_scientific_output,
    conditional_valid_detection_delays,
    validate_hash_bindings,
)


DIGEST = "d" * 64


class FirstEventAndDelayContractTests(unittest.TestCase):
    def test_early_false_positive_cannot_be_redeemed(self) -> None:
        outcome = classify_run_outcome(
            [20, 90], onset=50, trace_length=120, warmup_samples=0
        )
        self.assertEqual(outcome.outcome, "false_positive")
        self.assertFalse(outcome.detected)
        self.assertFalse(outcome.missed)
        self.assertIsNone(outcome.delay_samples)

    def test_false_positive_and_miss_have_no_valid_delay(self) -> None:
        false_positive = classify_run_outcome(
            [2], onset=5, trace_length=10, warmup_samples=0
        )
        missed = classify_run_outcome(
            [], onset=5, trace_length=10, warmup_samples=0
        )
        detected = classify_run_outcome(
            [8], onset=5, trace_length=10, warmup_samples=0
        )
        self.assertIsNone(false_positive.delay_samples)
        self.assertIsNone(missed.delay_samples)
        self.assertEqual(detected.delay_samples, 3)

    def test_conditional_delay_contains_valid_detections_only(self) -> None:
        outcomes = (
            RunOutcome(2, True, False, False, None),
            RunOutcome(None, False, False, True, None),
            RunOutcome(8, False, True, False, 3),
            RunOutcome(9, False, True, False, 4),
        )
        self.assertEqual(conditional_valid_detection_delays(outcomes), (3, 4))

    def test_censoring_is_explicit_and_not_silently_extrapolated(self) -> None:
        statistics = summarize_finite_horizon_alarms(
            [2, None, 7, None], [10, 10, 10, 10]
        )
        self.assertEqual(statistics.censoring_indicators, (False, True, False, True))
        self.assertEqual(statistics.censoring_count, 2)
        self.assertEqual(statistics.censoring_rate, 0.5)
        self.assertEqual(statistics.restricted_times_to_alarm, (2, 10, 7, 10))
        self.assertEqual(statistics.restricted_mean_time_to_alarm, 7.25)
        self.assertEqual(statistics.mean_observed_first_alarm_time, 4.5)


class ScientificAuthorizationTests(unittest.TestCase):
    def test_output_config_protocol_dataset_hash_binding_is_exact(self) -> None:
        expected = {
            "dataset": DIGEST,
            "split": DIGEST,
            "configuration": DIGEST,
            "protocol": DIGEST,
            "output": DIGEST,
        }
        validate_hash_bindings(dict(expected), expected)
        with self.assertRaises(ValueError):
            validate_hash_bindings({"dataset": DIGEST}, expected)
        changed = dict(expected)
        changed["output"] = "e" * 64
        with self.assertRaises(ValueError):
            validate_hash_bindings(changed, expected)

    def test_ranking_is_forbidden_when_achieved_risk_is_unmatched(self) -> None:
        with self.assertRaises(PermissionError):
            authorize_detector_ranking(
                admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
                achieved_risk_matched=False,
            )
        with self.assertRaises(PermissionError):
            authorize_detector_ranking(
                admission_level=AdmissionLevel.EXPLORATORY,
                achieved_risk_matched=True,
            )
        authorize_detector_ranking(
            admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
            achieved_risk_matched=True,
        )

    def test_scientific_output_is_forbidden_below_admitted_status(self) -> None:
        for level in AdmissionLevel:
            if level is AdmissionLevel.CLAIM_GRADE_ADMITTED:
                continue
            with self.subTest(level=level), self.assertRaises(PermissionError):
                authorize_scientific_output(
                    admission_level=level,
                    protocol_frozen=True,
                    bank_d_opened=True,
                )
        with self.assertRaises(PermissionError):
            authorize_scientific_output(
                admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
                protocol_frozen=False,
                bank_d_opened=False,
            )
        authorize_scientific_output(
            admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
            protocol_frozen=True,
            bank_d_opened=True,
        )


if __name__ == "__main__":
    unittest.main()
