from __future__ import annotations

import hashlib
import json
from pathlib import Path
import unittest

from stage3.admission.contracts import AdmissionLevel, DatasetAuthority


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]


def load(relative: str) -> dict[str, object]:
    def reject(token: str) -> None:
        raise ValueError(token)

    payload = json.loads(
        (REPOSITORY_ROOT / relative).read_text(encoding="utf-8"),
        parse_constant=reject,
    )
    if not isinstance(payload, dict):
        raise TypeError(relative)
    return payload


class DatasetAuthorityArtifactTests(unittest.TestCase):
    def test_candidate_search_and_deep_screen_limits_are_explicit(self) -> None:
        inventory = load("stage3/datasets/candidate-inventory.json")
        self.assertGreaterEqual(inventory["screened_count"], 8)
        self.assertLessEqual(inventory["deep_screened_count"], 3)
        self.assertLessEqual(inventory["actual_acquisition_count"], 2)
        self.assertEqual(len(inventory["candidates"]), inventory["screened_count"])

    def test_no_dataset_is_admitted_and_all_banks_remain_sealed(self) -> None:
        decisions = load("stage3/datasets/admission-decisions.json")
        self.assertEqual(decisions["status"], "blocked_at_dataset_authority")
        self.assertEqual(decisions["claim_grade_admitted_count"], 0)
        self.assertIsNone(decisions["selected_dataset"])
        self.assertFalse(decisions["protocol_freeze_authorized"])
        self.assertFalse(decisions["detector_evaluation_authorized"])
        self.assertEqual(decisions["detector_execution_count"], 0)
        self.assertEqual(
            decisions["banks"], {"A": "sealed", "B": "sealed", "C": "sealed", "D": "sealed"}
        )

    def test_skab_acquisition_is_hash_bound_and_non_evaluative(self) -> None:
        acquisition = load("stage3/datasets/acquisition/skab-v0.9.0.json")
        self.assertEqual(acquisition["admission_level"], "exploratory")
        self.assertEqual(
            acquisition["archive"]["sha256"],
            "288813774f29e06e98a3250f1aa9de455292b06db8d1ef022863a76cf348b910",
        )
        self.assertTrue(acquisition["archive_safety"]["safe_to_extract_isolated"])
        self.assertFalse(acquisition["access_contract"]["payload_committed_to_git"])
        self.assertFalse(acquisition["access_contract"]["detector_execution"])
        self.assertEqual(acquisition["access_contract"]["banks_opened"], [])
        self.assertEqual(acquisition["csv_audit"]["recording_count"], 35)
        self.assertEqual(acquisition["csv_audit"]["anomaly_free_recording_count"], 1)
        self.assertEqual(acquisition["csv_audit"]["disturbed_recording_count"], 34)
        self.assertEqual(acquisition["csv_audit"]["recordings_with_gap_transitions"], 35)

        member_path = (
            REPOSITORY_ROOT
            / acquisition["member_sha256_manifest"]["path"]
        )
        actual = hashlib.sha256(member_path.read_bytes()).hexdigest()
        self.assertEqual(actual, acquisition["member_sha256_manifest"]["sha256"])
        members = load("stage3/datasets/acquisition/skab-v0.9.0-member-sha256.json")
        self.assertEqual(len(members["members"]), 58)
        self.assertEqual(
            members["members"]["data/valve1/0.csv"],
            "16af3f71313a23dd33d9b7b8065d836d05c3f9257588881cc7fbe07c076d9dc8",
        )

    def test_skab_authority_record_validates_but_remains_exploratory(self) -> None:
        record = DatasetAuthority.from_dict(
            load("stage3/datasets/authority/skab-v0.9.0.json")
        )
        self.assertEqual(record.admission_level, AdmissionLevel.EXPLORATORY)
        self.assertFalse(record.normal_data_suitable)
        self.assertFalse(any(record.bank_suitability.values()))
        self.assertGreater(len(record.blocker_reasons), 0)

    def test_every_deep_screen_has_a_valid_authority_record(self) -> None:
        inventory = load("stage3/datasets/candidate-inventory.json")
        expected = {
            item["dataset_identifier"]
            for item in inventory["candidates"]
            if item["deep_screened"]
        }
        records: dict[str, DatasetAuthority] = {}
        for path in sorted(
            (REPOSITORY_ROOT / "stage3/datasets/authority").glob("*.json")
        ):
            record = DatasetAuthority.from_dict(load(str(path.relative_to(REPOSITORY_ROOT))))
            records[record.dataset_identifier] = record
        self.assertEqual(set(records), expected)
        self.assertEqual(
            records["tep-rieth-v1"].admission_level,
            AdmissionLevel.CLAIM_GRADE_CANDIDATE,
        )
        self.assertEqual(
            records["hai-22.04"].admission_level,
            AdmissionLevel.EXPLORATORY,
        )
        self.assertEqual(sum(
            record.admission_level is AdmissionLevel.CLAIM_GRADE_ADMITTED
            for record in records.values()
        ), 0)


if __name__ == "__main__":
    unittest.main()
