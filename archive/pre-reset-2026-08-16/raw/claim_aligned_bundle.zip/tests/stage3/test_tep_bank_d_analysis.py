from __future__ import annotations

from copy import deepcopy
import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig
from stage3.tep.authority_runner import (
    AuthorityTrajectoryInput,
    DualBoundaryBindings,
    evaluate_dual_boundary_records,
)
from stage3.tep.bank_d_analysis import analyze_bank_d_rows, compare_reproduced_rows
from stage3.tep.runner import DetectorSpec


BINDINGS = DualBoundaryBindings(
    input_sha256="1" * 64,
    protocol_sha256="2" * 64,
    dual_boundary_contract_sha256="3" * 64,
    runner_sha256="4" * 64,
    source_commit="5" * 40,
)


def _rows():
    trajectories = []
    for fault in (1, 2):
        for run in (1, 2, 3):
            signal = np.full(220, 2705.0, dtype=np.float64)
            start = 150 + 10 * run
            signal[start:] += 20.0 + fault
            trajectories.append(
                AuthorityTrajectoryInput.from_raw_xmeas_7(
                    fault,
                    run,
                    f"tep-rieth-v1/faulty_testing/fault_{fault:02d}/run_{run:03d}",
                    signal,
                )
            )
    gate = EventGateConfig(warmup_samples=92, persistence=2, refractory=8)
    detectors = (
        DetectorSpec.canonical_dmreda(name="dmreda_core_d_or_g"),
        DetectorSpec.rms(threshold=0.5, gate=gate),
    )
    return evaluate_dual_boundary_records(
        trajectories,
        detectors,
        bindings=BINDINGS,
    )


class TepBankDAnalysisTests(unittest.TestCase):
    def test_analysis_keeps_boundaries_coequal_and_only_admitted_reference(self) -> None:
        rows = _rows()
        result = analyze_bank_d_rows(
            rows,
            admitted_references=("rms",),
            bootstrap_replicates=10,
            require_frozen_campaign_shape=False,
        )
        self.assertEqual(result["fault_numbers"], [1, 2])
        self.assertEqual(
            result["evidence_channels"], ["dmreda_core_d_or_g", "rms"]
        )
        boundary = result["boundary_sensitivity_summary"]
        self.assertEqual(boundary["coequal_onsets"], [159, 160])
        self.assertIsNone(boundary["selected_onset"])
        self.assertEqual(
            set(result["admitted_reference_pairwise_results"]),
            {"onset_159", "onset_160"},
        )
        self.assertIn(
            "onset_159/rms/early_false_authority",
            result["statistical_analysis"]["holm_families"],
        )

    def test_analysis_rejects_unadmitted_or_incomplete_channel_matrix(self) -> None:
        rows = _rows()
        with self.assertRaisesRegex(ValueError, "allowlist"):
            analyze_bank_d_rows(
                rows,
                admitted_references=("page_hinkley",),
                require_frozen_campaign_shape=False,
            )
        without_one = tuple(
            row
            for row in rows
            if not (
                row["faultNumber"] == 2
                and row["simulationRun"] == 3
                and row["evidence_channel_identifier"] == "rms"
            )
        )
        with self.assertRaisesRegex(ValueError, "recording identities"):
            analyze_bank_d_rows(
                without_one,
                admitted_references=("rms",),
                bootstrap_replicates=10,
                require_frozen_campaign_shape=False,
            )

    def test_reproduction_diff_reports_first_changed_identity(self) -> None:
        rows = list(_rows())
        same = compare_reproduced_rows(rows, deepcopy(rows))
        self.assertEqual(same["status"], "no_differences")
        self.assertTrue(same["experiment_valid"])

        changed = deepcopy(rows)
        changed[1]["first_authoritative_event"] = 159
        different = compare_reproduced_rows(rows, changed)
        self.assertEqual(different["status"], "different")
        self.assertFalse(different["experiment_valid"])
        self.assertEqual(different["first_difference"]["record_index"], 1)

    def test_order_change_is_not_silently_accepted(self) -> None:
        rows = list(_rows())
        rows[0], rows[1] = rows[1], rows[0]
        with self.assertRaisesRegex(ValueError, "order"):
            analyze_bank_d_rows(
                rows,
                admitted_references=("rms",),
                require_frozen_campaign_shape=False,
            )


if __name__ == "__main__":
    unittest.main()
