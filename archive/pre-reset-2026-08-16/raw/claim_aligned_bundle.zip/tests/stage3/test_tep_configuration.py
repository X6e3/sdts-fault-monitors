from __future__ import annotations

from dataclasses import fields
import re
import unittest

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    DEFAULT_TRANSITIONS,
    DMREDAProfile,
    compute_dmreda_reference,
)
from stage3.tep.configuration import (
    FROZEN_EFFECTIVE_PROFILES_SHA256,
    FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
    FROZEN_TEP_CONFIGURATION_SHA256,
    FROZEN_TRANSITIONS_SHA256,
    TEP_AFFINE_CONFIGURATION,
    TEP_KAPPA,
    TEP_THRESHOLD_FIELDS,
    apply_tep_affine_scale,
    build_effective_profiles,
    build_tep_core_kwargs,
    build_unchanged_transitions,
    effective_profiles_sha256,
    effective_profiles_snapshot,
    tep_affine_configuration_sha256,
    tep_affine_configuration_snapshot,
    tep_configuration_sha256,
    tep_configuration_snapshot,
    transitions_sha256,
    transitions_snapshot,
)


class TepFrozenConfigurationTests(unittest.TestCase):
    def test_affine_and_core_kwargs_are_exact_and_fresh(self) -> None:
        self.assertEqual(TEP_AFFINE_CONFIGURATION.channel_name, "xmeas_7")
        self.assertEqual(TEP_AFFINE_CONFIGURATION.offset, 2705.0)
        self.assertEqual(TEP_AFFINE_CONFIGURATION.scale, 7.561259999999865)
        np.testing.assert_allclose(
            apply_tep_affine_scale(
                [2705.0, 2705.0 + 7.561259999999865]
            ),
            np.array([0.0, 1.0]),
            rtol=0.0,
            atol=2e-14,
        )

        first = build_tep_core_kwargs()
        second = build_tep_core_kwargs()
        self.assertEqual(first["regime_tick"], 50)
        self.assertEqual(first["initial_state"], 0)
        self.assertEqual(first["mode"], "D_or_G")
        self.assertEqual(first["warmup_samples"], 92)
        self.assertIsNot(first["profiles"], second["profiles"])
        self.assertIsNot(first["transitions"], second["transitions"])

    def test_effective_profiles_are_fresh_and_do_not_mutate_defaults(self) -> None:
        defaults_before = dict(DEFAULT_PROFILES)
        left = build_effective_profiles()
        right = build_effective_profiles()

        self.assertEqual(DEFAULT_PROFILES, defaults_before)
        self.assertIsNot(left, right)
        self.assertEqual(set(left), set(DEFAULT_PROFILES))
        for state in DEFAULT_PROFILES:
            self.assertIsNot(left[state], DEFAULT_PROFILES[state])
            self.assertIsNot(left[state], right[state])

        left[0] = DEFAULT_PROFILES[0]
        self.assertEqual(DEFAULT_PROFILES, defaults_before)
        self.assertNotEqual(left, right)

    def test_only_four_threshold_fields_are_multiplied(self) -> None:
        effective = build_effective_profiles()
        all_fields = {field.name for field in fields(DMREDAProfile)}
        self.assertEqual(
            set(TEP_THRESHOLD_FIELDS), {"th_d", "th_g", "th_d2", "th_a"}
        )

        for state, original in DEFAULT_PROFILES.items():
            changed = effective[state]
            for field_name in sorted(all_fields):
                with self.subTest(state=state, field=field_name):
                    if field_name in TEP_THRESHOLD_FIELDS:
                        self.assertEqual(
                            getattr(changed, field_name),
                            getattr(original, field_name) * TEP_KAPPA,
                        )
                    else:
                        self.assertEqual(
                            getattr(changed, field_name),
                            getattr(original, field_name),
                        )

    def test_default_transitions_remain_exactly_unchanged(self) -> None:
        defaults_before = dict(DEFAULT_TRANSITIONS)
        left = build_unchanged_transitions()
        right = build_unchanged_transitions()

        self.assertEqual(DEFAULT_TRANSITIONS, defaults_before)
        self.assertEqual(left, DEFAULT_TRANSITIONS)
        self.assertEqual(right, DEFAULT_TRANSITIONS)
        self.assertIsNot(left, right)
        for state in DEFAULT_TRANSITIONS:
            self.assertIsNot(left[state], DEFAULT_TRANSITIONS[state])
            self.assertIsNot(left[state], right[state])

    def test_canonical_snapshots_and_hashes_are_deterministic(self) -> None:
        self.assertEqual(
            effective_profiles_snapshot(), effective_profiles_snapshot()
        )
        self.assertEqual(transitions_snapshot(), transitions_snapshot())
        self.assertEqual(tep_configuration_snapshot(), tep_configuration_snapshot())
        self.assertEqual(
            effective_profiles_sha256(), FROZEN_EFFECTIVE_PROFILES_SHA256
        )
        self.assertEqual(transitions_sha256(), FROZEN_TRANSITIONS_SHA256)
        self.assertEqual(tep_configuration_sha256(), FROZEN_TEP_CONFIGURATION_SHA256)
        self.assertEqual(
            tep_affine_configuration_sha256(),
            FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
        )
        self.assertEqual(
            tep_affine_configuration_snapshot(),
            tep_configuration_snapshot()["channel"],
        )
        self.assertEqual(
            FROZEN_EFFECTIVE_PROFILES_SHA256,
            "0ee424e11677ab374410ce93efa9e024866160e64247a2770e71405c918c2e81",
        )
        self.assertEqual(
            FROZEN_TRANSITIONS_SHA256,
            "1e496ac52b44f4c3e97b71a5c7273245b86b1955b69feab073c692d9b68173d0",
        )
        self.assertEqual(
            FROZEN_TEP_CONFIGURATION_SHA256,
            "6ce21c097c72df22d9915cd2f2805548f25bc23b4e40d8ad8c2d65ec0bad663a",
        )
        self.assertEqual(
            FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
            "f515810ab1fdfbe0fd3b982fb03dc1ce504b0f1333f33320b3ad68f8d0e72f58",
        )
        for digest in (
            FROZEN_EFFECTIVE_PROFILES_SHA256,
            FROZEN_TRANSITIONS_SHA256,
            FROZEN_TEP_CONFIGURATION_SHA256,
            FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
        ):
            self.assertTrue(re.fullmatch(r"[0-9a-f]{64}", digest))

    def test_frozen_profiles_preserve_warmup_representation_invariance(self) -> None:
        sample_index = np.arange(360)
        signal = np.where((sample_index % 20) < 3, 3.0, 0.0)

        no_warmup_kwargs = build_tep_core_kwargs()
        no_warmup_kwargs["warmup_samples"] = 0
        frozen_kwargs = build_tep_core_kwargs()
        no_warmup = compute_dmreda_reference(signal, **no_warmup_kwargs)
        frozen_warmup = compute_dmreda_reference(signal, **frozen_kwargs)

        for field_name in (
            "mu",
            "e",
            "e1",
            "e_baseline",
            "e_baseline_safe",
            "d",
            "g_raw",
            "g",
            "r",
            "a",
            "a_slow",
            "state",
            "m_eff",
            "confirm_len_eff",
        ):
            with self.subTest(field=field_name):
                np.testing.assert_array_equal(
                    getattr(no_warmup, field_name),
                    getattr(frozen_warmup, field_name),
                )


if __name__ == "__main__":
    unittest.main()
