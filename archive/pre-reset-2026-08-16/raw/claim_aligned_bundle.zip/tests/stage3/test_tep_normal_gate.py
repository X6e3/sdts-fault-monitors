from __future__ import annotations

import csv
import gzip
import inspect
from pathlib import Path
import tempfile
import unittest

from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig
from stage3.admission.serialization import canonical_sha256
from stage3.tep.configuration import FROZEN_TEP_CONFIGURATION_SHA256
from stage3.tep.extraction import sha256_file
from stage3.tep.normal_gate import (
    FROZEN_REFERENCE_GATE,
    RawScalarTrajectory,
    calibrate_scalar_references,
    evaluate_normal_trajectories,
    iter_scalar_fault_groups,
    load_scalar_bank,
    render_normal_gate_report,
    summarize_normal_authority,
)
from stage3.tep.runner import DetectorSpec


DIGEST = "d" * 64
COMMIT = "c" * 40


def _raw(run: int, *, length: int = 180) -> RawScalarTrajectory:
    values = [2705.0 + ((index + run) % 7 - 3) * 0.15 for index in range(length)]
    return RawScalarTrajectory(
        partition="synthetic",
        fault_number=0,
        simulation_run=run,
        raw_samples=tuple(values),
    )


def _detectors() -> tuple[DetectorSpec, ...]:
    gate = EventGateConfig(warmup_samples=4, persistence=2, refractory=8)
    return (
        DetectorSpec.canonical_dmreda(name="dmreda_core_d_or_g"),
        DetectorSpec.rms(threshold=10.0, gate=gate, window=32),
        DetectorSpec.cusum(
            threshold=10.0, gate=gate, center=0.0, allowance=0.5
        ),
        DetectorSpec.ewma(
            threshold=10.0,
            gate=gate,
            center=0.0,
            scale=1.0,
            alpha=2.0 / 33.0,
        ),
    )


class TepNormalGateTests(unittest.TestCase):
    def test_loader_enforces_exact_shape_order_and_retains_whole_runs(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "scalar.csv.gz"
            with gzip.open(path, "wt", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle, lineterminator="\n")
                writer.writerow(("faultNumber", "simulationRun", "sample", "xmeas_7"))
                for run in range(1, 4):
                    for sample in range(1, 5):
                        writer.writerow((0, run, sample, 2705.0 + run + sample / 10.0))
            bank = load_scalar_bank(
                path,
                partition="fault_free_training",
                expected_fault_numbers=(0,),
                expected_runs_per_fault=3,
                expected_horizon=4,
                retain_simulation_runs=(2, 3),
                expected_extract_sha256=sha256_file(path),
            )
            self.assertEqual(bank.total_row_count, 12)
            self.assertEqual(
                [item.trajectory_identifier for item in bank.trajectories],
                [
                    "tep-rieth-v1/fault_free_training/fault_00/run_002",
                    "tep-rieth-v1/fault_free_training/fault_00/run_003",
                ],
            )
            self.assertEqual(len(bank.bank_sha256), 64)

            malformed = Path(temporary) / "malformed.csv.gz"
            with gzip.open(malformed, "wt", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle, lineterminator="\n")
                writer.writerow(("faultNumber", "simulationRun", "sample", "xmeas_7"))
                writer.writerow((0, 1, 2, 2705.0))
            with self.assertRaisesRegex(ValueError, "identity mismatch"):
                load_scalar_bank(
                    malformed,
                    partition="synthetic",
                    expected_fault_numbers=(0,),
                    expected_runs_per_fault=1,
                    expected_horizon=1,
                )

    def test_fault_group_iterator_validates_before_bounded_grouping(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "faults.csv.gz"
            with gzip.open(path, "wt", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle, lineterminator="\n")
                writer.writerow(("faultNumber", "simulationRun", "sample", "xmeas_7"))
                for fault in (1, 2):
                    for run in (1, 2):
                        for sample in (1, 2, 3):
                            writer.writerow((fault, run, sample, 2705.0 + fault + run))
            groups = tuple(
                iter_scalar_fault_groups(
                    path,
                    partition="faulty_testing",
                    expected_fault_numbers=(1, 2),
                    expected_runs_per_fault=2,
                    expected_horizon=3,
                    expected_extract_sha256=sha256_file(path),
                )
            )
            self.assertEqual(
                [[row.fault_number for row in group] for group in groups],
                [[1, 1], [2, 2]],
            )

    def test_calibration_freezes_only_thresholds_and_is_repeatable(self) -> None:
        trajectories = tuple(_raw(run, length=180) for run in range(1, 7))
        first, configs, detectors = calibrate_scalar_references(
            trajectories,
            target_false_authority_count=1,
            target_restricted_time_sum=1_000,
            require_frozen_campaign_shape=False,
        )
        second, configs_again, detectors_again = calibrate_scalar_references(
            trajectories,
            target_false_authority_count=1,
            target_restricted_time_sum=1_000,
            require_frozen_campaign_shape=False,
        )
        self.assertEqual(first, second)
        self.assertEqual(configs, configs_again)
        self.assertEqual(detectors, detectors_again)
        self.assertEqual(set(configs), {"rms", "cusum", "ewma"})
        for detector in detectors:
            self.assertEqual(detector.gate, FROZEN_REFERENCE_GATE)
            self.assertEqual(
                configs[detector.name]["configuration_sha256"],
                detector.detector_sha256,
            )

    def test_frozen_campaign_shape_is_fail_closed(self) -> None:
        with self.assertRaisesRegex(ValueError, "101..200"):
            calibrate_scalar_references(tuple(_raw(run) for run in range(1, 4)))

        synthetic_claim_shape = tuple(
            _raw(run, length=500) for run in range(101, 201)
        )
        with self.assertRaisesRegex(ValueError, "101..200"):
            calibrate_scalar_references(synthetic_claim_shape)

    def test_production_normal_path_rejects_nonfrozen_primary_before_compute(self) -> None:
        wrong_primary = DetectorSpec.canonical_dmreda(
            name="dmreda_core_d_or_g", mode="D_ONLY"
        )
        with self.assertRaisesRegex(ValueError, "D_OR_G"):
            evaluate_normal_trajectories(
                (_raw(1),),
                (wrong_primary, *_detectors()[1:]),
                input_sha256=DIGEST,
                protocol_sha256=DIGEST,
                runner_sha256=DIGEST,
                source_commit=COMMIT,
            )

    def test_normal_evaluation_is_onset_free_deterministic_and_affine_bound(self) -> None:
        self.assertNotIn("onset", inspect.signature(evaluate_normal_trajectories).parameters)
        trajectories = tuple(_raw(run) for run in range(1, 4))
        first = evaluate_normal_trajectories(
            trajectories,
            _detectors(),
            input_sha256=DIGEST,
            protocol_sha256=DIGEST,
            runner_sha256=DIGEST,
            source_commit=COMMIT,
            require_frozen_campaign_shape=False,
        )
        second = evaluate_normal_trajectories(
            tuple(reversed(trajectories)),
            tuple(reversed(_detectors())),
            input_sha256=DIGEST,
            protocol_sha256=DIGEST,
            runner_sha256=DIGEST,
            source_commit=COMMIT,
            require_frozen_campaign_shape=False,
        )
        self.assertEqual(first, second)
        self.assertEqual(len(first), 12)
        for row in first:
            self.assertEqual(row["faultNumber"], 0)
            self.assertNotEqual(row["raw_sample_sha256"], row["scaled_sample_sha256"])
            without_hash = dict(row)
            stored = without_hash.pop("row_sha256")
            self.assertEqual(stored, canonical_sha256(without_hash))

    def test_summary_reports_censoring_and_primary_independent_admission(self) -> None:
        detectors = _detectors()
        rows = list(
            evaluate_normal_trajectories(
                tuple(_raw(run) for run in range(1, 4)),
                detectors,
                input_sha256=DIGEST,
                protocol_sha256=DIGEST,
                runner_sha256=DIGEST,
                source_commit=COMMIT,
                require_frozen_campaign_shape=False,
            )
        )
        summary, admission = summarize_normal_authority(
            rows,
            detectors=detectors,
            require_frozen_campaign_shape=False,
        )
        self.assertFalse(
            summary["finite_horizon_interpretation"]["classical_uncensored_arl_claimed"]
        )
        self.assertEqual(
            summary["primary_dmreda"]["configuration_sha256"],
            FROZEN_TEP_CONFIGURATION_SHA256,
        )
        self.assertFalse(admission["primary_bank_d_veto_from_reference_failure"])
        self.assertEqual(
            set(admission["scalar_evidence_references"]), {"rms", "cusum", "ewma"}
        )
        report = render_normal_gate_report(summary, admission)
        self.assertIn("finite-horizon", report)
        self.assertNotIn("leaderboard", report.lower())

    def test_rehashed_tampered_restricted_time_is_recomputed_and_rejected(self) -> None:
        detectors = _detectors()
        rows = list(
            evaluate_normal_trajectories(
                tuple(_raw(run) for run in range(1, 3)),
                detectors,
                input_sha256=DIGEST,
                protocol_sha256=DIGEST,
                runner_sha256=DIGEST,
                source_commit=COMMIT,
                require_frozen_campaign_shape=False,
            )
        )
        rows[0]["restricted_time_to_authority"] = 17
        without_hash = dict(rows[0])
        without_hash.pop("row_sha256")
        rows[0]["row_sha256"] = canonical_sha256(without_hash)
        with self.assertRaisesRegex(ValueError, "restricted time"):
            summarize_normal_authority(
                rows,
                detectors=detectors,
                require_frozen_campaign_shape=False,
            )

    def test_frozen_gate_is_not_silently_replaced_by_test_gate(self) -> None:
        self.assertEqual(
            FROZEN_REFERENCE_GATE,
            EventGateConfig(warmup_samples=92, persistence=20, refractory=80),
        )


if __name__ == "__main__":
    unittest.main()
