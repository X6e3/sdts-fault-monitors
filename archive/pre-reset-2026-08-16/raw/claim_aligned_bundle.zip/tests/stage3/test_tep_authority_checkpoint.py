from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig
from stage3.tep.authority_checkpoint import evaluate_dual_boundary_fault
from stage3.tep.authority_runner import AuthorityTrajectoryInput, DualBoundaryBindings
from stage3.tep.checkpoints import CheckpointValidationError
from stage3.tep.runner import DetectorSpec


BINDINGS = DualBoundaryBindings(
    input_sha256="1" * 64,
    protocol_sha256="2" * 64,
    dual_boundary_contract_sha256="3" * 64,
    runner_sha256="4" * 64,
    source_commit="5" * 40,
)


def inputs():
    signal = np.zeros(220, dtype=np.float64)
    signal[150:] = 2.0
    trajectories = (
        AuthorityTrajectoryInput.from_raw_xmeas_7(
            1, 2, "fault_01/run_002", tuple(signal)
        ),
        AuthorityTrajectoryInput.from_raw_xmeas_7(
            1, 1, "fault_01/run_001", tuple(signal)
        ),
    )
    gate = EventGateConfig(warmup_samples=92, persistence=2, refractory=8)
    detectors = (
        DetectorSpec.rms(threshold=0.5, gate=gate),
        DetectorSpec.canonical_dmreda(),
    )
    return trajectories, detectors


class DualBoundaryCheckpointTests(unittest.TestCase):
    def run_once(self, root: Path, *, workers: int = 1, resume: bool = True):
        trajectories, detectors = inputs()
        return evaluate_dual_boundary_fault(
            trajectories,
            detectors,
            bindings=BINDINGS,
            result_path=root / "fault_01.jsonl",
            checkpoint_path=root / "fault_01.checkpoint.json",
            completed_at_utc="2026-08-05T12:00:00Z",
            workers=workers,
            resume=resume,
        )

    def test_complete_run_is_sorted_hash_bound_and_resumable_without_rewrite(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = self.run_once(root, workers=1)
            before = (
                (root / "fault_01.jsonl").stat().st_ino,
                (root / "fault_01.jsonl").read_bytes(),
                (root / "fault_01.checkpoint.json").stat().st_ino,
                (root / "fault_01.checkpoint.json").read_bytes(),
            )
            resumed = self.run_once(root, workers=2)
            self.assertFalse(first.resumed)
            self.assertTrue(resumed.resumed)
            self.assertEqual(first.result_sha256, resumed.result_sha256)
            self.assertEqual(
                before,
                (
                    (root / "fault_01.jsonl").stat().st_ino,
                    (root / "fault_01.jsonl").read_bytes(),
                    (root / "fault_01.checkpoint.json").stat().st_ino,
                    (root / "fault_01.checkpoint.json").read_bytes(),
                ),
            )

    def test_partial_pair_stale_binding_and_tampering_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = self.run_once(root)
            (root / "fault_01.checkpoint.json").unlink()
            recovered = self.run_once(root)
            self.assertTrue(recovered.resumed)
            self.assertEqual(recovered.result_sha256, first.result_sha256)
            self.assertTrue((root / "fault_01.checkpoint.json").is_file())

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.run_once(root)
            (root / "fault_01.jsonl").unlink()
            with self.assertRaisesRegex(CheckpointValidationError, "incomplete"):
                self.run_once(root)

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.run_once(root)
            checkpoint_path = root / "fault_01.checkpoint.json"
            checkpoint = json.loads(checkpoint_path.read_text())
            checkpoint["result_sha256"] = "9" * 64
            checkpoint_path.write_text(json.dumps(checkpoint), encoding="utf-8")
            with self.assertRaises(CheckpointValidationError):
                self.run_once(root)

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.run_once(root)
            stale = DualBoundaryBindings(
                input_sha256="1" * 64,
                protocol_sha256="9" * 64,
                dual_boundary_contract_sha256="3" * 64,
                runner_sha256="4" * 64,
                source_commit="5" * 40,
            )
            trajectories, detectors = inputs()
            with self.assertRaisesRegex(CheckpointValidationError, "stale"):
                evaluate_dual_boundary_fault(
                    trajectories,
                    detectors,
                    bindings=stale,
                    result_path=root / "fault_01.jsonl",
                    checkpoint_path=root / "fault_01.checkpoint.json",
                    completed_at_utc="2026-08-05T12:00:00Z",
                )

    def test_serial_and_parallel_results_match_before_checkpointing(self) -> None:
        with tempfile.TemporaryDirectory() as left, tempfile.TemporaryDirectory() as right:
            serial = self.run_once(Path(left), workers=1)
            parallel = self.run_once(Path(right), workers=2)
            self.assertEqual(serial.rows, parallel.rows)
            self.assertEqual(serial.result_sha256, parallel.result_sha256)

    def test_external_root_routes_result_and_checkpoint_through_guard(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            trajectories, detectors = inputs()
            run = evaluate_dual_boundary_fault(
                trajectories,
                detectors,
                bindings=BINDINGS,
                result_path=root / "fault_01.jsonl",
                checkpoint_path=root / "fault_01.checkpoint.json",
                completed_at_utc="2026-08-05T12:00:00Z",
                external_root=root,
            )
            self.assertFalse(run.resumed)
            resumed = evaluate_dual_boundary_fault(
                trajectories,
                detectors,
                bindings=BINDINGS,
                result_path=root / "fault_01.jsonl",
                checkpoint_path=root / "fault_01.checkpoint.json",
                completed_at_utc="2026-08-05T12:00:00Z",
                external_root=root,
            )
            self.assertTrue(resumed.resumed)


if __name__ == "__main__":
    unittest.main()
