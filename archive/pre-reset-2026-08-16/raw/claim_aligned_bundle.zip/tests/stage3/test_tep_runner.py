from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig
from stage3.tep.checkpoints import (
    CheckpointValidationError,
    read_canonical_checkpoint_strict,
    read_canonical_jsonl_strict,
    write_canonical_checkpoint_atomic,
    write_canonical_jsonl_atomic,
)
from stage3.tep.runner import (
    DetectorSpec,
    EvaluationBindings,
    TrajectoryInput,
    evaluate_fault,
)


DIGESTS = {
    "input_sha256": "1" * 64,
    "protocol_sha256": "2" * 64,
    "onset_sha256": "3" * 64,
    "runner_sha256": "4" * 64,
}


def synthetic_trajectories() -> tuple[TrajectoryInput, ...]:
    length = 180
    onset = 100
    detected = np.zeros(length, dtype=np.float64)
    detected[onset:] = 3.0
    early = np.zeros(length, dtype=np.float64)
    early[70:82] = 3.0
    early[onset:] = 3.0
    quiet = np.zeros(length, dtype=np.float64)
    return (
        TrajectoryInput("fault_01", "fault_01/run_003", 3, tuple(quiet), onset),
        TrajectoryInput("fault_01", "fault_01/run_001", 1, tuple(detected), onset),
        TrajectoryInput("fault_01", "fault_01/run_002", 2, tuple(early), onset),
    )


def detector_specs() -> tuple[DetectorSpec, ...]:
    gate = EventGateConfig(warmup_samples=4, persistence=2, refractory=8)
    return (
        DetectorSpec.canonical_dmreda(),
        DetectorSpec.rms(threshold=0.5, gate=gate),
        DetectorSpec.cusum(
            threshold=1.0, gate=gate, center=0.0, allowance=0.1
        ),
        DetectorSpec.ewma(
            threshold=0.2, gate=gate, center=0.0, scale=1.0, alpha=0.2
        ),
    )


class TepRunnerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.trajectories = synthetic_trajectories()
        self.bindings = EvaluationBindings(**DIGESTS)

    def run_once(
        self,
        root: Path,
        detector: DetectorSpec,
        *,
        workers: int,
        suffix: str,
    ):
        return evaluate_fault(
            self.trajectories,
            detector,
            bindings=self.bindings,
            result_path=root / f"{detector.name}-{suffix}.jsonl",
            checkpoint_path=root / f"{detector.name}-{suffix}.checkpoint.json",
            workers=workers,
        )

    def test_all_detector_specs_preserve_exact_first_event_outcomes(self) -> None:
        expected = {
            "dmreda_core": (
                ("valid_detection", 105, 5),
                ("miss", None, None),
                ("miss", None, None),
            ),
            "rms": (
                ("valid_detection", 101, 1),
                ("false_positive", 71, None),
                ("miss", None, None),
            ),
            "cusum": (
                ("valid_detection", 101, 1),
                ("false_positive", 71, None),
                ("miss", None, None),
            ),
            "ewma": (
                ("valid_detection", 101, 1),
                ("false_positive", 71, None),
                ("miss", None, None),
            ),
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for detector in detector_specs():
                with self.subTest(detector=detector.kind):
                    run = self.run_once(root, detector, workers=1, suffix="dispatch")
                    self.assertEqual(
                        [row["trajectory_id"] for row in run.rows],
                        [
                            "fault_01/run_001",
                            "fault_01/run_002",
                            "fault_01/run_003",
                        ],
                    )
                    self.assertEqual(
                        tuple(
                            (
                                row["outcome"],
                                row["first_alarm"],
                                row["valid_detection_delay_samples"],
                            )
                            for row in run.rows
                        ),
                        expected[detector.kind],
                    )
                    for row in run.rows:
                        outcome_flags = (
                            row["false_positive"], row["detected"], row["missed"]
                        )
                        self.assertEqual(sum(bool(value) for value in outcome_flags), 1)
                        if not row["detected"]:
                            self.assertIsNone(row["valid_detection_delay_samples"])

    def test_serial_parallel_parity_and_two_run_byte_equality(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for detector in detector_specs():
                with self.subTest(detector=detector.kind):
                    serial = self.run_once(root, detector, workers=1, suffix="serial")
                    parallel = self.run_once(root, detector, workers=2, suffix="parallel")
                    repeat = self.run_once(root, detector, workers=1, suffix="repeat")

                    self.assertEqual(serial.rows, parallel.rows)
                    self.assertEqual(serial.rows, repeat.rows)
                    self.assertEqual(serial.result_sha256, parallel.result_sha256)
                    self.assertEqual(serial.result_sha256, repeat.result_sha256)
                    self.assertEqual(
                        (root / f"{detector.name}-serial.jsonl").read_bytes(),
                        (root / f"{detector.name}-parallel.jsonl").read_bytes(),
                    )
                    self.assertEqual(
                        (root / f"{detector.name}-serial.checkpoint.json").read_bytes(),
                        (root / f"{detector.name}-repeat.checkpoint.json").read_bytes(),
                    )

    def test_valid_resume_does_not_rewrite_or_duplicate_rows(self) -> None:
        detector = detector_specs()[1]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            result_path = root / "result.jsonl"
            checkpoint_path = root / "checkpoint.json"
            first = evaluate_fault(
                self.trajectories,
                detector,
                bindings=self.bindings,
                result_path=result_path,
                checkpoint_path=checkpoint_path,
            )
            result_before = (result_path.stat().st_ino, result_path.read_bytes())
            checkpoint_before = (
                checkpoint_path.stat().st_ino,
                checkpoint_path.read_bytes(),
            )
            resumed = evaluate_fault(
                tuple(reversed(self.trajectories)),
                detector,
                bindings=self.bindings,
                result_path=result_path,
                checkpoint_path=checkpoint_path,
                workers=2,
            )
            self.assertTrue(resumed.resumed)
            self.assertEqual(first.result_sha256, resumed.result_sha256)
            self.assertEqual(len(resumed.rows), len(self.trajectories))
            self.assertEqual(result_before, (result_path.stat().st_ino, result_path.read_bytes()))
            self.assertEqual(
                checkpoint_before,
                (checkpoint_path.stat().st_ino, checkpoint_path.read_bytes()),
            )

    def test_resume_rejects_partial_duplicate_stale_and_tampered_artifacts(self) -> None:
        detector = detector_specs()[1]
        failure_kinds = ("partial", "duplicate", "stale", "tampered_result", "tampered_checkpoint")
        for failure_kind in failure_kinds:
            with self.subTest(failure=failure_kind), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                result_path = root / "result.jsonl"
                checkpoint_path = root / "checkpoint.json"
                evaluate_fault(
                    self.trajectories,
                    detector,
                    bindings=self.bindings,
                    result_path=result_path,
                    checkpoint_path=checkpoint_path,
                )

                if failure_kind == "partial":
                    result_path.write_bytes(result_path.read_bytes().rstrip(b"\n"))
                elif failure_kind == "duplicate":
                    rows, _ = read_canonical_jsonl_strict(result_path)
                    duplicate_rows = (rows[0], rows[0], rows[2])
                    new_hash = write_canonical_jsonl_atomic(result_path, duplicate_rows)
                    checkpoint = read_canonical_checkpoint_strict(checkpoint_path)
                    checkpoint["result_sha256"] = new_hash
                    write_canonical_checkpoint_atomic(checkpoint_path, checkpoint)
                elif failure_kind == "stale":
                    stale = EvaluationBindings(
                        **{**DIGESTS, "protocol_sha256": "9" * 64}
                    )
                    with self.assertRaisesRegex(
                        CheckpointValidationError, "stale|mismatch"
                    ):
                        evaluate_fault(
                            self.trajectories,
                            detector,
                            bindings=stale,
                            result_path=result_path,
                            checkpoint_path=checkpoint_path,
                        )
                    continue
                elif failure_kind == "tampered_result":
                    rows, _ = read_canonical_jsonl_strict(result_path)
                    tampered = [dict(row) for row in rows]
                    tampered[0]["outcome"] = "miss"
                    write_canonical_jsonl_atomic(result_path, tampered)
                else:
                    checkpoint = read_canonical_checkpoint_strict(checkpoint_path)
                    checkpoint["binding_sha256"] = "8" * 64
                    write_canonical_checkpoint_atomic(checkpoint_path, checkpoint)

                with self.assertRaises(CheckpointValidationError):
                    evaluate_fault(
                        self.trajectories,
                        detector,
                        bindings=self.bindings,
                        result_path=result_path,
                        checkpoint_path=checkpoint_path,
                    )

    def test_incomplete_result_checkpoint_pair_and_unbounded_workers_fail_closed(self) -> None:
        detector = detector_specs()[1]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            result_path = root / "result.jsonl"
            result_path.write_text("{}\n", encoding="utf-8")
            with self.assertRaises(CheckpointValidationError):
                evaluate_fault(
                    self.trajectories,
                    detector,
                    bindings=self.bindings,
                    result_path=result_path,
                    checkpoint_path=root / "missing.json",
                )
            with self.assertRaises(ValueError):
                evaluate_fault(
                    self.trajectories,
                    detector,
                    bindings=self.bindings,
                    result_path=root / "unused.jsonl",
                    checkpoint_path=root / "unused.json",
                    workers=9,
                )


if __name__ == "__main__":
    unittest.main()
