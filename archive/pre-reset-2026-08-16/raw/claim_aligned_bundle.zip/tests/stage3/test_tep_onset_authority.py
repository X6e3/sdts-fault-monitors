from __future__ import annotations

from copy import deepcopy
import unittest

from stage3.admission.serialization import canonical_json_bytes
from stage3.tep.onset_authority import (
    DUAL_BOUNDARY_CONTRACT_STATUS,
    DUAL_BOUNDARY_STATUS,
    build_dual_boundary_contract,
    sample_label_to_python_index,
    validate_dual_boundary_contract,
)


DIGEST = "d" * 64
COMMIT = "c" * 40


def build() -> dict[str, object]:
    return build_dual_boundary_contract(
        frozen_at_utc="2026-08-05T12:00:00Z",
        source_commit=COMMIT,
        onset_authority_evidence_sha256=DIGEST,
    )


class TepOnsetAuthorityTests(unittest.TestCase):
    def test_one_based_dataset_labels_map_to_zero_based_python_indices(self) -> None:
        self.assertEqual(sample_label_to_python_index(160), 159)
        self.assertEqual(sample_label_to_python_index(161), 160)
        with self.assertRaises(TypeError):
            sample_label_to_python_index(True)
        with self.assertRaises(ValueError):
            sample_label_to_python_index(0, first_sample_label=1)

    def test_contract_freezes_both_boundaries_without_selecting_a_primary(self) -> None:
        contract = build()
        self.assertEqual(contract["authority_decision"], DUAL_BOUNDARY_STATUS)
        self.assertEqual(contract["contract_status"], DUAL_BOUNDARY_CONTRACT_STATUS)
        self.assertIsNone(contract["selected_mapping"])
        self.assertFalse(contract["unique_primary_boundary"])
        self.assertEqual(
            contract["candidate_mappings"],
            [
                {
                    "mapping_id": "label_160_index_159",
                    "final_pre_fault_sample_label": 159,
                    "first_fault_affected_sample_label": 160,
                    "python_onset_index": 159,
                },
                {
                    "mapping_id": "label_161_index_160",
                    "final_pre_fault_sample_label": 160,
                    "first_fault_affected_sample_label": 161,
                    "python_onset_index": 160,
                },
            ],
        )
        self.assertFalse(contract["scientific_value_access_authorized"])

    def test_post_outcome_selection_or_incomplete_reporting_fails_closed(self) -> None:
        selected = deepcopy(build())
        selected["selected_mapping"] = "label_161_index_160"
        with self.assertRaisesRegex(ValueError, "cannot select"):
            validate_dual_boundary_contract(selected)

        incomplete = deepcopy(build())
        incomplete["execution_contract"][
            "expose_every_boundary_changed_trajectory"
        ] = False
        with self.assertRaisesRegex(ValueError, "must be enabled"):
            validate_dual_boundary_contract(incomplete)

    def test_contract_is_strict_finite_path_safe_and_deterministic(self) -> None:
        first = build()
        second = build()
        self.assertEqual(canonical_json_bytes(first), canonical_json_bytes(second))
        validate_dual_boundary_contract(first)


if __name__ == "__main__":
    unittest.main()
