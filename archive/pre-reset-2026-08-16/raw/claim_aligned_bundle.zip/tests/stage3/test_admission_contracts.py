from __future__ import annotations

from dataclasses import FrozenInstanceError
import json
import math
from pathlib import Path
import tempfile
import unittest

from stage3.admission.adapters import RecordingDescriptor, ScalarTrace
from stage3.admission.contracts import (
    AdmissionLevel,
    AuthorityStatus,
    DatasetAuthority,
    DataAccessPolicy,
    FrozenPreprocessing,
    LicenseStatus,
    apply_fixed_affine,
)
from stage3.admission.serialization import (
    atomic_write_json,
    canonical_json_bytes,
    load_strict_json,
    validate_no_machine_paths,
)


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
DIGEST = "a" * 64


def authority(**overrides: object) -> DatasetAuthority:
    values: dict[str, object] = {
        "schema_version": "1.0.0",
        "dataset_identifier": "example-v1",
        "admission_level": AdmissionLevel.EXPLORATORY,
        "authority_status": AuthorityStatus.VERIFIED_PRIMARY_SOURCE,
        "source_organization": "Example Institute",
        "source_locator": "https://example.invalid/dataset",
        "citation": "Example et al. (2026)",
        "version": "1",
        "license_status": LicenseStatus.VERIFIED_OPEN,
        "license_locator": "https://example.invalid/license",
        "archive_sha256": DIGEST,
        "member_sha256": {"data.csv": DIGEST},
        "raw_or_derived_status": "raw",
        "preprocessing_history": (),
        "recording_identity_fields": ("recording_id",),
        "label_authority": "dataset_supplied_interval",
        "sample_rate_authority": "exact",
        "channel_authority": "documented physical sensor",
        "normal_data_suitable": True,
        "bank_suitability": {"A": True, "B": True, "C": True, "D": False},
        "blocker_reasons": ("insufficient disturbed recordings",),
        "human_access_requirements": (),
    }
    values.update(overrides)
    return DatasetAuthority(**values)  # type: ignore[arg-type]


class StrictSerializationTests(unittest.TestCase):
    def test_canonical_json_is_deterministic_and_atomic(self) -> None:
        left = canonical_json_bytes({"b": [2, 1], "a": 3})
        right = canonical_json_bytes({"a": 3, "b": [2, 1]})
        self.assertEqual(left, right)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "artifact.json"
            atomic_write_json(path, {"schema_version": "1.0.0", "value": 1})
            self.assertEqual(load_strict_json(path)["value"], 1)
            self.assertTrue(path.read_bytes().endswith(b"\n"))

    def test_nonfinite_values_and_tokens_are_rejected(self) -> None:
        for value in (math.nan, math.inf, -math.inf):
            with self.subTest(value=value), self.assertRaises(ValueError):
                canonical_json_bytes({"value": value})
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            path.write_text('{"value": NaN}', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_strict_json(path)

    def test_absolute_user_paths_are_rejected_recursively(self) -> None:
        for value in (
            {"path": "/Users/example/data.csv"},
            ["/home/example/data.csv"],
            {"url": "file:///tmp/private"},
        ):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_no_machine_paths(value)


class AuthorityAndLicenseTests(unittest.TestCase):
    def test_valid_authority_record_is_strict_and_hashable(self) -> None:
        record = authority()
        payload = record.to_dict()
        self.assertEqual(payload["admission_level"], "exploratory")
        self.assertRegex(record.authority_record_sha256, r"^[0-9a-f]{64}$")
        self.assertEqual(
            DatasetAuthority.from_dict(payload).authority_record_sha256,
            record.authority_record_sha256,
        )
        with self.assertRaises(TypeError):
            DatasetAuthority(**payload)  # type: ignore[arg-type]

    def test_human_access_status_requires_explicit_requirement(self) -> None:
        with self.assertRaises(ValueError):
            authority(
                license_status=LicenseStatus.HUMAN_ACCESS_REQUIRED,
                human_access_requirements=(),
            )
        record = authority(
            license_status=LicenseStatus.HUMAN_ACCESS_REQUIRED,
            human_access_requirements=("accept publisher terms",),
        )
        self.assertEqual(record.license_status, LicenseStatus.HUMAN_ACCESS_REQUIRED)

    def test_claim_grade_admission_fails_with_any_authority_blocker(self) -> None:
        with self.assertRaises(ValueError):
            authority(admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED)
        admitted = authority(
            admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
            bank_suitability={"A": True, "B": True, "C": True, "D": True},
            blocker_reasons=(),
        )
        self.assertEqual(admitted.admission_level, AdmissionLevel.CLAIM_GRADE_ADMITTED)

    def test_json_schema_enums_match_code_contract(self) -> None:
        schema = json.loads(
            (
                REPOSITORY_ROOT
                / "stage3/schemas/dataset-authority.schema.json"
            ).read_text(encoding="utf-8")
        )
        self.assertEqual(schema["schema_version"], "1.0.0")
        self.assertEqual(
            set(schema["properties"]["admission_level"]["enum"]),
            {item.value for item in AdmissionLevel},
        )
        self.assertEqual(
            set(schema["properties"]["license_status"]["enum"]),
            {item.value for item in LicenseStatus},
        )


class PreprocessingAndAccessTests(unittest.TestCase):
    def setUp(self) -> None:
        self.preprocessing = FrozenPreprocessing(
            channel_name="sensor_pressure",
            units="bar",
            offset_fixed=10.0,
            scale_fixed=2.0,
            fitted_bank="A",
        )

    def test_channel_and_scaling_configuration_is_immutable(self) -> None:
        with self.assertRaises(FrozenInstanceError):
            self.preprocessing.channel_name = "evaluation_winner"  # type: ignore[misc]
        self.assertRegex(self.preprocessing.configuration_sha256, r"^[0-9a-f]{64}$")

    def test_full_trace_or_label_dependent_preprocessing_is_forbidden(self) -> None:
        for changes in (
            {"full_trace_normalization": True},
            {"label_dependent_selection": True},
            {"fitted_bank": "D"},
            {"scale_fixed": 0.0},
        ):
            values = {
                "channel_name": "sensor_pressure",
                "units": "bar",
                "offset_fixed": 10.0,
                "scale_fixed": 2.0,
                "fitted_bank": "A",
            }
            values.update(changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                FrozenPreprocessing(**values)  # type: ignore[arg-type]

    def test_fixed_affine_transform_is_prefix_causal(self) -> None:
        samples = [8.0, 10.0, 12.0, 20.0]
        full = apply_fixed_affine(samples, self.preprocessing)
        prefix = apply_fixed_affine(samples[:3], self.preprocessing)
        self.assertEqual(prefix, full[:3])
        self.assertEqual(full, (-1.0, 0.0, 1.0, 5.0))

    def test_calibration_banks_cannot_request_labels(self) -> None:
        for bank in ("A", "B", "C"):
            with self.subTest(bank=bank), self.assertRaises(PermissionError):
                DataAccessPolicy(bank=bank, include_labels=True, purpose="calibration")
        policy = DataAccessPolicy(bank="D", include_labels=True, purpose="evaluation")
        self.assertTrue(policy.include_labels)

    def test_adapter_metadata_exposes_hashes_gaps_and_intervals(self) -> None:
        descriptor = RecordingDescriptor(
            dataset_identifier="example-v1",
            recording_id="run-1",
            lineage_id="run-1",
            device_id="device-1",
            session_id="session-1",
            sample_count=3,
            sample_rate_hz=1.0,
            timestamp_authority="dataset supplied",
            channel_name="pressure",
            units="bar",
            source_member="data/run-1.csv",
            source_sha256=DIGEST,
            anomaly_interval_count=1,
            missing_sample_count=1,
        )
        trace = ScalarTrace(
            samples=(1.0, 2.0, 3.0),
            sample_indices=(0, 1, 2),
            timestamps=("t0", "t1", "t3"),
            missing_sample_indicators=(False, False, True),
            anomaly_intervals=((1, 3),),
        )
        self.assertEqual(descriptor.missing_sample_count, 1)
        self.assertEqual(trace.anomaly_intervals, ((1, 3),))


if __name__ == "__main__":
    unittest.main()
