from __future__ import annotations

from copy import deepcopy
import csv
import gzip
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from stage3.tep.extraction import (
    EXTRACTION_MANIFEST_SCHEMA_VERSION,
    SCALAR_COLUMNS,
    build_extraction_manifest,
    validate_extraction_bindings,
    validate_extraction_manifest,
    validate_scalar_trajectory,
    write_extraction_manifest,
)


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
R_EXTRACTOR = REPOSITORY_ROOT / "scripts/stage3/extract_tep_xmeas7.R"


class TepExtractionContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def _write_scalar(self, name: str, rows: list[tuple[object, ...]]) -> Path:
        path = self.root / name
        with gzip.open(path, "wt", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, lineterminator="\n")
            writer.writerow(SCALAR_COLUMNS)
            writer.writerows(rows)
        return path

    def _valid_scalar(self) -> Path:
        return self._write_scalar(
            "synthetic_xmeas7.csv.gz",
            [
                (0, 1, 1, 1.25),
                (0, 1, 2, 1.5),
                (0, 2, 1, -2.0),
                (1, 1, 1, 3.0),
            ],
        )

    def test_validates_exact_schema_order_identity_and_finiteness(self) -> None:
        summary = validate_scalar_trajectory(self._valid_scalar())
        self.assertEqual(summary.row_count, 4)
        self.assertEqual(summary.trajectory_count, 3)
        self.assertEqual(summary.first_key, (0, 1, 1))
        self.assertEqual(summary.last_key, (1, 1, 1))

    def test_rejects_header_key_order_duplicate_and_nonfinite_errors(self) -> None:
        wrong_header = self.root / "wrong_header.csv.gz"
        with gzip.open(wrong_header, "wt", encoding="utf-8", newline="") as handle:
            handle.write("simulationRun,faultNumber,sample,xmeas_7\n1,0,1,1\n")

        cases = (
            (wrong_header, "header"),
            (
                self._write_scalar(
                    "out_of_order.csv.gz", [(0, 2, 1, 1.0), (0, 1, 1, 2.0)]
                ),
                "not sorted",
            ),
            (
                self._write_scalar(
                    "duplicate.csv.gz", [(0, 1, 1, 1.0), (0, 1, 1, 2.0)]
                ),
                "duplicate",
            ),
            (
                self._write_scalar("fractional_key.csv.gz", [(0, 1.5, 1, 1.0)]),
                "non-integral",
            ),
            (
                self._write_scalar("noncanonical_key.csv.gz", [(0, "01", 1, 1.0)]),
                "non-canonical",
            ),
            (
                self._write_scalar("nan.csv.gz", [(0, 1, 1, "NaN")]),
                "non-finite",
            ),
            (
                self._write_scalar("inf.csv.gz", [(0, 1, 1, "Inf")]),
                "non-finite",
            ),
        )
        for path, message in cases:
            with self.subTest(path=path.name), self.assertRaisesRegex(
                ValueError, message
            ):
                validate_scalar_trajectory(path)

    def test_manifest_binds_source_script_and_output_hashes(self) -> None:
        source = self.root / "synthetic_source.RData"
        source.write_bytes(b"synthetic source fixture\n")
        extractor = self.root / "synthetic_extractor.R"
        extractor.write_text("# synthetic extractor fixture\n", encoding="utf-8")
        output = self._valid_scalar()

        manifest = build_extraction_manifest(
            dataset_identifier="tep-synthetic-fixture",
            expected_object="fault_free_training",
            source_path=source,
            extractor_script_path=extractor,
            output_path=output,
        )
        self.assertEqual(
            manifest["schema_version"], EXTRACTION_MANIFEST_SCHEMA_VERSION
        )
        self.assertFalse(manifest["validation"]["detector_outcomes_emitted"])
        validate_extraction_bindings(
            manifest,
            source_path=source,
            extractor_script_path=extractor,
            output_path=output,
        )

        source.write_bytes(b"changed fixture\n")
        with self.assertRaisesRegex(ValueError, "source hash mismatch"):
            validate_extraction_bindings(
                manifest,
                source_path=source,
                extractor_script_path=extractor,
                output_path=output,
            )

    def test_manifest_rejects_loose_schema_paths_nonfinite_and_outcomes(self) -> None:
        source = self.root / "source.RData"
        source.write_bytes(b"fixture\n")
        extractor = self.root / "extractor.R"
        extractor.write_text("# fixture\n", encoding="utf-8")
        manifest = build_extraction_manifest(
            dataset_identifier="tep-synthetic-fixture",
            expected_object="fault_free_training",
            source_path=source,
            extractor_script_path=extractor,
            output_path=self._valid_scalar(),
        )

        variants = []
        extra = deepcopy(manifest)
        extra["ranking"] = []
        variants.append(extra)
        absolute = deepcopy(manifest)
        absolute["source"]["logical_name"] = "/private/source.RData"
        variants.append(absolute)
        nonfinite = deepcopy(manifest)
        nonfinite["output"]["bytes"] = float("nan")
        variants.append(nonfinite)
        outcomes = deepcopy(manifest)
        outcomes["validation"]["detector_outcomes_emitted"] = True
        variants.append(outcomes)
        reordered = deepcopy(manifest)
        reordered["selection"]["columns"] = list(reversed(SCALAR_COLUMNS))
        variants.append(reordered)

        for index, variant in enumerate(variants):
            with self.subTest(index=index), self.assertRaises((ValueError, TypeError)):
                validate_extraction_manifest(variant)

    def test_manifest_is_written_atomically_outside_git(self) -> None:
        source = self.root / "source.RData"
        source.write_bytes(b"fixture\n")
        extractor = self.root / "extractor.R"
        extractor.write_text("# fixture\n", encoding="utf-8")
        output = self._valid_scalar()
        manifest = build_extraction_manifest(
            dataset_identifier="tep-synthetic-fixture",
            expected_object="fault_free_training",
            source_path=source,
            extractor_script_path=extractor,
            output_path=output,
        )
        destination = self.root / "extraction-manifest.json"
        write_extraction_manifest(destination, manifest, external_root=self.root)
        observed = json.loads(destination.read_text(encoding="utf-8"))
        self.assertEqual(observed, manifest)

    @unittest.skipUnless(shutil.which("Rscript"), "Rscript is unavailable")
    def test_standalone_r_extractor_uses_only_synthetic_fixture(self) -> None:
        source = self.root / "synthetic_training.RData"
        create = subprocess.run(
            [
                shutil.which("Rscript") or "Rscript",
                "--vanilla",
                "-e",
                (
                    "p<-commandArgs(TRUE)[1];"
                    "fault_free_training<-data.frame("
                    "faultNumber=c(0,0,0,0),"
                    "simulationRun=c(2,1,2,1),"
                    "sample=c(2L,2L,1L,1L),"
                    "xmeas_7=c(22,12,21,11));"
                    "save(fault_free_training,file=p)"
                ),
                str(source),
            ],
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(create.returncode, 0, create.stderr)

        external = self.root / "external"
        external.mkdir()
        output = external / "synthetic_xmeas7.csv.gz"
        command = [
            shutil.which("Rscript") or "Rscript",
            "--vanilla",
            str(R_EXTRACTOR),
            "--source",
            str(source),
            "--output",
            str(output),
            "--external-root",
            str(external),
            "--expected-object",
            "fault_free_training",
            "--expected-rows",
            "4",
            "--expected-columns",
            "4",
            "--expected-fault-numbers",
            "0",
            "--expected-runs-per-fault",
            "2",
            "--expected-samples-per-run",
            "2",
        ]
        extracted = subprocess.run(
            command, check=False, capture_output=True, text=True
        )
        self.assertEqual(extracted.returncode, 0, extracted.stderr)
        self.assertIn("extracted_rows=4", extracted.stdout)
        self.assertNotIn("outcome", extracted.stdout.lower())
        summary = validate_scalar_trajectory(output)
        self.assertEqual(summary.first_key, (0, 1, 1))
        self.assertEqual(summary.last_key, (0, 2, 2))
        with gzip.open(output, "rt", encoding="utf-8", newline="") as handle:
            rows = list(csv.reader(handle))
        self.assertEqual(rows[0], list(SCALAR_COLUMNS))
        self.assertEqual([row[:3] for row in rows[1:]], [
            ["0", "1", "1"],
            ["0", "1", "2"],
            ["0", "2", "1"],
            ["0", "2", "2"],
        ])

    @unittest.skipUnless(shutil.which("Rscript"), "Rscript is unavailable")
    def test_r_extractor_refuses_git_worktree_output(self) -> None:
        source = self.root / "synthetic_training.RData"
        create_code = (
            "p<-commandArgs(TRUE)[1];"
            "fault_free_training<-data.frame("
            "faultNumber=0,simulationRun=1,sample=1L,xmeas_7=1);"
            "save(fault_free_training,file=p)"
        )
        subprocess.run(
            [
                shutil.which("Rscript") or "Rscript",
                "--vanilla",
                "-e",
                create_code,
                str(source),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        repository = self.root / "repository"
        repository.mkdir()
        (repository / ".git").mkdir()
        output = repository / "forbidden.csv.gz"
        rejected = subprocess.run(
            [
                shutil.which("Rscript") or "Rscript",
                "--vanilla",
                str(R_EXTRACTOR),
                "--source",
                str(source),
                "--output",
                str(output),
                "--external-root",
                str(repository),
                "--expected-object",
                "fault_free_training",
                "--expected-rows",
                "1",
                "--expected-columns",
                "4",
                "--expected-fault-numbers",
                "0",
                "--expected-runs-per-fault",
                "1",
                "--expected-samples-per-run",
                "1",
            ],
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertNotEqual(rejected.returncode, 0)
        self.assertIn("Git worktree", rejected.stderr)
        self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
