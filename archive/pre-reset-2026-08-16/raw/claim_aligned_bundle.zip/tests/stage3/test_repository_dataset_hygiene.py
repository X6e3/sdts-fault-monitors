from __future__ import annotations

from pathlib import Path
import subprocess
import unittest

from stage3.admission.guards import forbidden_stage3_tracked_paths


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]


class RepositoryDatasetHygieneTests(unittest.TestCase):
    def test_raw_data_credentials_caches_and_recovery_payloads_are_rejected(self) -> None:
        forbidden = forbidden_stage3_tracked_paths(
            [
                "stage3/raw/dataset.csv.zip",
                "stage3/datasets/archive.RData",
                "stage3/.venv/bin/python",
                "stage3/dataset-audit/raw.csv",
                "stage3/kaggle.json",
                "repro/stage3/recovery.bundle",
                "stage3/outputs/snapshot.tar.gz",
            ]
        )
        self.assertEqual(len(forbidden), 7)
        self.assertEqual(
            forbidden_stage3_tracked_paths(
                [
                    "stage3/datasets/candidate-inventory.json",
                    "stage3/outputs/per-run-outcomes.csv",
                    "tests/fixtures/dmreda_fixed_golden.json",
                ]
            ),
            (),
        )

    def test_tracked_stage3_namespace_contains_no_forbidden_payload(self) -> None:
        result = subprocess.run(
            [
                "git",
                "ls-files",
                "stage3",
                "docs/stage3",
                "repro/stage3",
                "tests/stage3",
            ],
            cwd=REPOSITORY_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        tracked = tuple(line for line in result.stdout.splitlines() if line)
        self.assertEqual(forbidden_stage3_tracked_paths(tracked), ())

    def test_stage3_artifacts_do_not_contain_absolute_user_paths(self) -> None:
        forbidden = ("/Users/", "/home/", "file://")
        roots = (
            REPOSITORY_ROOT / "stage3",
            REPOSITORY_ROOT / "docs/stage3",
            REPOSITORY_ROOT / "repro/stage3",
        )
        for root in roots:
            for path in sorted(item for item in root.rglob("*") if item.is_file()):
                with self.subTest(path=path.relative_to(REPOSITORY_ROOT)):
                    text = path.read_text(encoding="utf-8")
                    self.assertFalse(any(marker in text for marker in forbidden))


if __name__ == "__main__":
    unittest.main()
