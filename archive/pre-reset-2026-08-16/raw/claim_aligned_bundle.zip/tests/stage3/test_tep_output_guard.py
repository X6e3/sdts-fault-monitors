from __future__ import annotations

import os
from pathlib import Path
import tempfile
import unittest

from stage3.tep.output_guard import (
    ExternalArtifactKind,
    atomic_replace_checkpoint_bytes,
    atomic_write_bytes,
    atomic_write_text,
    git_worktree_root,
    validate_external_destination,
)


class TepExternalOutputGuardTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.external = self.root / "external"
        self.external.mkdir()

    def test_allows_only_typed_artifact_beneath_external_root(self) -> None:
        scalar = self.external / "normal_training_xmeas7.csv.gz"
        manifest = self.external / "normal_training_xmeas7.manifest.json"
        self.assertEqual(
            validate_external_destination(
                scalar,
                external_root=self.external,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            ),
            scalar.resolve(),
        )
        self.assertEqual(
            validate_external_destination(
                manifest,
                external_root=self.external,
                kind=ExternalArtifactKind.EXTRACTION_MANIFEST,
            ),
            manifest.resolve(),
        )

    def test_rejects_external_root_inside_any_git_worktree(self) -> None:
        repository = self.root / "other-repository"
        repository.mkdir()
        (repository / ".git").mkdir()
        output_root = repository / "external-looking"
        output_root.mkdir()
        with self.assertRaisesRegex(PermissionError, "inside a Git worktree"):
            validate_external_destination(
                output_root / "trace.csv.gz",
                external_root=output_root,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            )
        self.assertEqual(git_worktree_root(output_root), repository.resolve())

    def test_rejects_nested_worktree_and_symlink_escape(self) -> None:
        nested = self.external / "nested-worktree"
        nested.mkdir()
        (nested / ".git").write_text("gitdir: elsewhere\n", encoding="utf-8")
        with self.assertRaisesRegex(PermissionError, "inside a Git worktree"):
            validate_external_destination(
                nested / "trace.csv.gz",
                external_root=self.external,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            )

        outside = self.root / "outside"
        outside.mkdir()
        link = self.external / "escape"
        try:
            link.symlink_to(outside, target_is_directory=True)
        except OSError as exc:  # pragma: no cover - restricted Windows runners.
            self.skipTest(f"symlink creation unavailable: {exc}")
        with self.assertRaisesRegex(PermissionError, "escapes"):
            validate_external_destination(
                link / "trace.csv.gz",
                external_root=self.external,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            )

    def test_rejects_existing_symlink_destination(self) -> None:
        target = self.external / "actual.csv.gz"
        target.write_bytes(b"payload")
        link = self.external / "linked.csv.gz"
        try:
            link.symlink_to(target)
        except OSError as exc:  # pragma: no cover - restricted Windows runners.
            self.skipTest(f"symlink creation unavailable: {exc}")
        with self.assertRaisesRegex(PermissionError, "must not be a symlink"):
            validate_external_destination(
                link,
                external_root=self.external,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            )

    def test_rejects_raw_archives_credentials_and_cache_paths(self) -> None:
        cache = self.external / "cache"
        cache.mkdir()
        cases = (
            (self.external / "source.RData", ExternalArtifactKind.SCALAR_TRAJECTORY),
            (self.external / "payload.tar.gz", ExternalArtifactKind.SCALAR_TRAJECTORY),
            (self.external / "credentials.json", ExternalArtifactKind.EXTRACTION_MANIFEST),
            (self.external / ".netrc", ExternalArtifactKind.AUDIT_LOG),
            (cache / "trace.csv.gz", ExternalArtifactKind.SCALAR_TRAJECTORY),
        )
        for path, kind in cases:
            with self.subTest(path=path.name), self.assertRaises(ValueError):
                validate_external_destination(
                    path,
                    external_root=self.external,
                    kind=kind,
                )

    def test_rejects_wrong_suffix_parent_escape_and_overwrite(self) -> None:
        with self.assertRaisesRegex(ValueError, "must use the .csv.gz"):
            validate_external_destination(
                self.external / "trace.csv",
                external_root=self.external,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            )
        with self.assertRaisesRegex(PermissionError, "escapes"):
            validate_external_destination(
                self.root / "escaped.csv.gz",
                external_root=self.external,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            )
        existing = self.external / "existing.json"
        existing.write_text("{}\n", encoding="utf-8")
        with self.assertRaises(FileExistsError):
            validate_external_destination(
                existing,
                external_root=self.external,
                kind=ExternalArtifactKind.EXTRACTION_MANIFEST,
            )

    def test_atomic_publication_is_complete_private_and_no_clobber(self) -> None:
        destination = self.external / "manifest.json"
        published = atomic_write_bytes(
            destination,
            b'{"complete":true}\n',
            external_root=self.external,
            kind=ExternalArtifactKind.EXTRACTION_MANIFEST,
        )
        self.assertEqual(published.read_bytes(), b'{"complete":true}\n')
        self.assertEqual(os.stat(published).st_mode & 0o777, 0o600)
        self.assertEqual(tuple(self.external.glob(f".{destination.name}.*.tmp")), ())
        with self.assertRaises(FileExistsError):
            atomic_write_text(
                destination,
                "replacement",
                external_root=self.external,
                kind=ExternalArtifactKind.EXTRACTION_MANIFEST,
            )
        self.assertEqual(published.read_bytes(), b'{"complete":true}\n')

    def test_scientific_output_types_are_explicit_and_immutable(self) -> None:
        cases = (
            ("result.json", ExternalArtifactKind.IMMUTABLE_JSON),
            ("rows.jsonl", ExternalArtifactKind.IMMUTABLE_JSONL),
            ("report.md", ExternalArtifactKind.MARKDOWN_REPORT),
            ("SHA256SUMS.txt", ExternalArtifactKind.HASH_MANIFEST),
        )
        for name, kind in cases:
            with self.subTest(kind=kind):
                path = self.external / name
                atomic_write_bytes(path, b"payload\n", external_root=self.external, kind=kind)
                with self.assertRaises(FileExistsError):
                    atomic_write_bytes(
                        path,
                        b"replacement\n",
                        external_root=self.external,
                        kind=kind,
                    )
                self.assertEqual(path.read_bytes(), b"payload\n")

    def test_only_checkpoints_and_ledgers_can_be_atomically_replaced(self) -> None:
        checkpoint = self.external / "fault_01.checkpoint.json"
        atomic_replace_checkpoint_bytes(
            checkpoint,
            b'{"state":1}\n',
            external_root=self.external,
            kind=ExternalArtifactKind.CHECKPOINT_JSON,
        )
        atomic_replace_checkpoint_bytes(
            checkpoint,
            b'{"state":2}\n',
            external_root=self.external,
            kind=ExternalArtifactKind.CHECKPOINT_JSON,
        )
        self.assertEqual(checkpoint.read_bytes(), b'{"state":2}\n')
        with self.assertRaisesRegex(ValueError, "only checkpoint"):
            atomic_replace_checkpoint_bytes(
                self.external / "result.json",
                b"{}\n",
                external_root=self.external,
                kind=ExternalArtifactKind.IMMUTABLE_JSON,
            )


if __name__ == "__main__":
    unittest.main()
