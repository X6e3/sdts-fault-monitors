from __future__ import annotations

import hashlib
import unittest

from stage3.admission.contracts import AdmissionLevel
from stage3.admission.seals import BankDSeal, FreezeBindings, open_bank_d
from stage3.admission.splits import (
    RecordingIdentity,
    build_recording_disjoint_split,
    validate_split_manifest,
)


DIGEST = "b" * 64


def record(index: int, *, content: str | None = None, lineage: str | None = None) -> RecordingIdentity:
    return RecordingIdentity(
        dataset_identifier="example-v1",
        recording_id=f"run-{index}",
        lineage_id=lineage or f"parent-{index}",
        content_sha256=content
        or hashlib.sha256(f"run-{index}".encode("ascii")).hexdigest(),
        sample_count=100,
        anomaly_interval_count=1 if index >= 6 else 0,
        eligible_banks=("A", "B", "C") if index < 6 else ("D",),
    )


class SplitContractTests(unittest.TestCase):
    def test_recording_level_split_is_deterministic_and_disjoint(self) -> None:
        records = [record(index) for index in range(10)]
        kwargs = {"bank_counts": {"A": 2, "B": 2, "C": 2, "D": 4}, "seed": 731}
        left = build_recording_disjoint_split(records, **kwargs)
        right = build_recording_disjoint_split(list(reversed(records)), **kwargs)
        self.assertEqual(left.to_dict(), right.to_dict())
        validate_split_manifest(left)
        ids = [item.recording_id for bank in left.banks.values() for item in bank]
        hashes = [item.content_sha256 for bank in left.banks.values() for item in bank]
        lineages = [item.lineage_id for bank in left.banks.values() for item in bank]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(len(hashes), len(set(hashes)))
        self.assertEqual(len(lineages), len(set(lineages)))

    def test_duplicate_identity_content_or_parent_lineage_fails(self) -> None:
        base = [record(index) for index in range(4)]
        variants = (
            base + [base[0]],
            base + [record(9, content=base[0].content_sha256)],
            base + [record(9, lineage=base[0].lineage_id)],
        )
        for records in variants:
            with self.subTest(records=len(records)), self.assertRaises(ValueError):
                build_recording_disjoint_split(
                    records,
                    bank_counts={"A": 1, "B": 1, "C": 1, "D": len(records) - 3},
                    seed=1,
                )

    def test_adjacent_windows_cannot_cross_banks_or_masquerade_as_recordings(self) -> None:
        records = [
            record(0, lineage="source-session"),
            record(1, lineage="source-session"),
            record(2),
            record(3),
        ]
        with self.assertRaisesRegex(ValueError, "whole recording"):
            build_recording_disjoint_split(
                records,
                bank_counts={"A": 1, "B": 1, "C": 1, "D": 1},
                seed=9,
            )

    def test_every_unassigned_recording_needs_an_exclusion_reason(self) -> None:
        records = [record(index) for index in range(10)]
        with self.assertRaisesRegex(ValueError, "explicit exclusion"):
            build_recording_disjoint_split(
                records,
                bank_counts={"A": 1, "B": 1, "C": 1, "D": 1},
                seed=3,
            )
        manifest = build_recording_disjoint_split(
            records,
            bank_counts={"A": 1, "B": 1, "C": 1, "D": 1},
            seed=3,
            exclusions={
                f"run-{index}": "not selected before freeze"
                for index in (3, 4, 5, 7, 8, 9)
            },
        )
        self.assertEqual(len(manifest.excluded_recording_ids), 6)


class BankSealTests(unittest.TestCase):
    def setUp(self) -> None:
        self.bindings = FreezeBindings(
            dataset_manifest_sha256=DIGEST,
            split_manifest_sha256=DIGEST,
            channel_configuration_sha256=DIGEST,
            scaling_configuration_sha256=DIGEST,
            detector_configuration_sha256=DIGEST,
            protocol_sha256=DIGEST,
            risk_result_sha256=DIGEST,
            source_commit="c" * 40,
        )
        self.flags = {
            "protocol_frozen": True,
            "detector_configuration_frozen": True,
            "channel_frozen": True,
            "scaling_frozen": True,
            "risk_target_frozen": True,
            "risk_match_passed": True,
            "opened_at_utc": "2026-08-04T12:00:00Z",
        }

    def test_bank_d_fails_closed_before_admission_or_any_freeze(self) -> None:
        with self.assertRaises(PermissionError):
            open_bank_d(
                BankDSeal(),
                admission_level=AdmissionLevel.EXPLORATORY,
                bindings=self.bindings,
                **self.flags,
            )
        for flag in (
            "protocol_frozen",
            "detector_configuration_frozen",
            "channel_frozen",
            "scaling_frozen",
            "risk_target_frozen",
            "risk_match_passed",
        ):
            values = dict(self.flags)
            values[flag] = False
            with self.subTest(flag=flag), self.assertRaises(PermissionError):
                open_bank_d(
                    BankDSeal(),
                    admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
                    bindings=self.bindings,
                    **values,
                )

    def test_bank_d_open_emits_one_bound_event_and_cannot_reopen(self) -> None:
        opened = open_bank_d(
            BankDSeal(),
            admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
            bindings=self.bindings,
            **self.flags,
        )
        self.assertTrue(opened.opened)
        self.assertEqual(len(opened.audit_events), 1)
        self.assertEqual(opened.audit_events[0]["action"], "open_bank_d")
        self.assertEqual(
            opened.audit_events[0]["binding_sha256"], self.bindings.binding_sha256
        )
        with self.assertRaises(PermissionError):
            open_bank_d(
                opened,
                admission_level=AdmissionLevel.CLAIM_GRADE_ADMITTED,
                bindings=self.bindings,
                **self.flags,
            )


if __name__ == "__main__":
    unittest.main()
