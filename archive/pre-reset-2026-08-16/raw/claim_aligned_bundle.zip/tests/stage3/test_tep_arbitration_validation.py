from __future__ import annotations

import unittest

from stage3.admission.serialization import canonical_sha256
from stage3.tep.arbitration_validation import (
    ARBITRATION_EXPECTATIONS_V1,
    FROZEN_ARBITRATION_EXPECTATIONS_SHA256,
    render_arbitration_report,
    run_arbitration_validation,
)


class TepArbitrationValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result = run_arbitration_validation()

    def test_frozen_expectations_and_all_components_pass(self) -> None:
        self.assertEqual(
            canonical_sha256(ARBITRATION_EXPECTATIONS_V1),
            FROZEN_ARBITRATION_EXPECTATIONS_SHA256,
        )
        self.assertEqual(self.result["status"], "passed")
        self.assertTrue(all(self.result["component_status"].values()))

    def test_required_controlled_cases_are_present(self) -> None:
        names = {row["case_name"] for row in self.result["boundary_cases"]}
        self.assertEqual(
            names,
            {
                "transient_below_persistence",
                "transient_at_persistence_boundary",
                "persistent_evidence",
                "interrupted_persistence",
                "refractory_during_and_after",
                "zero_refractory_single_sample_authority",
                "same_sample_timeout_rearm",
            },
        )

    def test_timeout_rearm_is_preserved_not_reinterpreted(self) -> None:
        case = next(
            row
            for row in self.result["boundary_cases"]
            if row["case_name"] == "same_sample_timeout_rearm"
        )
        self.assertEqual(case["observed"]["pending"], [False, True, True, True, False])
        self.assertEqual(
            self.result["known_unresolved_semantics"]["same_sample_timeout_rearm"],
            "unresolved_design_choice_preserved",
        )
        self.assertFalse(self.result["known_unresolved_semantics"]["policy_changed"])

    def test_refractory_and_regime_snapshot_boundaries(self) -> None:
        refractory = next(
            row
            for row in self.result["boundary_cases"]
            if row["case_name"] == "refractory_during_and_after"
        )
        self.assertEqual(refractory["observed"]["event_indices"], [0, 3, 6])
        snapshot = self.result["regime_pending_snapshot"]["observed"]
        self.assertEqual(snapshot["state"], [0, 1, 1])
        self.assertEqual(snapshot["confirm_len_eff"], [2, 4, 4])
        self.assertEqual(snapshot["event_indices"], [2])

    def test_modes_warmup_and_first_event_ownership(self) -> None:
        self.assertEqual(self.result["mode_gating"]["status"], "passed")
        self.assertEqual(self.result["warmup_authority"]["status"], "passed")
        ownership = self.result["first_event_ownership"]
        self.assertEqual(ownership["status"], "passed")
        self.assertFalse(ownership["later_authority_receives_detection_credit"])

    def test_repeatable_result_and_report(self) -> None:
        repeated = run_arbitration_validation()
        self.assertEqual(self.result, repeated)
        report = render_arbitration_report(self.result)
        self.assertIn("unresolved_design_choice_preserved", report)
        self.assertIn(self.result["result_sha256"], report)


if __name__ == "__main__":
    unittest.main()
