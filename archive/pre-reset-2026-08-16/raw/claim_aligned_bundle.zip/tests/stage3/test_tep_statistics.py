from __future__ import annotations

import unittest

from gold_line.evaluation.alarm_metrics import RunOutcome
from stage3.tep.statistics import (
    classify_boundary_interpretation,
    evaluate_normal_admission,
    evaluate_normal_admission_v2,
    holm_adjust,
    paired_comparison,
    paired_outcome_table,
    summarize_run_outcomes,
    summarize_dual_boundary_rows,
)
from stage3.tep.dual_boundary import (
    classify_dual_boundary_authority,
    invalid_dual_boundary_classification,
)


FP = RunOutcome(10, True, False, False, None)
DETECT_2 = RunOutcome(102, False, True, False, 2)
DETECT_5 = RunOutcome(105, False, True, False, 5)
MISS = RunOutcome(None, False, False, True, None)


class ExactNormalGateTests(unittest.TestCase):
    def test_v2_rejects_restricted_sums_outside_the_finite_horizon(self) -> None:
        valid_references = {
            "rms": (0, 480000),
            "cusum": (0, 480000),
            "ewma": (0, 480000),
        }
        contracts = {name: True for name in valid_references}
        with self.assertRaisesRegex(ValueError, "finite horizon"):
            evaluate_normal_admission_v2(
                dmreda_false_authority_count=0,
                dmreda_restricted_time_sum=-1,
                reference_results=valid_references,
                reference_contracts_valid=contracts,
            )
        invalid_reference = dict(valid_references)
        invalid_reference["ewma"] = (0, 480001)
        with self.assertRaisesRegex(ValueError, "finite horizon"):
            evaluate_normal_admission_v2(
                dmreda_false_authority_count=0,
                dmreda_restricted_time_sum=480000,
                reference_results=invalid_reference,
                reference_contracts_valid=contracts,
            )

    def test_integer_boundaries_admit_exact_point_zero_two_and_48_samples(self) -> None:
        report = evaluate_normal_admission(
            dmreda_fp_count=25,
            dmreda_restricted_sum=450000,
            baseline_results={"rms": (35, 474000)},
        )
        self.assertTrue(report["dmreda"]["passed"])
        self.assertTrue(report["scalar_evidence_references"]["rms"]["admitted"])

    def test_one_count_or_one_sum_beyond_boundary_fails(self) -> None:
        report = evaluate_normal_admission(
            dmreda_fp_count=25,
            dmreda_restricted_sum=450000,
            baseline_results={
                "count_fail": (36, 450000),
                "sum_fail": (25, 474001),
            },
        )
        self.assertFalse(report["all_references_admitted"])
        self.assertFalse(report["scalar_evidence_references"]["count_fail"]["admitted"])
        self.assertFalse(report["scalar_evidence_references"]["sum_fail"]["admitted"])

    def test_v2_reference_failure_never_vetoes_primary_dmreda(self) -> None:
        report = evaluate_normal_admission_v2(
            dmreda_false_authority_count=20,
            dmreda_restricted_time_sum=455000,
            reference_results={
                "rms": (30, 479000),
                "cusum": (31, 455000),
                "ewma": (20, 479001),
            },
            reference_contracts_valid={"rms": True, "cusum": True, "ewma": True},
        )
        self.assertTrue(report["primary_dmreda"]["admitted"])
        self.assertEqual(report["admitted_reference_allowlist"], ["rms"])
        self.assertFalse(report["primary_bank_d_veto_from_reference_failure"])

    def test_v2_all_references_may_fail_while_primary_remains_admitted(self) -> None:
        report = evaluate_normal_admission_v2(
            dmreda_false_authority_count=25,
            dmreda_restricted_time_sum=450000,
            reference_results={
                "rms": (36, 450000),
                "cusum": (25, 474001),
                "ewma": (25, 450000),
            },
            reference_contracts_valid={"rms": True, "cusum": True, "ewma": False},
        )
        self.assertTrue(report["primary_dmreda"]["admitted"])
        self.assertEqual(report["admitted_reference_allowlist"], [])
        self.assertFalse(report["added_value_beyond_scalar_references_claim_authorized"])

    def test_v2_exact_reference_limits_pass_and_one_unit_excess_fails(self) -> None:
        report = evaluate_normal_admission_v2(
            dmreda_false_authority_count=25,
            dmreda_restricted_time_sum=450000,
            reference_results={
                "rms": (35, 474000),
                "cusum": (36, 450000),
                "ewma": (25, 474001),
            },
            reference_contracts_valid={"rms": True, "cusum": True, "ewma": True},
        )
        self.assertEqual(
            report["scalar_evidence_references"]["rms"]["admission_status"],
            "admitted_reference",
        )
        self.assertEqual(
            report["scalar_evidence_references"]["cusum"]["admission_status"],
            "not_admitted_reference",
        )
        self.assertEqual(
            report["scalar_evidence_references"]["ewma"]["admission_status"],
            "not_admitted_reference",
        )


class OutcomeSummaryTests(unittest.TestCase):
    def test_false_positive_and_miss_never_enter_conditional_delay(self) -> None:
        summary = summarize_run_outcomes(
            [FP, DETECT_2, MISS, DETECT_5], onset=100, trace_length=200
        )
        delay = summary["conditional_valid_detection_delay_samples"]
        self.assertEqual(delay["contributing_trajectory_count"], 2)
        self.assertEqual(delay["mean"], 3.5)
        self.assertEqual(summary["counts"], {
            "false_positive": 1,
            "valid_detection": 2,
            "miss": 1,
        })

    def test_complete_three_by_three_table_preserves_fp_categories(self) -> None:
        left = [FP, FP, DETECT_2, DETECT_2, MISS, MISS]
        right = [FP, MISS, FP, MISS, DETECT_5, MISS]
        table = paired_outcome_table(left, right)
        self.assertEqual(table["false_positive"]["false_positive"], 1)
        self.assertEqual(table["false_positive"]["miss"], 1)
        self.assertEqual(table["valid_detection"]["false_positive"], 1)
        self.assertEqual(table["valid_detection"]["miss"], 1)
        self.assertEqual(table["miss"]["valid_detection"], 1)
        self.assertEqual(table["miss"]["miss"], 1)

    @staticmethod
    def dual_row(events):
        result = classify_dual_boundary_authority(events, trace_length=960)
        return {"sample_count": 960, **result.to_dict()}

    def test_dual_boundary_summary_preserves_exact_accounting(self) -> None:
        summary = summarize_dual_boundary_rows(
            [
                self.dual_row([159]),
                self.dual_row([160]),
                self.dual_row([158, 300]),
                self.dual_row([]),
            ]
        )
        self.assertEqual(summary["status"], "complete")
        self.assertEqual(summary["boundary_sensitivity_counts"], {
            "classification_flip_at_boundary": 1,
            "latency_shift_only": 1,
            "false_authority_under_both": 1,
            "no_authority_under_both": 1,
            "invalid": 0,
        })
        self.assertEqual(summary["onset_159"]["counts"], {
            "false_authority": 1,
            "valid_authority": 2,
            "no_authority": 1,
        })
        self.assertEqual(summary["onset_160"]["counts"], {
            "false_authority": 2,
            "valid_authority": 1,
            "no_authority": 1,
        })

    def test_invalid_dual_boundary_row_forces_invalid_summary(self) -> None:
        invalid = invalid_dual_boundary_classification(
            trace_length=960, integrity_failure_reason="synthetic integrity failure"
        )
        summary = summarize_dual_boundary_rows(
            [{"sample_count": 960, **invalid.to_dict()}]
        )
        self.assertEqual(summary["status"], "invalid")
        self.assertTrue(summary["stop_required"])

    def test_claim_level_boundary_interpretation_uses_explicit_categories(self) -> None:
        common = {
            "final_evidence_category_same": True,
            "high_level_conclusions_same": True,
            "admitted_reference_interpretations_same": True,
            "no_claim_unique_to_one_boundary": True,
        }
        self.assertEqual(
            classify_boundary_interpretation(
                classification_flip_count=0,
                **{**common, "high_level_conclusions_same": False},
            ),
            "exact_boundary_invariant",
        )
        self.assertEqual(
            classify_boundary_interpretation(classification_flip_count=1, **common),
            "conclusion_boundary_robust",
        )
        self.assertEqual(
            classify_boundary_interpretation(
                classification_flip_count=1,
                **{**common, "no_claim_unique_to_one_boundary": False},
            ),
            "boundary_material",
        )


class PairedInferenceTests(unittest.TestCase):
    def test_joint_delay_excludes_any_early_fp_and_reports_zero_case(self) -> None:
        report = paired_comparison(
            [FP, DETECT_2, MISS],
            [DETECT_2, DETECT_2, MISS],
            fault="01",
            comparator="rms",
            bootstrap_replicates=50,
        )
        delay = report["paired_valid_detection_delay"]
        self.assertEqual(delay["jointly_valid_detection_count"], 1)
        self.assertEqual(delay["wilcoxon"]["reason"], "all_paired_differences_are_zero")

    def test_bootstrap_is_identity_seeded_and_order_independent(self) -> None:
        left = [DETECT_2, DETECT_5, RunOutcome(109, False, True, False, 9)]
        right = [DETECT_5, DETECT_2, RunOutcome(107, False, True, False, 7)]
        a = paired_comparison(
            left, right, fault="02", comparator="cusum", bootstrap_replicates=100
        )
        b = paired_comparison(
            list(reversed(left)),
            list(reversed(right)),
            fault="02",
            comparator="cusum",
            bootstrap_replicates=100,
        )
        self.assertEqual(
            a["paired_valid_detection_delay"]["bootstrap"],
            b["paired_valid_detection_delay"]["bootstrap"],
        )

    def test_holm_is_monotone_and_preserves_uncomputed_entries(self) -> None:
        adjusted = holm_adjust({"a": 0.01, "b": 0.04, "c": 0.03, "d": None})
        self.assertEqual(adjusted["d"], None)
        self.assertAlmostEqual(adjusted["a"], 0.03)
        self.assertAlmostEqual(adjusted["c"], 0.06)
        self.assertAlmostEqual(adjusted["b"], 0.06)


if __name__ == "__main__":
    unittest.main()
