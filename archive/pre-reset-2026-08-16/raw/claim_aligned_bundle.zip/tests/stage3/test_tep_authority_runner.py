from __future__ import annotations

from copy import deepcopy
import inspect
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig
from stage3.tep.authority_runner import (
    AuthorityTrajectoryInput,
    DualBoundaryBindings,
    evaluate_dual_boundary_records,
    generate_onset_independent_authority,
    read_dual_boundary_records_strict,
    validate_dual_boundary_result_row,
    write_dual_boundary_records_atomic,
)
from stage3.tep.checkpoints import CheckpointValidationError
from stage3.tep.configuration import apply_tep_affine_scale
from stage3.tep.runner import DetectorSpec


BINDINGS = DualBoundaryBindings(
    input_sha256="1" * 64,
    protocol_sha256="2" * 64,
    dual_boundary_contract_sha256="3" * 64,
    runner_sha256="4" * 64,
    source_commit="5" * 40,
)


def trajectories() -> tuple[AuthorityTrajectoryInput, ...]:
    first = np.zeros(220, dtype=np.float64)
    first[150:175] = 3.0
    second = np.zeros(220, dtype=np.float64)
    second[170:] = 2.0
    return (
        AuthorityTrajectoryInput.from_raw_xmeas_7(
            2, 2, "fault_02/run_002", tuple(second)
        ),
        AuthorityTrajectoryInput.from_raw_xmeas_7(
            1, 1, "fault_01/run_001", tuple(first)
        ),
    )


def detectors() -> tuple[DetectorSpec, ...]:
    gate = EventGateConfig(warmup_samples=92, persistence=2, refractory=8)
    return (
        DetectorSpec.rms(threshold=0.5, gate=gate, window=32),
        DetectorSpec.canonical_dmreda(),
    )


class OnsetIndependentAuthorityRunnerTests(unittest.TestCase):
    def test_scientific_inputs_apply_and_bind_frozen_affine_scale_once(self) -> None:
        raw = np.linspace(2690.0, 2720.0, 220)
        trajectory = AuthorityTrajectoryInput.from_raw_xmeas_7(
            0, 1, "fault_free/run_001", raw
        )
        self.assertTrue(trajectory.frozen_tep_preprocessing_verified)
        self.assertEqual(trajectory.sample_domain, "tep_xmeas_7_fixed_affine_scaled")
        np.testing.assert_array_equal(
            trajectory.samples,
            apply_tep_affine_scale(raw),
        )

        synthetic = AuthorityTrajectoryInput(1, 1, "synthetic", tuple(np.zeros(220)))
        with self.assertRaisesRegex(ValueError, "exactly-once"):
            evaluate_dual_boundary_records(
                (synthetic,), detectors(), bindings=BINDINGS
            )

        rows = evaluate_dual_boundary_records(
            trajectories()[:1], detectors(), bindings=BINDINGS
        )
        self.assertEqual(
            {row["preprocessing_trace_sha256"] for row in rows},
            {rows[0]["sample_sha256"]},
        )

    def test_dmreda_modes_are_distinct_hashed_native_configurations(self) -> None:
        modes = tuple(
            DetectorSpec.canonical_dmreda(name=mode.lower(), mode=mode)
            for mode in ("D_ONLY", "G_ONLY", "D_OR_G")
        )
        self.assertEqual(len({detector.detector_sha256 for detector in modes}), 3)
        for detector, mode in zip(modes, ("D_ONLY", "G_ONLY", "D_OR_G")):
            self.assertEqual(detector.to_dict()["mode"], mode)

    def test_generator_api_has_no_onset_and_emits_hashed_trace_families(self) -> None:
        self.assertNotIn(
            "onset", inspect.signature(generate_onset_independent_authority).parameters
        )
        for detector in detectors():
            with self.subTest(channel=detector.name):
                authority = generate_onset_independent_authority(
                    trajectories()[0].samples, detector
                )
                self.assertEqual(authority.sample_count, 220)
                self.assertEqual(authority.configuration_sha256, detector.detector_sha256)
                self.assertEqual(len(authority.onset_independent_artifact_sha256), 64)
                if detector.kind == "dmreda_core":
                    self.assertIsNotNone(authority.representation_trace_sha256)
                    self.assertIsNotNone(authority.state_evolution_sha256)
                else:
                    self.assertIsNone(authority.representation_trace_sha256)
                    self.assertIsNone(authority.state_evolution_sha256)

    def test_event_generation_runs_exactly_once_per_trajectory_and_channel(self) -> None:
        original = generate_onset_independent_authority
        with patch(
            "stage3.tep.authority_runner.generate_onset_independent_authority",
            wraps=original,
        ) as generated:
            rows = evaluate_dual_boundary_records(
                trajectories(), detectors(), bindings=BINDINGS
            )
        self.assertEqual(generated.call_count, len(trajectories()) * len(detectors()))
        self.assertEqual(len(rows), generated.call_count)
        for row in rows:
            validate_dual_boundary_result_row(row)
            self.assertEqual(row["protocol_sha256"], BINDINGS.protocol_sha256)
            self.assertEqual(
                row["dual_boundary_contract_sha256"],
                BINDINGS.dual_boundary_contract_sha256,
            )

    def test_rows_have_stable_fault_run_channel_order(self) -> None:
        rows = evaluate_dual_boundary_records(
            tuple(reversed(trajectories())),
            tuple(reversed(detectors())),
            bindings=BINDINGS,
        )
        identities = [
            (
                row["faultNumber"],
                row["simulationRun"],
                row["evidence_channel_identifier"],
            )
            for row in rows
        ]
        self.assertEqual(identities, sorted(identities))

    def test_serial_parallel_and_atomic_jsonl_are_byte_identical(self) -> None:
        serial = evaluate_dual_boundary_records(
            trajectories(), detectors(), bindings=BINDINGS, workers=1
        )
        parallel = evaluate_dual_boundary_records(
            trajectories(), detectors(), bindings=BINDINGS, workers=2
        )
        self.assertEqual(serial, parallel)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            serial_path = root / "serial.jsonl"
            parallel_path = root / "parallel.jsonl"
            serial_hash = write_dual_boundary_records_atomic(serial_path, serial)
            parallel_hash = write_dual_boundary_records_atomic(parallel_path, parallel)
            self.assertEqual(serial_hash, parallel_hash)
            self.assertEqual(serial_path.read_bytes(), parallel_path.read_bytes())
            restored, restored_hash = read_dual_boundary_records_strict(serial_path)
            self.assertEqual(restored, serial)
            self.assertEqual(restored_hash, serial_hash)

    def test_tampered_onset_or_binding_field_fails_closed(self) -> None:
        row = deepcopy(
            evaluate_dual_boundary_records(
                trajectories()[:1], detectors()[:1], bindings=BINDINGS
            )[0]
        )
        row["latency_onset_159"] = 0
        with self.assertRaises(CheckpointValidationError):
            validate_dual_boundary_result_row(row)

        row = deepcopy(
            evaluate_dual_boundary_records(
                trajectories()[:1], detectors()[:1], bindings=BINDINGS
            )[0]
        )
        row["source_commit"] = "6" * 40
        with self.assertRaisesRegex(CheckpointValidationError, "binding"):
            validate_dual_boundary_result_row(row)

        row = deepcopy(
            evaluate_dual_boundary_records(
                trajectories()[:1], detectors()[:1], bindings=BINDINGS
            )[0]
        )
        row["score_trace_sha256"] = "7" * 64
        with self.assertRaisesRegex(CheckpointValidationError, "trace/event"):
            validate_dual_boundary_result_row(row)


if __name__ == "__main__":
    unittest.main()
