from __future__ import annotations

from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from stage3.admission.serialization import atomic_write_json, canonical_sha256
from stage3.tep.configuration import (
    FROZEN_EFFECTIVE_PROFILES_SHA256,
    FROZEN_TEP_CONFIGURATION_SHA256,
)
from stage3.tep.protocol import (
    DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
    EXPECTED_RAW_DATASET_SHA256,
    freeze_protocol_v2,
)
from stage3.tep.seals import (
    ArtifactReference,
    evaluate_bank_d_admission_v2,
    open_bank_d_once_v2,
    validate_bank_d_open_event_v2,
    write_admission_record,
)
from stage3.tep.statistics import evaluate_normal_admission_v2
from tests.stage3.test_tep_protocol import COMMIT, DIGEST, build_v2


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class TepBankSealV2Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        protocol = build_v2()
        freeze_protocol_v2(
            json_path=self.root / "protocol.json",
            markdown_path=self.root / "protocol.md",
            manifest_path=self.root / "protocol.manifest.json",
            payload=protocol,
        )
        self.protocol = protocol
        candidate = protocol["dual_boundary_contract"]["candidate_payload"]
        admission_core = evaluate_normal_admission_v2(
            dmreda_false_authority_count=5,
            dmreda_restricted_time_sum=470_000,
            reference_results={
                "rms": (6, 468_000),
                "cusum": (40, 420_000),
                "ewma": (7, 469_000),
            },
            reference_contracts_valid={"rms": True, "cusum": True, "ewma": True},
        )
        protocol_references = protocol["scalar_evidence_references"]
        protocol_sha256 = canonical_sha256(protocol)
        self.references = {
            "protocol_json": ArtifactReference(
                self.root / "protocol.json", _digest(self.root / "protocol.json")
            ),
            "protocol_freeze_manifest": ArtifactReference(
                self.root / "protocol.manifest.json",
                _digest(self.root / "protocol.manifest.json"),
            ),
        }
        self.special_hashes: dict[Path, str] = {}

        def write(name: str, payload, declared: str | None = None) -> str:
            path = self.root / f"{name}.json"
            atomic_write_json(path, payload)
            actual = _digest(path)
            reference_hash = actual if declared is None else declared
            self.references[name] = ArtifactReference(path, reference_hash)
            if reference_hash != actual:
                self.special_hashes[path] = reference_hash
            return reference_hash

        write(
            "dual_boundary_candidate",
            candidate,
            DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        )
        write(
            "dual_boundary_implementation",
            {
                "status": "passed",
                "candidate_file_sha256": DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
                "tests_passed": True,
                "runner_sha256": DIGEST,
                "event_generation_accepts_onset": False,
                "coequal_onsets": [159, 160],
            },
        )
        write("layer_a_result", {"status": "passed", "result_sha256": DIGEST}, DIGEST)
        write("layer_b_result", {"status": "passed", "result_sha256": DIGEST}, DIGEST)
        write(
            "raw_integrity",
            {
                "status": "passed",
                "raw_dataset_hashes": EXPECTED_RAW_DATASET_SHA256,
            },
        )
        write(
            "fault_free_testing_open_event",
            {
                "document_type": "dmreda.stage3_3.fault_free_testing_open_event",
                "action": "open_fault_free_testing_for_independent_normal_gate",
                "protocol_sha256": protocol_sha256,
                "source_commit": COMMIT,
                "bank_d_state": "sealed_unopened",
            },
        )
        write(
            "pre_bank_d_access_evidence",
            {
                "status": "complete",
                "source_commit": COMMIT,
                "protocol_sha256": protocol_sha256,
                "fault_free_testing_values_accessed": True,
                "faulty_testing_values_accessed": False,
                "bank_d_state": "sealed_unopened",
            },
        )
        extraction_manifest_sha = write(
            "fault_free_testing_extraction_manifest",
            {
                "schema_version": "dmreda.stage3.tep.extraction-manifest.v1",
                "dataset_identifier": "tep-rieth-v1",
                "source": {
                    "logical_name": "TEP_FaultFree_Testing.RData",
                    "object_name": "fault_free_testing",
                    "sha256": EXPECTED_RAW_DATASET_SHA256[
                        "TEP_FaultFree_Testing.RData"
                    ],
                },
                "extractor": {
                    "logical_name": "extract_tep_xmeas7.R",
                    "sha256": DIGEST,
                },
                "output": {
                    "bytes": 1,
                    "compression": "gzip",
                    "format": "csv",
                    "logical_name": "fault_free_testing_xmeas7.csv.gz",
                    "sha256": DIGEST,
                },
                "selection": {
                    "channel": "xmeas_7",
                    "columns": [
                        "faultNumber",
                        "simulationRun",
                        "sample",
                        "xmeas_7",
                    ],
                    "ordering": ["faultNumber", "simulationRun", "sample"],
                },
                "validation": {
                    "detector_outcomes_emitted": False,
                    "finite": True,
                    "first_key": [0, 1, 1],
                    "last_key": [0, 500, 960],
                    "row_count": 480_000,
                    "trajectory_count": 500,
                },
            },
        )
        extraction_adapter_sha = write(
            "fault_free_testing_extraction",
            {
                "status": "passed",
                "partition": "fault_free_testing",
                "schema_verified": True,
                "trajectory_count": 500,
                "horizon": 960,
                "extract_sha256": DIGEST,
                "extraction_manifest_sha256": extraction_manifest_sha,
            },
        )
        worker_memory_probe_sha = write(
            "worker_memory_probe",
            {
                "status": "measured",
                "source_commit": COMMIT,
                "protocol_sha256": protocol_sha256,
                "probe_workers": 1,
                "conservative_rss_bytes": 1024**3,
                "available_memory_bytes_at_probe": 12 * 1024**3,
                "reserved_memory_bytes": 3 * 1024**3,
                "per_worker_safety_factor": 2,
                "host": {"system": "Darwin", "release": "test", "machine": "arm64"},
                "maximum_campaign_workers": 4,
            },
        )
        normal_bindings = {
            "fault_free_testing_extract_sha256": DIGEST,
            "fault_free_testing_extraction_adapter_sha256": extraction_adapter_sha,
            "dmreda_trajectory_results_sha256": DIGEST,
            "scalar_reference_trajectory_results_sha256": DIGEST,
            "protocol_sha256": protocol_sha256,
            "runner_sha256": DIGEST,
            "source_commit": COMMIT,
        }
        normal_without_hash = {
            "status": "passed",
            "run_count": 500,
            "horizon": 960,
            "primary_dmreda": {
                "admitted": True,
                "false_authority_count": 5,
                "restricted_time_sum": 470_000,
                "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
            },
            "artifact_bindings": normal_bindings,
        }
        normal = {
            **normal_without_hash,
            "summary_payload_sha256": canonical_sha256(normal_without_hash),
        }
        normal_sha = write("dmreda_normal_gate", normal)
        admission_without_hash = {
            **admission_core,
            "status": "complete",
            "dmreda_primary_admitted": True,
            "artifact_bindings": {
                **normal_bindings,
                "dmreda_normal_summary_sha256": normal_sha,
            },
        }
        admission = {
            **admission_without_hash,
            "admission_payload_sha256": canonical_sha256(admission_without_hash),
        }
        admission_sha = write("scalar_reference_admission", admission)
        normal_manifest_without_hash = {
            "document_type": "dmreda.stage3_3.normal_gate_manifest",
            "status": "complete_and_verified",
            "source_commit": COMMIT,
            "protocol_sha256": protocol_sha256,
            "serial_parallel_parity": True,
            "worker_memory_probe_sha256": worker_memory_probe_sha,
            "artifact_sha256": {
                "fault_free_testing_extraction": extraction_adapter_sha,
                "dmreda_trajectory_results": DIGEST,
                "scalar_reference_trajectory_results": DIGEST,
                "dmreda_normal_summary": normal_sha,
                "scalar_reference_admission": admission_sha,
                "normal_gate_report": DIGEST,
            },
        }
        self.normal_manifest = {
            **normal_manifest_without_hash,
            "manifest_payload_sha256": canonical_sha256(normal_manifest_without_hash),
        }
        write("normal_gate_manifest", self.normal_manifest)
        payloads = {
            "test_report": {
                "status": "passed",
                "source_commit": COMMIT,
                "dual_boundary_tests_passed": True,
                "protocol_sha256": protocol_sha256,
            },
            "output_guard": {
                "status": "passed",
                "source_commit": COMMIT,
                "protocol_sha256": protocol_sha256,
            },
            "dmreda_configuration": {
                "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
                "effective_profiles_sha256": FROZEN_EFFECTIVE_PROFILES_SHA256,
                "source_commit": COMMIT,
            },
            "scalar_reference_configurations": {
                "status": "frozen",
                "source_commit": COMMIT,
                "configuration_sha256": {
                    name: protocol_references[name]["configuration_sha256"]
                    for name in ("rms", "cusum", "ewma")
                },
                "records": {
                    name: {
                        key: value
                        for key, value in protocol_references[name].items()
                        if key != "scientific_role"
                    }
                    for name in ("rms", "cusum", "ewma")
                },
            },
            "recovery_integrity": {
                "status": "passed",
                "bank_d_state": "sealed_unopened",
                "faulty_testing_values_accessed": False,
                "source_commit": COMMIT,
                "protocol_sha256": protocol_sha256,
            },
            "git_state": {
                "status": "clean",
                "source_commit": COMMIT,
                "protocol_sha256": protocol_sha256,
            },
        }
        for name, payload in payloads.items():
            write(name, payload)

    def _evaluate(self, references=None):
        from stage3.tep import seals

        real_hash = seals._file_sha256

        def resolved_hash(path: Path) -> str:
            return self.special_hashes.get(Path(path), real_hash(Path(path)))

        with patch("stage3.tep.seals._file_sha256", side_effect=resolved_hash):
            return evaluate_bank_d_admission_v2(
                self.references if references is None else references,
                source_commit=COMMIT,
                evaluated_at_utc="2026-08-05T14:00:00Z",
            )

    def _replace_admission_coherently(self, admission_core) -> None:
        normal = __import__("json").loads(
            self.references["dmreda_normal_gate"].path.read_text(encoding="utf-8")
        )
        without_hash = {
            **admission_core,
            "status": "complete",
            "dmreda_primary_admitted": admission_core["primary_dmreda"]["admitted"],
            "artifact_bindings": {
                **normal["artifact_bindings"],
                "dmreda_normal_summary_sha256": self.references[
                    "dmreda_normal_gate"
                ].sha256,
            },
        }
        admission = {
            **without_hash,
            "admission_payload_sha256": canonical_sha256(without_hash),
        }
        path = self.references["scalar_reference_admission"].path
        atomic_write_json(path, admission)
        self.references["scalar_reference_admission"] = ArtifactReference(
            path, _digest(path)
        )
        manifest = deepcopy(self.normal_manifest)
        manifest["artifact_sha256"]["scalar_reference_admission"] = _digest(path)
        manifest.pop("manifest_payload_sha256")
        manifest["manifest_payload_sha256"] = canonical_sha256(manifest)
        manifest_path = self.references["normal_gate_manifest"].path
        atomic_write_json(manifest_path, manifest)
        self.references["normal_gate_manifest"] = ArtifactReference(
            manifest_path, _digest(manifest_path)
        )
        self.normal_manifest = manifest

    def test_failed_comparator_is_excluded_without_vetoing_primary(self) -> None:
        record = self._evaluate()
        self.assertEqual(record["status"], "admitted")
        self.assertEqual(record["reasons"], [])
        self.assertEqual(record["admitted_reference_allowlist"], ["ewma", "rms"])
        self.assertEqual(record["excluded_references"], {"cusum": "risk_not_matched"})
        self.assertFalse(record["primary_bank_d_veto_from_reference_failure"])

    def test_all_reference_failures_still_do_not_veto_primary(self) -> None:
        admission = evaluate_normal_admission_v2(
            dmreda_false_authority_count=5,
            dmreda_restricted_time_sum=470_000,
            reference_results={name: (100, 300_000) for name in ("rms", "cusum", "ewma")},
            reference_contracts_valid={name: True for name in ("rms", "cusum", "ewma")},
        )
        self._replace_admission_coherently(admission)
        record = self._evaluate()
        self.assertEqual(record["status"], "admitted")
        self.assertEqual(record["admitted_reference_allowlist"], [])
        self.assertFalse(record["added_value_beyond_scalar_references_claim_authorized"])

    def test_primary_failure_denies_and_unknown_reference_status_denies(self) -> None:
        normal = deepcopy(
            __import__("json").loads(
                self.references["dmreda_normal_gate"].path.read_text(encoding="utf-8")
            )
        )
        normal["primary_dmreda"]["admitted"] = False
        normal["primary_dmreda"]["false_authority_count"] = 26
        path = self.references["dmreda_normal_gate"].path
        atomic_write_json(path, normal)
        self.references["dmreda_normal_gate"] = ArtifactReference(path, _digest(path))
        record = self._evaluate()
        self.assertEqual(record["status"], "denied")
        self.assertIn("dmreda_normal_false_authority_gate_failed", record["reasons"])

    def test_coherent_primary_failure_is_not_reported_as_disagreement(self) -> None:
        normal = deepcopy(
            __import__("json").loads(
                self.references["dmreda_normal_gate"].path.read_text(encoding="utf-8")
            )
        )
        normal["primary_dmreda"]["admitted"] = False
        normal["primary_dmreda"]["false_authority_count"] = 26
        normal.pop("summary_payload_sha256")
        normal["summary_payload_sha256"] = canonical_sha256(normal)
        path = self.references["dmreda_normal_gate"].path
        atomic_write_json(path, normal)
        self.references["dmreda_normal_gate"] = ArtifactReference(path, _digest(path))
        self.normal_manifest["artifact_sha256"]["dmreda_normal_summary"] = _digest(path)

        admission = evaluate_normal_admission_v2(
            dmreda_false_authority_count=26,
            dmreda_restricted_time_sum=470_000,
            reference_results={
                "rms": (6, 468_000),
                "cusum": (40, 420_000),
                "ewma": (7, 469_000),
            },
            reference_contracts_valid={
                "rms": True,
                "cusum": True,
                "ewma": True,
            },
        )
        self._replace_admission_coherently(admission)

        record = self._evaluate()
        self.assertEqual(record["status"], "denied")
        self.assertIn("dmreda_normal_false_authority_gate_failed", record["reasons"])
        self.assertNotIn("normal_summary_and_admission_disagree", record["reasons"])

    def test_unknown_reference_status_is_an_integrity_denial(self) -> None:
        import json

        path = self.references["scalar_reference_admission"].path
        admission = json.loads(path.read_text(encoding="utf-8"))
        admission["scalar_evidence_references"]["rms"]["admission_status"] = "unknown"
        atomic_write_json(path, admission)
        self.references["scalar_reference_admission"] = ArtifactReference(
            path, _digest(path)
        )
        record = self._evaluate()
        self.assertEqual(record["status"], "denied")
        self.assertIn("rms_reference_admission_status_invalid", record["reasons"])

    def test_worker_memory_probe_tamper_denies_bank_d(self) -> None:
        path = self.references["worker_memory_probe"].path
        payload = __import__("json").loads(path.read_text(encoding="utf-8"))
        payload["maximum_campaign_workers"] = 9
        atomic_write_json(path, payload)
        self.references["worker_memory_probe"] = ArtifactReference(
            path, _digest(path)
        )
        record = self._evaluate()
        self.assertEqual(record["status"], "denied")
        self.assertIn("worker_memory_probe_invalid", record["reasons"])

    def test_fault_free_access_chronology_tamper_denies_bank_d(self) -> None:
        path = self.references["fault_free_testing_open_event"].path
        payload = __import__("json").loads(path.read_text(encoding="utf-8"))
        payload["action"] = "reconstructed_after_access"
        atomic_write_json(path, payload)
        self.references["fault_free_testing_open_event"] = ArtifactReference(
            path, _digest(path)
        )
        record = self._evaluate()
        self.assertEqual(record["status"], "denied")
        self.assertIn("fault_free_testing_open_event_invalid", record["reasons"])

    def test_open_event_is_exclusive_and_hash_bound(self) -> None:
        record = self._evaluate()
        path = self.root / "BANK_D_ADMISSION_SEAL_V2.json"
        write_admission_record(path, record)
        event_path = self.root / "BANK_D_OPEN_EVENT_V2.json"
        event = open_bank_d_once_v2(
            admission_record_path=path,
            admission_file_sha256=_digest(path),
            open_event_path=event_path,
            opened_at_utc="2026-08-05T14:01:00Z",
        )
        self.assertEqual(event["coequal_onset_indices"], [159, 160])
        validate_bank_d_open_event_v2(event_path)
        with self.assertRaises(FileExistsError):
            open_bank_d_once_v2(
                admission_record_path=path,
                admission_file_sha256=_digest(path),
                open_event_path=event_path,
                opened_at_utc="2026-08-05T14:02:00Z",
            )


if __name__ == "__main__":
    unittest.main()
