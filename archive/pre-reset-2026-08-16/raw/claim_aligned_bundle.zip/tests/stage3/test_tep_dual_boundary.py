from __future__ import annotations

from dataclasses import replace
import unittest

from stage3.admission.serialization import canonical_json_bytes
from stage3.tep.dual_boundary import (
    BOUNDARY_SENSITIVITY_CATEGORIES,
    classify_dual_boundary_authority,
    invalid_dual_boundary_classification,
    validate_dual_boundary_classification,
    validate_dual_boundary_row,
)


class DualBoundaryClassificationTests(unittest.TestCase):
    def test_all_five_frozen_categories_are_constructible(self) -> None:
        cases = {
            "classification_flip_at_boundary": [159],
            "latency_shift_only": [160],
            "false_authority_under_both": [158],
            "no_authority_under_both": [],
        }
        observed = set()
        for expected, events in cases.items():
            with self.subTest(category=expected):
                result = classify_dual_boundary_authority(events, trace_length=960)
                self.assertEqual(result.boundary_sensitivity_category, expected)
                observed.add(expected)
        invalid = invalid_dual_boundary_classification(
            trace_length=960, integrity_failure_reason="synthetic integrity failure"
        )
        observed.add(invalid.boundary_sensitivity_category)
        self.assertEqual(observed, set(BOUNDARY_SENSITIVITY_CATEGORIES))

    def test_boundary_event_flips_category_without_false_latency(self) -> None:
        result = classify_dual_boundary_authority([159, 200], trace_length=960)
        self.assertEqual(result.first_authoritative_event, 159)
        self.assertEqual(result.outcome_onset_159.outcome, "valid_authority")
        self.assertEqual(result.outcome_onset_159.latency_samples, 0)
        self.assertEqual(result.outcome_onset_160.outcome, "false_authority")
        self.assertIsNone(result.outcome_onset_160.latency_samples)
        self.assertTrue(result.mutually_exclusive_outcome_changed)
        self.assertFalse(result.latency_shift_only)

    def test_later_event_has_exact_one_sample_latency_shift(self) -> None:
        for first in (160, 161, 500):
            with self.subTest(first=first):
                result = classify_dual_boundary_authority([first], trace_length=960)
                self.assertEqual(result.outcome_onset_159.outcome, "valid_authority")
                self.assertEqual(result.outcome_onset_160.outcome, "valid_authority")
                self.assertEqual(
                    result.outcome_onset_159.latency_samples,
                    result.outcome_onset_160.latency_samples + 1,
                )
                self.assertFalse(result.mutually_exclusive_outcome_changed)
                self.assertTrue(result.latency_shift_only)

    def test_first_event_owns_and_later_event_cannot_redeem_false_authority(self) -> None:
        result = classify_dual_boundary_authority([158, 200], trace_length=960)
        self.assertEqual(result.outcome_onset_159.outcome, "false_authority")
        self.assertEqual(result.outcome_onset_160.outcome, "false_authority")
        self.assertIsNone(result.outcome_onset_159.latency_samples)
        self.assertIsNone(result.outcome_onset_160.latency_samples)

    def test_malformed_events_fail_instead_of_becoming_invalid(self) -> None:
        for events in ([True], [-1], [960], [160, 160], [200, 160], [1.5]):
            with self.subTest(events=events), self.assertRaises((TypeError, ValueError)):
                classify_dual_boundary_authority(events, trace_length=960)
        with self.assertRaises(ValueError):
            invalid_dual_boundary_classification(
                trace_length=960, integrity_failure_reason=""
            )

    def test_validation_rejects_a_more_favorable_reclassification(self) -> None:
        valid = classify_dual_boundary_authority([159], trace_length=960)
        tampered = replace(
            valid,
            outcome_onset_160=valid.outcome_onset_159,
            boundary_sensitivity_category="latency_shift_only",
            mutually_exclusive_outcome_changed=False,
            latency_shift_only=True,
        )
        with self.assertRaisesRegex(ValueError, "first-event ownership"):
            validate_dual_boundary_classification(tampered)

    def test_machine_row_validation_and_serialization_are_deterministic(self) -> None:
        result = classify_dual_boundary_authority([160, 400], trace_length=960)
        row = {"sample_count": 960, **result.to_dict()}
        validate_dual_boundary_row(row)
        self.assertEqual(canonical_json_bytes(row), canonical_json_bytes(dict(row)))
        row["latency_onset_159"] = 0
        with self.assertRaisesRegex(ValueError, "inconsistent"):
            validate_dual_boundary_row(row)


if __name__ == "__main__":
    unittest.main()
