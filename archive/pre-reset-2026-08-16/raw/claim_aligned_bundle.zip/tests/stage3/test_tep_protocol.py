from __future__ import annotations

from pathlib import Path
from copy import deepcopy
import tempfile
import unittest

from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig
from stage3.admission.serialization import canonical_sha256
from stage3.tep.onset_authority import build_dual_boundary_contract
from stage3.tep.protocol import (
    DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
    EXPECTED_RAW_DATASET_SHA256,
    SCIENTIFIC_IDENTITY,
    build_protocol_payload,
    build_protocol_payload_v2,
    freeze_protocol,
    freeze_protocol_v2,
    validate_frozen_protocol,
    validate_frozen_protocol_v2,
    validate_protocol_payload_v2,
)
from stage3.tep.representation_validation import (
    FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
    FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256,
)
from stage3.tep.arbitration_validation import (
    FROZEN_ARBITRATION_EXPECTATIONS_SHA256,
)
from stage3.tep.runner import DetectorSpec


DIGEST = "d" * 64
COMMIT = "c" * 40


def build() -> dict[str, object]:
    return build_protocol_payload(
        freeze_timestamp_utc="2026-08-05T12:00:00Z",
        source_commit=COMMIT,
        source_hashes={"core": DIGEST, "baselines": DIGEST, "metrics": DIGEST},
        raw_dataset_hashes={"ff_train": DIGEST, "ff_test": DIGEST, "faulty_test": DIGEST},
        dataset_authority={"status": "verified_primary_source"},
        baseline_configurations={
            name: {"threshold": 1.0} for name in ("rms", "cusum", "ewma")
        },
        onset_mapping={
            "status": "resolved",
            "python_onset_index": 159,
            "first_fault_affected_sample_label": 160,
        },
        implementation_version="stage3.2-test",
    )


def _reference_record(detector: DetectorSpec, structural: dict[str, object]) -> dict[str, object]:
    configuration = detector.to_dict()
    return {
        "status": "frozen_from_fault_free_training_101_200",
        "configuration": configuration,
        "configuration_sha256": canonical_sha256(configuration),
        "structural_parameters": structural,
        "calibration": {
            "partition": "fault_free_training",
            "simulation_runs": [101, 200],
            "trajectory_count": 100,
            "horizon": 500,
            "target_false_authority_count": 3,
            "target_restricted_time_sum": 49283,
            "selection_objective": [
                "absolute_false_positive_count_deviation",
                "absolute_restricted_time_sum_deviation",
                "higher_threshold",
            ],
            "input_bank_sha256": DIGEST,
            "calibration_result_sha256": DIGEST,
        },
    }


def build_v2() -> dict[str, object]:
    gate = EventGateConfig(warmup_samples=92, persistence=20, refractory=80)
    references = {
        "rms": _reference_record(
            DetectorSpec.rms(threshold=1.25, gate=gate, window=32),
            {"window": 32},
        ),
        "cusum": _reference_record(
            DetectorSpec.cusum(
                threshold=2.5,
                gate=gate,
                center=0.0,
                allowance=0.5,
            ),
            {
                "allowance": 0.5,
                "allowance_sigma": 0.5,
                "center": 0.0,
                "scale": 1.0,
            },
        ),
        "ewma": _reference_record(
            DetectorSpec.ewma(
                threshold=0.75,
                gate=gate,
                center=0.0,
                scale=1.0,
                alpha=2.0 / 33.0,
            ),
            {"alpha": 2.0 / 33.0, "center": 0.0, "scale": 1.0},
        ),
    }
    dual = build_dual_boundary_contract(
        frozen_at_utc="2026-08-05T10:29:21Z",
        source_commit=COMMIT,
        onset_authority_evidence_sha256=DIGEST,
    )
    return build_protocol_payload_v2(
        freeze_timestamp_utc="2026-08-05T13:00:00Z",
        source_commit=COMMIT,
        source_hashes={
            "core": DIGEST,
            "runner": DIGEST,
            "statistics": DIGEST,
            "stage3/tep/normal_gate.py": DIGEST,
        },
        raw_dataset_hashes=EXPECTED_RAW_DATASET_SHA256,
        dataset_authority={
            "authority_status": "verified_primary_source",
            "admission_level": "claim_grade_candidate",
        },
        scalar_reference_configurations=references,
        dual_boundary_contract=dual,
        dual_boundary_candidate_file_sha256=DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        layer_a_binding={
            "status": "passed",
            "expectations_sha256": FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
            "fixture_contract_sha256": FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256,
            "result_payload_sha256": DIGEST,
            "result_file_sha256": DIGEST,
        },
        layer_b_binding={
            "status": "passed",
            "expectations_sha256": FROZEN_ARBITRATION_EXPECTATIONS_SHA256,
            "result_payload_sha256": DIGEST,
            "result_file_sha256": DIGEST,
            "same_sample_timeout_rearm": "unresolved_design_choice_preserved",
            "policy_changed": False,
        },
        pre_freeze_validation={
            "status": "passed",
            "worktree_clean": True,
            "full_test_report_sha256": DIGEST,
            "output_guard_report_sha256": DIGEST,
            "git_state_sha256": DIGEST,
        },
        access_evidence_sha256=DIGEST,
        implementation_version="stage3.3-test",
    )


class ProtocolTests(unittest.TestCase):
    def test_protocol_binds_corrected_identity_native_authority_and_frozen_values(self) -> None:
        payload = build()
        self.assertEqual(payload["scientific_identity"]["primary"], SCIENTIFIC_IDENTITY)
        self.assertEqual(
            set(payload["scientific_identity"]["layers"]),
            {"layer_a", "layer_b", "layer_c"},
        )
        self.assertEqual(
            payload["event_authority_contract"]["dmreda"],
            "native_pending_confirmation_refractory_external_authority",
        )
        config = payload["channel_and_core_configuration"]
        self.assertEqual(config["sensitivity"]["kappa"], 2.5)
        self.assertEqual(config["core"]["warmup_samples"], 92)

    def test_unresolved_onset_or_machine_path_fails_before_freeze(self) -> None:
        with self.assertRaisesRegex(ValueError, "onset"):
            build_protocol_payload(
                freeze_timestamp_utc="2026-08-05T12:00:00Z",
                source_commit=COMMIT,
                source_hashes={"core": DIGEST},
                raw_dataset_hashes={"raw": DIGEST},
                dataset_authority={"status": "verified_primary_source"},
                baseline_configurations={name: {} for name in ("rms", "cusum", "ewma")},
                onset_mapping={"status": "unresolved"},
                implementation_version="test",
            )
        payload = build()
        payload["dataset_authority"] = {"path": "/Users/example/private"}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with self.assertRaisesRegex(ValueError, "machine-specific"):
                freeze_protocol(
                    json_path=root / "p.json",
                    markdown_path=root / "p.md",
                    manifest_path=root / "manifest.json",
                    payload=payload,
                )

    def test_freeze_is_immutable_hash_bound_and_requires_completion_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = {
                "json_path": root / "protocol.json",
                "markdown_path": root / "protocol.md",
                "manifest_path": root / "manifest.json",
            }
            freeze_protocol(payload=build(), **paths)
            restored = validate_frozen_protocol(**paths)
            self.assertEqual(restored["source_commit"], COMMIT)
            with self.assertRaises(FileExistsError):
                freeze_protocol(payload=build(), **paths)
            paths["markdown_path"].write_text("tampered", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Markdown"):
                validate_frozen_protocol(**paths)


class ProtocolV2Tests(unittest.TestCase):
    def test_v2_binds_coequal_onsets_identity_and_comparator_independence(self) -> None:
        payload = build_v2()
        self.assertEqual(payload["scientific_identity"]["primary"], SCIENTIFIC_IDENTITY)
        dual = payload["dual_boundary_contract"]
        self.assertEqual(dual["coequal_python_onset_indices"], [159, 160])
        self.assertIsNone(dual["selected_mapping"])
        self.assertFalse(dual["unique_primary_boundary"])
        self.assertFalse(
            payload["scalar_reference_admission_policy"][
                "primary_bank_d_admission_depends_on_scalar_reference_admission"
            ]
        )
        self.assertNotIn(
            "any_scalar_reference_risk_match_failure", payload["stop_rules"]
        )

    def test_v2_rejects_boundary_selection_core_change_and_comparator_veto(self) -> None:
        selected = deepcopy(build_v2())
        selected["dual_boundary_contract"]["selected_mapping"] = "label_161_index_160"
        with self.assertRaisesRegex(ValueError, "co-equal"):
            validate_protocol_payload_v2(selected)

        core_changed = deepcopy(build_v2())
        core_changed["channel_and_core_configuration"]["core"]["warmup_samples"] = 93
        with self.assertRaisesRegex(ValueError, "Core"):
            validate_protocol_payload_v2(core_changed)

        comparator_veto = deepcopy(build_v2())
        comparator_veto["scalar_reference_admission_policy"][
            "primary_bank_d_admission_depends_on_scalar_reference_admission"
        ] = True
        with self.assertRaisesRegex(ValueError, "primary veto"):
            validate_protocol_payload_v2(comparator_veto)

    def test_v2_freeze_is_exclusive_and_hash_bound(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = {
                "json_path": root / "protocol_v2.json",
                "markdown_path": root / "protocol_v2.md",
                "manifest_path": root / "protocol_v2.manifest.json",
            }
            freeze_protocol_v2(payload=build_v2(), **paths)
            restored = validate_frozen_protocol_v2(**paths)
            self.assertEqual(restored["source_commit"], COMMIT)
            markdown = paths["markdown_path"].read_text(encoding="utf-8")
            self.assertIn("Python onset index 159", markdown)
            self.assertIn("Python onset index 160", markdown)
            self.assertIn("cannot veto", markdown)
            with self.assertRaises(FileExistsError):
                freeze_protocol_v2(payload=build_v2(), **paths)
            paths["json_path"].write_text("{}\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "JSON"):
                validate_frozen_protocol_v2(**paths)


if __name__ == "__main__":
    unittest.main()
