"""Regression tests for the canonical DMREDA paths."""
