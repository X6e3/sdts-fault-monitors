from __future__ import annotations

import ctypes
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import numpy as np

from tests.golden_support import (
    MODE_TO_C,
    compute_fixed_python,
    configuration_sha256,
    decode_runs,
    generate_signal,
    load_golden_set,
    signal_sha256,
)


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


class CConfig(ctypes.Structure):
    _fields_ = [
        ("w1", ctypes.c_int),
        ("w2", ctypes.c_int),
        ("beta", ctypes.c_double),
        ("rho", ctypes.c_double),
        ("m", ctypes.c_int),
        ("lambda_", ctypes.c_double),
        ("th_d", ctypes.c_double),
        ("th_g", ctypes.c_double),
        ("th_d2", ctypes.c_double),
        ("th_a", ctypes.c_double),
        ("n_min", ctypes.c_int),
        ("e_floor", ctypes.c_double),
        ("confirm_len", ctypes.c_int),
        ("refractory", ctypes.c_int),
        ("g_ref", ctypes.c_double),
        ("warmup_samples", ctypes.c_size_t),
        ("d_min", ctypes.c_double),
        ("d_max", ctypes.c_double),
        ("mode", ctypes.c_int),
    ]


class COutput(ctypes.Structure):
    _fields_ = [
        ("sample_index", ctypes.c_size_t),
        ("mu", ctypes.c_double),
        ("e", ctypes.c_double),
        ("e1", ctypes.c_double),
        ("e_baseline", ctypes.c_double),
        ("e_baseline_safe", ctypes.c_double),
        ("d", ctypes.c_double),
        ("g_raw", ctypes.c_double),
        ("g", ctypes.c_double),
        ("r", ctypes.c_double),
        ("a", ctypes.c_double),
        ("state", ctypes.c_int),
        ("m_eff", ctypes.c_int),
        ("confirm_len_eff", ctypes.c_int),
        ("pending", ctypes.c_int),
        ("confirmed", ctypes.c_int),
        ("event_active", ctypes.c_int),
    ]


class CState(ctypes.Structure):
    _fields_ = [
        ("config", CConfig),
        ("sample_count", ctypes.c_size_t),
        ("sample_ring", ctypes.c_double * 15),
        ("sample_ring_count", ctypes.c_int),
        ("sample_ring_pos", ctypes.c_int),
        ("error_ring", ctypes.c_double * 64),
        ("error_ring_count", ctypes.c_int),
        ("error_ring_pos", ctypes.c_int),
        ("e1_sum", ctypes.c_double),
        ("e_baseline", ctypes.c_double),
        ("r", ctypes.c_double),
        ("d_ring", ctypes.c_double * 16),
        ("d_ring_count", ctypes.c_int),
        ("d_ring_pos", ctypes.c_int),
        ("g", ctypes.c_double),
        ("pending_active", ctypes.c_int),
        ("pending_elapsed", ctypes.c_int),
        ("pending_area", ctypes.c_double),
        ("pending_count", ctypes.c_int),
        ("refractory_remaining", ctypes.c_int),
    ]


def config_from_fixture(configuration: dict[str, object]) -> CConfig:
    fixed = configuration["fixed_c"]
    assert isinstance(fixed, dict)
    return CConfig(
        w1=int(fixed["w1"]),
        w2=int(fixed["w2"]),
        beta=float(fixed["beta"]),
        rho=float(fixed["rho"]),
        m=int(fixed["m"]),
        lambda_=float(fixed["lambda"]),
        th_d=float(fixed["th_d"]),
        th_g=float(fixed["th_g"]),
        th_d2=float(fixed["th_d2"]),
        th_a=float(fixed["th_a"]),
        n_min=int(fixed["n_min"]),
        e_floor=float(fixed["e_floor"]),
        confirm_len=int(fixed["confirm_len"]),
        refractory=int(fixed["refractory"]),
        g_ref=float(fixed["g_ref"]),
        warmup_samples=int(fixed["warmup_samples"]),
        d_min=float(fixed["d_min"]),
        d_max=float(fixed["d_max"]),
        mode=MODE_TO_C[str(fixed["mode"])],
    )


class ImmutableGoldenVectorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.golden = load_golden_set()
        compiler = shutil.which("clang") or shutil.which("cc")
        if compiler is None:
            raise unittest.SkipTest("no C99 compiler available")
        cls._tempdir = tempfile.TemporaryDirectory(prefix="dmreda-golden-")
        suffix = ".dylib" if sys.platform == "darwin" else ".so"
        cls.library_path = Path(cls._tempdir.name) / f"libdmreda_fixed{suffix}"
        shared_flags = ["-dynamiclib"] if sys.platform == "darwin" else ["-shared", "-fPIC"]
        subprocess.run(
            [
                compiler,
                "-std=c99",
                "-O2",
                "-Wall",
                "-Wextra",
                "-Werror",
                *shared_flags,
                str(REPOSITORY_ROOT / "gold_line/core/dmreda_streaming_fixed.c"),
                "-lm",
                "-o",
                str(cls.library_path),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        cls.library = ctypes.CDLL(str(cls.library_path))
        cls.library.dmreda_fixed_init.argtypes = [
            ctypes.POINTER(CState),
            ctypes.POINTER(CConfig),
        ]
        cls.library.dmreda_fixed_init.restype = ctypes.c_int
        cls.library.dmreda_fixed_step.argtypes = [
            ctypes.POINTER(CState),
            ctypes.c_double,
            ctypes.POINTER(COutput),
        ]
        cls.library.dmreda_fixed_step.restype = ctypes.c_int

    @classmethod
    def tearDownClass(cls) -> None:
        cls._tempdir.cleanup()

    @classmethod
    def run_c(cls, signal: np.ndarray, configuration: dict[str, object]) -> dict[str, np.ndarray]:
        config = config_from_fixture(configuration)
        state = CState()
        if cls.library.dmreda_fixed_init(ctypes.byref(state), ctypes.byref(config)) != 0:
            raise AssertionError("C fixture configuration was rejected")

        collected = {
            "mu": [],
            "e1": [],
            "d": [],
            "g": [],
            "state": [],
            "pending": [],
            "confirmed": [],
            "event_active": [],
        }
        for index, sample in enumerate(signal):
            output = COutput()
            status = cls.library.dmreda_fixed_step(
                ctypes.byref(state), float(sample), ctypes.byref(output)
            )
            if status != 0:
                raise AssertionError(f"C step rejected fixture sample {index}")
            if output.sample_index != index:
                raise AssertionError("C sample index drift")
            for field in collected:
                collected[field].append(getattr(output, field))
        return {
            field: np.asarray(values)
            for field, values in collected.items()
        }

    def test_required_fixture_inventory(self) -> None:
        names = [fixture["fixture_name"] for fixture in self.golden["fixtures"]]
        self.assertEqual(
            names,
            [
                "constant_signal",
                "anomaly_entirely_inside_warmup",
                "post_warmup_step",
                "impulse_followed_by_ramp",
                "alternating_sign_signal",
                "confirmation_length_boundary",
                "refractory_boundary",
                "ring_buffer_wrap_boundary",
            ],
        )

    def test_python_and_c_match_the_same_immutable_fixture(self) -> None:
        for fixture in self.golden["fixtures"]:
            with self.subTest(fixture=fixture["fixture_name"]):
                input_contract = fixture["input"]
                signal = generate_signal(input_contract["generator_definition"])
                self.assertEqual(
                    signal_sha256(signal),
                    input_contract["float64_little_endian_sha256"],
                )
                configuration = fixture["configuration"]
                self.assertEqual(
                    configuration_sha256(configuration),
                    fixture["configuration_sha256"],
                )
                self.assertEqual(
                    configuration["fixed_c"]["warmup_samples"],
                    fixture["expected_warmup_samples"],
                )

                expected = fixture["expected"]
                expected_discrete = {
                    "state": decode_runs(expected["state_trace_rle"]),
                    "pending": decode_runs(expected["pending_trace_rle"]),
                    "confirmed": decode_runs(expected["confirmation_trace_rle"]),
                    "event_active": decode_runs(expected["event_active_trace_rle"]),
                }
                for field, values in expected_discrete.items():
                    self.assertEqual(values.size, signal.size, field)

                python = compute_fixed_python(signal, configuration)
                c_result = self.run_c(signal, configuration)
                for field, expected_values in expected_discrete.items():
                    np.testing.assert_array_equal(
                        getattr(python, field).astype(np.int64), expected_values
                    )
                    np.testing.assert_array_equal(
                        c_result[field].astype(np.int64), expected_values
                    )

                python_events = list(np.flatnonzero(python.confirmed))
                c_events = list(np.flatnonzero(c_result["confirmed"]))
                self.assertEqual(python_events, expected["event_indices"])
                self.assertEqual(c_events, expected["event_indices"])

                absolute = float(fixture["numeric_tolerance"]["absolute"])
                relative = float(fixture["numeric_tolerance"]["relative"])
                python_fields = {
                    "mu": python.mu,
                    "E1": python.e1,
                    "D": python.d,
                    "G": python.g,
                }
                c_fields = {
                    "mu": c_result["mu"],
                    "E1": c_result["e1"],
                    "D": c_result["d"],
                    "G": c_result["g"],
                }
                for checkpoint in expected["selected_float_trace"]:
                    index = int(checkpoint["index"])
                    for field in ("mu", "E1", "D", "G"):
                        np.testing.assert_allclose(
                            python_fields[field][index],
                            float(checkpoint[field]),
                            rtol=relative,
                            atol=absolute,
                        )
                        np.testing.assert_allclose(
                            c_fields[field][index],
                            float(checkpoint[field]),
                            rtol=relative,
                            atol=absolute,
                        )


if __name__ == "__main__":
    unittest.main()
