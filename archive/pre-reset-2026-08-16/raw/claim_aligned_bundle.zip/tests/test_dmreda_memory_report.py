from __future__ import annotations

import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import unittest


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


class DmredaMemoryReportTests(unittest.TestCase):
    def test_host_report_distinguishes_persistent_state_from_total_ram(self) -> None:
        if sys.platform != "darwin" or platform.machine() != "arm64":
            self.skipTest("checked size assertions describe the recorded arm64 macOS ABI")
        with tempfile.TemporaryDirectory(prefix="dmreda-memory-test-") as directory:
            output = Path(directory) / "memory.json"
            subprocess.run(
                [
                    sys.executable,
                    "tools/report_dmreda_memory.py",
                    "--output-json",
                    str(output),
                ],
                cwd=REPOSITORY_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            report = json.loads(output.read_text(encoding="utf-8"))

        structures = report["structures_and_known_scratch"]
        self.assertEqual(structures["sizeof_dmreda_fixed_config"], 136)
        self.assertEqual(structures["sizeof_dmreda_fixed_state"], 984)
        self.assertEqual(structures["sizeof_dmreda_fixed_output"], 112)
        self.assertEqual(
            structures["known_local_scratch_arrays"][
                "trailing_median_sorted_bytes"
            ],
            120,
        )
        self.assertEqual(
            report["allowed_claim"],
            "The verified persistent runtime state structure occupies 984 "
            "bytes on the tested arm64 ABI.",
        )
        self.assertEqual(report["core_object_sections"]["data_bytes"], 0)
        self.assertEqual(report["core_object_sections"]["bss_bytes"], 0)
        self.assertGreater(report["core_object_sections"]["text_bytes"], 0)
        self.assertEqual(
            report["compiler_static_stack_usage"]["dmreda_fixed_step"]["bytes"],
            144,
        )
        limitations = " ".join(report["interpretation_limits"])
        self.assertIn("not total runtime RAM", limitations)
        self.assertIn("MCU peak stack", limitations)


if __name__ == "__main__":
    unittest.main()
