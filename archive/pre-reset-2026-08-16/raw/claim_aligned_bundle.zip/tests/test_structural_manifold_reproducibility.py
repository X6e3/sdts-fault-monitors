from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

import numpy as np

from gold_line.structural_manifold import pqd16c_benchmark as benchmark


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


class StructuralManifoldReproducibilityTests(unittest.TestCase):
    def test_offline_mode_never_falls_back_to_download(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(benchmark, "download_pqd16c") as download:
                with self.assertRaises(FileNotFoundError):
                    benchmark.resolve_dataset_archive(
                        explicit_archive=None,
                        cache_dir=Path(directory),
                        offline=True,
                    )
            download.assert_not_called()

    def test_explicit_archive_is_content_identified(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive = root / "content-fixture.zip"
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED) as handle:
                handle.writestr("fixture.csv", "value\n0.0\n1.0\n")

            resolved = benchmark.resolve_dataset_archive(
                explicit_archive=archive,
                cache_dir=root / "missing-cache",
                offline=True,
            )
            manifest = benchmark.dataset_archive_manifest(resolved)
            self.assertEqual(
                manifest["sha256"], hashlib.sha256(archive.read_bytes()).hexdigest()
            )
            self.assertEqual(manifest["member_count"], 1)

            changed = root / "changed-content.zip"
            with zipfile.ZipFile(changed, "w", compression=zipfile.ZIP_STORED) as handle:
                handle.writestr("fixture.csv", "value\n0.0\n2.0\n")
            changed_manifest = benchmark.dataset_archive_manifest(changed)
            self.assertNotEqual(manifest["sha256"], changed_manifest["sha256"])

    def test_configuration_hash_is_array_content_and_threshold_sensitive(self) -> None:
        first = {
            "threshold": 2.0,
            "centroid": np.array([1.0, 2.0], dtype=np.float64),
        }
        same = {
            "centroid": np.array([1.0, 2.0], dtype=np.float64),
            "threshold": 2.0,
        }
        changed_array = {**first, "centroid": np.array([1.0, 3.0])}
        changed_threshold = {**first, "threshold": 2.1}
        self.assertEqual(benchmark.config_hash(first), benchmark.config_hash(same))
        self.assertNotEqual(
            benchmark.config_hash(first), benchmark.config_hash(changed_array)
        )
        self.assertNotEqual(
            benchmark.config_hash(first), benchmark.config_hash(changed_threshold)
        )

    def test_structural_calibration_reports_unobservable_target_as_censored(self) -> None:
        scores = [np.array([0.0, 1.0, 2.0]), np.array([0.0, 0.5, 1.0])]
        indices = [np.arange(3), np.arange(3)]
        result = benchmark.calibrate_threshold_noise(
            scores,
            indices,
            target_arl=10.0,
            persistence=1,
            signal_lengths=[3, 3],
        )
        self.assertEqual(result.achieved_restricted_mean_time_to_alarm, 3.0)
        self.assertEqual(result.achieved_statistics.censoring_rate, 1.0)
        self.assertEqual(result.target_deviation, -7.0)

    def test_strict_json_replaces_nonfinite_values_with_null(self) -> None:
        text = benchmark.strict_json_dumps(
            {"finite": 1.0, "nan": math.nan, "positive_infinity": math.inf}
        )
        self.assertNotIn("NaN", text)
        self.assertNotIn("Infinity", text)
        self.assertEqual(
            json.loads(text),
            {"finite": 1.0, "nan": None, "positive_infinity": None},
        )

    def test_canonical_and_compatibility_wrapper_smoke_outputs_match(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            canonical_json = output / "canonical.json"
            canonical_csv = output / "canonical.csv"
            wrapper_json = output / "wrapper.json"
            wrapper_csv = output / "wrapper.csv"
            package_wrapper_json = output / "package-wrapper.json"
            package_wrapper_csv = output / "package-wrapper.csv"
            common = ["--synthetic-smoke", "--runs", "2"]
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "gold_line.structural_manifold.pqd16c_benchmark",
                    *common,
                    "--output-json",
                    str(canonical_json),
                    "--output-csv",
                    str(canonical_csv),
                ],
                cwd=REPOSITORY_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            subprocess.run(
                [
                    sys.executable,
                    "dmreda_pqd16c_streaming_benchmark.py",
                    *common,
                    "--output-json",
                    str(wrapper_json),
                    "--output-csv",
                    str(wrapper_csv),
                ],
                cwd=REPOSITORY_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark",
                    *common,
                    "--output-json",
                    str(package_wrapper_json),
                    "--output-csv",
                    str(package_wrapper_csv),
                ],
                cwd=REPOSITORY_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            self.assertEqual(canonical_json.read_bytes(), wrapper_json.read_bytes())
            self.assertEqual(canonical_csv.read_bytes(), wrapper_csv.read_bytes())
            self.assertEqual(
                canonical_json.read_bytes(), package_wrapper_json.read_bytes()
            )
            self.assertEqual(
                canonical_csv.read_bytes(), package_wrapper_csv.read_bytes()
            )
            payload = json.loads(canonical_json.read_text(encoding="utf-8"))
            self.assertEqual(
                payload["validation_level"], "deterministic_synthetic_smoke_only"
            )
            self.assertFalse(payload["scientific_validation"])
            self.assertEqual(
                sorted(payload["detectors"]), ["rms", "structural_manifold"]
            )
            self.assertTrue(payload["banks_are_content_disjoint"])
            for detector in payload["detectors"].values():
                self.assertIn("censoring_rate", detector["achieved_operating_statistics"])
                self.assertIn(
                    "achieved_operating_target_deviation_samples", detector
                )
                self.assertIn("event_contract", detector)

    def test_help_paths_do_not_attempt_kaggle_authentication(self) -> None:
        commands = (
            [
                sys.executable,
                "-m",
                "gold_line.structural_manifold.pqd16c_benchmark",
                "--help",
            ],
            [sys.executable, "dmreda_pqd16c_streaming_benchmark.py", "--help"],
            [
                sys.executable,
                "-m",
                "gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark",
                "--help",
            ],
        )
        with tempfile.TemporaryDirectory() as directory:
            environment = dict(os.environ)
            environment.pop("KAGGLE_USERNAME", None)
            environment.pop("KAGGLE_KEY", None)
            environment["KAGGLE_CONFIG_DIR"] = directory
            for command in commands:
                with self.subTest(command=command):
                    completed = subprocess.run(
                        command,
                        cwd=REPOSITORY_ROOT,
                        env=environment,
                        capture_output=True,
                        text=True,
                        check=False,
                    )
                    self.assertEqual(completed.returncode, 0, completed.stderr)
                    self.assertIn("--offline", completed.stdout)


if __name__ == "__main__":
    unittest.main()
