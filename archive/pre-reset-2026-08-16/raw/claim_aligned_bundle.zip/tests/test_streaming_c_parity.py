from __future__ import annotations

import csv
import io
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    RegimeTransition,
    compute_dmreda_reference,
)


REPO_ROOT = Path(__file__).resolve().parents[1]
FIXED_RANDOM_SEEDS = tuple(range(10_000, 10_100))
FIXED_WARMUPS = (0, 1, 91, 92, 93)
FIXED_MODES = ("d_only", "g_only", "d_or_g")
WRAP_BOUNDARY_LENGTHS = (
    1,
    3,
    4,
    5,
    6,
    7,
    8,
    15,
    16,
    17,
    31,
    32,
    33,
    63,
    64,
    65,
    91,
    92,
    93,
    127,
    128,
    129,
    191,
    257,
)


def randomized_case(seed: int, case_index: int) -> tuple[str, np.ndarray]:
    """Generate bounded deterministic disturbances without future leakage."""

    rng = np.random.default_rng(seed)
    length = WRAP_BOUNDARY_LENGTHS[case_index % len(WRAP_BOUNDARY_LENGTHS)]
    pattern_index = case_index % 10

    if pattern_index == 0:
        return "constant", np.full(length, (case_index % 3 - 1) * 0.1)
    if pattern_index == 1:
        return "low_noise", rng.normal(0.0, 1e-4, length)
    if pattern_index == 2:
        return "high_noise", rng.normal(0.0, 1.0, length)
    if pattern_index == 3:
        signal = rng.normal(0.0, 0.02, length)
        signal[length // 2 :] += 0.8
        return "step", signal
    if pattern_index == 4:
        signal = rng.normal(0.0, 0.03, length)
        signal[length // 2] += 2.0
        return "impulse", signal
    if pattern_index == 5:
        signal = rng.normal(0.0, 0.02, length)
        width = max(1, min(5, length // 4))
        for start in range(max(1, length // 5), length, max(3, length // 3)):
            signal[start : start + width] += 1.0
        return "bursts", signal
    if pattern_index == 6:
        signal = rng.normal(0.0, 0.01, length)
        start = length // 3
        signal[start:] += np.linspace(0.0, 1.2, length - start)
        return "ramp", signal
    if pattern_index == 7:
        amplitude = 0.2 + 0.05 * (case_index % 5)
        signal = amplitude * np.where(np.arange(length) % 2 == 0, 1.0, -1.0)
        return "alternating_sign", signal
    if pattern_index == 8:
        signal = rng.normal(0.0, 0.04, length)
        if length > 1:
            signal[length // 4] += 1.5
            signal[length // 2 :] += np.linspace(0.0, 0.7, length - length // 2)
            signal[3 * length // 4 :] -= 0.4
        return "mixed_disturbances", signal

    pattern = np.array([0.0, 0.2, -0.1, 0.4, -0.3, 0.1], dtype=np.float64)
    return "repeated_pattern", np.resize(pattern, length)


class StreamingCParityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        compiler = shutil.which("clang") or shutil.which("cc")
        if compiler is None:
            raise unittest.SkipTest("no C99 compiler available")
        cls._tempdir = tempfile.TemporaryDirectory(prefix="dmreda-c-parity-")
        cls.binary = Path(cls._tempdir.name) / "dmreda_streaming_fixed_cli"
        subprocess.run(
            [
                compiler,
                "-std=c99",
                "-O2",
                "-Wall",
                "-Wextra",
                "-Werror",
                str(REPO_ROOT / "gold_line/core/dmreda_streaming_fixed.c"),
                str(REPO_ROOT / "gold_line/support/dmreda_streaming_fixed_cli.c"),
                "-lm",
                "-o",
                str(cls.binary),
            ],
            check=True,
            capture_output=True,
            text=True,
        )

    @classmethod
    def tearDownClass(cls) -> None:
        cls._tempdir.cleanup()

    def run_c(
        self,
        signal: np.ndarray,
        *,
        warmup_samples: int = 92,
        mode: str = "d_or_g",
    ) -> list[dict[str, str]]:
        completed = subprocess.run(
            [str(self.binary), str(warmup_samples), mode],
            input="".join(f"{sample:.17g}\n" for sample in signal),
            capture_output=True,
            text=True,
            check=True,
        )
        return list(csv.DictReader(io.StringIO(completed.stdout)))

    def assert_parity(
        self,
        signal: np.ndarray,
        *,
        warmup_samples: int = 92,
        mode: str = "d_or_g",
        absolute_tolerance: float = 5e-12,
    ) -> None:
        rows = self.run_c(
            signal, warmup_samples=warmup_samples, mode=mode
        )
        result = compute_dmreda_reference(
            signal,
            profiles={0: DEFAULT_PROFILES[0]},
            transitions={0: RegimeTransition()},
            regime_tick=signal.size + 1,
            warmup_samples=warmup_samples,
            mode=mode,
        )
        self.assertEqual(len(rows), signal.size)

        for field in ("mu", "e", "e1", "e_baseline", "e_baseline_safe", "d", "g_raw", "g", "r", "a"):
            c_values = np.array([float(row[field]) for row in rows], dtype=np.float64)
            np.testing.assert_allclose(
                c_values,
                getattr(result, field),
                rtol=0.0,
                atol=absolute_tolerance,
            )
        for field in ("state", "m_eff", "confirm_len_eff", "pending", "confirmed", "event_active"):
            c_values = np.array([int(row[field]) for row in rows], dtype=np.int64)
            np.testing.assert_array_equal(c_values, getattr(result, field).astype(np.int64))

        c_events = [index for index, row in enumerate(rows) if int(row["confirmed"])]
        self.assertEqual(c_events, result.event_times)

    def test_noise_then_step_parity(self) -> None:
        signal = np.random.default_rng(29).normal(0.0, 0.05, 512)
        signal[180:220] += 0.8
        self.assert_parity(signal)

    def test_impulse_and_ramp_parity(self) -> None:
        signal = np.random.default_rng(41).normal(0.0, 0.03, 640)
        signal[180] += 2.0
        signal[360:520] += np.linspace(0.0, 0.9, 160)
        self.assert_parity(signal)

    def test_c_mirror_has_no_pre_warmup_event_authority(self) -> None:
        signal = np.zeros(256, dtype=np.float64)
        signal[1:] = 1.0
        rows = self.run_c(signal)
        self.assertFalse(any(int(row["pending"]) for row in rows[:92]))
        self.assertFalse(any(int(row["confirmed"]) for row in rows[:92]))

    def test_one_hundred_seed_randomized_fixed_subset_parity(self) -> None:
        """Normal-CI parity matrix: 100 fixed seeds across all declared modes."""

        observed_patterns: set[str] = set()
        observed_lengths: set[int] = set()
        observed_warmups: set[int] = set()
        observed_modes: set[str] = set()

        for case_index, seed in enumerate(FIXED_RANDOM_SEEDS):
            pattern, signal = randomized_case(seed, case_index)
            warmup = FIXED_WARMUPS[case_index % len(FIXED_WARMUPS)]
            mode = FIXED_MODES[case_index % len(FIXED_MODES)]
            with self.subTest(
                seed=seed,
                pattern=pattern,
                length=signal.size,
                warmup=warmup,
                mode=mode,
            ):
                self.assert_parity(
                    signal,
                    warmup_samples=warmup,
                    mode=mode,
                )
            observed_patterns.add(pattern)
            observed_lengths.add(int(signal.size))
            observed_warmups.add(warmup)
            observed_modes.add(mode)

        self.assertEqual(len(FIXED_RANDOM_SEEDS), 100)
        self.assertEqual(
            observed_patterns,
            {
                "constant",
                "low_noise",
                "high_noise",
                "step",
                "impulse",
                "bursts",
                "ramp",
                "alternating_sign",
                "mixed_disturbances",
                "repeated_pattern",
            },
        )
        self.assertEqual(observed_lengths, set(WRAP_BOUNDARY_LENGTHS))
        self.assertEqual(observed_warmups, set(FIXED_WARMUPS))
        self.assertEqual(observed_modes, set(FIXED_MODES))


if __name__ == "__main__":
    unittest.main()
