from __future__ import annotations

from dataclasses import replace
import unittest

import numpy as np

from experimental.finalization.run_development_ablation import (
    KAPPA_GRID,
    WARMUP,
    compute_representation,
    fixed_confirmation_profiles,
    fixed_profiles,
    full_profiles,
    full_transitions,
    native_authority_grid,
    no_regime_profiles,
)
from experimental.finalization.minimal_state_model import (
    MinimalAuthorityState,
    OpenContract,
    state_collision_witnesses,
    step_authority,
)
from gold_line.core.dmreda_reference_clean import compute_dmreda_reference


THRESHOLD_FIELDS = ("th_d", "th_g", "th_d2", "th_a")


def scaled_profiles(profiles, kappa):
    return {
        state: replace(
            profile,
            **{
                field: getattr(profile, field) * kappa
                for field in THRESHOLD_FIELDS
            },
        )
        for state, profile in profiles.items()
    }


class FinalizationAblationTests(unittest.TestCase):
    def test_kappa_grid_is_complete_and_stable(self) -> None:
        self.assertEqual(KAPPA_GRID.size, 311)
        self.assertEqual(KAPPA_GRID[0], 0.5)
        self.assertEqual(KAPPA_GRID[-1], 16.0)
        np.testing.assert_allclose(np.diff(KAPPA_GRID), 0.05, atol=1e-15)

    def test_vectorized_native_replay_matches_reference_first_authority(self) -> None:
        rng = np.random.default_rng(20260814)
        signals = [
            rng.normal(0.0, 0.7, 500),
            np.r_[rng.normal(0.0, 0.2, 180), np.ones(320) * 5.0],
            np.sin(np.linspace(0.0, 50.0, 500)) + rng.normal(0.0, 0.3, 500),
        ]
        definitions = (
            (full_profiles(), full_transitions(), "d_or_g"),
            (full_profiles(), full_transitions(), "d_only"),
            (full_profiles(), full_transitions(), "g_only"),
            (no_regime_profiles(), {}, "d_or_g"),
            (fixed_profiles(), {}, "d_or_g"),
            (fixed_confirmation_profiles(), full_transitions(), "d_or_g"),
        )
        kappas = np.array([0.75, 1.0, 2.5, 5.0], dtype=np.float64)
        for profiles, transitions, mode in definitions:
            for signal in signals:
                trace = compute_representation(
                    signal, profiles=profiles, transitions=transitions
                )
                replay = native_authority_grid(
                    trace,
                    kappas,
                    opening=mode,
                    require_area=True,
                    require_count=True,
                )
                for index, kappa in enumerate(kappas):
                    reference = compute_dmreda_reference(
                        signal,
                        profiles=scaled_profiles(profiles, float(kappa)),
                        transitions=transitions,
                        mode=mode,
                        warmup_samples=WARMUP,
                    )
                    expected = reference.event_times[0] if reference.event_times else -1
                    self.assertEqual(
                        int(replay[index]),
                        expected,
                        msg=(mode, kappa, list(profiles)),
                    )

    def test_reduced_authority_state_matches_historical_trace_semantics(self) -> None:
        rng = np.random.default_rng(9173)
        signal = np.r_[
            rng.normal(0.0, 0.4, 150),
            rng.normal(2.0, 0.8, 150),
            rng.normal(0.0, 1.2, 300),
        ]
        kappa = 1.25
        profiles = scaled_profiles(full_profiles(), kappa)
        transitions = full_transitions()
        for mode in ("d_only", "g_only", "d_or_g"):
            reference = compute_dmreda_reference(
                signal,
                profiles=profiles,
                transitions=transitions,
                mode=mode,
                warmup_samples=WARMUP,
            )
            used_state = np.empty(signal.size, dtype=np.int64)
            used_state[0] = 0
            used_state[1:] = reference.state[:-1]
            used_l = np.empty(signal.size, dtype=np.int64)
            used_l[0] = profiles[0].confirm_base
            used_l[1:] = reference.confirm_len_eff[:-1]
            reduced = MinimalAuthorityState()
            pending = []
            confirmed = []
            for index in range(signal.size):
                profile = profiles[int(used_state[index])]
                output = step_authority(
                    reduced,
                    d_value=float(reference.d[index]),
                    g_value=float(reference.g[index]),
                    th_d=profile.th_d,
                    th_g=profile.th_g,
                    current_contract=OpenContract(
                        confirm_len=int(used_l[index]),
                        th_d2=profile.th_d2,
                        th_a=profile.th_a,
                        n_min=profile.n_min,
                        refractory=profile.refractory,
                    ),
                    mode=mode,
                    authority_enabled=index >= WARMUP,
                )
                pending.append(output.pending)
                confirmed.append(output.confirmed)
            np.testing.assert_array_equal(pending, reference.pending)
            np.testing.assert_array_equal(confirmed, reference.confirmed)

    def test_explicit_state_collision_witnesses_force_count_ell_and_contract(self) -> None:
        witnesses = state_collision_witnesses()
        self.assertEqual(set(witnesses), {
            "count_is_necessary_given_ell_and_area",
            "ell_is_necessary_given_area_and_count",
            "open_contract_is_necessary",
            "refractory_is_additional_multi_event_state",
        })

        count_contract = OpenContract(4, 1.0, 1.0, 3, 0)
        count_1 = MinimalAuthorityState(2, 0.6, 1, count_contract, 0)
        count_2 = MinimalAuthorityState(2, 0.6, 2, count_contract, 0)
        output_1 = step_authority(
            count_1,
            d_value=1.5,
            g_value=0.0,
            th_d=10.0,
            th_g=10.0,
            current_contract=count_contract,
            mode="d_or_g",
            authority_enabled=True,
        )
        output_2 = step_authority(
            count_2,
            d_value=1.5,
            g_value=0.0,
            th_d=10.0,
            th_g=10.0,
            current_contract=count_contract,
            mode="d_or_g",
            authority_enabled=True,
        )
        self.assertFalse(output_1.confirmed)
        self.assertTrue(output_2.confirmed)

        ell_contract = OpenContract(3, 1.0, 1.0, 2, 0)
        ell_1 = MinimalAuthorityState(2, 0.2, 1, ell_contract, 0)
        ell_2 = MinimalAuthorityState(1, 0.2, 1, ell_contract, 0)
        for state in (ell_1, ell_2):
            step_authority(
                state,
                d_value=0.5,
                g_value=0.0,
                th_d=10.0,
                th_g=10.0,
                current_contract=ell_contract,
                mode="d_or_g",
                authority_enabled=True,
            )
        ell_output_1 = step_authority(
            ell_1,
            d_value=2.0,
            g_value=0.0,
            th_d=1.0,
            th_g=10.0,
            current_contract=ell_contract,
            mode="d_or_g",
            authority_enabled=True,
        )
        ell_output_2 = step_authority(
            ell_2,
            d_value=2.0,
            g_value=0.0,
            th_d=1.0,
            th_g=10.0,
            current_contract=ell_contract,
            mode="d_or_g",
            authority_enabled=True,
        )
        self.assertFalse(ell_output_1.confirmed)
        self.assertTrue(ell_output_2.confirmed)

        contract_0 = OpenContract(20, 0.20, 1.8, 6, 80)
        contract_1 = OpenContract(28, 0.28, 2.6, 8, 100)
        open_0 = MinimalAuthorityState(5, 1.7, 5, contract_0, 0)
        open_1 = MinimalAuthorityState(5, 1.7, 5, contract_1, 0)
        outcome_0 = step_authority(
            open_0,
            d_value=0.5,
            g_value=0.0,
            th_d=10.0,
            th_g=10.0,
            current_contract=contract_0,
            mode="d_or_g",
            authority_enabled=True,
        )
        outcome_1 = step_authority(
            open_1,
            d_value=0.5,
            g_value=0.0,
            th_d=10.0,
            th_g=10.0,
            current_contract=contract_1,
            mode="d_or_g",
            authority_enabled=True,
        )
        self.assertTrue(outcome_0.confirmed)
        self.assertFalse(outcome_1.confirmed)


if __name__ == "__main__":
    unittest.main()
