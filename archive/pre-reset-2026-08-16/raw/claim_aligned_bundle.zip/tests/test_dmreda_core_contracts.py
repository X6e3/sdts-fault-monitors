from __future__ import annotations

from dataclasses import replace
import unittest

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    RegimeTransition,
    apply_fixed_input_scale,
    compute_dmreda_reference,
)


class WarmupContractTests(unittest.TestCase):
    def test_event_authority_is_silent_through_warmup(self) -> None:
        cases = []
        early_step = np.zeros(256, dtype=np.float64)
        early_step[1:] = 1.0
        cases.append(early_step)

        early_impulse = np.zeros(256, dtype=np.float64)
        early_impulse[1] = 4.0
        cases.append(early_impulse)
        cases.append(np.random.default_rng(0).normal(0.0, 0.05, 256))

        for signal in cases:
            with self.subTest(kind=len(cases)):
                result = compute_dmreda_reference(signal)
                warmup = result.warmup_samples
                self.assertFalse(np.any(result.pending[:warmup]))
                self.assertFalse(np.any(result.confirmed[:warmup]))
                self.assertFalse(np.any(result.event_active[:warmup]))
                self.assertTrue(all(event >= warmup for event in result.event_times))

    def test_post_warmup_event_still_confirms(self) -> None:
        signal = np.zeros(512, dtype=np.float64)
        signal[180:] = 1.0
        result = compute_dmreda_reference(signal)
        self.assertTrue(result.event_times)
        self.assertGreaterEqual(result.event_times[0], result.warmup_samples)

    def test_zero_warmup_preserves_explicit_opt_out(self) -> None:
        signal = np.zeros(128, dtype=np.float64)
        signal[1:] = 1.0
        result = compute_dmreda_reference(signal, warmup_samples=0)
        self.assertEqual(result.event_times[0], 6)

    def test_warmup_changes_only_event_authority_not_representation(self) -> None:
        sample_index = np.arange(360)
        signal = np.where((sample_index % 20) < 3, 3.0, 0.0)

        no_warmup = compute_dmreda_reference(signal, warmup_samples=0)
        default_warmup = compute_dmreda_reference(signal, warmup_samples=92)

        self.assertNotEqual(no_warmup.event_times, default_warmup.event_times)
        for field in (
            "mu",
            "e",
            "e1",
            "e_baseline",
            "e_baseline_safe",
            "d",
            "g_raw",
            "g",
            "r",
            "a",
            "a_slow",
            "state",
            "m_eff",
            "confirm_len_eff",
        ):
            with self.subTest(field=field):
                np.testing.assert_array_equal(
                    getattr(no_warmup, field),
                    getattr(default_warmup, field),
                )


class InputScalingContractTests(unittest.TestCase):
    def test_equivalent_fixed_calibrations_preserve_detector_trace(self) -> None:
        physical = np.random.default_rng(17).normal(0.0, 0.05, 1024)
        physical[400:460] += 0.4

        raw_millivolts = 1250.0 + 100.0 * physical
        raw_microvolts = -8000.0 + 100_000.0 * physical
        scaled_a = apply_fixed_input_scale(raw_millivolts, offset=1250.0, scale=100.0)
        scaled_b = apply_fixed_input_scale(raw_microvolts, offset=-8000.0, scale=100_000.0)

        result_a = compute_dmreda_reference(scaled_a)
        result_b = compute_dmreda_reference(scaled_b)
        for field in ("mu", "e", "e1", "e_baseline", "d", "g_raw", "g", "r", "a"):
            np.testing.assert_allclose(getattr(result_a, field), getattr(result_b, field), rtol=0.0, atol=2e-12)
        np.testing.assert_array_equal(result_a.state, result_b.state)
        np.testing.assert_array_equal(result_a.pending, result_b.pending)
        np.testing.assert_array_equal(result_a.confirmed, result_b.confirmed)
        self.assertEqual(result_a.event_times, result_b.event_times)

    def test_unscaled_amplitude_change_is_detectably_not_invariant(self) -> None:
        signal = np.random.default_rng(31).normal(0.0, 0.05, 1024)
        signal[400:460] += 0.4
        nominal = compute_dmreda_reference(signal)
        amplified = compute_dmreda_reference(10.0 * signal)

        self.assertFalse(np.array_equal(nominal.state, amplified.state))
        self.assertNotEqual(nominal.event_times, amplified.event_times)
        self.assertFalse(np.allclose(nominal.r, amplified.r))

    def test_scaling_and_core_reject_non_finite_inputs(self) -> None:
        with self.assertRaises(ValueError):
            apply_fixed_input_scale([0.0, np.inf])
        with self.assertRaises(ValueError):
            apply_fixed_input_scale([0.0, 1.0], scale=0.0)
        with self.assertRaises(ValueError):
            compute_dmreda_reference([0.0, np.nan])


class ConfigurationValidationTests(unittest.TestCase):
    def test_control_values_must_be_integral(self) -> None:
        for kwargs in (
            {"warmup_samples": np.nan},
            {"warmup_samples": 1.5},
            {"regime_tick": 2.5},
            {"initial_state": 0.0},
            {"debug": True, "debug_every": 1.5},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                compute_dmreda_reference([0.0, 1.0], **kwargs)

    def test_bounds_and_profile_thresholds_must_be_finite(self) -> None:
        with self.assertRaises(ValueError):
            compute_dmreda_reference([0.0, 1.0], d_bounds=(np.nan, 5.0))

        invalid_profile = replace(DEFAULT_PROFILES[0], th_d=np.nan)
        with self.assertRaises(ValueError):
            compute_dmreda_reference(
                [0.0, 1.0],
                profiles={0: invalid_profile},
                transitions={0: RegimeTransition()},
            )

    def test_profile_integer_and_coefficient_domains_are_enforced(self) -> None:
        invalid_profiles = (
            replace(DEFAULT_PROFILES[0], w1=7.0),
            replace(DEFAULT_PROFILES[0], m_set=(1.5,), m_base=1.5),
            replace(DEFAULT_PROFILES[0], beta=-0.01),
            replace(DEFAULT_PROFILES[0], n_min=13),
        )
        for profile in invalid_profiles:
            with self.subTest(profile=profile), self.assertRaises(ValueError):
                compute_dmreda_reference(
                    np.zeros(16),
                    profiles={0: profile},
                    transitions={0: RegimeTransition()},
                )


if __name__ == "__main__":
    unittest.main()
