#!/usr/bin/env python3
"""Opt-in long-trace fixed-subset Python/C parity stress.

Run explicitly:

    python3 tests/stress_streaming_c_parity.py

This file is intentionally outside the normal ``test*.py`` discovery pattern.
The larger tolerance covers different but mathematically equivalent rolling-sum
rounding orders over long/high-amplitude traces.  Discrete authority traces and
event indices remain exact.
"""

from __future__ import annotations

import csv
import io
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import numpy as np

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    RegimeTransition,
    compute_dmreda_reference,
)


def run() -> None:
    compiler = shutil.which("clang") or shutil.which("cc")
    if compiler is None:
        raise SystemExit("no C99 compiler available")

    cases = (
        (91_001, 50_000, 1.0, 0, "d_only", 5e-11),
        (91_002, 50_000, 1.0, 92, "g_only", 5e-11),
        (91_003, 20_000, 1_000.0, 93, "d_or_g", 1e-8),
    )
    with tempfile.TemporaryDirectory(prefix="dmreda-parity-stress-") as directory:
        binary = Path(directory) / "dmreda_streaming_fixed_cli"
        subprocess.run(
            [
                compiler,
                "-std=c99",
                "-O2",
                "-Wall",
                "-Wextra",
                "-Werror",
                str(REPOSITORY_ROOT / "gold_line/core/dmreda_streaming_fixed.c"),
                str(REPOSITORY_ROOT / "gold_line/support/dmreda_streaming_fixed_cli.c"),
                "-lm",
                "-o",
                str(binary),
            ],
            check=True,
        )

        for seed, length, scale, warmup, mode, tolerance in cases:
            rng = np.random.default_rng(seed)
            signal = rng.normal(0.0, scale, length)
            signal[length // 4] += 2.0 * scale
            signal[length // 2 :] += np.linspace(0.0, 0.8 * scale, length - length // 2)
            completed = subprocess.run(
                [str(binary), str(warmup), mode],
                input="".join(f"{sample:.17g}\n" for sample in signal),
                capture_output=True,
                text=True,
                check=True,
            )
            rows = list(csv.DictReader(io.StringIO(completed.stdout)))
            python = compute_dmreda_reference(
                signal,
                profiles={0: DEFAULT_PROFILES[0]},
                transitions={0: RegimeTransition()},
                regime_tick=length + 1,
                warmup_samples=warmup,
                mode=mode,
            )

            max_error = 0.0
            for field in (
                "mu",
                "e",
                "e1",
                "e_baseline",
                "e_baseline_safe",
                "d",
                "g_raw",
                "g",
                "r",
                "a",
            ):
                c_values = np.asarray([float(row[field]) for row in rows])
                error = float(np.max(np.abs(c_values - getattr(python, field))))
                max_error = max(max_error, error)
                np.testing.assert_allclose(
                    c_values,
                    getattr(python, field),
                    rtol=0.0,
                    atol=tolerance,
                )
            for field in (
                "state",
                "m_eff",
                "confirm_len_eff",
                "pending",
                "confirmed",
                "event_active",
            ):
                c_values = np.asarray([int(row[field]) for row in rows])
                np.testing.assert_array_equal(
                    c_values, getattr(python, field).astype(np.int64)
                )
            c_events = [
                index for index, row in enumerate(rows) if int(row["confirmed"])
            ]
            if c_events != python.event_times:
                raise AssertionError("event-index parity failed")
            print(
                f"seed={seed} length={length} scale={scale:g} mode={mode} "
                f"max_abs_error={max_error:.3e} tolerance={tolerance:.3e} exact_events=yes"
            )


if __name__ == "__main__":
    run()
