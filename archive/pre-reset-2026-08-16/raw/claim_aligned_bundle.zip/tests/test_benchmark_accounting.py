from __future__ import annotations

import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import evaluate_alarm_times
from gold_line.structural_manifold import pqd16c_benchmark as benchmark


class IdentityDetector(benchmark.StreamingDetector):
    def reset(self) -> None:
        pass

    def update(self, x_t: float) -> float:
        return x_t


def identity_factory(_params: object) -> IdentityDetector:
    return IdentityDetector()


class FirstAlarmAccountingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.signal = np.array([0, 2, 2, 2, 0, 0, 0, 2, 2, 2, 0, 0], dtype=np.float64)
        self.onset = 7
        self.model = {"factory": identity_factory, "params": {}, "threshold": 1.0, "arl": 10.0}

    def test_complete_trace_lookup_keeps_pre_onset_alarm(self) -> None:
        cache = benchmark.compute_seq_cache([self.signal], [self.onset], "identity", self.model)
        self.assertEqual(benchmark.detect_from_seq(cache[0], 1.0), 3)

    def test_legacy_rms_helper_does_not_hide_pre_onset_alarm(self) -> None:
        signal = np.ones(12, dtype=np.float64)
        detected = benchmark.rms_detect(signal, self.onset, persistence=3, bias=0.0, threshold=0.1)
        self.assertIsNotNone(detected)
        self.assertLess(detected, self.onset)

    def test_evaluate_detector_charges_false_positive_and_no_detection_credit(self) -> None:
        result = benchmark.evaluate_detector([self.signal], [self.onset], "identity", self.model)
        delays, _, miss, fp, miss_flags, fp_flags, detect_times = result
        self.assertEqual(fp, 1)
        self.assertEqual(miss, 0)
        self.assertTrue(fp_flags[0])
        self.assertFalse(miss_flags[0])
        self.assertTrue(np.isnan(delays[0]))
        self.assertEqual(detect_times[0], 3)

    def test_strict_and_roc_paths_use_the_same_first_alarm_rule(self) -> None:
        strict = benchmark.evaluate_detector_strict_only(
            [self.signal], [self.onset], "identity", self.model
        )
        self.assertEqual(strict[2], 1)
        cache = benchmark.compute_seq_cache([self.signal], [self.onset], "identity", self.model)
        roc = benchmark.roc_sweep(cache, 1.0, [1.0])[0]
        self.assertEqual(roc["detection_rate"], 0.0)
        self.assertEqual(roc["fp_rate"], 1.0)

    def test_scaffold_first_alarm_is_mutually_exclusive(self) -> None:
        outcome = evaluate_alarm_times([3, 9], onset=7, trace_length=12, warmup_samples=0)
        self.assertTrue(outcome.false_positive)
        self.assertFalse(outcome.detected)
        self.assertFalse(outcome.missed)
        self.assertIsNone(outcome.delay_samples)

    def test_eighty_percent_false_positives_never_become_zero_delay_credit(self) -> None:
        unsafe_delays = [np.nan, np.nan, np.nan, np.nan, 10.0]
        reliable_delays = [10.0] * 5

        unsafe = benchmark.detector_metric_payload(
            unsafe_delays,
            unsafe_delays,
            miss=0,
            fp=4,
            runs=5,
            arl=100.0,
        )
        reliable = benchmark.detector_metric_payload(
            reliable_delays,
            reliable_delays,
            miss=0,
            fp=0,
            runs=5,
            arl=100.0,
        )

        self.assertEqual(unsafe["fp_rate_per_run"], 80.0)
        self.assertEqual(unsafe["valid_detection_count"], 1)
        self.assertEqual(
            unsafe["conditional_valid_detection_delay_mean_samples"],
            reliable["conditional_valid_detection_delay_mean_samples"],
        )
        self.assertNotIn("expected_delay_samples", unsafe)
        self.assertFalse(any("unconditional" in key for key in unsafe))

    def test_pairwise_delay_reports_only_joint_valid_population(self) -> None:
        left = np.array([np.nan, 5.0, np.nan, 8.0])
        right = np.array([2.0, 7.0, np.nan, 10.0])
        deltas = benchmark.joint_valid_conditional_delay_deltas(left, right)
        np.testing.assert_array_equal(deltas, np.array([2.0, 2.0]))

        table = benchmark.paired_outcome_contingency(
            left_miss=[False, False, True, False],
            left_fp=[True, False, False, False],
            right_miss=[False, False, True, False],
            right_fp=[False, False, False, False],
        )
        self.assertEqual(table["false_positive"]["valid_detection"], 1)
        self.assertEqual(table["valid_detection"]["valid_detection"], 2)
        self.assertEqual(table["miss"]["miss"], 1)


if __name__ == "__main__":
    unittest.main()
