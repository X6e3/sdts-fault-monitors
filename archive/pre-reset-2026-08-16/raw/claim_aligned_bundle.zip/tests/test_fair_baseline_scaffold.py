from __future__ import annotations

import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    EventGateConfig,
    baseline_event_contract,
    calibrate_baseline_suite,
    calibrate_threshold,
    confirmed_alarm_times,
    evaluate_score_trace,
    signal_bank_hash,
    validate_disjoint_signal_banks,
)


class FairBaselineScaffoldTests(unittest.TestCase):
    def test_refractory_boundary_is_characterized_without_policy_change(self) -> None:
        scores = np.array([2, 2, 2, 0, 2, 2, 2, 2, 2, 0, 2, 2, 2], dtype=np.float64)
        gate = EventGateConfig(warmup_samples=3, persistence=3, refractory=4)
        self.assertEqual(confirmed_alarm_times(scores, 1.0, gate), [6, 12])
        contract = baseline_event_contract(gate)
        self.assertEqual(
            contract.refractory_boundary,
            "decrement_before_test; sample_is_eligible_when_counter_reaches_zero",
        )

    def test_threshold_calibration_reaches_requested_restricted_mean(self) -> None:
        score_runs = [
            np.array([0.0] * 5 + [2.0] * 3 + [0.0] * 12),
            np.array([0.0] * 10 + [2.0] * 3 + [0.0] * 7),
            np.zeros(20),
        ]
        gate = EventGateConfig(warmup_samples=0, persistence=3, refractory=0)
        calibration = calibrate_threshold(
            score_runs,
            gate=gate,
            target_restricted_mean_time_to_alarm=15.0,
        )
        self.assertTrue(np.isfinite(calibration.threshold))
        self.assertGreaterEqual(
            calibration.achieved_restricted_mean_time_to_alarm,
            15.0,
        )
        self.assertGreaterEqual(calibration.achieved_statistics.censoring_count, 1)

    def test_noise_bank_baselines_record_frozen_contract_and_hashes(self) -> None:
        rng = np.random.default_rng(81)
        noise_bank = [rng.normal(0.0, 0.05, 256) for _ in range(5)]
        gate = EventGateConfig(warmup_samples=46, persistence=3, refractory=40)
        suite = calibrate_baseline_suite(
            noise_bank,
            target_restricted_mean_time_to_alarm=180.0,
            gate=gate,
        )
        self.assertEqual(set(suite), {"rms", "cusum", "ewma"})
        for baseline in suite.values():
            self.assertEqual(baseline.gate, gate)
            self.assertEqual(
                baseline.event_contract.event_mechanism,
                "external_score_threshold_persistence_gate",
            )
            self.assertEqual(
                baseline.event_contract.reset_policy,
                "score_and_gate_state_reset_at_trace_start",
            )
            self.assertTrue(baseline.frozen_parameters)
            self.assertEqual(len(baseline.configuration_hash), 64)
            self.assertEqual(baseline.calibration_bank_hash, signal_bank_hash(noise_bank))
            self.assertGreaterEqual(
                baseline.achieved_restricted_mean_time_to_alarm,
                180.0,
            )

    def test_configuration_hash_is_deterministic_and_gate_sensitive(self) -> None:
        rng = np.random.default_rng(82)
        noise_bank = [rng.normal(0.0, 0.05, 128) for _ in range(3)]
        gate_a = EventGateConfig(warmup_samples=10, persistence=2, refractory=4)
        gate_b = EventGateConfig(warmup_samples=10, persistence=3, refractory=4)
        suite_a1 = calibrate_baseline_suite(
            noise_bank,
            target_restricted_mean_time_to_alarm=90.0,
            gate=gate_a,
        )
        suite_a2 = calibrate_baseline_suite(
            noise_bank,
            target_restricted_mean_time_to_alarm=90.0,
            gate=gate_a,
        )
        suite_b = calibrate_baseline_suite(
            noise_bank,
            target_restricted_mean_time_to_alarm=90.0,
            gate=gate_b,
        )
        for name in suite_a1:
            self.assertEqual(
                suite_a1[name].configuration_hash,
                suite_a2[name].configuration_hash,
            )
            self.assertNotEqual(
                suite_a1[name].configuration_hash,
                suite_b[name].configuration_hash,
            )

    def test_disjoint_bank_helper_records_hashes_and_rejects_overlap(self) -> None:
        calibration_bank = [np.arange(8, dtype=np.float64), np.ones(8)]
        evaluation_bank = [np.arange(8, dtype=np.float64) + 10.0, np.zeros(8)]
        provenance = validate_disjoint_signal_banks(calibration_bank, evaluation_bank)
        self.assertEqual(
            provenance.calibration_bank_hash,
            signal_bank_hash(calibration_bank),
        )
        self.assertEqual(
            provenance.evaluation_bank_hash,
            signal_bank_hash(evaluation_bank),
        )
        self.assertNotEqual(
            provenance.calibration_bank_hash,
            provenance.evaluation_bank_hash,
        )
        with self.assertRaisesRegex(ValueError, "share exact signal content"):
            validate_disjoint_signal_banks(calibration_bank, [calibration_bank[1]])

    def test_pre_onset_alarm_cannot_become_a_detection(self) -> None:
        scores = np.array([0, 2, 2, 2, 0, 2, 2, 2], dtype=np.float64)
        gate = EventGateConfig(warmup_samples=0, persistence=3, refractory=0)
        outcome = evaluate_score_trace(scores, threshold=1.0, gate=gate, onset=5)
        self.assertTrue(outcome.false_positive)
        self.assertFalse(outcome.detected)


if __name__ == "__main__":
    unittest.main()
