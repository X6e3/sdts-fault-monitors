from __future__ import annotations

import csv
from dataclasses import replace
import io
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    RegimeTransition,
    compute_dmreda_reference,
)


REPO_ROOT = Path(__file__).resolve().parents[1]


C_BOUNDARY_HARNESS = r"""
#include "dmreda_streaming_fixed.h"

#include <stdio.h>

static int check_timeout_restart(void) {
    const double samples[] = {0.0, 1.0, 2.0, 2.0, 2.0};
    const int expected_pending[] = {0, 1, 1, 1, 0};
    const int expected_end_active[] = {0, 1, 1, 0, 0};
    const int expected_end_elapsed[] = {0, 1, 1, 0, 0};
    DmredaFixedConfig config = dmreda_fixed_default_config();
    DmredaFixedState state;
    DmredaFixedOutput output;
    size_t index;

    config.w1 = 3;
    config.w2 = 1;
    config.confirm_len = 2;
    config.th_d2 = 99.0;
    config.th_a = 999.0;
    config.n_min = 2;
    config.warmup_samples = 0U;
    config.mode = DMREDA_MODE_D_ONLY;
    if (dmreda_fixed_init(&state, &config) != 0) {
        return 10;
    }
    for (index = 0U; index < 5U; ++index) {
        if (dmreda_fixed_step(&state, samples[index], &output) != 0) {
            return 11;
        }
        if (output.pending != expected_pending[index] ||
            state.pending_active != expected_end_active[index] ||
            state.pending_elapsed != expected_end_elapsed[index]) {
            return 12;
        }
    }
    return 0;
}

static int check_confirmation_boundary(void) {
    const double samples[] = {0.0, 1.0, 2.0, 3.0, 3.0};
    const int expected_confirmed[] = {0, 0, 0, 1, 0};
    DmredaFixedConfig config = dmreda_fixed_default_config();
    DmredaFixedState state;
    DmredaFixedOutput output;
    size_t index;

    config.w1 = 3;
    config.w2 = 1;
    config.confirm_len = 3;
    config.th_d2 = 0.0;
    config.th_a = 1.0;
    config.n_min = 3;
    config.refractory = 3;
    config.warmup_samples = 0U;
    config.mode = DMREDA_MODE_D_ONLY;
    if (dmreda_fixed_init(&state, &config) != 0) {
        return 20;
    }
    for (index = 0U; index < 5U; ++index) {
        if (dmreda_fixed_step(&state, samples[index], &output) != 0 ||
            output.confirmed != expected_confirmed[index]) {
            return 21;
        }
    }
    return 0;
}

static int check_refractory_boundary(void) {
    const int expected_confirmed[] = {1, 0, 0, 1, 0, 0, 1, 0};
    DmredaFixedConfig config = dmreda_fixed_default_config();
    DmredaFixedState state;
    DmredaFixedOutput output;
    size_t index;

    config.confirm_len = 2;
    config.th_d = -2.0;
    config.th_d2 = -2.0;
    config.th_a = 0.0;
    config.n_min = 1;
    config.refractory = 3;
    config.warmup_samples = 0U;
    config.mode = DMREDA_MODE_D_ONLY;
    if (dmreda_fixed_init(&state, &config) != 0) {
        return 30;
    }
    for (index = 0U; index < 8U; ++index) {
        if (dmreda_fixed_step(&state, 0.0, &output) != 0 ||
            output.confirmed != expected_confirmed[index]) {
            return 31;
        }
    }
    return 0;
}

static int check_zero_refractory_single_authority(void) {
    DmredaFixedConfig config = dmreda_fixed_default_config();
    DmredaFixedState state;
    DmredaFixedOutput output;

    config.confirm_len = 2;
    config.th_d = -2.0;
    config.th_d2 = -2.0;
    config.th_a = 0.0;
    config.n_min = 2;
    config.refractory = 0;
    config.warmup_samples = 0U;
    config.mode = DMREDA_MODE_D_ONLY;
    if (dmreda_fixed_init(&state, &config) != 0) {
        return 40;
    }
    if (dmreda_fixed_step(&state, 0.0, &output) != 0 ||
        output.confirmed != 0 || state.pending_active != 1) {
        return 41;
    }
    if (dmreda_fixed_step(&state, 0.0, &output) != 0 ||
        output.confirmed != 1 || state.pending_active != 0) {
        return 42;
    }
    if (dmreda_fixed_step(&state, 0.0, &output) != 0 ||
        output.confirmed != 0 || state.pending_active != 1) {
        return 43;
    }
    return 0;
}

static int check_invalid_configurations(void) {
    DmredaFixedConfig config = dmreda_fixed_default_config();
    DmredaFixedState state;

    config.beta = -0.01;
    if (dmreda_fixed_init(&state, &config) == 0) {
        return 50;
    }
    config = dmreda_fixed_default_config();
    config.lambda = 1.01;
    if (dmreda_fixed_init(&state, &config) == 0) {
        return 51;
    }
    config = dmreda_fixed_default_config();
    config.n_min = config.confirm_len + 1;
    if (dmreda_fixed_init(&state, &config) == 0) {
        return 52;
    }
    return 0;
}

int main(void) {
    int result;
    result = check_timeout_restart();
    if (result != 0) return result;
    result = check_confirmation_boundary();
    if (result != 0) return result;
    result = check_refractory_boundary();
    if (result != 0) return result;
    result = check_zero_refractory_single_authority();
    if (result != 0) return result;
    result = check_invalid_configurations();
    if (result != 0) return result;
    puts("ok");
    return 0;
}
"""


class CoreEventBoundaryTests(unittest.TestCase):
    @staticmethod
    def run_fixed_profile(signal: np.ndarray, profile, *, mode: str = "d_only"):
        return compute_dmreda_reference(
            signal,
            profiles={0: profile},
            transitions={0: RegimeTransition()},
            regime_tick=len(signal) + 1,
            warmup_samples=0,
            mode=mode,
        )

    def test_pending_timeout_restarts_on_the_same_sample(self) -> None:
        profile = replace(
            DEFAULT_PROFILES[0],
            w1=3,
            w2=1,
            confirm_base=2,
            confirm_min=2,
            confirm_max=2,
            th_d2=99.0,
            th_a=999.0,
            n_min=2,
        )
        result = self.run_fixed_profile(np.array([0.0, 1.0, 2.0, 2.0, 2.0]), profile)

        np.testing.assert_array_equal(result.d, [-1.0, 5.0, 5.0, -1.0, -1.0])
        np.testing.assert_array_equal(result.pending, [False, True, True, True, False])
        self.assertEqual(result.event_times, [])

    def test_confirmation_succeeds_on_last_allowed_sample(self) -> None:
        profile = replace(
            DEFAULT_PROFILES[0],
            w1=3,
            w2=1,
            confirm_base=3,
            confirm_min=3,
            confirm_max=3,
            th_d2=0.0,
            th_a=1.0,
            n_min=3,
            refractory=3,
        )
        result = self.run_fixed_profile(np.array([0.0, 1.0, 2.0, 3.0, 3.0]), profile)

        np.testing.assert_array_equal(result.confirmed, [False, False, False, True, False])
        self.assertEqual(result.event_times, [3])

    def test_refractory_reopens_at_confirmation_plus_length(self) -> None:
        profile = replace(
            DEFAULT_PROFILES[0],
            confirm_base=2,
            confirm_min=2,
            confirm_max=2,
            th_d=-2.0,
            th_d2=-2.0,
            th_a=0.0,
            n_min=1,
            refractory=3,
        )
        result = self.run_fixed_profile(np.zeros(8), profile)

        self.assertEqual(result.event_times, [0, 3, 6])

    def test_zero_refractory_cannot_confirm_twice_on_one_sample(self) -> None:
        profile = replace(
            DEFAULT_PROFILES[0],
            confirm_base=2,
            confirm_min=2,
            confirm_max=2,
            th_d=-2.0,
            th_d2=0.0,
            th_a=1.0,
            n_min=1,
            refractory=0,
        )
        result = self.run_fixed_profile(np.array([0.0, 1.0]), profile)

        np.testing.assert_array_equal(result.confirmed, [False, True])
        self.assertEqual(result.event_times, [1])


class FixedCAndStartupBoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        compiler = shutil.which("clang") or shutil.which("cc")
        if compiler is None:
            raise unittest.SkipTest("no C99 compiler available")

        cls._tempdir = tempfile.TemporaryDirectory(prefix="dmreda-boundaries-")
        cls.cli_binary = Path(cls._tempdir.name) / "dmreda_streaming_fixed_cli"
        cls.boundary_binary = Path(cls._tempdir.name) / "dmreda_boundary_harness"
        common_flags = ["-std=c99", "-O2", "-Wall", "-Wextra", "-Werror"]
        core_source = REPO_ROOT / "gold_line/core/dmreda_streaming_fixed.c"

        subprocess.run(
            [
                compiler,
                *common_flags,
                str(core_source),
                str(REPO_ROOT / "gold_line/support/dmreda_streaming_fixed_cli.c"),
                "-lm",
                "-o",
                str(cls.cli_binary),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [
                compiler,
                *common_flags,
                "-I",
                str(REPO_ROOT / "gold_line/core"),
                str(core_source),
                "-x",
                "c",
                "-",
                "-lm",
                "-o",
                str(cls.boundary_binary),
            ],
            input=C_BOUNDARY_HARNESS,
            check=True,
            capture_output=True,
            text=True,
        )

    @classmethod
    def tearDownClass(cls) -> None:
        cls._tempdir.cleanup()

    def run_c(
        self,
        signal: np.ndarray,
        *,
        warmup_samples: int = 92,
        mode: str = "d_or_g",
    ) -> list[dict[str, str]]:
        completed = subprocess.run(
            [str(self.cli_binary), str(warmup_samples), mode],
            input="".join(f"{sample:.17g}\n" for sample in signal),
            capture_output=True,
            text=True,
            check=True,
        )
        return list(csv.DictReader(io.StringIO(completed.stdout)))

    def test_c_boundary_harness(self) -> None:
        completed = subprocess.run(
            [str(self.boundary_binary)],
            capture_output=True,
            text=True,
            check=True,
        )
        self.assertEqual(completed.stdout.strip(), "ok")

    def test_startup_policy_five_cases_matches_python_and_c(self) -> None:
        length = 220
        cases = []

        inside_warmup = np.zeros(length)
        inside_warmup[20:35] = 1.0
        cases.append(("inside_warmup", inside_warmup, [], None))

        starts_during_and_persists = np.zeros(length)
        starts_during_and_persists[88:] = 1.0
        cases.append(("starts_during_and_persists", starts_during_and_persists, [97], 92))

        starts_at_boundary = np.zeros(length)
        starts_at_boundary[92:] = 1.0
        cases.append(("starts_at_boundary", starts_at_boundary, [97], 92))

        starts_after_warmup = np.zeros(length)
        starts_after_warmup[120:] = 1.0
        cases.append(("starts_after_warmup", starts_after_warmup, [125], 120))

        residual_evidence = np.zeros(length)
        residual_evidence[88:90] = 1.0
        cases.append(("residual_evidence", residual_evidence, [97], 92))

        for name, signal, expected_events, expected_pending_start in cases:
            with self.subTest(name=name):
                python_result = compute_dmreda_reference(signal)
                c_rows = self.run_c(signal)
                c_events = [
                    index for index, row in enumerate(c_rows) if int(row["confirmed"])
                ]
                c_pending = [
                    index for index, row in enumerate(c_rows) if int(row["pending"])
                ]

                self.assertEqual(python_result.event_times, expected_events)
                self.assertEqual(c_events, expected_events)
                self.assertFalse(np.any(python_result.pending[:92]))
                self.assertFalse(any(int(row["pending"]) for row in c_rows[:92]))
                if expected_pending_start is None:
                    self.assertFalse(np.any(python_result.pending))
                    self.assertEqual(c_pending, [])
                else:
                    self.assertEqual(int(np.flatnonzero(python_result.pending)[0]), expected_pending_start)
                    self.assertEqual(c_pending[0], expected_pending_start)

        during = compute_dmreda_reference(starts_during_and_persists)
        boundary = compute_dmreda_reference(starts_at_boundary)
        self.assertNotEqual(during.g[92], boundary.g[92])

    def test_cli_mode_matches_fixed_python_subset(self) -> None:
        signal = np.zeros(160)
        signal[30:] = 1.0
        for mode in ("d_only", "g_only", "d_or_g"):
            with self.subTest(mode=mode):
                rows = self.run_c(signal, warmup_samples=0, mode=mode)
                python_result = compute_dmreda_reference(
                    signal,
                    profiles={0: DEFAULT_PROFILES[0]},
                    transitions={0: RegimeTransition()},
                    regime_tick=len(signal) + 1,
                    warmup_samples=0,
                    mode=mode,
                )
                c_events = [
                    index for index, row in enumerate(rows) if int(row["confirmed"])
                ]
                self.assertEqual(c_events, python_result.event_times)

    def test_cli_rejects_bad_arguments_and_malformed_stream(self) -> None:
        cases = (
            ([str(self.cli_binary), "-1"], "", 2),
            ([str(self.cli_binary), str(1 << 200)], "", 2),
            ([str(self.cli_binary), "92", "bad_mode"], "", 2),
            ([str(self.cli_binary)], "0\nbogus\n", 3),
        )
        for command, input_text, expected_code in cases:
            with self.subTest(command=command):
                completed = subprocess.run(
                    command,
                    input=input_text,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                self.assertEqual(completed.returncode, expected_code)


if __name__ == "__main__":
    unittest.main()
