"""Shared immutable-golden support for the fixed DMREDA subset.

Ordinary tests only read the checked-in fixture.  Creation is deliberately
owned by ``tools/regenerate_dmreda_golden.py`` and requires a written reason.
"""

from __future__ import annotations

from dataclasses import replace
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    RegimeTransition,
    compute_dmreda_reference,
)


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
GOLDEN_PATH = REPOSITORY_ROOT / "tests" / "fixtures" / "dmreda_fixed_golden.json"
GOLDEN_SHA256_PATH = GOLDEN_PATH.with_suffix(GOLDEN_PATH.suffix + ".sha256")

MODE_TO_C = {"D_ONLY": 0, "G_ONLY": 1, "D_OR_G": 2}


def canonical_json_bytes(value: object) -> bytes:
    return (
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def signal_sha256(signal: np.ndarray) -> str:
    canonical = np.ascontiguousarray(signal, dtype=np.dtype("<f8"))
    return sha256_bytes(canonical.tobytes(order="C"))


def generate_signal(specification: Mapping[str, Any]) -> np.ndarray:
    """Materialize one deterministic, human-inspectable generator contract."""

    generator = specification["generator"]
    length = int(specification["length"])
    if length <= 0:
        raise ValueError("fixture signal length must be positive")

    if generator == "constant":
        return np.full(length, float(specification["value"]), dtype=np.float64)

    if generator == "piecewise_constant":
        signal = np.full(length, float(specification.get("base", 0.0)), dtype=np.float64)
        for start, end, value in specification.get("segments", []):
            signal[int(start) : int(end)] = float(value)
        return signal

    if generator == "impulse_then_ramp":
        signal = np.full(length, float(specification.get("base", 0.0)), dtype=np.float64)
        signal[int(specification["impulse_index"])] += float(
            specification["impulse_value"]
        )
        start = int(specification["ramp_start"])
        ramp_length = int(specification["ramp_length"])
        signal[start : start + ramp_length] += np.linspace(
            float(specification["ramp_first"]),
            float(specification["ramp_last"]),
            ramp_length,
            dtype=np.float64,
        )
        return signal

    if generator == "alternating_sign":
        amplitude = float(specification["amplitude"])
        offset = float(specification.get("offset", 0.0))
        signs = np.where(np.arange(length) % 2 == 0, 1.0, -1.0)
        return offset + amplitude * signs

    if generator == "periodic_pulses":
        signal = np.full(length, float(specification.get("base", 0.0)), dtype=np.float64)
        start = int(specification["start"])
        period = int(specification["period"])
        width = int(specification["width"])
        amplitude = float(specification["amplitude"])
        for pulse_start in range(start, length, period):
            signal[pulse_start : min(length, pulse_start + width)] = amplitude
        return signal

    if generator == "repeated_pattern_with_overrides":
        pattern = np.asarray(specification["pattern"], dtype=np.float64)
        if pattern.size == 0:
            raise ValueError("repeated pattern must not be empty")
        signal = np.resize(pattern, length).astype(np.float64, copy=False)
        for index, value in specification.get("overrides", []):
            signal[int(index)] = float(value)
        return signal

    raise ValueError(f"unknown fixture generator: {generator}")


def fixed_configuration(
    *,
    trace_length: int,
    warmup_samples: int,
    mode: str,
) -> dict[str, object]:
    profile = DEFAULT_PROFILES[0]
    normalized_mode = mode.upper()
    if normalized_mode not in MODE_TO_C:
        raise ValueError(f"unsupported mode: {mode}")
    return {
        "fixed_c": {
            "w1": profile.w1,
            "w2": profile.w2,
            "beta": profile.beta,
            "rho": profile.rho,
            "m": profile.m_base,
            "lambda": profile.lam,
            "th_d": profile.th_d,
            "th_g": profile.th_g,
            "th_d2": profile.th_d2,
            "th_a": profile.th_a,
            "n_min": profile.n_min,
            "e_floor": profile.e_floor,
            "confirm_len": profile.confirm_base,
            "refractory": profile.refractory,
            "g_ref": profile.g_ref,
            "warmup_samples": int(warmup_samples),
            "d_min": -5.0,
            "d_max": 5.0,
            "mode": normalized_mode,
        },
        "python_scope": {
            "profile_state": 0,
            "regime_transitions": "disabled",
            "regime_tick": int(trace_length) + 1,
            "adaptive_m": "disabled_by_singleton_m_set",
            "adaptive_confirmation": "disabled_by_equal_bounds",
            "input_scaling": "already_scaled_float64_samples",
        },
    }


def configuration_sha256(configuration: Mapping[str, object]) -> str:
    return sha256_bytes(canonical_json_bytes(configuration))


def compute_fixed_python(signal: np.ndarray, configuration: Mapping[str, object]):
    fixed = configuration["fixed_c"]
    scope = configuration["python_scope"]
    if not isinstance(fixed, Mapping) or not isinstance(scope, Mapping):
        raise ValueError("invalid fixture configuration")
    base = DEFAULT_PROFILES[0]
    profile = replace(
        base,
        w1=int(fixed["w1"]),
        w2=int(fixed["w2"]),
        beta=float(fixed["beta"]),
        rho=float(fixed["rho"]),
        m_set=(int(fixed["m"]),),
        m_base=int(fixed["m"]),
        lam=float(fixed["lambda"]),
        th_d=float(fixed["th_d"]),
        th_g=float(fixed["th_g"]),
        th_d2=float(fixed["th_d2"]),
        th_a=float(fixed["th_a"]),
        n_min=int(fixed["n_min"]),
        e_floor=float(fixed["e_floor"]),
        confirm_base=int(fixed["confirm_len"]),
        confirm_min=int(fixed["confirm_len"]),
        confirm_max=int(fixed["confirm_len"]),
        refractory=int(fixed["refractory"]),
        g_ref=float(fixed["g_ref"]),
    )
    return compute_dmreda_reference(
        signal,
        profiles={0: profile},
        transitions={0: RegimeTransition()},
        initial_state=int(scope["profile_state"]),
        regime_tick=int(scope["regime_tick"]),
        d_bounds=(float(fixed["d_min"]), float(fixed["d_max"])),
        warmup_samples=int(fixed["warmup_samples"]),
        mode=str(fixed["mode"]).lower(),
    )


def encode_runs(values: Iterable[int | bool]) -> list[list[int]]:
    encoded: list[list[int]] = []
    for raw in values:
        value = int(raw)
        if encoded and encoded[-1][0] == value:
            encoded[-1][1] += 1
        else:
            encoded.append([value, 1])
    return encoded


def decode_runs(encoded: Iterable[Iterable[int]]) -> np.ndarray:
    values: list[int] = []
    for raw_value, raw_count in encoded:
        value = int(raw_value)
        count = int(raw_count)
        if count <= 0:
            raise ValueError("run length must be positive")
        values.extend([value] * count)
    return np.asarray(values, dtype=np.int64)


def load_golden_set() -> dict[str, object]:
    raw = GOLDEN_PATH.read_bytes()
    expected_hash = GOLDEN_SHA256_PATH.read_text(encoding="ascii").strip().split()[0]
    actual_hash = sha256_bytes(raw)
    if actual_hash != expected_hash:
        raise AssertionError(
            f"golden fixture checksum mismatch: {actual_hash} != {expected_hash}"
        )
    payload = json.loads(raw)
    if payload.get("schema_version") != 1:
        raise AssertionError("unsupported golden fixture schema")
    return payload
