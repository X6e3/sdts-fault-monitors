from __future__ import annotations

import unittest

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    EventGateConfig,
    calibrate_threshold,
    finite_horizon_alarm_statistics,
)
from gold_line.evaluation import (
    RunOutcome,
    classify_run_outcome,
    summarize_finite_horizon_alarms,
)


class RunOutcomeContractTests(unittest.TestCase):
    def test_early_first_alarm_cannot_be_redeemed(self) -> None:
        outcome = classify_run_outcome(
            [3, 11],
            onset=8,
            trace_length=16,
            warmup_samples=0,
        )
        self.assertEqual(outcome.outcome, "false_positive")
        self.assertTrue(outcome.false_positive)
        self.assertFalse(outcome.detected)
        self.assertFalse(outcome.missed)
        self.assertIsNone(outcome.delay_samples)
        self.assertIsNone(outcome.to_dict()["valid_detection_delay_samples"])

    def test_run_outcome_rejects_overlapping_categories(self) -> None:
        with self.assertRaisesRegex(ValueError, "exactly one"):
            RunOutcome(3, True, True, False, 0)


class FiniteHorizonAlarmStatisticsTests(unittest.TestCase):
    def test_all_runs_produce_alarms(self) -> None:
        statistics = summarize_finite_horizon_alarms([1, 3], [5, 5])
        self.assertEqual(statistics.censoring_indicators, (False, False))
        self.assertEqual(statistics.censoring_count, 0)
        self.assertEqual(statistics.censoring_rate, 0.0)
        self.assertEqual(statistics.restricted_mean_time_to_alarm, 2.0)
        self.assertEqual(statistics.mean_observed_first_alarm_time, 2.0)

    def test_some_runs_are_right_censored(self) -> None:
        statistics = summarize_finite_horizon_alarms([1, None, 4], [5, 6, 7])
        self.assertEqual(statistics.censoring_indicators, (False, True, False))
        self.assertEqual(statistics.censoring_count, 1)
        self.assertAlmostEqual(statistics.censoring_rate, 1.0 / 3.0)
        self.assertEqual(statistics.restricted_times_to_alarm, (1, 6, 4))
        self.assertAlmostEqual(statistics.restricted_mean_time_to_alarm, 11.0 / 3.0)
        self.assertEqual(statistics.mean_observed_first_alarm_time, 2.5)
        self.assertIsNone(statistics.calibration_horizon)

    def test_all_runs_are_right_censored(self) -> None:
        statistics = summarize_finite_horizon_alarms([None, None], [5, 7])
        self.assertEqual(statistics.censoring_count, 2)
        self.assertEqual(statistics.censoring_rate, 1.0)
        self.assertEqual(statistics.restricted_mean_time_to_alarm, 6.0)
        self.assertIsNone(statistics.mean_observed_first_alarm_time)

    def test_target_beyond_mean_observable_horizon_is_rejected(self) -> None:
        gate = EventGateConfig(warmup_samples=0, persistence=1, refractory=0)
        with self.assertRaisesRegex(ValueError, "observable calibration horizon"):
            calibrate_threshold(
                [np.zeros(5), np.zeros(10)],
                gate=gate,
                target_restricted_mean_time_to_alarm=8.0,
            )

    def test_higher_threshold_cannot_reduce_observed_time_to_alarm(self) -> None:
        score_runs = [
            np.array([0.0, 1.0, 0.0, 2.0, 0.0]),
            np.array([0.0, 0.8, 0.0, 1.8, 0.0]),
        ]
        gate = EventGateConfig(warmup_samples=0, persistence=1, refractory=0)
        lower = finite_horizon_alarm_statistics(score_runs, 0.5, gate)
        higher = finite_horizon_alarm_statistics(score_runs, 1.5, gate)
        self.assertGreaterEqual(
            higher.restricted_mean_time_to_alarm,
            lower.restricted_mean_time_to_alarm,
        )
        self.assertGreaterEqual(higher.censoring_rate, lower.censoring_rate)

    def test_trace_horizon_changes_restricted_interpretation(self) -> None:
        gate = EventGateConfig(warmup_samples=0, persistence=1, refractory=0)
        short = finite_horizon_alarm_statistics([np.zeros(10)], 1.0, gate)
        long = finite_horizon_alarm_statistics([np.zeros(20)], 1.0, gate)
        self.assertEqual(short.censoring_rate, long.censoring_rate)
        self.assertEqual(short.restricted_mean_time_to_alarm, 10.0)
        self.assertEqual(long.restricted_mean_time_to_alarm, 20.0)

    def test_calibration_result_exposes_achieved_censoring(self) -> None:
        score_runs = [
            np.array([0.0] * 5 + [2.0] * 3 + [0.0] * 12),
            np.array([0.0] * 10 + [2.0] * 3 + [0.0] * 7),
            np.zeros(20),
        ]
        gate = EventGateConfig(warmup_samples=0, persistence=3, refractory=0)
        result = calibrate_threshold(
            score_runs,
            gate=gate,
            target_restricted_mean_time_to_alarm=15.0,
        )
        self.assertTrue(np.isfinite(result.threshold))
        self.assertGreaterEqual(result.achieved_restricted_mean_time_to_alarm, 15.0)
        self.assertEqual(result.achieved_statistics.calibration_horizons, (20, 20, 20))
        self.assertGreaterEqual(result.achieved_statistics.censoring_count, 1)
        threshold, achieved = result
        self.assertEqual(threshold, result.threshold)
        self.assertEqual(achieved, result.achieved_restricted_mean_time_to_alarm)


if __name__ == "__main__":
    unittest.main()
