import numpy as np
import matplotlib.pyplot as plt

# ======================================
# SIMULATION SETTINGS
# ======================================

N = 5000
Ts = 1.0

noise_std = 0.6
burst_start = 2500
burst_len = 100
burst_amp = 0.8

np.random.seed(0)

# ======================================
# SIGNAL
# ======================================

signal = np.random.normal(0, noise_std, N)
signal[burst_start:burst_start+burst_len] += burst_amp

# ======================================
# FAST LOOP METRIC (risk proxy)
# ======================================

W_fast = 20
risk = np.zeros(N)

for i in range(W_fast, N):
    risk[i] = np.std(signal[i-W_fast:i])

# entropy proxy (simple energy)
entropy = np.convolve(signal**2, np.ones(20)/20, mode='same')

collapse_rate = np.gradient(risk)

# ======================================
# SLOW LOOP
# ======================================

T_phase = 50   # time-scale separation
N_phase = np.zeros(N)
N_phase[0] = 3

k1, k2, k3 = 2.0, 0.5, 0.5
N_max = 12

for t in range(1, N):
    if t % T_phase == 0:

        N_target = 3 + k1*risk[t] + k2*entropy[t] + k3*abs(collapse_rate[t])
        N_target = np.clip(N_target, 3, N_max)

        delta = np.clip(N_target - N_phase[t-1], -1, 1)
        N_phase[t] = N_phase[t-1] + delta
    else:
        N_phase[t] = N_phase[t-1]

# ======================================
# EXPONENT DYNAMICS
# ======================================

xi_min = 0.5
xi_max = 4.0
a = 0.05

xi = np.zeros(N)
xi[0] = 1.0

for t in range(1, N):
    xi_target = xi_min + (xi_max - xi_min) * (N_phase[t] - 3) / (N_max - 3)
    xi[t] = xi[t-1] + a * (xi_target - xi[t-1])

# ======================================
# WEIGHT KERNEL
# ======================================

eps = 1e-3
d = np.abs(signal) + eps

w = 1 / (d ** xi)

# ======================================
# BARRIER LYAPUNOV
# ======================================

V = np.sum(1 / (d ** (xi - 1)), axis=0)

# ======================================
# PLOTS
# ======================================

plt.figure(figsize=(12,10))

plt.subplot(5,1,1)
plt.title("Signal")
plt.plot(signal)

plt.subplot(5,1,2)
plt.title("Risk (fast loop)")
plt.plot(risk)

plt.subplot(5,1,3)
plt.title("N_phase (slow loop)")
plt.plot(N_phase)

plt.subplot(5,1,4)
plt.title("Exponent xi(t)")
plt.plot(xi)

plt.subplot(5,1,5)
plt.title("Weight kernel sample")
plt.plot(w)

plt.tight_layout()
plt.show()