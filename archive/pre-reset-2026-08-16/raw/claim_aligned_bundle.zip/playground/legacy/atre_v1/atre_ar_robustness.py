import numpy as np
import matplotlib.pyplot as plt

# ======================================
# CONFIG
# ======================================

N = 5000
train_len = 1000
T_phase = 50
burst_start = 2500
burst_len = 80

noise_levels = [0.3, 0.5, 0.7, 0.9]
burst_levels = [0.3, 0.5, 0.8, 1.2, 1.5]
orders = [1, 2, 4]

seeds = range(50)

W_fast = 20
k1 = 5.0
N_max = 12

xi_min = 0.5
xi_max = 4.0
a_relax = 0.05

# ======================================
# FUNCTION
# ======================================

def run_trial(noise_std, burst_amp, p, seed):
    np.random.seed(seed)

    signal = np.random.normal(0, noise_std, N)
    signal[burst_start:burst_start+burst_len] += burst_amp

    # --- Train AR ---
    X, Y = [], []
    for t in range(p, train_len):
        X.append(signal[t-p:t][::-1])
        Y.append(signal[t])
    X = np.array(X)
    Y = np.array(Y)

    a = np.linalg.lstsq(X, Y, rcond=None)[0]

    innovation = np.zeros(N)
    for t in range(p, N):
        x_hat = np.dot(a, signal[t-p:t][::-1])
        innovation[t] = signal[t] - x_hat

    risk = np.convolve(innovation**2, np.ones(W_fast)/W_fast, mode='same')

    pre_mean = np.mean(risk[:burst_start])
    threshold = pre_mean * 3

    detected = np.any(risk[burst_start:] > threshold)
    false_alarm = np.any(risk[:burst_start] > threshold)

    return detected, false_alarm

# ======================================
# SWEEP
# ======================================

for p in orders:

    print(f"\n=== AR Order p = {p} ===")

    for noise_std in noise_levels:

        print(f"\nNoise STD = {noise_std}")

        for burst_amp in burst_levels:

            detections = []
            false_alarms = []

            for seed in seeds:
                d, f = run_trial(noise_std, burst_amp, p, seed)
                detections.append(d)
                false_alarms.append(f)

            det_rate = np.mean(detections)
            fa_rate = np.mean(false_alarms)

            print(f"Burst {burst_amp:.1f} → Det: {det_rate:.2f}, FA: {fa_rate:.2f}")