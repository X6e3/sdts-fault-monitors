import numpy as np

N = 5000
window = 80
noise_std = 0.7
trials = 100

def compute_glr(signal):
    sigma0 = np.var(signal)
    glr = np.zeros(N)

    for t in range(window, N):
        segment = signal[t-window:t]
        sigma1 = np.var(segment) + 1e-8
        glr[t] = window * (
            np.log(sigma0 / sigma1) +
            sigma1 / sigma0 - 1
        )
    return glr

# --- Noise-only calibration ---
max_vals = []

for seed in range(trials):
    np.random.seed(seed)
    signal = np.random.normal(0, noise_std, N)
    glr = compute_glr(signal)
    max_vals.append(np.max(glr))

threshold = np.quantile(max_vals, 0.95)

print("Calibrated threshold:", threshold)

# --- Test with burst ---
np.random.seed(0)
signal = np.random.normal(0, noise_std, N)
signal[2500:2580] += 0.8

glr = compute_glr(signal)

alarm = glr > threshold

print("Detection:", np.any(alarm[2500:]))
print("False Alarm:", np.any(alarm[:2500]))