import numpy as np

# ======================================
# CONFIG
# ======================================

N = 5000
train_len = 1000
p = 2
burst_start = 2500
burst_len = 80

noise_levels = [0.3, 0.5, 0.7, 0.9]
burst_levels = [0.3, 0.5, 0.8, 1.2]
seeds = range(50)

# CUSUM parameters
k = 0.5   # sensitivity
h = 8.0   # decision threshold

# ======================================
# FUNCTION
# ======================================

def run_trial(noise_std, burst_amp, seed):
    np.random.seed(seed)

    signal = np.random.normal(0, noise_std, N)
    signal[burst_start:burst_start+burst_len] += burst_amp

    # ---- Train AR ----
    X, Y = [], []
    for t in range(p, train_len):
        X.append(signal[t-p:t][::-1])
        Y.append(signal[t])
    X = np.array(X)
    Y = np.array(Y)

    a = np.linalg.lstsq(X, Y, rcond=None)[0]

    innovation = np.zeros(N)
    for t in range(p, N):
        x_hat = np.dot(a, signal[t-p:t][::-1])
        innovation[t] = signal[t] - x_hat

    # Normalize innovation energy
    sigma0 = np.std(innovation[:burst_start]) + 1e-8
    z = (innovation / sigma0)**2 - 1

    # ---- CUSUM ----
    S = 0
    alarm = np.zeros(N)

    for t in range(N):
        S = max(0, S + z[t] - k)
        if S > h:
            alarm[t] = 1
            S = 0  # reset

    detected = np.any(alarm[burst_start:])
    false_alarm = np.any(alarm[:burst_start])

    return detected, false_alarm

# ======================================
# SWEEP
# ======================================

print("=== FINAL TEST ===")

for noise_std in noise_levels:
    print(f"\nNoise STD = {noise_std}")

    for burst_amp in burst_levels:

        detections = []
        false_alarms = []

        for seed in seeds:
            d, f = run_trial(noise_std, burst_amp, seed)
            detections.append(d)
            false_alarms.append(f)

        print(
            f"Burst {burst_amp:.1f} → "
            f"Det: {np.mean(detections):.2f}, "
            f"FA: {np.mean(false_alarms):.2f}"
        )