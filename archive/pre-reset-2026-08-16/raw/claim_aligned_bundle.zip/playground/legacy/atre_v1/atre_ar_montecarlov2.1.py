import numpy as np

# ======================================
# GLOBAL CONFIG
# ======================================

N = 5000
p = 2
train_len = 1000
W_fast = 20

burst_len = 80
burst_start = 2500

seeds = range(100)  # hardcore ama makul

# Sweep ranges
noise_range = np.linspace(0.5, 1.0, 5)
burst_range = np.linspace(0.3, 0.9, 5)
k_sigma_range = np.linspace(3.0, 5.0, 5)

# ======================================
# CORE SIM FUNCTION
# ======================================

def run_single_trial(noise_std, burst_amp, k_sigma, seed):

    np.random.seed(seed)

    signal = np.random.normal(0, noise_std, N)
    signal[burst_start:burst_start+burst_len] += burst_amp

    # ---- Train AR ----
    X = []
    Y = []
    for t in range(p, train_len):
        X.append(signal[t-p:t][::-1])
        Y.append(signal[t])
    X = np.array(X)
    Y = np.array(Y)

    a = np.linalg.lstsq(X, Y, rcond=None)[0]

    # ---- Innovation ----
    innovation = np.zeros(N)
    for t in range(p, N):
        x_hat = np.dot(a, signal[t-p:t][::-1])
        innovation[t] = signal[t] - x_hat

    risk = np.convolve(innovation**2,
                       np.ones(W_fast)/W_fast,
                       mode='same')

    noise_risk = risk[:burst_start]
    mu = np.mean(noise_risk)
    sigma = np.std(noise_risk)
    threshold = mu + k_sigma * sigma

    burst_risk = risk[burst_start:burst_start+burst_len]

    detected = np.any(burst_risk > threshold)
    false_events = np.sum(noise_risk > threshold)
    false_rate = false_events / burst_start

    separation = np.mean(burst_risk) / (mu + 1e-8)

    return detected, false_rate, separation


# ======================================
# SWEEP ENGINE
# ======================================

print("=== HARDCORE SWEEP START ===")

results = {}

for noise_std in noise_range:
    for burst_amp in burst_range:

        snr_key = (round(noise_std,2), round(burst_amp,2))
        results[snr_key] = {}

        for k_sigma in k_sigma_range:

            det_list = []
            fa_list = []
            sep_list = []

            for seed in seeds:
                d, f, s = run_single_trial(noise_std, burst_amp, k_sigma, seed)
                det_list.append(d)
                fa_list.append(f)
                sep_list.append(s)

            results[snr_key][k_sigma] = {
                "detection_rate": np.mean(det_list),
                "false_alarm_rate": np.mean(fa_list),
                "separation": np.mean(sep_list)
            }

print("=== SWEEP COMPLETE ===")


# ======================================
# SUMMARY ANALYSIS
# ======================================

print("\n=== WORST CASE ANALYSIS ===")

worst_detection = 1.0
worst_case_key = None

for snr_key in results:
    for k_sigma in results[snr_key]:
        det = results[snr_key][k_sigma]["detection_rate"]
        if det < worst_detection:
            worst_detection = det
            worst_case_key = (snr_key, k_sigma)

print("Worst detection rate:", worst_detection)
print("Worst condition (noise, burst, k_sigma):", worst_case_key)


# ======================================
# ROC PRINT FOR MID SNR
# ======================================

mid_noise = noise_range[len(noise_range)//2]
mid_burst = burst_range[len(burst_range)//2]

print("\n=== ROC at MID SNR ===")
print("Noise:", mid_noise, "Burst:", mid_burst)

for k_sigma in k_sigma_range:
    metrics = results[(round(mid_noise,2), round(mid_burst,2))][k_sigma]
    print("k=", round(k_sigma,2),
          "Det=", round(metrics["detection_rate"],3),
          "FA=", round(metrics["false_alarm_rate"],5))