import numpy as np

# ======================================
# CONFIG
# ======================================

N = 5000
p = 2
train_len = 1000
T_phase = 50

noise_std = 0.6
burst_amp = 0.8
burst_len = 80
burst_start = 2500

seeds = range(1000)

W_fast = 20
k_sigma = 4.0   # threshold = mu + k_sigma * sigma

# ======================================
# METRIC STORAGE
# ======================================

detections = []
false_alarm_rates = []
innovation_ratios = []

# ======================================
# MONTE CARLO
# ======================================

for seed in seeds:
    np.random.seed(seed)

    # ---- Signal ----
    signal = np.random.normal(0, noise_std, N)
    signal[burst_start:burst_start+burst_len] += burst_amp

    # ---- Train AR model ----
    X = []
    Y = []
    for t in range(p, train_len):
        X.append(signal[t-p:t][::-1])
        Y.append(signal[t])
    X = np.array(X)
    Y = np.array(Y)

    a = np.linalg.lstsq(X, Y, rcond=None)[0]

    # ---- Innovation ----
    innovation = np.zeros(N)
    for t in range(p, N):
        x_hat = np.dot(a, signal[t-p:t][::-1])
        innovation[t] = signal[t] - x_hat

    risk = np.convolve(innovation**2,
                       np.ones(W_fast)/W_fast,
                       mode='same')

    # ---- Noise statistics ----
    noise_risk = risk[:burst_start]
    mu = np.mean(noise_risk)
    sigma = np.std(noise_risk)
    threshold = mu + k_sigma * sigma

    # ---- Separation ratio ----
    burst_risk = risk[burst_start:burst_start+burst_len]
    innovation_ratios.append(
        np.mean(burst_risk) / (mu + 1e-8)
    )

    # ---- Detection (strict window) ----
    detected = np.any(burst_risk > threshold)
    detections.append(int(detected))

    # ---- False alarm event rate ----
    false_events = np.sum(noise_risk > threshold)
    false_alarm_rate = false_events / burst_start
    false_alarm_rates.append(false_alarm_rate)

# ======================================
# RESULTS
# ======================================

print("=== CLEAN MONTE CARLO RESULTS ===")
print("Detection rate:", np.mean(detections))
print("False alarm event rate:", np.mean(false_alarm_rates))
print("Innovation separation ratio (mean):", np.mean(innovation_ratios))