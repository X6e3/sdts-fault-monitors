import numpy as np
import matplotlib.pyplot as plt

# ======================================
# SIMULATION SETTINGS
# ======================================

N = 5000
noise_std = 0.3
burst_start = 2500
burst_len = 100
burst_amp = 2.0

np.random.seed(0)

# ======================================
# SIGNAL
# ======================================

signal = np.random.normal(0, noise_std, N)
signal[burst_start:burst_start+burst_len] += burst_amp

# ======================================
# AR(2) BASELINE MODEL (estimated from first 1000 samples)
# ======================================

p = 2
train_len = 1000

X = []
Y = []

for t in range(p, train_len):
    X.append(signal[t-p:t][::-1])
    Y.append(signal[t])

X = np.array(X)
Y = np.array(Y)

a = np.linalg.lstsq(X, Y, rcond=None)[0]

# ======================================
# FAST LOOP: Innovation energy
# ======================================

innovation = np.zeros(N)

for t in range(p, N):
    x_hat = np.dot(a, signal[t-p:t][::-1])
    innovation[t] = signal[t] - x_hat

risk = np.convolve(innovation**2, np.ones(20)/20, mode='same')

# ======================================
# SLOW LOOP
# ======================================

T_phase = 50
N_phase = np.zeros(N)
N_phase[0] = 3

k1 = 5.0
N_max = 12

for t in range(1, N):
    if t % T_phase == 0:
        N_target = 3 + k1 * risk[t]
        N_target = np.clip(N_target, 3, N_max)
        delta = np.clip(N_target - N_phase[t-1], -1, 1)
        N_phase[t] = N_phase[t-1] + delta
    else:
        N_phase[t] = N_phase[t-1]

# ======================================
# EXPONENT DYNAMICS
# ======================================

xi_min = 0.5
xi_max = 4.0
a_relax = 0.05

xi = np.zeros(N)
xi[0] = 1.0

for t in range(1, N):
    xi_target = xi_min + (xi_max - xi_min) * (N_phase[t] - 3) / (N_max - 3)
    xi[t] = xi[t-1] + a_relax * (xi_target - xi[t-1])

# ======================================
# PLOTS
# ======================================

plt.figure(figsize=(12,10))

plt.subplot(4,1,1)
plt.title("Signal")
plt.plot(signal)

plt.subplot(4,1,2)
plt.title("Innovation Energy (risk)")
plt.plot(risk)

plt.subplot(4,1,3)
plt.title("N_phase")
plt.plot(N_phase)

plt.subplot(4,1,4)
plt.title("Exponent xi(t)")
plt.plot(xi)

plt.tight_layout()
plt.show()