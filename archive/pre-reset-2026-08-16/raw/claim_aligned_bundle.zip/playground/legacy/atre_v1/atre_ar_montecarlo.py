import numpy as np

# ======================================
# CONFIG
# ======================================

N = 5000
p = 2
train_len = 1000
T_phase = 50

noise_std = 0.6
burst_amp = 0.8
burst_len = 80
burst_start = 2500

seeds = range(100)

k1 = 5.0
N_max = 12

xi_min = 0.5
xi_max = 4.0
a_relax = 0.05

W_fast = 20

# ======================================
# STORAGE
# ======================================

false_alarms = []
detections = []
innovation_ratios = []
N_var_noise = []
xi_var_noise = []

# ======================================
# MONTE CARLO
# ======================================

for seed in seeds:

    np.random.seed(seed)

    # ---- Signal ----
    signal = np.random.normal(0, noise_std, N)
    signal[burst_start:burst_start+burst_len] += burst_amp

    # ---- Train AR model ----
    X = []
    Y = []
    for t in range(p, train_len):
        X.append(signal[t-p:t][::-1])
        Y.append(signal[t])
    X = np.array(X)
    Y = np.array(Y)
    a = np.linalg.lstsq(X, Y, rcond=None)[0]

    # ---- Innovation ----
    innovation = np.zeros(N)
    for t in range(p, N):
        x_hat = np.dot(a, signal[t-p:t][::-1])
        innovation[t] = signal[t] - x_hat

    risk = np.convolve(innovation**2, np.ones(W_fast)/W_fast, mode='same')

    # ---- Separation Metric ----
    pre_mean = np.mean(risk[:burst_start])
    post_mean = np.mean(risk[burst_start:burst_start+burst_len])
    innovation_ratios.append(post_mean / (pre_mean + 1e-8))

    # ---- Detection (simple threshold) ----
    threshold = pre_mean * 3
    detected = np.any(risk[burst_start:] > threshold)
    detections.append(int(detected))

    false_alarm = np.any(risk[:burst_start] > threshold)
    false_alarms.append(int(false_alarm))

    # ---- Slow Loop ----
    N_phase = np.zeros(N)
    N_phase[0] = 3

    for t in range(1, N):
        if t % T_phase == 0:
            N_target = 3 + k1 * risk[t]
            N_target = np.clip(N_target, 3, N_max)
            delta = np.clip(N_target - N_phase[t-1], -1, 1)
            N_phase[t] = N_phase[t-1] + delta
        else:
            N_phase[t] = N_phase[t-1]

    xi = np.zeros(N)
    xi[0] = 1.0

    for t in range(1, N):
        xi_target = xi_min + (xi_max - xi_min) * (N_phase[t] - 3) / (N_max - 3)
        xi[t] = xi[t-1] + a_relax * (xi_target - xi[t-1])

    # Noise-only variance
    N_var_noise.append(np.var(N_phase[:burst_start]))
    xi_var_noise.append(np.var(xi[:burst_start]))

# ======================================
# RESULTS
# ======================================

print("=== MONTE CARLO RESULTS ===")
print("Detection rate:", np.mean(detections))
print("False alarm rate:", np.mean(false_alarms))
print("Innovation separation ratio (mean):", np.mean(innovation_ratios))
print("Noise N_phase variance:", np.mean(N_var_noise))
print("Noise xi variance:", np.mean(xi_var_noise))