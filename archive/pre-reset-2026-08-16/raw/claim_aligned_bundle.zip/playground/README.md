# Playground

`playground/` holds research scripts that are useful, but not safe to present as final detector evidence.

## Promotion criteria

A playground script must satisfy all of the following before it can move to `gold_line/`:

- no leakage from same-trial pre-onset thresholding
- causal streaming path only
- shared event-level confirmation / persistence semantics
- reproducible calibration on noise-only data or ARL targeting
- no heavy runtime dependence on FFT + covariance inverse + eigendecomposition unless those steps are explicitly frozen offline
- no `sklearn`, `torch`, or `tensorflow` on the Gold Line path

## Folder meanings

- `promotion_priority/`
  - serious research artifacts that are closest to promotion
- `offline_diagnostic_only/`
  - diagnostics, ROC studies, PCA-style attribution, and analysis scripts that must not be used for claims

## Offline diagnostic warning

Anything in `offline_diagnostic_only/` is analysis-only. These scripts may use ROC, sklearn, or other offline-only tooling and should not be cited as detector evidence.
