# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
import json
import math
import os
from pathlib import Path
import sys
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.core.dmreda_reference_clean import DEFAULT_PROFILES, DMREDAProfile, compute_dmreda_reference
from playground.offline_diagnostic_only import dmreda_operating_map_analysis as base


ROOT = Path("/Users/x6e3/vscode")
RESULT_JSON = ROOT / "results" / "dmreda_equal_fa_recalibrated_sweep.json"
RESULT_JSON.parent.mkdir(parents=True, exist_ok=True)

DISTURBANCES = ("burst", "drift", "shock")
MODES = ("D_only", "D_or_G")
SEED_COUNT = int(os.environ.get("DMREDA_EQUAL_FA_SEEDS", "20"))
base.SEEDS = tuple(range(SEED_COUNT))

# Wide single-scale sweep over active trigger thresholds.
DMREDA_SCALE_GRID = tuple(
    float(value)
    for value in np.unique(
        np.concatenate(
            [
                np.linspace(0.5, 4.0, 36),
                np.linspace(4.5, 20.0, 32),
                np.array([25.0, 30.0, 40.0, 60.0], dtype=float),
            ]
        )
    )
)


def _load_base_profiles() -> Dict[int, DMREDAProfile]:
    profiles = dict(DEFAULT_PROFILES)
    task2_path = ROOT / "results" / "task2_g_threshold_recalibration.json"
    if not task2_path.exists():
        return profiles

    payload = json.loads(task2_path.read_text(encoding="utf-8"))
    recal = payload.get("recalibrated_theta_g", payload)
    selected = recal.get("selected_state_thresholds", {})
    if not selected:
        return profiles

    for state, profile in profiles.items():
        if str(state) in selected:
            profiles[state] = replace(profile, th_g=float(selected[str(state)]))
    return profiles


def _profiles_for_mode(
    base_profiles: Mapping[int, DMREDAProfile],
    *,
    mode: str,
    scale: float,
) -> Dict[int, DMREDAProfile]:
    profiles: Dict[int, DMREDAProfile] = {}
    for state, profile in base_profiles.items():
        if mode == "D_only":
            profiles[state] = replace(
                profile,
                th_d=float(profile.th_d * scale),
                th_g=float("inf"),
            )
        elif mode == "D_or_G":
            profiles[state] = replace(
                profile,
                th_d=float(profile.th_d * scale),
                th_g=float(profile.th_g * scale),
            )
        else:
            raise ValueError(f"unsupported mode: {mode}")
    return profiles


def _evaluate_dmreda_trials(
    trials: Sequence[base.Trial],
    *,
    mode: str,
    base_profiles: Mapping[int, DMREDAProfile],
    scale: float,
    warmup_samples: int,
) -> Dict[str, float]:
    profiles = _profiles_for_mode(base_profiles, mode=mode, scale=scale)
    metrics = []
    for trial in trials:
        result = compute_dmreda_reference(
            trial.signal,
            profiles=profiles,
            mode=mode,
            warmup_samples=warmup_samples,
        )
        filtered_event_times = [t for t in result.event_times if t >= warmup_samples]
        metrics.append(
            base.evaluate_event_times(
                filtered_event_times,
                trial.meta,
                len(trial.signal),
            )
        )
    summary = base.summarize_metrics(metrics)
    summary["scale"] = float(scale)
    return summary


def _evaluate_rms_default(
    trials: Sequence[base.Trial],
    *,
    warmup_samples: int,
) -> Dict[str, float]:
    threshold = base.calibrate_rms_threshold(trials, warmup_samples=warmup_samples)
    metrics = []
    for trial in trials:
        rms_result = base.rms_event_detector_causal(
            trial.signal,
            threshold=threshold,
            window=base.RMS_WINDOW,
            confirm_window=base.RMS_CONFIRM_WINDOW,
            n_persist=base.RMS_N_PERSIST,
            refractory=base.RMS_REFRACTORY,
            warmup_samples=warmup_samples,
        )
        metrics.append(
            base.evaluate_event_times(
                rms_result.event_times,
                trial.meta,
                len(trial.signal),
            )
        )
    summary = base.summarize_metrics(metrics)
    summary["threshold"] = float(threshold)
    return summary


def _select_dmreda_match(
    trials: Sequence[base.Trial],
    *,
    mode: str,
    base_profiles: Mapping[int, DMREDAProfile],
    warmup_samples: int,
    rms_fa_rate: float,
) -> Dict[str, float]:
    candidates: List[Dict[str, float]] = []
    for scale in DMREDA_SCALE_GRID:
        summary = _evaluate_dmreda_trials(
            trials,
            mode=mode,
            base_profiles=base_profiles,
            scale=scale,
            warmup_samples=warmup_samples,
        )
        summary["fa_gap"] = abs(summary["false_alarm_rate"] - rms_fa_rate)
        candidates.append(summary)

    candidates.sort(
        key=lambda row: (
            row["fa_gap"],
            abs(row["false_alarm_rate"] - rms_fa_rate),
            row["latency_mean"] if not math.isnan(row["latency_mean"]) else float("inf"),
            -row["detection_rate"],
            row["scale"],
        )
    )
    return candidates[0]


def _evaluate_condition(condition: base.Condition) -> Dict[str, object]:
    base_profiles = _load_base_profiles()
    warmup_samples = base.compute_warmup_samples(base_profiles)
    trials = base.build_trials(condition)
    rms_summary = _evaluate_rms_default(trials, warmup_samples=warmup_samples)

    rows: List[Dict[str, object]] = []
    for mode in MODES:
        dmreda_summary = _select_dmreda_match(
            trials,
            mode=mode,
            base_profiles=base_profiles,
            warmup_samples=warmup_samples,
            rms_fa_rate=rms_summary["false_alarm_rate"],
        )
        latency_delta = dmreda_summary["latency_mean"] - rms_summary["latency_mean"]
        rows.append(
            {
                "disturbance": condition.disturbance,
                "noise_std": float(condition.noise_std),
                "amplitude": float(condition.amplitude),
                "mode": mode,
                "warmup_samples": int(warmup_samples),
                "rms_threshold": float(rms_summary["threshold"]),
                "rms_false_alarm_rate": float(rms_summary["false_alarm_rate"]),
                "dmreda_false_alarm_rate": float(dmreda_summary["false_alarm_rate"]),
                "fa_gap": float(dmreda_summary["fa_gap"]),
                "latency_rms": float(rms_summary["latency_mean"]) if not math.isnan(rms_summary["latency_mean"]) else math.nan,
                "latency_dmreda": float(dmreda_summary["latency_mean"]) if not math.isnan(dmreda_summary["latency_mean"]) else math.nan,
                "latency_delta": float(latency_delta) if not math.isnan(latency_delta) else math.nan,
                "rms_detection_rate": float(rms_summary["detection_rate"]),
                "dmreda_detection_rate": float(dmreda_summary["detection_rate"]),
                "dmreda_scale": float(dmreda_summary["scale"]),
                "wins": bool(
                    np.isfinite(latency_delta)
                    and latency_delta < 0.0
                    and dmreda_summary["detection_rate"] > 0.0
                ),
            }
        )

    return {
        "condition": asdict(condition),
        "rms_summary": rms_summary,
        "rows": rows,
    }


def build_conditions() -> List[base.Condition]:
    return [
        base.Condition(disturbance=disturbance, noise_std=noise_std, amplitude=base.AMPLITUDE)
        for disturbance in DISTURBANCES
        for noise_std in base.NOISE_LEVELS
    ]


def run_equal_fa_sweep() -> Dict[str, object]:
    condition_results: List[Dict[str, object]] = []
    with ProcessPoolExecutor(max_workers=min(6, os.cpu_count() or 1)) as executor:
        futures = {executor.submit(_evaluate_condition, condition): condition for condition in build_conditions()}
        for future in as_completed(futures):
            condition_results.append(future.result())

    condition_results.sort(
        key=lambda item: (
            item["condition"]["disturbance"],
            item["condition"]["noise_std"],
        )
    )

    all_rows: List[Dict[str, object]] = []
    for item in condition_results:
        rows = sorted(item["rows"], key=lambda row: row["mode"])
        all_rows.extend(rows)

    wins = [row for row in all_rows if row["wins"]]
    report = {
        "meta": {
            "seed_count": SEED_COUNT,
            "disturbances": list(DISTURBANCES),
            "noise_levels": list(base.NOISE_LEVELS),
            "amplitude": base.AMPLITUDE,
            "modes": list(MODES),
            "dmreda_scale_grid": list(DMREDA_SCALE_GRID),
        },
        "rows": all_rows,
        "winning_conditions": wins,
        "has_publishable_zone": bool(wins),
    }
    return report


def print_report(report: Mapping[str, object]) -> None:
    print("Equal-FA recalibrated sweep — D-only vs D_or_G")
    print("Disturbance | Noise | Amplitude | Mode | RMS_FA | DMREDA_FA | Latency_RMS | Latency_DMREDA | Latency_delta | Wins")
    for row in report["rows"]:
        print(
            f"{row['disturbance']} | {row['noise_std']:.2f} | {row['amplitude']:.2f} | {row['mode']} | "
            f"{base.format_value(row['rms_false_alarm_rate'])} | {base.format_value(row['dmreda_false_alarm_rate'])} | "
            f"{base.format_value(row['latency_rms'])} | {base.format_value(row['latency_dmreda'])} | "
            f"{base.format_value(row['latency_delta'])} | {int(row['wins'])}"
        )

    if report["winning_conditions"]:
        print("\nPublishable operating zones")
        for row in report["winning_conditions"]:
            print(
                f"{row['disturbance']} noise={row['noise_std']:.2f} mode={row['mode']} "
                f"delta={base.format_value(row['latency_delta'])} "
                f"RMS_FA={base.format_value(row['rms_false_alarm_rate'])} "
                f"DMREDA_FA={base.format_value(row['dmreda_false_alarm_rate'])}"
            )
    else:
        print("\nNo condition produced latency_delta < 0 under equal-FA matching.")


def main() -> None:
    report = run_equal_fa_sweep()
    RESULT_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print_report(report)
    print(f"\nSaved {RESULT_JSON}")


if __name__ == "__main__":
    main()
