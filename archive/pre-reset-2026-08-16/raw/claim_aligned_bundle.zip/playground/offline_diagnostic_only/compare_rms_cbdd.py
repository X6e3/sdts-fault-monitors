# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
from __future__ import annotations

import csv
import itertools
import json
import math
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis


warnings.filterwarnings("ignore", category=RuntimeWarning)


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64

N_RUNS = 50
ENABLE_PLOTS = True
PLOT_SAMPLES_PER_CLASS = 2_500

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
AMPLITUDE_JITTER = 0.05
TIME_JITTER = 0.10
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

DRIFT_START = 3_200
DRIFT_END = 4_800

SHOCK_INDEX = 5_000
SHOCK_AMPLITUDE = 2.5
SHOCK_ANALYSIS_WIDTH = 256

LOW_FREQ_RATIO = 0.1

CLASS_ORDER = ("noise", "burst", "drift", "shock")
CLASS_LABELS = {
    "noise": "Noise",
    "burst": "Symmetric burst",
    "drift": "Coherent drift",
    "shock": "Shock",
}
CLASS_COLORS = {
    "noise": "tab:blue",
    "burst": "tab:green",
    "drift": "tab:red",
    "shock": "black",
}

ORIGINAL_FEATURE_NAMES = (
    "run_length_mean",
    "sign_autocorr_lag1",
    "zero_cross_density",
    "local_monotonicity_ratio",
    "sign_variance",
    "trend_entropy",
)
NEW_FEATURE_NAMES = (
    "linreg_slope_mag",
    "norm_cumsum_mag",
    "low_freq_energy_ratio",
    "window_mean_drift",
)
AUGMENTED_FEATURE_NAMES = ORIGINAL_FEATURE_NAMES + NEW_FEATURE_NAMES


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(slope: float) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    length = DRIFT_END - DRIFT_START
    template[DRIFT_START:DRIFT_END] = slope * np.arange(length, dtype=DTYPE)
    return template


def build_shock_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    template[SHOCK_INDEX:] = SHOCK_AMPLITUDE
    return template


def noise_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[3_000:4_600] = True
    return mask


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[DRIFT_START:DRIFT_END] = True
    return mask


def shock_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[SHOCK_INDEX:SHOCK_INDEX + SHOCK_ANALYSIS_WIDTH] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.01

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(np.mean(trailing_rms(build_drift_template(mid), RMS_WINDOW)[drift_mask()]))
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def generate_noise_signal(rng: np.random.Generator) -> np.ndarray:
    return rng.normal(0.0, NOISE_ONLY_STD, size=NUM_SAMPLES).astype(DTYPE)


def generate_burst_signal(rng: np.random.Generator) -> np.ndarray:
    return rng.normal(0.0, EVENT_NOISE_STD, size=NUM_SAMPLES).astype(DTYPE) + build_burst_template()


def generate_drift_signal(rng: np.random.Generator, slope: float) -> np.ndarray:
    return rng.normal(0.0, EVENT_NOISE_STD, size=NUM_SAMPLES).astype(DTYPE) + build_drift_template(slope)


def generate_shock_signal(rng: np.random.Generator) -> np.ndarray:
    return rng.normal(0.0, EVENT_NOISE_STD, size=NUM_SAMPLES).astype(DTYPE) + build_shock_template()


def sanitize_sign(values: np.ndarray) -> np.ndarray:
    signs = np.sign(values).astype(np.int8)
    if signs.size == 0:
        return signs

    nonzero = np.flatnonzero(signs)
    if nonzero.size == 0:
        signs[:] = 1
        return signs

    signs[: nonzero[0]] = signs[nonzero[0]]
    for i in range(nonzero[0] + 1, signs.size):
        if signs[i] == 0:
            signs[i] = signs[i - 1]

    return signs


def mean_run_length(signs: np.ndarray) -> float:
    if signs.size == 0:
        return 0.0

    lengths = []
    current = 1
    for i in range(1, signs.size):
        if signs[i] == signs[i - 1]:
            current += 1
        else:
            lengths.append(current)
            current = 1
    lengths.append(current)
    return float(np.mean(lengths))


def mean_positive_run_length(values: np.ndarray) -> float:
    positive = values > 0
    if positive.size == 0:
        return 0.0

    runs = []
    current = 0
    for flag in positive:
        if flag:
            current += 1
        elif current > 0:
            runs.append(current)
            current = 0
    if current > 0:
        runs.append(current)
    if not runs:
        return 0.0
    return float(np.mean(runs))


def sign_autocorr_lag1(signs: np.ndarray) -> float:
    if signs.size < 2:
        return 0.0
    x = signs[:-1].astype(DTYPE)
    y = signs[1:].astype(DTYPE)
    x_centered = x - np.mean(x)
    y_centered = y - np.mean(y)
    denom = math.sqrt(float(np.sum(x_centered**2) * np.sum(y_centered**2))) + EPS
    return float(np.sum(x_centered * y_centered) / denom)


def zero_cross_density(signs: np.ndarray) -> float:
    if signs.size < 2:
        return 0.0
    crossings = np.sum(signs[1:] != signs[:-1])
    return float(crossings / (signs.size - 1))


def local_monotonicity_ratio(dx: np.ndarray) -> float:
    return float(abs(np.sum(dx)) / (np.sum(np.abs(dx)) + EPS))


def trend_entropy(signs: np.ndarray) -> float:
    _, counts = np.unique(signs, return_counts=True)
    probabilities = counts.astype(DTYPE) / np.sum(counts)
    entropy = -np.sum(probabilities * np.log2(probabilities + EPS))
    max_entropy = math.log2(len(probabilities)) if len(probabilities) > 1 else 1.0
    return float(entropy / max_entropy)


def linear_regression_slope(window: np.ndarray) -> float:
    n = window.size
    t = np.arange(n, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = window - np.mean(window)
    denom = float(np.sum(t_centered**2)) + EPS
    return float(np.sum(t_centered * y_centered) / denom)


def low_frequency_energy_ratio(window: np.ndarray) -> float:
    centered = window - np.mean(window)
    spectrum = np.fft.rfft(centered)
    energy = np.abs(spectrum) ** 2
    if energy.size == 0:
        return 0.0
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.size)))
    total = float(np.sum(energy)) + EPS
    return float(np.sum(energy[:cutoff]) / total)


def feature_bundle_from_window(window: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    dx = np.diff(window)
    dx_signs = sanitize_sign(dx)
    window_rms = math.sqrt(float(np.mean(window**2))) + EPS
    window_energy = float(np.sum(window**2)) + EPS

    original = np.array(
        [
            mean_run_length(dx_signs),
            sign_autocorr_lag1(dx_signs),
            zero_cross_density(dx_signs),
            local_monotonicity_ratio(dx),
            float(np.var(dx_signs.astype(DTYPE))),
            trend_entropy(dx_signs),
        ],
        dtype=DTYPE,
    )

    slope = linear_regression_slope(window)
    cumulative = np.cumsum(window, dtype=DTYPE)
    augmented_extra = np.array(
        [
            abs(slope) / window_rms,
            float(np.max(np.abs(cumulative)) / window_energy),
            low_frequency_energy_ratio(window),
            float(abs(np.mean(window)) / window_rms),
        ],
        dtype=DTYPE,
    )

    return original, np.concatenate((original, augmented_extra)), slope


def extract_feature_payload(
    signal: np.ndarray,
    mask: np.ndarray,
    window: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    valid_indices = np.flatnonzero(mask)
    valid_indices = valid_indices[valid_indices >= window - 1]
    original = np.empty((valid_indices.size, len(ORIGINAL_FEATURE_NAMES)), dtype=DTYPE)
    augmented = np.empty((valid_indices.size, len(AUGMENTED_FEATURE_NAMES)), dtype=DTYPE)
    slopes = np.empty(valid_indices.size, dtype=DTYPE)

    for row, idx in enumerate(valid_indices):
        segment = signal[idx - window + 1:idx + 1]
        original[row], augmented[row], slopes[row] = feature_bundle_from_window(segment)

    return original, augmented, slopes


def standardize(
    features: np.ndarray,
    mean: np.ndarray | None = None,
    std: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if mean is None:
        mean = np.mean(features, axis=0)
    if std is None:
        std = np.std(features, axis=0)
    std = np.where(std < 1e-6, 1.0, std)
    normalized = (features - mean) / std
    normalized = np.nan_to_num(normalized, nan=0.0, posinf=0.0, neginf=0.0)
    normalized = np.clip(normalized, -100.0, 100.0)
    return normalized, mean, std


def class_centroid(features: np.ndarray) -> np.ndarray:
    return np.mean(features, axis=0)


def within_scatter(features: np.ndarray, centroid: np.ndarray) -> float:
    return float(np.mean(np.sum((features - centroid) ** 2, axis=1)))


def overall_between_within_ratio(feature_by_class: dict[str, np.ndarray]) -> float:
    centroids = {name: class_centroid(feature_by_class[name]) for name in CLASS_ORDER}
    global_centroid = np.mean(np.vstack([centroids[name] for name in CLASS_ORDER]), axis=0)
    between = 0.0
    within = 0.0
    for name in CLASS_ORDER:
        features = feature_by_class[name]
        centroid = centroids[name]
        between += features.shape[0] * float(np.sum((centroid - global_centroid) ** 2))
        within += float(np.sum((features - centroid) ** 2))
    return between / (within + EPS)


def per_class_between_within_ratio(feature_by_class: dict[str, np.ndarray]) -> dict[str, float]:
    centroids = {name: class_centroid(feature_by_class[name]) for name in CLASS_ORDER}
    ratios = {}
    for name in CLASS_ORDER:
        centroid = centroids[name]
        other_centroids = [centroids[other] for other in CLASS_ORDER if other != name]
        between = float(np.mean([np.sum((centroid - other) ** 2) for other in other_centroids]))
        within = within_scatter(feature_by_class[name], centroid)
        ratios[name] = between / (within + EPS)
    return ratios


def fisher_score_1d(feature_by_class: dict[str, np.ndarray], axis: int) -> float:
    centroids = {name: float(np.mean(feature_by_class[name][:, axis])) for name in CLASS_ORDER}
    global_mean = float(np.mean([centroids[name] for name in CLASS_ORDER]))
    between = 0.0
    within = 0.0
    for name in CLASS_ORDER:
        values = feature_by_class[name][:, axis]
        between += values.size * (centroids[name] - global_mean) ** 2
        within += float(np.sum((values - centroids[name]) ** 2))
    return between / (within + EPS)


def lda_score(feature_by_class: dict[str, np.ndarray], classes: tuple[str, ...]) -> float:
    x = np.vstack([feature_by_class[name] for name in classes])
    y = np.concatenate(
        [np.full(feature_by_class[name].shape[0], idx, dtype=np.int64) for idx, name in enumerate(classes)]
    )
    normalized, _, _ = standardize(x)
    lda = LinearDiscriminantAnalysis(
        n_components=min(len(classes) - 1, normalized.shape[1]),
        solver="eigen",
        shrinkage="auto",
    )
    transformed = lda.fit_transform(normalized, y)
    transformed = np.nan_to_num(transformed, nan=0.0, posinf=0.0, neginf=0.0)

    between = 0.0
    within = 0.0
    global_mean = np.mean(transformed, axis=0)
    for idx in range(len(classes)):
        cls_values = transformed[y == idx]
        cls_centroid = np.mean(cls_values, axis=0)
        between += cls_values.shape[0] * float(np.sum((cls_centroid - global_mean) ** 2))
        within += float(np.sum((cls_values - cls_centroid) ** 2))
    return between / (within + EPS)


def pooled_covariance_inverse(feature_by_class: dict[str, np.ndarray]) -> np.ndarray:
    centered = []
    for name in CLASS_ORDER:
        values = feature_by_class[name]
        centered.append(values - np.mean(values, axis=0))
    stacked = np.vstack(centered)
    covariance = np.cov(stacked, rowvar=False) + 1e-6 * np.eye(stacked.shape[1], dtype=DTYPE)
    return np.linalg.pinv(covariance)


def mahalanobis_distance_matrix(feature_by_class: dict[str, np.ndarray]) -> dict[str, dict[str, float]]:
    centroids = {name: class_centroid(feature_by_class[name]) for name in CLASS_ORDER}
    inv_cov = pooled_covariance_inverse(feature_by_class)
    table: dict[str, dict[str, float]] = {}
    for name_i in CLASS_ORDER:
        table[name_i] = {}
        for name_j in CLASS_ORDER:
            delta = centroids[name_i] - centroids[name_j]
            table[name_i][name_j] = float(math.sqrt(max(float(delta @ inv_cov @ delta), 0.0)))
    return table


def correlation_matrix(feature_by_class: dict[str, np.ndarray]) -> np.ndarray:
    stacked = np.vstack([feature_by_class[name] for name in CLASS_ORDER])
    return np.corrcoef(stacked, rowvar=False)


def compute_pca(
    feature_by_class: dict[str, np.ndarray],
    n_components: int,
) -> tuple[dict[str, np.ndarray], np.ndarray]:
    stacked = np.vstack([feature_by_class[name] for name in CLASS_ORDER])
    normalized, mean, std = standardize(stacked)
    covariance = np.cov(normalized, rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    order = np.argsort(eigenvalues)[::-1]
    components = eigenvectors[:, order[:n_components]]
    explained = eigenvalues[order[:n_components]] / (np.sum(eigenvalues) + EPS)

    projections = {}
    for name in CLASS_ORDER:
        values, _, _ = standardize(feature_by_class[name], mean, std)
        projections[name] = np.nan_to_num(values @ components, nan=0.0, posinf=0.0, neginf=0.0)

    return projections, explained


def apply_amplitude_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    scale = 1.0 + rng.normal(0.0, AMPLITUDE_JITTER, size=signal.size).astype(DTYPE)
    return signal * scale


def apply_time_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    t = np.arange(signal.size, dtype=DTYPE)
    offsets = rng.uniform(-TIME_JITTER, TIME_JITTER, size=signal.size).astype(DTYPE)
    jittered_t = np.clip(t + offsets, 0.0, signal.size - 1.0)
    return np.interp(t, jittered_t, signal).astype(DTYPE)


def apply_combined_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    return apply_amplitude_jitter(apply_time_jitter(signal, rng), rng)


def feature_importance_ranking(
    feature_by_class: dict[str, np.ndarray],
    feature_names: tuple[str, ...],
) -> list[tuple[str, float]]:
    scores = [(feature_names[i], fisher_score_1d(feature_by_class, i)) for i in range(len(feature_names))]
    scores.sort(key=lambda item: item[1], reverse=True)
    return scores


def subsample(values: np.ndarray, rng: np.random.Generator, size: int) -> np.ndarray:
    if values.shape[0] <= size:
        return values
    idx = rng.choice(values.shape[0], size=size, replace=False)
    return values[idx]


def analyze_space(
    feature_by_class: dict[str, np.ndarray],
    feature_names: tuple[str, ...],
) -> dict[str, object]:
    centroids = {name: class_centroid(feature_by_class[name]) for name in CLASS_ORDER}
    fisher = {feature_names[i]: fisher_score_1d(feature_by_class, i) for i in range(len(feature_names))}
    pairwise_lda = {}
    for class_a, class_b in itertools.combinations(CLASS_ORDER, 2):
        pairwise_lda[f"{class_a} vs {class_b}"] = lda_score(feature_by_class, (class_a, class_b))

    return {
        "centroids": centroids,
        "correlation": correlation_matrix(feature_by_class),
        "overall_ratio": overall_between_within_ratio(feature_by_class),
        "per_class_ratio": per_class_between_within_ratio(feature_by_class),
        "fisher": fisher,
        "pairwise_lda": pairwise_lda,
        "mahalanobis": mahalanobis_distance_matrix(feature_by_class),
        "pca2": compute_pca(feature_by_class, 2),
        "pca3": compute_pca(feature_by_class, 3),
        "ranking": feature_importance_ranking(feature_by_class, feature_names),
    }


def save_results(
    output_dir: Path,
    original_analysis: dict[str, object],
    augmented_analysis: dict[str, object],
    temporal_persistence: dict[str, float],
    burst_rms: list[float],
    drift_rms: list[float],
    stability: dict[str, dict[str, list[float]]],
) -> None:
    json_path = output_dir / "compare_rms_cbdd_results.json"
    csv_path = output_dir / "compare_rms_cbdd_centroids.csv"

    def serialize_analysis(analysis: dict[str, object], feature_names: tuple[str, ...]) -> dict[str, object]:
        pca2_proj, pca2_exp = analysis["pca2"]  # type: ignore[index]
        pca3_proj, pca3_exp = analysis["pca3"]  # type: ignore[index]
        _ = pca2_proj, pca3_proj
        return {
            "feature_names": list(feature_names),
            "centroids": {name: analysis["centroids"][name].tolist() for name in CLASS_ORDER},  # type: ignore[index]
            "correlation": analysis["correlation"].tolist(),  # type: ignore[index]
            "overall_ratio": analysis["overall_ratio"],
            "per_class_ratio": analysis["per_class_ratio"],
            "fisher": analysis["fisher"],
            "pairwise_lda": analysis["pairwise_lda"],
            "mahalanobis": analysis["mahalanobis"],
            "ranking": [{"feature": name, "score": score} for name, score in analysis["ranking"]],  # type: ignore[index]
            "pca2_explained": pca2_exp.tolist(),
            "pca3_explained": pca3_exp.tolist(),
        }

    payload = {
        "rms_equivalence": {
            "burst_mean": float(np.mean(burst_rms)),
            "burst_std": float(np.std(burst_rms)),
            "drift_mean": float(np.mean(drift_rms)),
            "drift_std": float(np.std(drift_rms)),
        },
        "original": serialize_analysis(original_analysis, ORIGINAL_FEATURE_NAMES),
        "augmented": serialize_analysis(augmented_analysis, AUGMENTED_FEATURE_NAMES),
        "drift_vs_noise": {
            "original_pairwise_lda": original_analysis["pairwise_lda"]["noise vs drift"],  # type: ignore[index]
            "augmented_pairwise_lda": augmented_analysis["pairwise_lda"]["noise vs drift"],  # type: ignore[index]
            "original_mahalanobis": original_analysis["mahalanobis"]["noise"]["drift"],  # type: ignore[index]
            "augmented_mahalanobis": augmented_analysis["mahalanobis"]["noise"]["drift"],  # type: ignore[index]
        },
        "temporal_persistence": temporal_persistence,
        "stability": stability,
    }
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["feature_set", "class", "feature", "value"])
        for feature_set_name, analysis, feature_names in (
            ("original", original_analysis, ORIGINAL_FEATURE_NAMES),
            ("augmented", augmented_analysis, AUGMENTED_FEATURE_NAMES),
        ):
            for class_name in CLASS_ORDER:
                centroid = analysis["centroids"][class_name]  # type: ignore[index]
                for feature_name, value in zip(feature_names, centroid):
                    writer.writerow([feature_set_name, class_name, feature_name, float(value)])


def print_rms_equivalence(burst_rms: list[float], drift_rms: list[float]) -> None:
    burst_mean = float(np.mean(burst_rms))
    burst_std = float(np.std(burst_rms))
    drift_mean = float(np.mean(drift_rms))
    drift_std = float(np.std(drift_rms))
    gap = abs(burst_mean - drift_mean) / (0.5 * (burst_mean + drift_mean) + EPS)
    status = "PASS" if gap <= 0.05 else "WARN"

    print("RMS equivalence")
    print("---------------")
    print(f"{'Class':<18} | {'Mean RMS':<12} | {'Std RMS':<12}")
    print("----------------------------------------------")
    print(f"{'Symmetric burst':<18} | {burst_mean:<12.6f} | {burst_std:<12.6f}")
    print(f"{'Coherent drift':<18} | {drift_mean:<12.6f} | {drift_std:<12.6f}")
    print(f"Relative gap: {100.0 * gap:.2f}% [{status}]")


def print_feature_ranking(title: str, ranking: list[tuple[str, float]]) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    for feature_name, score in ranking:
        print(f"  {feature_name}: {score:.6f}")


def print_centroids(title: str, centroids: dict[str, np.ndarray], feature_names: tuple[str, ...]) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    header = "Class".ljust(18) + " | " + " | ".join(name[:14].ljust(14) for name in feature_names)
    print(header)
    print("-" * len(header))
    for name in CLASS_ORDER:
        row = " | ".join(f"{centroids[name][i]:<14.6f}" for i in range(len(feature_names)))
        print(f"{CLASS_LABELS[name]:<18} | {row}")


def print_ratios(title: str, overall_ratio: float, per_class_ratio: dict[str, float]) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    print(f"Overall ratio: {overall_ratio:.6f}")
    for name in CLASS_ORDER:
        print(f"  {CLASS_LABELS[name]}: {per_class_ratio[name]:.6f}")


def print_pairwise_lda(title: str, pairwise_lda: dict[str, float]) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    for name, score in pairwise_lda.items():
        print(f"  {name}: {score:.6f}")


def print_mahalanobis(title: str, table: dict[str, dict[str, float]]) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    header = "Class".ljust(18) + " | " + " | ".join(CLASS_LABELS[name][:18].ljust(18) for name in CLASS_ORDER)
    print(header)
    print("-" * len(header))
    for row_name in CLASS_ORDER:
        row = " | ".join(f"{table[row_name][col_name]:<18.6f}" for col_name in CLASS_ORDER)
        print(f"{CLASS_LABELS[row_name]:<18} | {row}")


def print_drift_vs_noise(original_analysis: dict[str, object], augmented_analysis: dict[str, object]) -> None:
    print("\nDrift vs Noise separability")
    print("---------------------------")
    print(
        f"Pairwise LDA: original={original_analysis['pairwise_lda']['noise vs drift']:.6f} "
        f"augmented={augmented_analysis['pairwise_lda']['noise vs drift']:.6f}"  # type: ignore[index]
    )
    print(
        f"Mahalanobis distance: original={original_analysis['mahalanobis']['noise']['drift']:.6f} "
        f"augmented={augmented_analysis['mahalanobis']['noise']['drift']:.6f}"  # type: ignore[index]
    )
    print(
        f"Overall ratio: original={original_analysis['overall_ratio']:.6f} "
        f"augmented={augmented_analysis['overall_ratio']:.6f}"
    )


def print_before_after(original_analysis: dict[str, object], augmented_analysis: dict[str, object]) -> None:
    print("\nBefore/after comparison")
    print("-----------------------")
    print(
        f"{'Metric':<28} | {'Original':<12} | {'Augmented':<12}"
    )
    print("-" * 60)
    rows = [
        ("overall_ratio", original_analysis["overall_ratio"], augmented_analysis["overall_ratio"]),
        (
            "noise_vs_drift_lda",
            original_analysis["pairwise_lda"]["noise vs drift"],  # type: ignore[index]
            augmented_analysis["pairwise_lda"]["noise vs drift"],  # type: ignore[index]
        ),
        (
            "noise_vs_drift_mahal",
            original_analysis["mahalanobis"]["noise"]["drift"],  # type: ignore[index]
            augmented_analysis["mahalanobis"]["noise"]["drift"],  # type: ignore[index]
        ),
        (
            "drift_feature_top_score",
            next(iter(original_analysis["ranking"]))[1],  # type: ignore[arg-type]
            next(iter(augmented_analysis["ranking"]))[1],  # type: ignore[arg-type]
        ),
    ]
    for name, original_value, augmented_value in rows:
        print(f"{name:<28} | {float(original_value):<12.6f} | {float(augmented_value):<12.6f}")


def print_matrix(title: str, matrix: np.ndarray, feature_names: tuple[str, ...]) -> None:
    print(f"\n{title}")
    print("-" * len(title))
    header = "Feature".ljust(24) + " | " + " | ".join(name[:13].ljust(13) for name in feature_names)
    print(header)
    print("-" * len(header))
    for i, name in enumerate(feature_names):
        row = " | ".join(f"{matrix[i, j]:<13.4f}" for j in range(len(feature_names)))
        print(f"{name:<24} | {row}")


def print_stability(stability: dict[str, dict[str, list[float]]]) -> None:
    print("\nStability summary")
    print("-----------------")
    for mode_name, class_values in stability.items():
        print(mode_name)
        print(f"{'Class':<18} | {'Mean shift':<12} | {'Std shift':<12}")
        print("-" * 48)
        for class_name in CLASS_ORDER:
            values = np.array(class_values[class_name], dtype=DTYPE)
            print(
                f"{CLASS_LABELS[class_name]:<18} | "
                f"{float(np.mean(values)):<12.6f} | "
                f"{float(np.std(values)):<12.6f}"
            )


def print_temporal_persistence(persistence: dict[str, float]) -> None:
    print("\nTemporal persistence test")
    print("-------------------------")
    for class_name in CLASS_ORDER:
        print(f"{CLASS_LABELS[class_name]}: {persistence[class_name]:.6f}")


def plot_pca(
    original_analysis: dict[str, object],
    augmented_analysis: dict[str, object],
) -> None:
    original_pca2, _ = original_analysis["pca2"]  # type: ignore[index]
    augmented_pca2, _ = augmented_analysis["pca2"]  # type: ignore[index]
    augmented_pca3, _ = augmented_analysis["pca3"]  # type: ignore[index]
    rng = np.random.default_rng(SEED + 505)

    fig = plt.figure(figsize=(16, 6))
    ax1 = fig.add_subplot(1, 3, 1)
    ax2 = fig.add_subplot(1, 3, 2)
    ax3 = fig.add_subplot(1, 3, 3, projection="3d")

    for name in CLASS_ORDER:
        orig = subsample(original_pca2[name], rng, PLOT_SAMPLES_PER_CLASS)  # type: ignore[index]
        aug2 = subsample(augmented_pca2[name], rng, PLOT_SAMPLES_PER_CLASS)  # type: ignore[index]
        aug3 = subsample(augmented_pca3[name], rng, PLOT_SAMPLES_PER_CLASS)  # type: ignore[index]

        ax1.scatter(orig[:, 0], orig[:, 1], s=8, alpha=0.22, color=CLASS_COLORS[name], label=CLASS_LABELS[name])
        ax2.scatter(aug2[:, 0], aug2[:, 1], s=8, alpha=0.22, color=CLASS_COLORS[name])
        ax3.scatter(aug3[:, 0], aug3[:, 1], aug3[:, 2], s=8, alpha=0.18, color=CLASS_COLORS[name])

    ax1.set_title("Original PCA 2D")
    ax1.set_xlabel("PC1")
    ax1.set_ylabel("PC2")
    ax1.grid(True, alpha=0.25)

    ax2.set_title("Augmented PCA 2D")
    ax2.set_xlabel("PC1")
    ax2.set_ylabel("PC2")
    ax2.grid(True, alpha=0.25)

    ax3.set_title("Augmented PCA 3D")
    ax3.set_xlabel("PC1")
    ax3.set_ylabel("PC2")
    ax3.set_zlabel("PC3")

    handles, labels = ax1.get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    plt.show()


def main() -> None:
    output_dir = Path(__file__).resolve().parent
    slope = calibrate_drift_slope()
    masks = {
        "noise": noise_mask(),
        "burst": burst_mask(),
        "drift": drift_mask(),
        "shock": shock_mask(),
    }

    original_runs = {name: [] for name in CLASS_ORDER}
    augmented_runs = {name: [] for name in CLASS_ORDER}
    burst_rms = []
    drift_rms = []
    slope_persistence = {name: [] for name in CLASS_ORDER}
    stability = {
        "amplitude_jitter": {name: [] for name in CLASS_ORDER},
        "time_jitter": {name: [] for name in CLASS_ORDER},
        "combined_jitter": {name: [] for name in CLASS_ORDER},
    }

    for run_idx in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_idx)
        signals = {
            "noise": generate_noise_signal(rng),
            "burst": generate_burst_signal(rng),
            "drift": generate_drift_signal(rng, slope),
            "shock": generate_shock_signal(rng),
        }

        for name in CLASS_ORDER:
            original_features, augmented_features, slope_series = extract_feature_payload(
                signals[name], masks[name], FEATURE_WINDOW
            )
            original_runs[name].append(original_features)
            augmented_runs[name].append(augmented_features)
            slope_persistence[name].append(mean_positive_run_length(slope_series))

            rms_mean = float(np.mean(trailing_rms(signals[name], RMS_WINDOW)[masks[name]]))
            if name == "burst":
                burst_rms.append(rms_mean)
            elif name == "drift":
                drift_rms.append(rms_mean)

            perturbed_signals = {
                "amplitude_jitter": apply_amplitude_jitter(signals[name], rng),
                "time_jitter": apply_time_jitter(signals[name], rng),
                "combined_jitter": apply_combined_jitter(signals[name], rng),
            }
            base_centroid = class_centroid(augmented_features)
            for mode_name, perturbed_signal in perturbed_signals.items():
                _, perturbed_augmented, _ = extract_feature_payload(perturbed_signal, masks[name], FEATURE_WINDOW)
                shift = float(np.linalg.norm(class_centroid(perturbed_augmented) - base_centroid))
                stability[mode_name][name].append(shift)

    original_by_class = {name: np.vstack(original_runs[name]).astype(DTYPE, copy=False) for name in CLASS_ORDER}
    augmented_by_class = {name: np.vstack(augmented_runs[name]).astype(DTYPE, copy=False) for name in CLASS_ORDER}
    temporal_persistence = {name: float(np.mean(slope_persistence[name])) for name in CLASS_ORDER}

    original_analysis = analyze_space(original_by_class, ORIGINAL_FEATURE_NAMES)
    augmented_analysis = analyze_space(augmented_by_class, AUGMENTED_FEATURE_NAMES)

    print_rms_equivalence(burst_rms, drift_rms)
    print_matrix("Augmented feature correlation matrix", augmented_analysis["correlation"], AUGMENTED_FEATURE_NAMES)  # type: ignore[arg-type]
    print_feature_ranking("Original feature importance", original_analysis["ranking"])  # type: ignore[arg-type]
    print_feature_ranking("Ranked feature importance", augmented_analysis["ranking"])  # type: ignore[arg-type]
    print_centroids("Original centroid table", original_analysis["centroids"], ORIGINAL_FEATURE_NAMES)  # type: ignore[arg-type]
    print_centroids("Augmented centroid table", augmented_analysis["centroids"], AUGMENTED_FEATURE_NAMES)  # type: ignore[arg-type]
    print_ratios(
        "Original variance ratios",
        float(original_analysis["overall_ratio"]),
        original_analysis["per_class_ratio"],  # type: ignore[arg-type]
    )
    print_ratios(
        "Augmented variance ratios",
        float(augmented_analysis["overall_ratio"]),
        augmented_analysis["per_class_ratio"],  # type: ignore[arg-type]
    )
    print_pairwise_lda("Original pairwise LDA", original_analysis["pairwise_lda"])  # type: ignore[arg-type]
    print_pairwise_lda("Augmented pairwise LDA", augmented_analysis["pairwise_lda"])  # type: ignore[arg-type]
    print_mahalanobis("Original Mahalanobis distances", original_analysis["mahalanobis"])  # type: ignore[arg-type]
    print_mahalanobis("Augmented Mahalanobis distances", augmented_analysis["mahalanobis"])  # type: ignore[arg-type]
    print_drift_vs_noise(original_analysis, augmented_analysis)
    print_before_after(original_analysis, augmented_analysis)
    print_temporal_persistence(temporal_persistence)
    print_stability(stability)

    save_results(
        output_dir,
        original_analysis,
        augmented_analysis,
        temporal_persistence,
        burst_rms,
        drift_rms,
        stability,
    )

    if ENABLE_PLOTS:
        plot_pca(original_analysis, augmented_analysis)


if __name__ == "__main__":
    main()
