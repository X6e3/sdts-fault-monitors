# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, dataclass, replace
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
from sklearn.metrics import roc_auc_score

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from deprecated.detectors import rms_detector_causal, rms_event_detector_causal
from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    DMREDAProfile,
    compute_dmreda_reference,
    compute_warmup_samples,
)
from gold_line.support.signal_gen import SignalMetadata, generate_signal


ROOT = Path("/Users/x6e3/vscode")
RESULT_DIR = ROOT / "results"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

N_SAMPLES = 5000
AMPLITUDE = 0.8
NOISE_LEVELS = (0.2, 0.3, 0.5)
SEED_COUNT = int(os.environ.get("DMREDA_NUM_SEEDS", "20"))
SEEDS = tuple(range(SEED_COUNT))
RAMP_LENGTHS = (5, 10, 20, 40, 80, 160, 320)
TARGET_FALSE_ALARM_RATE = 0.05
G_ONLY_FA_PER_1000_TARGET = 0.02
SWEEP_MODES = tuple(
    mode.strip()
    for mode in os.environ.get("DMREDA_SWEEP_MODES", "D_or_G").split(",")
    if mode.strip()
)
THETA_G_SWEEP_SCALES = tuple(
    float(value.strip())
    for value in os.environ.get("DMREDA_THETA_G_SWEEP_SCALES", "1.0").split(",")
    if value.strip()
)

STATE0_PROFILE = DEFAULT_PROFILES[0]
RMS_WINDOW = max(profile.w2 for profile in DEFAULT_PROFILES.values())
RMS_CONFIRM_WINDOW = STATE0_PROFILE.confirm_base
RMS_N_PERSIST = STATE0_PROFILE.n_min
RMS_REFRACTORY = STATE0_PROFILE.refractory

COMPARE_SCRIPT = ROOT / "playground" / "offline_diagnostic_only" / "compare_rms_cbdd.py"
CURVATURE_SCRIPT = ROOT / "playground" / "offline_diagnostic_only" / "curvature_diagnostics.py"

TASK1_JSON = RESULT_DIR / "task1_g_channel_independence.json"
TASK2_JSON = RESULT_DIR / "task2_g_threshold_recalibration.json"
TASK3_JSON = RESULT_DIR / "task3_ramp_operating_region.json"
TASK4_JSON = RESULT_DIR / "task4_strong_zone.json"
TASK5_JSON = RESULT_DIR / "task5_reduced_feature_set.json"
TASK6_JSON = RESULT_DIR / "task6_coupled_score_variants.json"
FINAL_JSON = RESULT_DIR / "dmreda_operating_map.json"


@dataclass(frozen=True)
class EvalConfig:
    config_id: str
    warmup_samples: int
    mode: str
    w1_override: Optional[int] = None
    th_scale: Optional[Dict[str, float]] = None


@dataclass(frozen=True)
class Condition:
    disturbance: str
    noise_std: float
    amplitude: float
    ramp_len: Optional[int] = None

    @property
    def label(self) -> str:
        if self.ramp_len is None:
            return self.disturbance
        return f"{self.disturbance}(ramp_len={self.ramp_len})"


@dataclass
class Trial:
    signal: np.ndarray
    meta: SignalMetadata


def load_module(module_path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def make_shock_trial(
    n: int,
    *,
    amplitude: float,
    noise_std: float,
    seed: int,
    disturb_idx: Optional[int] = None,
) -> Trial:
    if disturb_idx is None:
        disturb_idx = n // 2
    rng = np.random.default_rng(seed)
    signal = rng.normal(0.0, noise_std, n)
    signal[disturb_idx:] += amplitude
    meta = SignalMetadata(
        disturbance_type="shock",
        start=disturb_idx,
        end=n,
        amplitude=amplitude,
        noise_std=noise_std,
        seed=seed,
    )
    return Trial(signal=signal, meta=meta)


def build_trials(condition: Condition) -> List[Trial]:
    trials: List[Trial] = []
    for seed in SEEDS:
        if condition.disturbance == "shock":
            trials.append(
                make_shock_trial(
                    N_SAMPLES,
                    amplitude=condition.amplitude,
                    noise_std=condition.noise_std,
                    seed=seed,
                )
            )
            continue

        signal, meta = generate_signal(
            N_SAMPLES,
            disturbance_type=condition.disturbance,
            amplitude=condition.amplitude,
            noise_std=condition.noise_std,
            seed=seed,
            ramp_len=condition.ramp_len if condition.ramp_len is not None else 200,
            return_metadata=True,
        )
        trials.append(Trial(signal=signal, meta=meta))
    return trials


def build_eval_profiles(eval_config: EvalConfig, base_profiles: Mapping[int, DMREDAProfile]) -> Dict[int, DMREDAProfile]:
    scales = eval_config.th_scale or {}
    theta_d_scale = scales.get("thetaD", 1.0)
    theta_g_scale = scales.get("thetaG", 1.0)
    theta_a_scale = scales.get("thetaA", 1.0)

    profiles: Dict[int, DMREDAProfile] = {}
    for state, profile in base_profiles.items():
        updated = replace(
            profile,
            th_d=profile.th_d * theta_d_scale,
            th_g=profile.th_g * theta_g_scale,
            th_a=profile.th_a * theta_a_scale,
        )
        if eval_config.w1_override is not None:
            updated = replace(updated, w1=eval_config.w1_override)
        profiles[state] = updated
    return profiles


def make_eval_config_grid(base_profiles: Mapping[int, DMREDAProfile]) -> List[EvalConfig]:
    configs: List[EvalConfig] = []
    config_idx = 1
    for w1 in (3, 5, 7, 9, 11):
        for theta_a_scale in (0.6, 0.8, 1.0, 1.2, 1.4):
            for theta_d_scale in (0.8, 1.0, 1.2):
                for theta_g_scale in THETA_G_SWEEP_SCALES:
                    for mode in SWEEP_MODES:
                        provisional = EvalConfig(
                            config_id=f"CFG_{config_idx:04d}",
                            warmup_samples=0,
                            mode=mode,
                            w1_override=w1,
                            th_scale={
                                "thetaA": theta_a_scale,
                                "thetaD": theta_d_scale,
                                "thetaG": theta_g_scale,
                            },
                        )
                        warmup = compute_warmup_samples(build_eval_profiles(provisional, base_profiles))
                        configs.append(replace(provisional, warmup_samples=warmup))
                        config_idx += 1
    return configs


def evaluate_event_times(
    event_times: Sequence[int],
    meta: SignalMetadata,
    signal_len: int,
    *,
    detection_horizon: int = 200,
) -> Tuple[bool, bool, float]:
    false_alarm = any(t < meta.start for t in event_times)
    detection_end = min(signal_len, max(meta.end, meta.start + detection_horizon))
    post_events = [t for t in event_times if meta.start <= t < detection_end]
    detected = len(post_events) > 0
    latency = float(post_events[0] - meta.start) if detected else math.nan
    return detected, false_alarm, latency


def summarize_metrics(metric_rows: Sequence[Tuple[bool, bool, float]]) -> Dict[str, float]:
    detections = np.array([row[0] for row in metric_rows], dtype=float)
    false_alarms = np.array([row[1] for row in metric_rows], dtype=float)
    latencies = np.array([row[2] for row in metric_rows], dtype=float)
    valid_latencies = latencies[~np.isnan(latencies)]
    return {
        "latency_mean": float(np.mean(valid_latencies)) if valid_latencies.size else math.nan,
        "latency_std": float(np.std(valid_latencies)) if valid_latencies.size else math.nan,
        "detection_rate": float(np.mean(detections)),
        "false_alarm_rate": float(np.mean(false_alarms)),
    }


def calibrate_rms_threshold(
    trials: Sequence[Trial],
    *,
    warmup_samples: int,
) -> float:
    scores = [rms_detector_causal(trial.signal, window=RMS_WINDOW)[1] for trial in trials]
    pooled_pre = np.concatenate([score[warmup_samples : trial.meta.start] for score, trial in zip(scores, trials)])
    candidates = np.unique(np.quantile(pooled_pre, np.linspace(0.80, 0.9995, 96)))
    candidates = np.append(candidates, np.max(pooled_pre) + 1e-9)

    selected_threshold = float(candidates[-1])
    for threshold in candidates:
        fa_flags = []
        for trial in trials:
            rms_result = rms_event_detector_causal(
                trial.signal,
                threshold=float(threshold),
                window=RMS_WINDOW,
                confirm_window=RMS_CONFIRM_WINDOW,
                n_persist=RMS_N_PERSIST,
                refractory=RMS_REFRACTORY,
                warmup_samples=warmup_samples,
            )
            _, false_alarm, _ = evaluate_event_times(
                rms_result.event_times,
                trial.meta,
                len(trial.signal),
            )
            fa_flags.append(false_alarm)
        if float(np.mean(fa_flags)) <= TARGET_FALSE_ALARM_RATE:
            selected_threshold = float(threshold)
            break

    return selected_threshold


def evaluate_rms_condition(
    trials: Sequence[Trial],
    *,
    warmup_samples: int,
) -> Dict[str, float]:
    threshold = calibrate_rms_threshold(trials, warmup_samples=warmup_samples)
    metrics = []
    for trial in trials:
        rms_result = rms_event_detector_causal(
            trial.signal,
            threshold=threshold,
            window=RMS_WINDOW,
            confirm_window=RMS_CONFIRM_WINDOW,
            n_persist=RMS_N_PERSIST,
            refractory=RMS_REFRACTORY,
            warmup_samples=warmup_samples,
        )
        metrics.append(
            evaluate_event_times(
                rms_result.event_times,
                trial.meta,
                len(trial.signal),
            )
        )

    summary = summarize_metrics(metrics)
    summary["threshold"] = threshold
    return summary


def format_value(value: object) -> str:
    if isinstance(value, float):
        if math.isnan(value):
            return "nan"
        return f"{value:.4f}"
    return str(value)


def regress_residual_variance(x: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    x = x[valid]
    y = y[valid]
    if x.size < 3:
        return {
            "corr_d_g": math.nan,
            "beta": math.nan,
            "intercept": math.nan,
            "residual_variance_fraction": math.nan,
            "r_squared": math.nan,
            "partial_corr_after_regression": math.nan,
            "sample_count": int(x.size),
        }
    x_mean = float(np.mean(x))
    y_mean = float(np.mean(y))
    var_x = float(np.var(x))
    cov_xy = float(np.mean((x - x_mean) * (y - y_mean)))
    beta = cov_xy / max(var_x, 1e-12)
    intercept = y_mean - beta * x_mean
    y_hat = intercept + beta * x
    resid = y - y_hat
    var_y = float(np.var(y))
    var_resid = float(np.var(resid))
    corr = float(np.corrcoef(x, y)[0, 1]) if np.std(x) > 0.0 and np.std(y) > 0.0 else math.nan
    corr_partial = float(np.corrcoef(x, resid)[0, 1]) if np.std(resid) > 0.0 and np.std(x) > 0.0 else 0.0
    residual_fraction = var_resid / max(var_y, 1e-12)
    return {
        "corr_d_g": corr,
        "beta": beta,
        "intercept": intercept,
        "residual_variance_fraction": residual_fraction,
        "r_squared": 1.0 - residual_fraction,
        "partial_corr_after_regression": corr_partial,
        "sample_count": int(x.size),
    }


def collect_trials_for_analysis() -> List[Trial]:
    conditions: List[Condition] = []
    for noise_std in NOISE_LEVELS:
        for disturbance in ("burst", "drift", "shock"):
            conditions.append(Condition(disturbance=disturbance, noise_std=noise_std, amplitude=AMPLITUDE))
        for ramp_len in RAMP_LENGTHS:
            conditions.append(Condition(disturbance="ramp", noise_std=noise_std, amplitude=AMPLITUDE, ramp_len=ramp_len))

    trials: List[Trial] = []
    for condition in conditions:
        trials.extend(build_trials(condition))
    return trials


def run_task1_g_channel_independence(base_profiles: Mapping[int, DMREDAProfile]) -> Dict[str, object]:
    warmup_samples = compute_warmup_samples(base_profiles)
    pooled_all_d: List[np.ndarray] = []
    pooled_all_g: List[np.ndarray] = []
    pooled_pre_d: List[np.ndarray] = []
    pooled_pre_g: List[np.ndarray] = []

    for trial in collect_trials_for_analysis():
        result = compute_dmreda_reference(
            trial.signal,
            profiles=base_profiles,
            mode="D_or_G",
            warmup_samples=warmup_samples,
        )
        idx_all = np.arange(warmup_samples, len(trial.signal), dtype=int)
        idx_pre = np.arange(warmup_samples, trial.meta.start, dtype=int)
        pooled_all_d.append(result.d[idx_all])
        pooled_all_g.append(result.g[idx_all])
        pooled_pre_d.append(result.d[idx_pre])
        pooled_pre_g.append(result.g[idx_pre])

    full_stats = regress_residual_variance(np.concatenate(pooled_all_d), np.concatenate(pooled_all_g))
    noise_stats = regress_residual_variance(np.concatenate(pooled_pre_d), np.concatenate(pooled_pre_g))

    report = {
        "warmup_samples": warmup_samples,
        "full_trace": full_stats,
        "pre_event_noise_only": noise_stats,
        "g_channel_independent": bool(full_stats["residual_variance_fraction"] >= 0.05),
        "flag": (
            "G channel carries no independent information"
            if full_stats["residual_variance_fraction"] < 0.05
            else "G channel retains non-trivial residual information"
        ),
    }
    TASK1_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("\nTASK 1 — G channel independence")
    print("Scope | Corr(D,G) | ResidualVarFrac | R^2 | Flag")
    for scope_name, stats in (("full_trace", full_stats), ("pre_event_noise_only", noise_stats)):
        print(
            f"{scope_name} | {format_value(stats['corr_d_g'])} | "
            f"{format_value(stats['residual_variance_fraction'])} | "
            f"{format_value(stats['r_squared'])} | "
            f"{'NO_INDEPENDENT_INFO' if stats['residual_variance_fraction'] < 0.05 else 'HAS_RESIDUAL'}"
        )
    return report


def collect_pre_event_g_samples(
    trials: Sequence[Trial],
    base_profiles: Mapping[int, DMREDAProfile],
    warmup_samples: int,
) -> Dict[int, np.ndarray]:
    state_samples: Dict[int, List[np.ndarray]] = {state: [] for state in base_profiles}
    for trial in trials:
        result = compute_dmreda_reference(
            trial.signal,
            profiles=base_profiles,
            mode="G_only",
            warmup_samples=warmup_samples,
        )
        valid = np.arange(warmup_samples, trial.meta.start, dtype=int)
        for state in base_profiles:
            state_idx = valid[result.state[valid] == state]
            if state_idx.size:
                state_samples[state].append(result.g[state_idx])
    return {
        state: np.concatenate(chunks) if chunks else np.array([], dtype=float)
        for state, chunks in state_samples.items()
    }


def thresholds_to_profiles(
    base_profiles: Mapping[int, DMREDAProfile],
    th_g_map: Mapping[int, float],
) -> Dict[int, DMREDAProfile]:
    profiles: Dict[int, DMREDAProfile] = {}
    for state, profile in base_profiles.items():
        profiles[state] = replace(profile, th_g=float(th_g_map[state]))
    return profiles


def compute_pre_event_g_only_rate_per_1000(
    trials: Sequence[Trial],
    profiles: Mapping[int, DMREDAProfile],
    *,
    warmup_samples: int,
) -> Dict[str, float]:
    total_pre_samples = 0
    false_alarm_events = 0
    for trial in trials:
        result = compute_dmreda_reference(
            trial.signal,
            profiles=profiles,
            mode="G_only",
            warmup_samples=warmup_samples,
        )
        total_pre_samples += max(0, trial.meta.start - warmup_samples)
        false_alarm_events += sum(warmup_samples <= t < trial.meta.start for t in result.event_times)
    rate_per_1000 = 1000.0 * false_alarm_events / max(total_pre_samples, 1)
    return {
        "false_alarm_events": int(false_alarm_events),
        "total_pre_samples": int(total_pre_samples),
        "rate_per_1000_samples": float(rate_per_1000),
    }


def calibrate_theta_g_by_state(
    base_profiles: Mapping[int, DMREDAProfile],
    trials: Sequence[Trial],
) -> Dict[str, object]:
    warmup_samples = compute_warmup_samples(base_profiles)
    pooled = collect_pre_event_g_samples(trials, base_profiles, warmup_samples)
    target_sample_rate = G_ONLY_FA_PER_1000_TARGET / 1000.0

    raw_thresholds: Dict[int, float] = {}
    pooled_counts: Dict[int, int] = {}
    for state, values in pooled.items():
        pooled_counts[state] = int(values.size)
        if values.size == 0:
            raw_thresholds[state] = base_profiles[state].th_g
            continue
        q = max(0.0, min(1.0, 1.0 - target_sample_rate))
        raw_thresholds[state] = float(np.quantile(values, q))

    scale_candidates = np.concatenate(
        [
            np.linspace(1.0, 2.5, 31),
            np.linspace(2.6, 5.0, 13),
        ]
    )
    best_scale = float(scale_candidates[-1])
    best_rate = math.inf
    best_profiles = thresholds_to_profiles(base_profiles, raw_thresholds)
    for scale in scale_candidates:
        scaled_thresholds = {state: raw_thresholds[state] * float(scale) for state in raw_thresholds}
        scaled_profiles = thresholds_to_profiles(base_profiles, scaled_thresholds)
        stats = compute_pre_event_g_only_rate_per_1000(
            trials,
            scaled_profiles,
            warmup_samples=warmup_samples,
        )
        if stats["rate_per_1000_samples"] <= G_ONLY_FA_PER_1000_TARGET:
            best_scale = float(scale)
            best_rate = float(stats["rate_per_1000_samples"])
            best_profiles = scaled_profiles
            break
        if stats["rate_per_1000_samples"] < best_rate:
            best_rate = float(stats["rate_per_1000_samples"])
            best_scale = float(scale)
            best_profiles = scaled_profiles

    rate_stats = compute_pre_event_g_only_rate_per_1000(
        trials,
        best_profiles,
        warmup_samples=warmup_samples,
    )
    report = {
        "warmup_samples": warmup_samples,
        "target_fa_per_1000_samples": G_ONLY_FA_PER_1000_TARGET,
        "raw_state_thresholds": {str(k): float(v) for k, v in raw_thresholds.items()},
        "selected_scale": best_scale,
        "selected_state_thresholds": {str(k): float(v.th_g) for k, v in best_profiles.items()},
        "pooled_state_sample_counts": pooled_counts,
        "achieved_g_only_pre_event_rate": rate_stats,
    }
    TASK2_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("\nTASK 2 — thetaG recalibration")
    print("State | thetaG_old | thetaG_new")
    for state in sorted(base_profiles):
        print(
            f"{state} | {format_value(base_profiles[state].th_g)} | "
            f"{format_value(best_profiles[state].th_g)}"
        )
    print(
        "G_ONLY_PRE_EVENT_FA "
        f"target_per_1000={format_value(G_ONLY_FA_PER_1000_TARGET)} "
        f"achieved_per_1000={format_value(rate_stats['rate_per_1000_samples'])}"
    )
    return {
        "report": report,
        "profiles": best_profiles,
    }


def evaluate_dmreda_config(
    condition: Condition,
    trials: Sequence[Trial],
    eval_config: EvalConfig,
    rms_summary: Dict[str, float],
    base_profiles: Mapping[int, DMREDAProfile],
) -> Dict[str, float]:
    profiles = build_eval_profiles(eval_config, base_profiles)
    metrics = []
    for trial in trials:
        result = compute_dmreda_reference(
            trial.signal,
            profiles=profiles,
            mode=eval_config.mode,
            warmup_samples=eval_config.warmup_samples,
        )
        filtered_event_times = [t for t in result.event_times if t >= eval_config.warmup_samples]
        metrics.append(
            evaluate_event_times(
                filtered_event_times,
                trial.meta,
                len(trial.signal),
            )
        )

    summary = summarize_metrics(metrics)
    latency_delta = summary["latency_mean"] - rms_summary["latency_mean"]
    return {
        "disturbance": condition.disturbance,
        "noise_std": condition.noise_std,
        "amplitude": condition.amplitude,
        "ramp_len": condition.ramp_len if condition.ramp_len is not None else "",
        "configuration_id": eval_config.config_id,
        "mode": eval_config.mode,
        "w1": eval_config.w1_override,
        "thetaA_scale": (eval_config.th_scale or {}).get("thetaA", 1.0),
        "thetaD_scale": (eval_config.th_scale or {}).get("thetaD", 1.0),
        "thetaG_scale": (eval_config.th_scale or {}).get("thetaG", 1.0),
        "warmup_samples": eval_config.warmup_samples,
        "latency_mean": summary["latency_mean"],
        "latency_std": summary["latency_std"],
        "detection_rate": summary["detection_rate"],
        "false_alarm_rate": summary["false_alarm_rate"],
        "rms_latency_mean": rms_summary["latency_mean"],
        "rms_latency_std": rms_summary["latency_std"],
        "rms_detection_rate": rms_summary["detection_rate"],
        "rms_false_alarm_rate": rms_summary["false_alarm_rate"],
        "rms_threshold": rms_summary["threshold"],
        "latency_delta_vs_rms": latency_delta,
    }


def sweep_condition(
    condition: Condition,
    configs: Sequence[EvalConfig],
    base_profiles: Mapping[int, DMREDAProfile],
) -> Dict[str, object]:
    trials = build_trials(condition)
    warmup_samples = configs[0].warmup_samples
    rms_summary = evaluate_rms_condition(trials, warmup_samples=warmup_samples)
    rows = [
        evaluate_dmreda_config(
            condition,
            trials,
            eval_config,
            rms_summary,
            base_profiles,
        )
        for eval_config in configs
    ]
    return {
        "condition": asdict(condition),
        "rms_summary": rms_summary,
        "rows": rows,
    }


def build_conditions() -> List[Condition]:
    conditions: List[Condition] = []
    for noise_std in NOISE_LEVELS:
        for disturbance in ("burst", "drift", "shock"):
            conditions.append(Condition(disturbance=disturbance, noise_std=noise_std, amplitude=AMPLITUDE))
        for ramp_len in RAMP_LENGTHS:
            conditions.append(
                Condition(
                    disturbance="ramp",
                    noise_std=noise_std,
                    amplitude=AMPLITUDE,
                    ramp_len=ramp_len,
                )
            )
    return conditions


def run_recalibrated_sweep(base_profiles: Mapping[int, DMREDAProfile]) -> Dict[str, object]:
    configs = make_eval_config_grid(base_profiles)
    conditions = build_conditions()
    condition_results: List[Dict[str, object]] = []
    max_workers = min(10, os.cpu_count() or 1)
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(sweep_condition, condition, configs, base_profiles): condition for condition in conditions
        }
        for future in as_completed(future_map):
            condition_results.append(future.result())

    condition_results.sort(
        key=lambda item: (
            item["condition"]["noise_std"],
            item["condition"]["disturbance"],
            item["condition"]["ramp_len"] if item["condition"]["ramp_len"] is not None else -1,
        )
    )

    all_rows: List[Dict[str, float]] = []
    rms_by_condition: Dict[Tuple[str, float, Optional[int]], Dict[str, float]] = {}
    for item in condition_results:
        cond = Condition(**item["condition"])
        rows = item["rows"]
        rows.sort(key=lambda row: row["configuration_id"])
        all_rows.extend(rows)
        rms_by_condition[(cond.disturbance, cond.noise_std, cond.ramp_len)] = item["rms_summary"]

    return {
        "configs": [asdict(cfg) for cfg in configs],
        "rows": all_rows,
        "rms_by_condition": {
            f"{key[0]}|{key[1]}|{key[2]}": value for key, value in rms_by_condition.items()
        },
    }


def best_row_for_condition(
    rows: Sequence[Dict[str, float]],
    *,
    disturbance: str,
    noise_std: float,
    ramp_len: Optional[int] = None,
    fa_limit: float = TARGET_FALSE_ALARM_RATE,
) -> Optional[Dict[str, float]]:
    target_ramp = "" if ramp_len is None else ramp_len
    candidates = [
        row for row in rows
        if row["disturbance"] == disturbance
        and row["noise_std"] == noise_std
        and row["ramp_len"] == target_ramp
        and not math.isnan(row["latency_mean"])
        and row["false_alarm_rate"] <= fa_limit
    ]
    if not candidates:
        return None
    candidates.sort(
        key=lambda row: (
            row["latency_mean"],
            -row["detection_rate"],
            row["false_alarm_rate"],
            row["configuration_id"],
        )
    )
    return dict(candidates[0])


def run_task3_ramp_operating_region(sweep_report: Dict[str, object]) -> Dict[str, object]:
    rows: List[Dict[str, float]] = sweep_report["rows"]
    per_noise: List[Dict[str, object]] = []
    overall_best: Optional[Dict[str, object]] = None

    for noise_std in NOISE_LEVELS:
        crossover = None
        for ramp_len in RAMP_LENGTHS:
            best = best_row_for_condition(rows, disturbance="ramp", noise_std=noise_std, ramp_len=ramp_len)
            if best is None:
                continue
            if best["latency_delta_vs_rms"] < 0.0:
                crossover = {
                    "noise_std": noise_std,
                    "ramp_len": ramp_len,
                    "configuration_id": best["configuration_id"],
                    "mode": best["mode"],
                    "latency_mean": best["latency_mean"],
                    "rms_latency_mean": best["rms_latency_mean"],
                    "latency_delta_vs_rms": best["latency_delta_vs_rms"],
                    "detection_rate": best["detection_rate"],
                    "false_alarm_rate": best["false_alarm_rate"],
                }
                break
        per_noise.append(
            crossover if crossover is not None else {
                "noise_std": noise_std,
                "ramp_len": None,
                "configuration_id": None,
                "mode": None,
                "latency_mean": math.nan,
                "rms_latency_mean": math.nan,
                "latency_delta_vs_rms": math.nan,
                "detection_rate": math.nan,
                "false_alarm_rate": math.nan,
            }
        )
        if crossover is not None and overall_best is None:
            overall_best = dict(crossover)

    report = {
        "per_noise_crossover": per_noise,
        "overall_crossover_exists": overall_best is not None,
        "overall_crossover": overall_best,
    }
    TASK3_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("\nTASK 3 — Ramp operating region")
    print("Noise | Crossover_rise_time | Latency_delta_vs_RMS | Detection_rate | FA_rate")
    for row in per_noise:
        print(
            f"{row['noise_std']:.2f} | {row['ramp_len']} | "
            f"{format_value(row['latency_delta_vs_rms'])} | "
            f"{format_value(row['detection_rate'])} | "
            f"{format_value(row['false_alarm_rate'])}"
        )
    if overall_best is None:
        print("RAMP_CROSSOVER none")
    else:
        print(
            f"RAMP_CROSSOVER rise_time={overall_best['ramp_len']} "
            f"noise_std={overall_best['noise_std']:.2f} "
            f"latency_delta={format_value(overall_best['latency_delta_vs_rms'])}"
        )
    return report


def run_task4_strong_zone(sweep_report: Dict[str, object]) -> Dict[str, object]:
    rows: List[Dict[str, float]] = sweep_report["rows"]
    summary_rows: List[Dict[str, object]] = []
    for disturbance in ("burst", "drift", "shock"):
        for noise_std in NOISE_LEVELS:
            best = best_row_for_condition(rows, disturbance=disturbance, noise_std=noise_std)
            if best is None:
                summary_rows.append({
                    "disturbance": disturbance,
                    "noise_std": noise_std,
                    "configuration_id": None,
                    "mode": None,
                    "latency_mean": math.nan,
                    "detection_rate": math.nan,
                    "false_alarm_rate": math.nan,
                    "latency_delta_vs_rms": math.nan,
                    "dmreda_wins": False,
                })
                continue
            summary_rows.append({
                "disturbance": disturbance,
                "noise_std": noise_std,
                "configuration_id": best["configuration_id"],
                "mode": best["mode"],
                "latency_mean": best["latency_mean"],
                "detection_rate": best["detection_rate"],
                "false_alarm_rate": best["false_alarm_rate"],
                "latency_delta_vs_rms": best["latency_delta_vs_rms"],
                "dmreda_wins": bool(best["latency_delta_vs_rms"] < 0.0 and best["false_alarm_rate"] <= TARGET_FALSE_ALARM_RATE),
            })

    report = {"rows": summary_rows, "fa_limit": TARGET_FALSE_ALARM_RATE}
    TASK4_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("\nTASK 4 — DMREDA strong zone")
    print("Disturbance | Noise | DMREDA_wins | Latency_mean | Detection_rate | Latency_delta_vs_RMS")
    for row in summary_rows:
        print(
            f"{row['disturbance']} | {row['noise_std']:.2f} | {int(row['dmreda_wins'])} | "
            f"{format_value(row['latency_mean'])} | {format_value(row['detection_rate'])} | "
            f"{format_value(row['latency_delta_vs_rms'])}"
        )
    return report


def run_task5_remove_trend_entropy() -> Dict[str, object]:
    compare = load_module(COMPARE_SCRIPT, "compare_rms_cbdd_reduced")
    slope = compare.calibrate_drift_slope()
    masks = {
        "noise": compare.noise_mask(),
        "burst": compare.burst_mask(),
        "drift": compare.drift_mask(),
        "shock": compare.shock_mask(),
    }
    augmented_runs = {name: [] for name in compare.CLASS_ORDER}
    for run_idx in range(compare.N_RUNS):
        rng = np.random.default_rng(compare.SEED + run_idx)
        signals = {
            "noise": compare.generate_noise_signal(rng),
            "burst": compare.generate_burst_signal(rng),
            "drift": compare.generate_drift_signal(rng, slope),
            "shock": compare.generate_shock_signal(rng),
        }
        for name in compare.CLASS_ORDER:
            _, augmented, _ = compare.extract_feature_payload(signals[name], masks[name], compare.FEATURE_WINDOW)
            augmented_runs[name].append(augmented)

    full_by_class = {
        name: np.vstack(augmented_runs[name]).astype(np.float64, copy=False) for name in compare.CLASS_ORDER
    }
    reduced_names = tuple(name for name in compare.AUGMENTED_FEATURE_NAMES if name != "trend_entropy")
    keep_indices = [i for i, name in enumerate(compare.AUGMENTED_FEATURE_NAMES) if name != "trend_entropy"]
    reduced_by_class = {
        name: full_by_class[name][:, keep_indices] for name in compare.CLASS_ORDER
    }

    full_analysis = compare.analyze_space(full_by_class, compare.AUGMENTED_FEATURE_NAMES)
    reduced_analysis = compare.analyze_space(reduced_by_class, reduced_names)
    report = {
        "removed_feature": "trend_entropy",
        "full_overall_ratio": float(full_analysis["overall_ratio"]),
        "reduced_overall_ratio": float(reduced_analysis["overall_ratio"]),
        "overall_ratio_delta": float(reduced_analysis["overall_ratio"] - full_analysis["overall_ratio"]),
        "full_noise_vs_drift_lda": float(full_analysis["pairwise_lda"]["noise vs drift"]),
        "reduced_noise_vs_drift_lda": float(reduced_analysis["pairwise_lda"]["noise vs drift"]),
        "full_noise_vs_drift_mahalanobis": float(full_analysis["mahalanobis"]["noise"]["drift"]),
        "reduced_noise_vs_drift_mahalanobis": float(reduced_analysis["mahalanobis"]["noise"]["drift"]),
        "reduced_feature_names": list(reduced_names),
    }
    TASK5_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("\nTASK 5 — Remove trend_entropy")
    print("Feature_removed | Overall_ratio_before | Overall_ratio_after | Delta")
    print(
        f"trend_entropy | {format_value(report['full_overall_ratio'])} | "
        f"{format_value(report['reduced_overall_ratio'])} | "
        f"{format_value(report['overall_ratio_delta'])}"
    )
    return report


def compute_norm_cumsum_mag(window: np.ndarray) -> float:
    energy = float(np.sum(window * window)) + 1e-12
    cumulative = np.cumsum(window, dtype=float)
    return float(np.max(np.abs(cumulative)) / energy)


def compute_persistence_series(
    signal: np.ndarray,
    projector: np.ndarray,
    window_size: int,
    fit_fn,
) -> np.ndarray:
    persistence = np.full(len(signal), np.nan, dtype=float)
    for t in range(window_size - 1, len(signal)):
        _, _, persistence_score = fit_fn(signal, t, projector, window_size)
        persistence[t] = persistence_score
    return persistence


def mean_last(series: np.ndarray, time_index: int, history: int) -> float:
    start = max(0, time_index - history + 1)
    segment = series[start : time_index + 1]
    if np.all(np.isnan(segment)):
        return math.nan
    return float(np.nanmean(segment))


def run_task6_coupled_score_variants(base_profiles: Mapping[int, DMREDAProfile]) -> Dict[str, object]:
    curvature = load_module(CURVATURE_SCRIPT, "curvature_diag_v2")
    warmup_samples = compute_warmup_samples(base_profiles)
    window_size = curvature.CURVATURE_WINDOW
    _, projector = curvature.build_quadratic_solver(window_size)
    compare = load_module(COMPARE_SCRIPT, "compare_rms_cbdd_for_coupled")

    records: List[Dict[str, object]] = []
    labels: List[int] = []
    scores_v1: List[float] = []
    scores_v2: List[float] = []
    scores_v3: List[float] = []

    for noise_std in NOISE_LEVELS:
        for ramp_len in RAMP_LENGTHS:
            condition = Condition(
                disturbance="ramp",
                noise_std=noise_std,
                amplitude=AMPLITUDE,
                ramp_len=ramp_len,
            )
            trials = build_trials(condition)
            for trial in trials:
                result = compute_dmreda_reference(
                    trial.signal,
                    profiles=base_profiles,
                    mode="D_or_G",
                    warmup_samples=warmup_samples,
                )
                persistence_series = compute_persistence_series(
                    trial.signal,
                    projector,
                    window_size,
                    curvature.fit_local_quadratic,
                )
                for event_time in result.event_times:
                    trigger_class = curvature.classify_trigger(
                        event_time,
                        trial.meta.start,
                        ramp_len,
                        warmup_samples,
                    )
                    if trigger_class not in {"true_ramp", "false_alarm"}:
                        continue
                    p_mean = mean_last(persistence_series, event_time, 8)
                    g_mean = mean_last(result.g, event_time, 8)
                    d_mean = mean_last(result.d, event_time, 8)
                    feat_start = max(0, event_time - compare.FEATURE_WINDOW + 1)
                    window = trial.signal[feat_start : event_time + 1]
                    norm_cumsum = compute_norm_cumsum_mag(window)
                    persistence_score = float(persistence_series[event_time]) if np.isfinite(persistence_series[event_time]) else math.nan
                    v1 = g_mean * p_mean if np.isfinite(g_mean) and np.isfinite(p_mean) else math.nan
                    v2 = d_mean * p_mean if np.isfinite(d_mean) and np.isfinite(p_mean) else math.nan
                    v3 = norm_cumsum * persistence_score if np.isfinite(persistence_score) else math.nan
                    label = 1 if trigger_class == "true_ramp" else 0
                    labels.append(label)
                    scores_v1.append(v1)
                    scores_v2.append(v2)
                    scores_v3.append(v3)
                    records.append(
                        {
                            "noise_std": float(noise_std),
                            "ramp_len": int(ramp_len),
                            "seed": int(trial.meta.seed),
                            "time": int(event_time),
                            "class": trigger_class,
                            "score_v1": float(v1) if np.isfinite(v1) else math.nan,
                            "score_v2": float(v2) if np.isfinite(v2) else math.nan,
                            "score_v3": float(v3) if np.isfinite(v3) else math.nan,
                        }
                    )

    def auc_for(values: Sequence[float]) -> float:
        scores = np.asarray(values, dtype=float)
        y_true = np.asarray(labels, dtype=int)
        valid = np.isfinite(scores)
        if np.sum(valid) == 0 or len(np.unique(y_true[valid])) < 2:
            return math.nan
        return float(roc_auc_score(y_true[valid], scores[valid]))

    aucs = {
        "coupled_score_v1_g_times_persistence": auc_for(scores_v1),
        "coupled_score_v2_d_times_persistence": auc_for(scores_v2),
        "coupled_score_v3_norm_cumsum_times_persistence": auc_for(scores_v3),
    }
    best_variant = min(
        aucs.items(),
        key=lambda item: (math.isnan(item[1]), -item[1] if not math.isnan(item[1]) else math.inf),
    )[0]

    report = {
        "positive_count": int(sum(labels)),
        "negative_count": int(len(labels) - sum(labels)),
        "auc_by_variant": aucs,
        "best_variant": best_variant,
        "trigger_records": records,
    }
    TASK6_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("\nTASK 6 — Coupled score refinement")
    print("Variant | ROC_AUC")
    for name, value in aucs.items():
        print(f"{name} | {format_value(value)}")
    print(f"BEST_VARIANT {best_variant}")
    return report


def build_operating_map(
    strong_zone: Dict[str, object],
    ramp_report: Dict[str, object],
) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for row in strong_zone["rows"]:
        rows.append(
            {
                "disturbance_type": row["disturbance"],
                "noise_level": row["noise_std"],
                "dmreda_wins": bool(row["dmreda_wins"]),
                "latency_delta": row["latency_delta_vs_rms"],
                "detection_rate": row["detection_rate"],
                "fa_rate": row["false_alarm_rate"],
                "condition_notes": (
                    f"mode={row['mode']} cfg={row['configuration_id']}"
                    if row["configuration_id"] is not None
                    else "NO_FEASIBLE_CONFIGURATION"
                ),
            }
        )
    for row in ramp_report["per_noise_crossover"]:
        rows.append(
            {
                "disturbance_type": "ramp",
                "noise_level": row["noise_std"],
                "dmreda_wins": bool(row["ramp_len"] is not None),
                "latency_delta": row["latency_delta_vs_rms"],
                "detection_rate": row["detection_rate"],
                "fa_rate": row["false_alarm_rate"],
                "condition_notes": (
                    f"ramp_len={row['ramp_len']} mode={row['mode']} cfg={row['configuration_id']}"
                    if row["ramp_len"] is not None
                    else "no crossover up to ramp_len=320"
                ),
            }
        )
    return rows


def main() -> None:
    base_profiles = dict(DEFAULT_PROFILES)

    task1 = run_task1_g_channel_independence(base_profiles)
    calibration_trials = collect_trials_for_analysis()
    task2 = calibrate_theta_g_by_state(base_profiles, calibration_trials)
    recalibrated_profiles = task2["profiles"]

    sweep_report = run_recalibrated_sweep(recalibrated_profiles)
    sweep_json = dict(sweep_report)
    sweep_json["recalibrated_theta_g"] = task2["report"]
    TASK2_JSON.write_text(json.dumps(sweep_json, indent=2), encoding="utf-8")

    task3 = run_task3_ramp_operating_region(sweep_report)
    task4 = run_task4_strong_zone(sweep_report)
    task5 = run_task5_remove_trend_entropy()
    task6 = run_task6_coupled_score_variants(recalibrated_profiles)

    operating_map_rows = build_operating_map(task4, task3)
    final_report = {
        "meta": {
            "seed_count": SEED_COUNT,
            "noise_levels": list(NOISE_LEVELS),
            "ramp_lengths": list(RAMP_LENGTHS),
            "sweep_modes": list(SWEEP_MODES),
            "theta_g_sweep_scales": list(THETA_G_SWEEP_SCALES),
            "target_false_alarm_rate": TARGET_FALSE_ALARM_RATE,
            "g_only_fa_per_1000_target": G_ONLY_FA_PER_1000_TARGET,
        },
        "task1": task1,
        "task2": task2["report"],
        "task3": task3,
        "task4": task4,
        "task5": task5,
        "task6": task6,
        "operating_map": operating_map_rows,
    }
    FINAL_JSON.write_text(json.dumps(final_report, indent=2), encoding="utf-8")

    print("\nFINAL SUMMARY — DMREDA operating map")
    print("Disturbance | DMREDA_wins | Condition | Latency_delta_vs_RMS")
    for row in operating_map_rows:
        print(
            f"{row['disturbance_type']} | {int(row['dmreda_wins'])} | "
            f"{row['condition_notes']} | {format_value(row['latency_delta'])}"
        )
    print(f"\nSaved {TASK1_JSON}")
    print(f"Saved {TASK2_JSON}")
    print(f"Saved {TASK3_JSON}")
    print(f"Saved {TASK4_JSON}")
    print(f"Saved {TASK5_JSON}")
    print(f"Saved {TASK6_JSON}")
    print(f"Saved {FINAL_JSON}")


if __name__ == "__main__":
    main()
