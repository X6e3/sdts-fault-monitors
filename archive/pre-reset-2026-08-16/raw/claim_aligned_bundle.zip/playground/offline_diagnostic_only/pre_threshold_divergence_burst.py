# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
from __future__ import annotations

import json
import math
from pathlib import Path
import sys
from typing import Dict, List, Optional

import matplotlib.pyplot as plt
import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.core.dmreda_reference_clean import DEFAULT_PROFILES, DMREDAProfile, compute_dmreda_reference
from gold_line.support.signal_gen import generate_signal
from playground.offline_diagnostic_only import dmreda_equal_fa_recalibrated_sweep as equal_fa
from deprecated.detectors import rms_detector_causal


ROOT = Path("/Users/x6e3/vscode")
RESULT_DIR = ROOT / "results"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_JSON = RESULT_DIR / "pre_threshold_divergence_burst.json"
OUTPUT_PNG = RESULT_DIR / "pre_threshold_divergence_burst.png"

N_SAMPLES = 5000
N_SEEDS = 100
DISTURBANCE = "burst"
NOISE_STD = 0.3
AMPLITUDE = 0.8


def load_operating_point() -> Dict[str, float]:
    payload = json.loads((RESULT_DIR / "dmreda_equal_fa_recalibrated_sweep.json").read_text(encoding="utf-8"))
    for row in payload["rows"]:
        if (
            row["disturbance"] == DISTURBANCE
            and float(row["noise_std"]) == NOISE_STD
            and float(row["amplitude"]) == AMPLITUDE
            and row["mode"] == "D_only"
        ):
            return row
    raise RuntimeError("operating point not found in dmreda_equal_fa_recalibrated_sweep.json")


def build_profiles(scale: float) -> Dict[int, DMREDAProfile]:
    profiles = equal_fa._load_base_profiles()
    return equal_fa._profiles_for_mode(
        profiles,
        mode="D_only",
        scale=scale,
    )


def first_index_at_or_after(mask: np.ndarray, onset: int) -> Optional[int]:
    idx = np.flatnonzero(mask[onset:])
    if idx.size == 0:
        return None
    return int(onset + idx[0])


def pad_nan(series_list: List[np.ndarray]) -> np.ndarray:
    max_len = max(len(series) for series in series_list)
    out = np.full((len(series_list), max_len), np.nan, dtype=float)
    for row_idx, series in enumerate(series_list):
        out[row_idx, : len(series)] = series
    return out


def main() -> None:
    operating_point = load_operating_point()
    rms_threshold = float(operating_point["rms_threshold"])
    dmreda_scale = float(operating_point["dmreda_scale"])
    warmup_samples = int(operating_point["warmup_samples"])
    profiles = build_profiles(dmreda_scale)

    d_norm_series: List[np.ndarray] = []
    rms_norm_series: List[np.ndarray] = []
    d_slope_series: List[np.ndarray] = []
    rms_slope_series: List[np.ndarray] = []
    seed_records: List[Dict[str, object]] = []

    early_rise_flags: List[bool] = []
    window_lengths: List[int] = []
    mean_d_slopes: List[float] = []
    mean_rms_slopes: List[float] = []

    for seed in range(N_SEEDS):
        signal, meta = generate_signal(
            N_SAMPLES,
            disturbance_type=DISTURBANCE,
            amplitude=AMPLITUDE,
            noise_std=NOISE_STD,
            seed=seed,
            return_metadata=True,
        )
        onset = meta.start
        _, rms_score = rms_detector_causal(signal, window=equal_fa.base.RMS_WINDOW)
        dmreda_result = compute_dmreda_reference(
            signal,
            profiles=profiles,
            mode="D_only",
            warmup_samples=warmup_samples,
        )

        d_threshold_trace = np.array(
            [profiles[int(state)].th_d for state in dmreda_result.state],
            dtype=float,
        )
        d_cross = first_index_at_or_after(dmreda_result.d > d_threshold_trace, onset)
        rms_cross = first_index_at_or_after(rms_score > rms_threshold, onset)

        candidates = [idx for idx in (d_cross, rms_cross) if idx is not None]
        if not candidates:
            continue
        end = min(candidates)
        if end <= onset:
            continue

        d_window = dmreda_result.d[onset : end + 1]
        rms_window = rms_score[onset : end + 1]
        d_th_window = d_threshold_trace[onset : end + 1]

        d_norm = d_window / np.maximum(d_th_window, 1e-12)
        rms_norm = rms_window / max(rms_threshold, 1e-12)

        d_slope = np.diff(d_norm)
        rms_slope = np.diff(rms_norm)

        mean_d_slope = float(np.mean(d_slope)) if d_slope.size else math.nan
        mean_rms_slope = float(np.mean(rms_slope)) if rms_slope.size else math.nan
        early_rise = bool(np.isfinite(mean_d_slope) and np.isfinite(mean_rms_slope) and mean_d_slope > mean_rms_slope)

        d_norm_series.append(d_norm)
        rms_norm_series.append(rms_norm)
        d_slope_series.append(d_slope)
        rms_slope_series.append(rms_slope)
        early_rise_flags.append(early_rise)
        window_lengths.append(int(len(d_norm)))
        mean_d_slopes.append(mean_d_slope)
        mean_rms_slopes.append(mean_rms_slope)

        seed_records.append(
            {
                "seed": seed,
                "onset": int(onset),
                "d_cross": d_cross,
                "rms_cross": rms_cross,
                "window_end": int(end),
                "window_length": int(len(d_norm)),
                "mean_d_slope_norm": mean_d_slope,
                "mean_rms_slope_norm": mean_rms_slope,
                "pre_threshold_early_rise": early_rise,
                "d_values": d_window.tolist(),
                "rms_values": rms_window.tolist(),
                "d_norm_values": d_norm.tolist(),
                "rms_norm_values": rms_norm.tolist(),
            }
        )

    if not seed_records:
        raise RuntimeError("no valid pre-threshold windows found")

    d_norm_matrix = pad_nan(d_norm_series)
    rms_norm_matrix = pad_nan(rms_norm_series)
    d_slope_matrix = pad_nan(d_slope_series)
    rms_slope_matrix = pad_nan(rms_slope_series)

    mean_d_norm = np.nanmean(d_norm_matrix, axis=0)
    mean_rms_norm = np.nanmean(rms_norm_matrix, axis=0)
    mean_d_slope_trace = np.nanmean(d_slope_matrix, axis=0)
    mean_rms_slope_trace = np.nanmean(rms_slope_matrix, axis=0)

    report = {
        "condition": {
            "disturbance": DISTURBANCE,
            "noise_std": NOISE_STD,
            "amplitude": AMPLITUDE,
            "seeds": N_SEEDS,
        },
        "operating_point": {
            "mode": "D_only",
            "rms_threshold": rms_threshold,
            "dmreda_scale": dmreda_scale,
            "warmup_samples": warmup_samples,
        },
        "summary": {
            "valid_seed_count": len(seed_records),
            "mean_window_length": float(np.mean(window_lengths)),
            "median_window_length": float(np.median(window_lengths)),
            "mean_d_slope_norm": float(np.nanmean(mean_d_slopes)),
            "mean_rms_slope_norm": float(np.nanmean(mean_rms_slopes)),
            "pre_threshold_early_rise_rate": float(np.mean(early_rise_flags)),
            "avg_d_cross": float(np.mean([record["d_cross"] for record in seed_records if record["d_cross"] is not None]))
            if any(record["d_cross"] is not None for record in seed_records)
            else math.nan,
            "avg_rms_cross": float(np.mean([record["rms_cross"] for record in seed_records if record["rms_cross"] is not None]))
            if any(record["rms_cross"] is not None for record in seed_records)
            else math.nan,
        },
        "average_trajectory": {
            "sample_offset": list(range(len(mean_d_norm))),
            "d_norm": mean_d_norm.tolist(),
            "rms_norm": mean_rms_norm.tolist(),
            "d_norm_slope": mean_d_slope_trace.tolist(),
            "rms_norm_slope": mean_rms_slope_trace.tolist(),
        },
        "seed_records": seed_records,
    }
    OUTPUT_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=False)

    x_traj = np.arange(len(mean_d_norm))
    axes[0].plot(x_traj, mean_d_norm, label="D(t) / theta_D", linewidth=2.0)
    axes[0].plot(x_traj, mean_rms_norm, label="RMS(t) / theta_RMS", linewidth=2.0)
    axes[0].axhline(1.0, color="black", linestyle="--", linewidth=1.0, alpha=0.6)
    axes[0].set_title("Burst pre-threshold normalized trajectory (100 seeds)")
    axes[0].set_xlabel("Samples after disturbance onset")
    axes[0].set_ylabel("Normalized score")
    axes[0].legend()

    x_slope = np.arange(len(mean_d_slope_trace))
    axes[1].plot(x_slope, mean_d_slope_trace, label="D normalized slope", linewidth=2.0)
    axes[1].plot(x_slope, mean_rms_slope_trace, label="RMS normalized slope", linewidth=2.0)
    axes[1].axhline(0.0, color="black", linestyle="--", linewidth=1.0, alpha=0.6)
    axes[1].set_title(
        "Normalized slope comparison "
        f"(early-rise rate={report['summary']['pre_threshold_early_rise_rate']:.3f})"
    )
    axes[1].set_xlabel("Samples after disturbance onset")
    axes[1].set_ylabel("Delta normalized score")
    axes[1].legend()

    fig.tight_layout()
    fig.savefig(OUTPUT_PNG, dpi=160)
    plt.close(fig)

    print("Pre-threshold divergence analysis — burst")
    print(
        "mean_d_slope_norm="
        f"{report['summary']['mean_d_slope_norm']:.6f} "
        "mean_rms_slope_norm="
        f"{report['summary']['mean_rms_slope_norm']:.6f} "
        "early_rise_rate="
        f"{report['summary']['pre_threshold_early_rise_rate']:.4f}"
    )
    print(f"Saved {OUTPUT_JSON}")
    print(f"Saved {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
