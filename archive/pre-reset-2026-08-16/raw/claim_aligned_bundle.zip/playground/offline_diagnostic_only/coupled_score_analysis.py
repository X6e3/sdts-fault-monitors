# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import csv
import json
import math
import os

import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve

from curvature_diagnostics import (
    CURVATURE_WINDOW,
    build_quadratic_solver,
    classify_trigger,
    fit_local_quadratic,
)
from deprecated.detectors import rms_event_detector_causal
from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference, compute_warmup_samples
from gold_line.near_gold_todo.validation_sweep import (
    AMPLITUDE,
    NOISE_LEVELS,
    RAMP_LENGTHS,
    Condition,
    RMS_CONFIRM_WINDOW,
    RMS_N_PERSIST,
    RMS_REFRACTORY,
    RMS_WINDOW,
    build_trials,
    calibrate_rms_threshold,
    evaluate_event_times,
)


COUPLED_SEED_COUNT = int(os.environ.get("DMREDA_COUPLED_SEEDS", "20"))
COUPLED_HISTORY = int(os.environ.get("DMREDA_COUPLED_HISTORY", "8"))
RESULT_JSON = "coupled_score_diagnostics.json"
RESULT_CSV = "coupled_score_sweep.csv"


def compute_persistence_series(signal, projector, window_size):
    persistence = np.full(len(signal), np.nan, dtype=float)
    for t in range(window_size - 1, len(signal)):
        _, _, persistence_score = fit_local_quadratic(signal, t, projector, window_size)
        persistence[t] = persistence_score
    return persistence


def compute_coupled_score(g_series, persistence_series, time_index, history):
    start = max(0, time_index - history + 1)
    g_mean = float(np.mean(g_series[start : time_index + 1]))
    p_window = persistence_series[start : time_index + 1]
    if np.all(np.isnan(p_window)):
        return math.nan
    p_mean = float(np.nanmean(p_window))
    return g_mean * p_mean


def threshold_candidate(scores, labels):
    if len(scores) == 0 or len(np.unique(labels)) < 2:
        return {
            "threshold": math.nan,
            "tpr": math.nan,
            "fpr": math.nan,
            "youden_j": math.nan,
        }

    fpr, tpr, thresholds = roc_curve(labels, scores)
    youden = tpr - fpr
    idx = int(np.argmax(youden))
    return {
        "threshold": float(thresholds[idx]),
        "tpr": float(tpr[idx]),
        "fpr": float(fpr[idx]),
        "youden_j": float(youden[idx]),
    }


def summarize_condition(metrics):
    detections = np.array([m[0] for m in metrics], dtype=float)
    false_alarms = np.array([m[1] for m in metrics], dtype=float)
    latencies = np.array([m[2] for m in metrics], dtype=float)
    valid = latencies[~np.isnan(latencies)]
    return {
        "latency_mean": float(np.mean(valid)) if valid.size else math.nan,
        "latency_std": float(np.std(valid)) if valid.size else math.nan,
        "detection_rate": float(np.mean(detections)),
        "false_alarm_rate": float(np.mean(false_alarms)),
    }


def evaluate_rms(trials, warmup_samples):
    threshold = calibrate_rms_threshold(trials, warmup_samples=warmup_samples)
    metrics = []
    for trial in trials:
        rms = rms_event_detector_causal(
            trial.signal,
            threshold=threshold,
            window=RMS_WINDOW,
            confirm_window=RMS_CONFIRM_WINDOW,
            n_persist=RMS_N_PERSIST,
            refractory=RMS_REFRACTORY,
            warmup_samples=warmup_samples,
        )
        metrics.append(evaluate_event_times(rms.event_times, trial.meta, len(trial.signal)))
    summary = summarize_condition(metrics)
    summary["threshold"] = threshold
    return summary


def run_analysis():
    warmup_samples = compute_warmup_samples(DEFAULT_PROFILES)
    window_size = CURVATURE_WINDOW
    _, projector = build_quadratic_solver(window_size)

    trigger_records = []
    positive_scores = []
    negative_scores = []
    sweep_rows = []

    for noise_std in NOISE_LEVELS:
        for ramp_len in RAMP_LENGTHS:
            condition = Condition(
                disturbance="ramp",
                noise_std=noise_std,
                amplitude=AMPLITUDE,
                ramp_len=ramp_len,
            )
            trials = build_trials(condition)[:COUPLED_SEED_COUNT]
            rms_summary = evaluate_rms(trials, warmup_samples)

            trial_trigger_data = []
            pre_event_scores = []
            condition_positive_scores = []
            condition_negative_scores = []

            for trial in trials:
                result = compute_dmreda_reference(
                    trial.signal,
                    profiles=DEFAULT_PROFILES,
                    mode="D_or_G",
                )
                persistence_series = compute_persistence_series(
                    trial.signal,
                    projector,
                    window_size,
                )

                trial_records = []
                for event_time in result.event_times:
                    coupled_score = compute_coupled_score(
                        result.g,
                        persistence_series,
                        event_time,
                        COUPLED_HISTORY,
                    )
                    trigger_class = classify_trigger(
                        event_time,
                        trial.meta.start,
                        ramp_len,
                        warmup_samples,
                    )
                    record = {
                        "noise_std": float(noise_std),
                        "ramp_len": int(ramp_len),
                        "seed": int(trial.meta.seed),
                        "time": int(event_time),
                        "class": trigger_class,
                        "D": float(result.d[event_time]),
                        "G": float(result.g[event_time]),
                        "coupled_score": float(coupled_score) if not math.isnan(coupled_score) else math.nan,
                    }
                    trigger_records.append(record)
                    trial_records.append(record)

                    if trigger_class == "true_ramp" and not math.isnan(coupled_score):
                        positive_scores.append(coupled_score)
                        condition_positive_scores.append(coupled_score)
                    elif trigger_class == "false_alarm" and not math.isnan(coupled_score):
                        negative_scores.append(coupled_score)
                        condition_negative_scores.append(coupled_score)
                        pre_event_scores.append(coupled_score)

                trial_trigger_data.append((trial, trial_records))

            roc_scores = (
                np.concatenate([condition_positive_scores, condition_negative_scores])
                if (condition_positive_scores or condition_negative_scores)
                else np.array([])
            )
            y_true = (
                np.concatenate(
                    [
                        np.ones(len(condition_positive_scores), dtype=int),
                        np.zeros(len(condition_negative_scores), dtype=int),
                    ]
                )
                if (condition_positive_scores or condition_negative_scores)
                else np.array([])
            )

            if len(roc_scores) > 0 and len(np.unique(y_true)) == 2:
                coupled_auc = float(roc_auc_score(y_true, roc_scores))
            else:
                coupled_auc = math.nan

            candidate_thresholds = np.unique(
                np.quantile(pre_event_scores, np.linspace(0.0, 1.0, 41))
            ) if pre_event_scores else np.array([math.nan])
            if pre_event_scores:
                candidate_thresholds = np.append(candidate_thresholds, np.max(pre_event_scores) + 1e-9)

            best_row = None
            for threshold in candidate_thresholds:
                metrics = []
                for trial, records in trial_trigger_data:
                    filtered_event_times = [
                        record["time"]
                        for record in records
                        if not math.isnan(record["coupled_score"]) and record["coupled_score"] >= threshold
                    ]
                    metrics.append(
                        evaluate_event_times(
                            filtered_event_times,
                            trial.meta,
                            len(trial.signal),
                        )
                    )

                summary = summarize_condition(metrics)
                row = {
                    "noise_std": float(noise_std),
                    "ramp_len": int(ramp_len),
                    "threshold": float(threshold) if not math.isnan(threshold) else math.nan,
                    "latency_mean": summary["latency_mean"],
                    "latency_std": summary["latency_std"],
                    "detection_rate": summary["detection_rate"],
                    "false_alarm_rate": summary["false_alarm_rate"],
                    "rms_latency_mean": rms_summary["latency_mean"],
                    "rms_false_alarm_rate": rms_summary["false_alarm_rate"],
                    "rms_threshold": rms_summary["threshold"],
                    "latency_delta_vs_rms": (
                        summary["latency_mean"] - rms_summary["latency_mean"]
                        if not math.isnan(summary["latency_mean"]) and not math.isnan(rms_summary["latency_mean"])
                        else math.nan
                    ),
                    "roc_auc_coupled_score": coupled_auc,
                    "condition": f"noise={noise_std:.1f},ramp_len={ramp_len}",
                    "selected_under_rms_constraint": 0,
                }
                sweep_rows.append(row)

                if row["false_alarm_rate"] <= rms_summary["false_alarm_rate"]:
                    if best_row is None or (
                        (not math.isnan(row["latency_mean"]) and math.isnan(best_row["latency_mean"]))
                        or (
                            not math.isnan(row["latency_mean"])
                            and row["latency_mean"] < best_row["latency_mean"]
                        )
                    ):
                        best_row = dict(row)

            if best_row is None:
                best_row = {
                    "noise_std": float(noise_std),
                    "ramp_len": int(ramp_len),
                    "threshold": math.nan,
                    "latency_mean": math.nan,
                    "latency_std": math.nan,
                    "detection_rate": math.nan,
                    "false_alarm_rate": math.nan,
                    "rms_latency_mean": rms_summary["latency_mean"],
                    "rms_false_alarm_rate": rms_summary["false_alarm_rate"],
                    "rms_threshold": rms_summary["threshold"],
                    "latency_delta_vs_rms": math.nan,
                    "roc_auc_coupled_score": coupled_auc,
                    "condition": f"noise={noise_std:.1f},ramp_len={ramp_len}",
                    "selected_under_rms_constraint": 1,
                }
            else:
                best_row["selected_under_rms_constraint"] = 1

            sweep_rows.append(best_row)

    roc_summary = {
        "roc_auc": float(roc_auc_score(
            np.concatenate([np.ones(len(positive_scores)), np.zeros(len(negative_scores))]),
            np.concatenate([positive_scores, negative_scores]),
        )) if positive_scores and negative_scores else math.nan,
        "threshold_candidate": threshold_candidate(
            np.concatenate([positive_scores, negative_scores]) if positive_scores or negative_scores else np.array([]),
            np.concatenate([np.ones(len(positive_scores)), np.zeros(len(negative_scores))]) if positive_scores or negative_scores else np.array([]),
        ),
        "positive_count": len(positive_scores),
        "negative_count": len(negative_scores),
    }

    with open(RESULT_CSV, "w", newline="", encoding="ascii") as handle:
        fieldnames = sorted({key for row in sweep_rows for key in row.keys()})
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sweep_rows)

    report = {
        "seed_count": COUPLED_SEED_COUNT,
        "history": COUPLED_HISTORY,
        "warmup_samples": warmup_samples,
        "curvature_window": window_size,
        "roc": roc_summary,
        "trigger_records": trigger_records,
        "sweep_rows": sweep_rows,
    }

    with open(RESULT_JSON, "w", encoding="ascii") as handle:
        json.dump(report, handle, indent=2)

    return report


if __name__ == "__main__":
    result = run_analysis()
    print(json.dumps(result["roc"], indent=2))
