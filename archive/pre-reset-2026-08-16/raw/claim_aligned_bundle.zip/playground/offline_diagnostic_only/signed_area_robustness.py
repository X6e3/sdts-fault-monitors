# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import json
import math
import os
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve

from curvature_diagnostics import classify_trigger
from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference, compute_warmup_samples
from gold_line.near_gold_todo.validation_sweep import Condition, build_trials


SEED_COUNT = 50
NOISE_LEVELS = (0.2, 0.3, 0.5, 0.7)
AMPLITUDES = (0.6, 0.8, 1.0)
RAMP_LENGTHS = (5, 10, 20, 40, 80)
WINDOWS = (16, 24)
HISTORY = 8
GAMMAS = (1.0, 1.5, 2.0)
RESULT_JSON = "signed_area_robustness.json"


def condition_key(condition):
    return (
        f"noise={condition.noise_std:.1f},"
        f"amp={condition.amplitude:.1f},"
        f"ramp_len={condition.ramp_len}"
    )


def compute_area_norm_series(signal, window):
    area_norm = np.full(len(signal), np.nan, dtype=float)

    for t in range(window - 1, len(signal)):
        segment = signal[t - window + 1 : t + 1]
        area_raw = float(np.sum(segment))
        window_rms = float(np.sqrt(np.mean(segment ** 2)) + 1e-12)
        area_norm[t] = area_raw / (window * window_rms)

    return area_norm


def trailing_mean(values, time_index, history):
    start = max(0, time_index - history + 1)
    window = values[start : time_index + 1]
    if np.all(np.isnan(window)):
        return math.nan
    return float(np.nanmean(window))


def empirical_ks_distance(sample_a, sample_b):
    if len(sample_a) == 0 or len(sample_b) == 0:
        return math.nan

    values = np.sort(np.unique(np.concatenate([sample_a, sample_b])))
    cdf_a = np.searchsorted(np.sort(sample_a), values, side="right") / len(sample_a)
    cdf_b = np.searchsorted(np.sort(sample_b), values, side="right") / len(sample_b)
    return float(np.max(np.abs(cdf_a - cdf_b)))


def best_threshold_stats(scores, labels):
    if len(scores) == 0 or len(np.unique(labels)) < 2:
        return {
            "threshold": math.nan,
            "fpr": math.nan,
            "tpr": math.nan,
            "youden_j": math.nan,
        }

    fpr, tpr, thresholds = roc_curve(labels, scores)
    youden = tpr - fpr
    idx = int(np.argmax(youden))
    return {
        "threshold": float(thresholds[idx]),
        "fpr": float(fpr[idx]),
        "tpr": float(tpr[idx]),
        "youden_j": float(youden[idx]),
    }


def score_from_series(g_series, area_norm_series, event_time, gamma):
    g_mean = trailing_mean(g_series, event_time, HISTORY)
    signed_area_mean = trailing_mean(area_norm_series, event_time, HISTORY)
    if math.isnan(g_mean) or math.isnan(signed_area_mean):
        return math.nan
    return float(g_mean * (abs(signed_area_mean) ** gamma))


def summarize_scores(true_scores, false_scores):
    labels = np.concatenate(
        [
            np.ones(len(true_scores), dtype=int),
            np.zeros(len(false_scores), dtype=int),
        ]
    )
    scores = np.concatenate([true_scores, false_scores])

    if len(scores) > 0 and len(np.unique(labels)) == 2:
        auc = float(roc_auc_score(labels, scores))
    else:
        auc = math.nan

    threshold_stats = best_threshold_stats(scores, labels)
    return {
        "auc": auc,
        "ks": empirical_ks_distance(
            np.asarray(true_scores, dtype=float),
            np.asarray(false_scores, dtype=float),
        ),
        "positive_count": int(len(true_scores)),
        "negative_count": int(len(false_scores)),
        "fpr_at_best_threshold": threshold_stats["fpr"],
        "tpr_at_best_threshold": threshold_stats["tpr"],
        "best_threshold": threshold_stats["threshold"],
        "youden_j": threshold_stats["youden_j"],
    }


def analyze_condition(condition):
    warmup_samples = compute_warmup_samples(DEFAULT_PROFILES)
    trials = build_trials(condition)[:SEED_COUNT]

    per_window_scores = {
        window: {gamma: {"true": [], "false": []} for gamma in GAMMAS}
        for window in WINDOWS
    }

    for trial in trials:
        result = compute_dmreda_reference(
            trial.signal,
            profiles=DEFAULT_PROFILES,
            mode="D_or_G",
        )
        area_norm_cache = {
            window: compute_area_norm_series(trial.signal, window) for window in WINDOWS
        }

        for event_time in result.event_times:
            trigger_class = classify_trigger(
                event_time,
                trial.meta.start,
                condition.ramp_len,
                warmup_samples,
            )
            if trigger_class not in {"true_ramp", "false_alarm"}:
                continue

            for window in WINDOWS:
                for gamma in GAMMAS:
                    score = score_from_series(
                        result.g,
                        area_norm_cache[window],
                        event_time,
                        gamma,
                    )
                    if math.isnan(score):
                        continue
                    bucket = "true" if trigger_class == "true_ramp" else "false"
                    per_window_scores[window][gamma][bucket].append(score)

    baseline = summarize_scores(
        per_window_scores[16][1.0]["true"],
        per_window_scores[16][1.0]["false"],
    )
    window_sensitivity = {
        str(window): summarize_scores(
            per_window_scores[window][1.0]["true"],
            per_window_scores[window][1.0]["false"],
        )
        for window in WINDOWS
    }
    gamma_sensitivity = {
        str(gamma): summarize_scores(
            per_window_scores[16][gamma]["true"],
            per_window_scores[16][gamma]["false"],
        )
        for gamma in GAMMAS
    }

    return {
        "condition": condition_key(condition),
        "baseline": baseline,
        "window_sensitivity": window_sensitivity,
        "gamma_sensitivity": gamma_sensitivity,
    }


def aggregate_metric_map(condition_results, section, metric):
    return {
        item["condition"]: item[section][metric]
        for item in condition_results
    }


def aggregate_nested_metric_map(condition_results, section, metric):
    result = {}
    keys = list(condition_results[0][section].keys()) if condition_results else []
    for key in keys:
        result[key] = {
            item["condition"]: item[section][key][metric]
            for item in condition_results
        }
    return result


def summarize_auc(values):
    arr = np.asarray([v for v in values if not math.isnan(v)], dtype=float)
    if arr.size == 0:
        return math.nan, math.nan
    return float(np.mean(arr)), float(np.std(arr))


def run_signed_area_robustness():
    conditions = [
        Condition(
            disturbance="ramp",
            noise_std=noise,
            amplitude=amp,
            ramp_len=ramp_len,
        )
        for noise in NOISE_LEVELS
        for amp in AMPLITUDES
        for ramp_len in RAMP_LENGTHS
    ]

    max_workers = min(10, os.cpu_count() or 1)
    condition_results = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(analyze_condition, condition): condition
            for condition in conditions
        }
        for future in as_completed(future_map):
            condition_results.append(future.result())

    condition_results.sort(key=lambda item: item["condition"])

    per_condition_auc = {
        item["condition"]: item["baseline"]["auc"] for item in condition_results
    }
    per_condition_ks = {
        item["condition"]: item["baseline"]["ks"] for item in condition_results
    }

    window_sensitivity = {}
    for window in (str(v) for v in WINDOWS):
        auc_map = {
            item["condition"]: item["window_sensitivity"][window]["auc"]
            for item in condition_results
        }
        ks_map = {
            item["condition"]: item["window_sensitivity"][window]["ks"]
            for item in condition_results
        }
        pos_map = {
            item["condition"]: item["window_sensitivity"][window]["positive_count"]
            for item in condition_results
        }
        neg_map = {
            item["condition"]: item["window_sensitivity"][window]["negative_count"]
            for item in condition_results
        }
        mean_auc, std_auc = summarize_auc(list(auc_map.values()))
        window_sensitivity[window] = {
            "per_condition_auc": auc_map,
            "per_condition_ks": ks_map,
            "per_condition_positive_count": pos_map,
            "per_condition_negative_count": neg_map,
            "mean_auc": mean_auc,
            "std_auc": std_auc,
        }

    gamma_sensitivity = {}
    for gamma in (str(v) for v in GAMMAS):
        auc_map = {
            item["condition"]: item["gamma_sensitivity"][gamma]["auc"]
            for item in condition_results
        }
        ks_map = {
            item["condition"]: item["gamma_sensitivity"][gamma]["ks"]
            for item in condition_results
        }
        fpr_map = {
            item["condition"]: item["gamma_sensitivity"][gamma]["fpr_at_best_threshold"]
            for item in condition_results
        }
        pos_map = {
            item["condition"]: item["gamma_sensitivity"][gamma]["positive_count"]
            for item in condition_results
        }
        neg_map = {
            item["condition"]: item["gamma_sensitivity"][gamma]["negative_count"]
            for item in condition_results
        }
        mean_auc, std_auc = summarize_auc(list(auc_map.values()))
        gamma_sensitivity[gamma] = {
            "per_condition_auc": auc_map,
            "per_condition_ks": ks_map,
            "per_condition_fpr_at_best_threshold": fpr_map,
            "per_condition_positive_count": pos_map,
            "per_condition_negative_count": neg_map,
            "mean_auc": mean_auc,
            "std_auc": std_auc,
        }

    global_mean_auc, global_std_auc = summarize_auc(list(per_condition_auc.values()))

    report = {
        "per_condition_auc": per_condition_auc,
        "per_condition_ks": per_condition_ks,
        "window_sensitivity": window_sensitivity,
        "gamma_sensitivity": gamma_sensitivity,
        "global_mean_auc": global_mean_auc,
        "global_std_auc": global_std_auc,
    }

    with open(RESULT_JSON, "w", encoding="ascii") as handle:
        json.dump(report, handle, indent=2)

    return report


if __name__ == "__main__":
    print(json.dumps(run_signed_area_robustness(), indent=2))
