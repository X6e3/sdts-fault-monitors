# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
"""
Class-aware benchmark: detector logic comparison on the same DMREDA feature space.
"""

from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark import (
    EPS,
    FEATURE_WINDOW,
    GLR_WINDOW,
    GLOBAL_SEED,
    HP_ALPHA,
    PERSISTENCE,
    TARGET_ARL,
    TwoSidedCUSUMDetector,
    VarianceCUSUMDetector,
    augmented_features,
    build_dmreda_model,
    calibrate_threshold_noise,
    gate_score_series,
    mahalanobis_series,
    perturb_runlength_structure,
    robust_location_scale,
    run_streaming_detector,
    sequential_statistic,
    tune_positive_drift_param,
)


RESULT_PATH = Path("/Users/x6e3/vscode/results/dmreda_feature_space_benchmark.json")
STREAM_LEN = 16_000
ONSET = 5_500
TARGET_STD = 0.05
CAL_RUNS = 24
SCENARIO_RUNS = 16
ARL_TARGETS = [10_000, 5_000, 2_000, 1_000, 500]


@dataclass
class DetectorModel:
    name: str
    threshold: float
    payload: Dict[str, object]
    kind: str


@dataclass
class DetectorBankEntry:
    name: str
    kind: str
    payload: Dict[str, object]
    noise_scores: List[np.ndarray]
    idx_runs: List[np.ndarray]
    lengths: List[int]


FEATURE_MODEL_KINDS = {"dmreda", "hotelling_t2", "feature_glr"}


def json_default(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        value = value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def ar1_noise(rng: np.random.Generator, length: int, rho: float = 0.9, std: float = TARGET_STD) -> np.ndarray:
    eps_std = std * math.sqrt(max(1.0 - rho * rho, EPS))
    out = np.empty(length, dtype=np.float64)
    out[0] = rng.normal(0.0, std)
    for idx in range(1, length):
        out[idx] = rho * out[idx - 1] + rng.normal(0.0, eps_std)
    return out


def normalize_to_window_stats(segment: np.ndarray, target_mean: float, target_std: float) -> np.ndarray:
    out = segment.astype(np.float64, copy=True)
    out -= float(np.mean(out))
    out_std = float(np.std(out) + EPS)
    out *= target_std / out_std
    out += target_mean
    return out


def first_alarm(trigger: np.ndarray) -> Optional[int]:
    idx = np.flatnonzero(trigger)
    if idx.size == 0:
        return None
    return int(idx[0])


def summarize_results(records: Dict[str, List[Dict[str, object]]], signals: List[np.ndarray]) -> Dict[str, Dict[str, object]]:
    summary: Dict[str, Dict[str, object]] = {}
    for name, rows in records.items():
        delays = np.asarray([math.nan if row["delay"] is None else float(row["delay"]) for row in rows], dtype=np.float64)
        misses = np.asarray([bool(row["miss"]) for row in rows], dtype=bool)
        fps = np.asarray([bool(row["fp"]) for row in rows], dtype=bool)
        success = (~misses) & (~fps)
        unconditional = delays.copy()
        for idx, sig in enumerate(signals):
            if fps[idx]:
                unconditional[idx] = 0.0
            elif misses[idx]:
                unconditional[idx] = float(sig.size - ONSET)
        valid = delays[np.isfinite(delays)]
        summary[name] = {
            "median_delay": float(np.nanmedian(valid)) if valid.size else None,
            "delay_variance": float(np.nanvar(valid)) if valid.size else None,
            "detection_rate": float(np.mean(success)),
            "miss_rate": float(np.mean(misses)),
            "false_positive_rate": float(np.mean(fps)),
            "expected_delay": float(np.mean(unconditional)),
        }
    return summary


def build_feature_runs(signals: List[np.ndarray]) -> Dict[str, object]:
    idx_runs: List[np.ndarray] = []
    feat_runs: List[np.ndarray] = []
    lengths: List[int] = []
    for sig in signals:
        idx, feats = augmented_features(sig, FEATURE_WINDOW)
        idx_runs.append(idx)
        feat_runs.append(feats)
        lengths.append(sig.size)
    return {"idx_runs": idx_runs, "feat_runs": feat_runs, "lengths": lengths}


def make_feature_baseline(feature_runs: Dict[str, object]) -> Dict[str, object]:
    idx_runs = feature_runs["idx_runs"]  # type: ignore[index]
    feat_runs = feature_runs["feat_runs"]  # type: ignore[index]
    lengths = feature_runs["lengths"]  # type: ignore[index]
    all_feats = np.vstack(feat_runs)
    mean = np.mean(all_feats, axis=0)
    std = np.std(all_feats, axis=0)
    std_safe = np.where(std < 1e-6, 1.0, std)
    feats_std = [(f - mean) / std_safe for f in feat_runs]
    centroid = np.mean(np.vstack(feats_std), axis=0)
    centered = np.vstack([f - centroid for f in feats_std])
    cov = np.cov(centered, rowvar=False) + 1e-3 * np.eye(centered.shape[1], dtype=np.float64)
    inv_cov = np.linalg.pinv(cov)
    return {
        "idx_runs": idx_runs,
        "feat_runs": feat_runs,
        "lengths": lengths,
        "feats_std": feats_std,
        "mean": mean,
        "std": std_safe,
        "centroid": centroid,
        "inv_cov": inv_cov,
    }


def dmreda_bank_entry(noise_feature_runs: Dict[str, object]) -> DetectorBankEntry:
    base = make_feature_baseline(noise_feature_runs)
    dist_runs = [mahalanobis_series(f, base["centroid"], base["inv_cov"]) for f in base["feats_std"]]  # type: ignore[index]
    dist_all = np.concatenate(dist_runs)
    dist_median = float(np.median(dist_all))
    mad = float(np.median(np.abs(dist_all - dist_median)) + EPS)
    bias = dist_median

    def drift_for_bias(b: float) -> float:
        seq = sequential_statistic(dist_all, b)
        return float(np.mean(np.diff(seq))) if seq.size > 1 else 0.0

    drift_rate = drift_for_bias(bias)
    if abs(drift_rate) >= 1e-3:
        lo = np.percentile(dist_all, 40.0)
        hi = np.percentile(dist_all, 60.0)
        trimmed = dist_all[(dist_all >= lo) & (dist_all <= hi)]
        if trimmed.size:
            bias = float(np.median(trimmed))
            drift_rate = drift_for_bias(bias)

    steps = 0
    while abs(drift_rate) >= 1e-3 and steps < 10:
        bias += math.copysign(mad, drift_rate)
        drift_rate = drift_for_bias(bias)
        steps += 1

    if abs(drift_rate) > 0.01:
        raise RuntimeError(f"Sequential drift too high after centering: {drift_rate}")

    seq_runs = [sequential_statistic(d, bias) for d in dist_runs]
    payload = dict(base)
    payload["bias"] = bias
    return DetectorBankEntry(
        "dmreda",
        "dmreda",
        payload,
        seq_runs,
        base["idx_runs"],  # type: ignore[arg-type]
        base["lengths"],  # type: ignore[arg-type]
    )


def hotelling_t2_bank_entry(noise_feature_runs: Dict[str, object]) -> DetectorBankEntry:
    base = make_feature_baseline(noise_feature_runs)
    t2_runs = []
    for feats in base["feat_runs"]:
        feats_std = (feats - base["mean"]) / base["std"]
        t2_runs.append(mahalanobis_series(feats_std, base["centroid"], base["inv_cov"]))
    return DetectorBankEntry(
        "hotelling_t2",
        "hotelling_t2",
        dict(base),
        t2_runs,
        base["idx_runs"],  # type: ignore[arg-type]
        base["lengths"],  # type: ignore[arg-type]
    )


def feature_glr_score(delta: np.ndarray, inv_cov: np.ndarray, window: int) -> np.ndarray:
    n, dim = delta.shape
    prefix = np.zeros((n + 1, dim), dtype=np.float64)
    prefix[1:] = np.cumsum(delta, axis=0)
    scores = np.zeros(n, dtype=np.float64)
    for t in range(n):
        best = 0.0
        max_width = min(window, t + 1)
        for width in range(1, max_width + 1):
            seg_sum = prefix[t + 1] - prefix[t + 1 - width]
            score = float(seg_sum @ inv_cov @ seg_sum) / width
            if score > best:
                best = score
        scores[t] = best
    return scores


def feature_glr_bank_entry(noise_feature_runs: Dict[str, object]) -> DetectorBankEntry:
    base = make_feature_baseline(noise_feature_runs)
    glr_runs = []
    for feats in base["feat_runs"]:
        feats_std = (feats - base["mean"]) / base["std"]
        delta = feats_std - base["centroid"]
        glr_runs.append(feature_glr_score(delta, base["inv_cov"], GLR_WINDOW))
    return DetectorBankEntry(
        "feature_glr",
        "feature_glr",
        dict(base),
        glr_runs,
        base["idx_runs"],  # type: ignore[arg-type]
        base["lengths"],  # type: ignore[arg-type]
    )


def raw_cusum_bank_entries(noise_signals: List[np.ndarray]) -> Dict[str, DetectorBankEntry]:
    all_noise = np.concatenate(noise_signals)
    mu0, sigma0 = robust_location_scale(all_noise)

    params_mean = tune_positive_drift_param(
        {"mu0": mu0, "k": 0.5 * sigma0},
        "k",
        0.1 * sigma0,
        lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
        noise_signals,
    )
    score_runs_mean = [run_streaming_detector(TwoSidedCUSUMDetector(params_mean["mu0"], params_mean["k"]), sig) for sig in noise_signals]
    idx_runs = [np.arange(sig.size, dtype=np.int64) for sig in noise_signals]
    lengths = [sig.size for sig in noise_signals]

    ewma_mean = mu0
    hp_energy = []
    for sample in all_noise:
        ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
        hp_energy.append((sample - ewma_mean) ** 2)
    hp_energy_arr = np.asarray(hp_energy, dtype=np.float64)
    params_var = tune_positive_drift_param(
        {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp_energy_arr, 60.0))},
        "k",
        float(np.median(np.abs(hp_energy_arr - np.median(hp_energy_arr))) + EPS),
        lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
        noise_signals,
    )
    score_runs_var = [
        run_streaming_detector(VarianceCUSUMDetector(params_var["mu0"], params_var["alpha_hp"], params_var["k"]), sig)
        for sig in noise_signals
    ]

    return {
        "cusum_mean": DetectorBankEntry("cusum_mean", "cusum_mean", {"params": params_mean}, score_runs_mean, idx_runs, lengths),
        "cusum_variance": DetectorBankEntry("cusum_variance", "cusum_variance", {"params": params_var}, score_runs_var, idx_runs, lengths),
    }


def build_model_bank(
    noise_signals: List[np.ndarray],
    noise_feature_runs: Dict[str, object],
) -> Dict[str, DetectorBankEntry]:
    bank = {
        "dmreda": dmreda_bank_entry(noise_feature_runs),
        "hotelling_t2": hotelling_t2_bank_entry(noise_feature_runs),
        "feature_glr": feature_glr_bank_entry(noise_feature_runs),
    }
    bank.update(raw_cusum_bank_entries(noise_signals))
    return bank


def instantiate_models(
    model_bank: Dict[str, DetectorBankEntry],
    target_arl: float,
) -> Dict[str, DetectorModel]:
    models: Dict[str, DetectorModel] = {}
    for name, bank_entry in model_bank.items():
        threshold, arl = calibrate_threshold_noise(
            bank_entry.noise_scores,
            bank_entry.idx_runs,
            target_arl,
            PERSISTENCE,
            bank_entry.lengths,
        )
        payload = dict(bank_entry.payload)
        payload["arl"] = float(arl)
        models[name] = DetectorModel(name, float(threshold), payload, bank_entry.kind)
    return models


def score_for_detector(
    signal: np.ndarray,
    model: DetectorModel,
    cached_features: Optional[Dict[str, np.ndarray]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    if model.kind == "dmreda":
        if cached_features is None:
            idx, feats = augmented_features(signal, FEATURE_WINDOW)
        else:
            idx = cached_features["idx"]
            feats = cached_features["feats"]
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        dist = mahalanobis_series(feats_std, model.payload["centroid"], model.payload["inv_cov"])  # type: ignore[index]
        seq = sequential_statistic(dist, float(model.payload["bias"]))  # type: ignore[index]
        return idx, seq
    if model.kind == "hotelling_t2":
        if cached_features is None:
            idx, feats = augmented_features(signal, FEATURE_WINDOW)
        else:
            idx = cached_features["idx"]
            feats = cached_features["feats"]
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        t2 = mahalanobis_series(feats_std, model.payload["centroid"], model.payload["inv_cov"])  # type: ignore[index]
        return idx, t2
    if model.kind == "feature_glr":
        if cached_features is None:
            idx, feats = augmented_features(signal, FEATURE_WINDOW)
        else:
            idx = cached_features["idx"]
            feats = cached_features["feats"]
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        delta = feats_std - model.payload["centroid"]  # type: ignore[index]
        glr = feature_glr_score(delta, model.payload["inv_cov"], GLR_WINDOW)  # type: ignore[index]
        return idx, glr
    if model.kind == "cusum_mean":
        params = model.payload["params"]  # type: ignore[index]
        detector = TwoSidedCUSUMDetector(params["mu0"], params["k"])
        score = run_streaming_detector(detector, signal)
        return np.arange(signal.size, dtype=np.int64), score
    if model.kind == "cusum_variance":
        params = model.payload["params"]  # type: ignore[index]
        detector = VarianceCUSUMDetector(params["mu0"], params["alpha_hp"], params["k"])
        score = run_streaming_detector(detector, signal)
        return np.arange(signal.size, dtype=np.int64), score
    raise ValueError(model.kind)


def evaluate_signal(
    signal: np.ndarray,
    model: DetectorModel,
    cached_features: Optional[Dict[str, np.ndarray]] = None,
) -> Dict[str, object]:
    idx, score = score_for_detector(signal, model, cached_features)
    trigger = gate_score_series(score, model.threshold, PERSISTENCE, signal.size, idx)
    first = first_alarm(trigger)
    fp = first is not None and first < ONSET
    after = np.flatnonzero(trigger[ONSET:])
    detect = None if after.size == 0 or fp else int(ONSET + after[0])
    miss = detect is None
    return {
        "delay": None if miss else float(detect - ONSET),
        "miss": miss,
        "fp": fp,
        "detect": detect,
    }


def evaluate_signal_from_score(signal: np.ndarray, model: DetectorModel, idx: np.ndarray, score: np.ndarray) -> Dict[str, object]:
    trigger = gate_score_series(score, model.threshold, PERSISTENCE, signal.size, idx)
    first = first_alarm(trigger)
    fp = first is not None and first < ONSET
    after = np.flatnonzero(trigger[ONSET:])
    detect = None if after.size == 0 or fp else int(ONSET + after[0])
    miss = detect is None
    return {
        "delay": None if miss else float(detect - ONSET),
        "miss": miss,
        "fp": fp,
        "detect": detect,
    }


def scenario_correlation_inversion(rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, float]]:
    pre = ar1_noise(rng, ONSET, rho=0.8, std=TARGET_STD)
    post = ar1_noise(rng, STREAM_LEN - ONSET, rho=-0.8, std=TARGET_STD)
    signal = np.concatenate([pre, post]).astype(np.float64)
    return signal, {"rho_pre": 0.8, "rho_post": -0.8}


def scenario_spectral_redistribution(rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = ar1_noise(rng, STREAM_LEN, rho=0.9, std=TARGET_STD)
    seg = signal[ONSET:].copy()
    spectrum = np.fft.rfft(seg)
    mag = np.abs(spectrum)
    phase = np.angle(spectrum)
    n = mag.size
    low = slice(1, max(4, n // 10))
    mid = slice(max(4, n // 5), max(8, n // 3))
    transfer = 0.3 * np.sum(mag[mid])
    mag[mid] *= 0.7
    mag[low] += transfer / max(1, mag[low].size)
    warped = np.fft.irfft(mag * np.exp(1j * phase), n=seg.size)
    target_mean = float(np.mean(signal[:ONSET]))
    target_std = float(np.std(signal[:ONSET]) + EPS)
    signal[ONSET:] = normalize_to_window_stats(warped, target_mean, target_std)
    pre_rms = math.sqrt(float(np.mean(signal[ONSET - 1024 : ONSET] ** 2)) + EPS)
    post_rms = math.sqrt(float(np.mean(signal[ONSET : ONSET + 1024] ** 2)) + EPS)
    return signal, {"rms_gap_rel": abs(post_rms - pre_rms) / pre_rms}


def scenario_phase_randomization(rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = ar1_noise(rng, STREAM_LEN, rho=0.9, std=TARGET_STD)
    pre = signal[:ONSET]
    post = signal[ONSET:].copy()

    pre_mean = float(np.mean(pre))
    pre_std = float(np.std(pre) + EPS)
    rms_pre = math.sqrt(float(np.mean(pre**2)) + EPS)

    spectrum = np.fft.rfft(post)
    magnitude = np.abs(spectrum)
    random_phase = rng.uniform(-math.pi, math.pi, size=spectrum.shape)
    random_phase[0] = np.angle(spectrum[0])
    if random_phase.size > 1 and post.size % 2 == 0:
        random_phase[-1] = np.angle(spectrum[-1])

    randomized = np.fft.irfft(magnitude * np.exp(1j * random_phase), n=post.size)
    randomized = normalize_to_window_stats(randomized, pre_mean, pre_std)
    signal[ONSET:] = randomized

    rms_post = math.sqrt(float(np.mean(signal[ONSET:] ** 2)) + EPS)
    rms_gap_rel = abs(rms_post - rms_pre) / rms_pre

    mag_after = np.abs(np.fft.rfft(signal[ONSET:]))
    spectral_magnitude_difference = float(
        np.linalg.norm(mag_after - magnitude) / (np.linalg.norm(magnitude) + EPS)
    )

    phase_bins = np.linspace(-math.pi, math.pi, 17)
    phase_hist, _ = np.histogram(random_phase[1:-1] if random_phase.size > 2 else random_phase, bins=phase_bins)
    phase_prob = phase_hist.astype(np.float64)
    phase_prob /= np.sum(phase_prob) + EPS
    phase_randomization_entropy = float(-np.sum(phase_prob * np.log2(phase_prob + EPS)))

    diagnostics = {
        "rms_pre": rms_pre,
        "rms_post": rms_post,
        "rms_gap_rel": rms_gap_rel,
        "spectral_magnitude_difference": spectral_magnitude_difference,
        "phase_randomization_entropy": phase_randomization_entropy,
    }
    return signal, diagnostics


def scenario_runlength_structure(rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = ar1_noise(rng, STREAM_LEN, rho=0.9, std=TARGET_STD)
    diag, _ = perturb_runlength_structure(rng, signal, ONSET)
    return signal, {k: float(v) if isinstance(v, (int, float)) else float(np.mean(v)) for k, v in diag.items() if k != "feature_delta"}


def scenario_variance_shift(rng: np.random.Generator) -> Tuple[np.ndarray, Dict[str, float]]:
    pre = ar1_noise(rng, ONSET, rho=0.9, std=TARGET_STD)
    post = ar1_noise(rng, STREAM_LEN - ONSET, rho=0.9, std=TARGET_STD * math.sqrt(1.5))
    signal = np.concatenate([pre, post]).astype(np.float64)
    return signal, {"variance_factor": 1.5}


SCENARIOS = {
    "correlation_inversion": scenario_correlation_inversion,
    "phase_randomization": scenario_phase_randomization,
    "spectral_redistribution": scenario_spectral_redistribution,
    "runlength_structure_change": scenario_runlength_structure,
    "variance_shift": scenario_variance_shift,
}


def build_scenario_cache() -> Dict[str, Dict[str, object]]:
    cache: Dict[str, Dict[str, object]] = {}
    for scen_name in SCENARIOS:
        rng = np.random.default_rng(GLOBAL_SEED + 1000 + list(SCENARIOS).index(scen_name))
        signals: List[np.ndarray] = []
        diagnostics: List[Dict[str, float]] = []
        features: List[Dict[str, np.ndarray]] = []
        for _ in range(SCENARIO_RUNS):
            for _attempt in range(50):
                signal, diag = SCENARIOS[scen_name](rng)
                if float(diag.get("rms_gap_rel", 0.0)) <= 0.05:
                    break
            else:
                raise RuntimeError(f"{scen_name}: could not generate RMS-preserved run within tolerance")
            signals.append(signal)
            diagnostics.append(diag)
            idx, feats = augmented_features(signal, FEATURE_WINDOW)
            features.append({"idx": idx, "feats": feats})
        cache[scen_name] = {"signals": signals, "diagnostics": diagnostics, "features": features}
    return cache


def build_scenario_score_cache(
    model_bank: Dict[str, DetectorBankEntry],
    scenario_cache: Dict[str, Dict[str, object]],
) -> Dict[str, Dict[str, List[Dict[str, np.ndarray]]]]:
    score_cache: Dict[str, Dict[str, List[Dict[str, np.ndarray]]]] = {}
    for scen_name, payload in scenario_cache.items():
        signals = payload["signals"]  # type: ignore[index]
        feature_cache = payload["features"]  # type: ignore[index]
        score_cache[scen_name] = {}
        for det_name, bank_entry in model_bank.items():
            runs: List[Dict[str, np.ndarray]] = []
            temp_model = DetectorModel(det_name, 0.0, bank_entry.payload, bank_entry.kind)
            for idx, sig in enumerate(signals):
                cached = feature_cache[idx] if bank_entry.kind in FEATURE_MODEL_KINDS else None
                run_idx, run_score = score_for_detector(sig, temp_model, cached)
                runs.append({"idx": run_idx, "score": run_score})
            score_cache[scen_name][det_name] = runs
    return score_cache


def run_scenario(
    name: str,
    models: Dict[str, DetectorModel],
    scenario_cache: Dict[str, Dict[str, object]],
    score_cache: Dict[str, Dict[str, List[Dict[str, np.ndarray]]]],
) -> Dict[str, object]:
    signals = scenario_cache[name]["signals"]  # type: ignore[index]
    diagnostics = scenario_cache[name]["diagnostics"]  # type: ignore[index]
    records = {
        det_name: [
            evaluate_signal_from_score(sig, model, score_cache[name][det_name][idx]["idx"], score_cache[name][det_name][idx]["score"])
            for idx, sig in enumerate(signals)
        ]
        for det_name, model in models.items()
    }
    return {"summary": summarize_results(records, signals), "diagnostics": diagnostics}


def interpretation(results: Dict[str, object]) -> List[str]:
    notes: List[str] = []
    q = results["scenarios"]

    def md(scen: str, det: str) -> Optional[float]:
        return q[scen]["summary"][det]["median_delay"]

    if md("correlation_inversion", "dmreda") is not None and md("correlation_inversion", "hotelling_t2") is not None:
        if md("correlation_inversion", "dmreda") < md("correlation_inversion", "hotelling_t2"):
            notes.append("DMREDA beats static Hotelling T² on correlation inversion, indicating a benefit from sequential accumulation in feature space.")
        else:
            notes.append("Static Hotelling T² matches or beats DMREDA on correlation inversion; sequential accumulation does not provide a clear gain there.")

    if md("runlength_structure_change", "dmreda") is not None and md("runlength_structure_change", "feature_glr") is not None:
        if md("runlength_structure_change", "dmreda") < md("runlength_structure_change", "feature_glr"):
            notes.append("DMREDA is faster than feature-space GLR on runlength structure changes.")
        else:
            notes.append("Feature-space GLR matches or beats DMREDA on runlength structure changes.")

    if md("variance_shift", "cusum_variance") is not None and md("variance_shift", "dmreda") is not None:
        if md("variance_shift", "cusum_variance") < md("variance_shift", "dmreda"):
            notes.append("Variance shift remains a baseline-friendly regime; raw variance CUSUM is stronger there.")
        else:
            notes.append("DMREDA competes with variance CUSUM even on explicit variance shifts.")

    return notes


def main() -> None:
    noise_signals = [ar1_noise(np.random.default_rng(GLOBAL_SEED + idx), STREAM_LEN, rho=0.9, std=TARGET_STD) for idx in range(CAL_RUNS)]
    noise_feature_runs = build_feature_runs(noise_signals)
    scenario_cache = build_scenario_cache()
    base_target = ARL_TARGETS[0]
    model_bank = build_model_bank(noise_signals, noise_feature_runs)
    score_cache = build_scenario_score_cache(model_bank, scenario_cache)
    models = instantiate_models(model_bank, base_target)

    results = {
        "meta": {
            "seed": GLOBAL_SEED,
            "target_arl": base_target,
            "arl_targets": ARL_TARGETS,
            "persistence": PERSISTENCE,
            "feature_window": FEATURE_WINDOW,
            "stream_len": STREAM_LEN,
            "onset": ONSET,
            "noise_model": {"type": "AR1", "rho": 0.9, "std": TARGET_STD},
        },
        "detectors": {
            name: {
                "threshold": model.threshold,
                "kind": model.kind,
                "arl": model.payload.get("arl"),
            }
            for name, model in models.items()
        },
        "scenarios": {},
        "arl_sweep": {},
    }

    for scen_name in SCENARIOS:
        results["scenarios"][scen_name] = run_scenario(scen_name, models, scenario_cache, score_cache)

    for target_arl in ARL_TARGETS:
        sweep_models = models if target_arl == base_target else instantiate_models(model_bank, target_arl)
        sweep_key = f"ARL_{int(target_arl)}"
        results["arl_sweep"][sweep_key] = {
            "detectors": {
                name: {
                    "threshold": model.threshold,
                    "kind": model.kind,
                    "arl": model.payload.get("arl"),
                }
                for name, model in sweep_models.items()
            },
            "scenarios": {
                scen_name: run_scenario(scen_name, sweep_models, scenario_cache, score_cache)
                for scen_name in SCENARIOS
            },
        }

    results["interpretation"] = interpretation(results)
    RESULT_PATH.write_text(json.dumps(results, indent=2, default=json_default), encoding="utf-8")

    print("scenario | detector | ARL | median_delay | detection_rate | fp_rate")
    for sweep_key in results["arl_sweep"]:
        arl_value = sweep_key.split("_", 1)[1]
        for scen_name, payload in results["arl_sweep"][sweep_key]["scenarios"].items():
            for det_name, summary in payload["summary"].items():
                print(
                    f"{scen_name:26s} | {det_name:15s} | {arl_value:>5s} | "
                    f"{str(summary['median_delay']):>12} | "
                    f"{summary['detection_rate']:.3f} | "
                    f"{summary['false_positive_rate']:.3f}"
                )

    print("\nScientific interpretation")
    for line in results["interpretation"]:
        print(f"- {line}")
    print(f"\nSaved: {RESULT_PATH}")


if __name__ == "__main__":
    main()
