# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
from __future__ import annotations

import json
import math
from pathlib import Path
import sys
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from deprecated.detectors import rms_detector_causal
from gold_line.core.dmreda_reference_clean import compute_dmreda_reference
from playground.offline_diagnostic_only import dmreda_equal_fa_recalibrated_sweep as equal_fa


ROOT = Path("/Users/x6e3/vscode")
RESULT_DIR = ROOT / "results"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_JSON = RESULT_DIR / "pre_threshold_divergence_accel_ramp.json"
OUTPUT_PNG = RESULT_DIR / "pre_threshold_divergence_accel_ramp.png"

N_SAMPLES = 5000
ONSET = 2500
NOISE_STD = 0.3
N_SEEDS = 100
A_VALUES = (0.0003, 0.0005, 0.0008)
POWER = 1.5


def make_accel_ramp_signal(amplitude_coeff: float, seed: int) -> Tuple[np.ndarray, Dict[str, float]]:
    rng = np.random.default_rng(seed)
    signal = rng.normal(0.0, NOISE_STD, N_SAMPLES)
    tau = np.arange(0, N_SAMPLES - ONSET, dtype=float)
    base_curve = tau ** POWER
    normalization = max(base_curve[-1] / 1000.0, 1e-12)
    disturbance = amplitude_coeff * (base_curve / normalization)
    signal[ONSET:] += disturbance
    meta = {
        "start": ONSET,
        "end": N_SAMPLES,
        "amplitude_coeff": amplitude_coeff,
        "effective_final_amplitude": float(disturbance[-1]),
        "seed": seed,
    }
    return signal, meta


def load_reference_operating_point() -> Dict[str, float]:
    payload = json.loads((RESULT_DIR / "dmreda_equal_fa_recalibrated_sweep.json").read_text(encoding="utf-8"))
    for row in payload["rows"]:
        if (
            row["disturbance"] == "burst"
            and float(row["noise_std"]) == NOISE_STD
            and row["mode"] == "D_only"
        ):
            return row
    raise RuntimeError("reference operating point not found")


def pad_nan(series_list: Sequence[np.ndarray]) -> np.ndarray:
    max_len = max(len(series) for series in series_list)
    out = np.full((len(series_list), max_len), np.nan, dtype=float)
    for idx, series in enumerate(series_list):
        out[idx, : len(series)] = series
    return out


def first_index_at_or_after(mask: np.ndarray, onset: int) -> Optional[int]:
    idx = np.flatnonzero(mask[onset:])
    if idx.size == 0:
        return None
    return int(onset + idx[0])


def evaluate_seed_set(amplitude_coeff: float) -> Dict[str, object]:
    reference = load_reference_operating_point()
    base_profiles = equal_fa._load_base_profiles()
    warmup_samples = int(reference["warmup_samples"])
    rms_threshold = float(reference["rms_threshold"])
    dmreda_scale = float(reference["dmreda_scale"])

    trials: List[equal_fa.base.Trial] = []
    for seed in range(N_SEEDS):
        signal, meta = make_accel_ramp_signal(amplitude_coeff, seed)
        fake_meta = equal_fa.base.SignalMetadata(
            disturbance_type="accelerating_ramp",
            start=meta["start"],
            end=meta["end"],
            amplitude=float(meta["effective_final_amplitude"]),
            noise_std=NOISE_STD,
            seed=seed,
        )
        trials.append(equal_fa.base.Trial(signal=signal, meta=fake_meta))

    profiles = equal_fa._profiles_for_mode(base_profiles, mode="D_only", scale=dmreda_scale)

    d_norm_series: List[np.ndarray] = []
    rms_norm_series: List[np.ndarray] = []
    d_slope_series: List[np.ndarray] = []
    rms_slope_series: List[np.ndarray] = []
    seed_records: List[Dict[str, object]] = []
    early_rise_flags: List[bool] = []
    d_crosses: List[float] = []
    rms_crosses: List[float] = []
    window_lengths: List[int] = []
    mean_d_slopes: List[float] = []
    mean_rms_slopes: List[float] = []

    for trial in trials:
        _, rms_score = rms_detector_causal(trial.signal, window=equal_fa.base.RMS_WINDOW)
        dmreda_result = compute_dmreda_reference(
            trial.signal,
            profiles=profiles,
            mode="D_only",
            warmup_samples=warmup_samples,
        )
        d_threshold_trace = np.array(
            [profiles[int(state)].th_d for state in dmreda_result.state],
            dtype=float,
        )

        d_cross = first_index_at_or_after(dmreda_result.d > d_threshold_trace, ONSET)
        rms_cross = first_index_at_or_after(rms_score > rms_threshold, ONSET)
        if d_cross is not None:
            d_crosses.append(float(d_cross))
        if rms_cross is not None:
            rms_crosses.append(float(rms_cross))

        candidates = [idx for idx in (d_cross, rms_cross) if idx is not None]
        if not candidates:
            continue
        end = min(candidates)
        if end <= ONSET:
            continue

        d_window = dmreda_result.d[ONSET : end + 1]
        rms_window = rms_score[ONSET : end + 1]
        d_th_window = d_threshold_trace[ONSET : end + 1]

        d_norm = d_window / np.maximum(d_th_window, 1e-12)
        rms_norm = rms_window / max(rms_threshold, 1e-12)
        d_slope = np.diff(d_norm)
        rms_slope = np.diff(rms_norm)

        mean_d_slope = float(np.mean(d_slope)) if d_slope.size else math.nan
        mean_rms_slope = float(np.mean(rms_slope)) if rms_slope.size else math.nan
        early_rise = bool(np.isfinite(mean_d_slope) and np.isfinite(mean_rms_slope) and mean_d_slope > mean_rms_slope)

        d_norm_series.append(d_norm)
        rms_norm_series.append(rms_norm)
        d_slope_series.append(d_slope)
        rms_slope_series.append(rms_slope)
        early_rise_flags.append(early_rise)
        window_lengths.append(len(d_norm))
        mean_d_slopes.append(mean_d_slope)
        mean_rms_slopes.append(mean_rms_slope)

        seed_records.append(
            {
                "seed": int(trial.meta.seed),
                "d_cross": d_cross,
                "rms_cross": rms_cross,
                "window_length": int(len(d_norm)),
                "mean_d_slope_norm": mean_d_slope,
                "mean_rms_slope_norm": mean_rms_slope,
                "pre_threshold_early_rise": early_rise,
                "d_norm_values": d_norm.tolist(),
                "rms_norm_values": rms_norm.tolist(),
            }
        )

    if not seed_records:
        return {
            "amplitude_coeff": amplitude_coeff,
            "valid_seed_count": 0,
            "rms_threshold": rms_threshold,
            "dmreda_scale": dmreda_scale,
            "seed_records": [],
        }

    d_norm_matrix = pad_nan(d_norm_series)
    rms_norm_matrix = pad_nan(rms_norm_series)
    d_slope_matrix = pad_nan(d_slope_series)
    rms_slope_matrix = pad_nan(rms_slope_series)

    return {
        "amplitude_coeff": amplitude_coeff,
        "effective_final_amplitude": float(amplitude_coeff * 1000.0),
        "warmup_samples": int(warmup_samples),
        "reference_operating_point": {
            "rms_threshold": rms_threshold,
            "dmreda_scale": dmreda_scale,
        },
        "summary": {
            "valid_seed_count": len(seed_records),
            "mean_window_length": float(np.mean(window_lengths)),
            "median_window_length": float(np.median(window_lengths)),
            "mean_d_slope_norm": float(np.nanmean(mean_d_slopes)),
            "mean_rms_slope_norm": float(np.nanmean(mean_rms_slopes)),
            "pre_threshold_early_rise_rate": float(np.mean(early_rise_flags)),
            "mean_d_cross_time": float(np.mean(d_crosses)) if d_crosses else math.nan,
            "mean_rms_cross_time": float(np.mean(rms_crosses)) if rms_crosses else math.nan,
        },
        "average_trajectory": {
            "sample_offset": list(range(d_norm_matrix.shape[1])),
            "d_norm": np.nanmean(d_norm_matrix, axis=0).tolist(),
            "rms_norm": np.nanmean(rms_norm_matrix, axis=0).tolist(),
            "d_norm_slope": np.nanmean(d_slope_matrix, axis=0).tolist(),
            "rms_norm_slope": np.nanmean(rms_slope_matrix, axis=0).tolist(),
        },
        "seed_records": seed_records,
    }


def make_plot(results: Sequence[Dict[str, object]]) -> None:
    fig, axes = plt.subplots(len(results), 2, figsize=(12, 4 * len(results)))
    if len(results) == 1:
        axes = np.array([axes])

    for row_idx, result in enumerate(results):
        traj = result["average_trajectory"]
        summary = result.get("summary", {})
        x_traj = np.arange(len(traj["d_norm"]))
        x_slope = np.arange(len(traj["d_norm_slope"]))

        ax0 = axes[row_idx, 0]
        ax0.plot(x_traj, traj["d_norm"], label="D(t) / theta_D", linewidth=2.0)
        ax0.plot(x_traj, traj["rms_norm"], label="RMS(t) / theta_RMS", linewidth=2.0)
        ax0.axhline(1.0, color="black", linestyle="--", linewidth=1.0, alpha=0.6)
        ax0.set_title(
            f"A={result['amplitude_coeff']:.4f} "
            f"(final~{result['effective_final_amplitude']:.2f})"
        )
        ax0.set_xlabel("Samples after onset")
        ax0.set_ylabel("Normalized score")
        ax0.legend()

        ax1 = axes[row_idx, 1]
        ax1.plot(x_slope, traj["d_norm_slope"], label="D normalized slope", linewidth=2.0)
        ax1.plot(x_slope, traj["rms_norm_slope"], label="RMS normalized slope", linewidth=2.0)
        ax1.axhline(0.0, color="black", linestyle="--", linewidth=1.0, alpha=0.6)
        ax1.set_title(
            f"early_rise={summary.get('pre_threshold_early_rise_rate', math.nan):.3f} "
            f"d_cross={summary.get('mean_d_cross_time', math.nan):.1f} "
            f"rms_cross={summary.get('mean_rms_cross_time', math.nan):.1f}"
        )
        ax1.set_xlabel("Samples after onset")
        ax1.set_ylabel("Delta normalized score")
        ax1.legend()

    fig.tight_layout()
    fig.savefig(OUTPUT_PNG, dpi=160)
    plt.close(fig)


def main() -> None:
    results = [evaluate_seed_set(amplitude_coeff) for amplitude_coeff in A_VALUES]
    payload = {
        "condition": {
            "signal": "noise + A*(t-t0)^1.5 / normalization",
            "t0": ONSET,
            "noise_std": NOISE_STD,
            "power": POWER,
            "seeds": N_SEEDS,
            "amplitude_coeffs": list(A_VALUES),
            "threshold_source": "burst noise=0.3 D_only equal-FA reference operating point",
        },
        "results": results,
    }
    OUTPUT_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    make_plot(results)

    print("Accelerating ramp pre-threshold divergence")
    print("A | early_rise_rate | mean_d_slope_norm | mean_rms_slope_norm | mean_d_cross | mean_rms_cross")
    for result in results:
        summary = result.get("summary", {})
        print(
            f"{result['amplitude_coeff']:.4f} | "
            f"{summary.get('pre_threshold_early_rise_rate', math.nan):.4f} | "
            f"{summary.get('mean_d_slope_norm', math.nan):.6f} | "
            f"{summary.get('mean_rms_slope_norm', math.nan):.6f} | "
            f"{summary.get('mean_d_cross_time', math.nan):.2f} | "
            f"{summary.get('mean_rms_cross_time', math.nan):.2f}"
        )
    print(f"Saved {OUTPUT_JSON}")
    print(f"Saved {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
