# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from deprecated.detectors import rms_detector_causal
from gold_line.core.dmreda_reference_clean import DEFAULT_PROFILES, compute_dmreda_reference


ROOT = Path("/Users/x6e3/vscode")
RESULT_DIR = ROOT / "results"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_JSON = RESULT_DIR / "raw_shape_comparison_accel_ramp.json"
OUTPUT_PNG = RESULT_DIR / "raw_shape_comparison_accel_ramp.png"

N_SAMPLES = 5000
ONSET = 2500
NOISE_STD = 0.3
AMPLITUDE_COEFF = 0.0005
POWER = 1.5
N_SEEDS = 100
PLOT_HORIZON = 400
EARLY_HORIZON = 200
RMS_WINDOW = 32


def make_accel_ramp_signal(seed: int) -> Tuple[np.ndarray, Dict[str, float]]:
    rng = np.random.default_rng(seed)
    signal = rng.normal(0.0, NOISE_STD, N_SAMPLES)
    tau = np.arange(0, N_SAMPLES - ONSET, dtype=float)
    base_curve = tau ** POWER
    normalization = max(base_curve[-1] / 1000.0, 1e-12)
    disturbance = AMPLITUDE_COEFF * (base_curve / normalization)
    signal[ONSET:] += disturbance
    return signal, {
        "seed": seed,
        "effective_final_amplitude": float(disturbance[-1]),
    }


def main() -> None:
    d_segments: List[np.ndarray] = []
    rms_segments: List[np.ndarray] = []
    d_slopes: List[float] = []
    rms_slopes: List[float] = []
    d_delta_200: List[float] = []
    rms_delta_200: List[float] = []

    profiles = dict(DEFAULT_PROFILES)

    for seed in range(N_SEEDS):
        signal, meta = make_accel_ramp_signal(seed)
        dmreda = compute_dmreda_reference(
            signal,
            profiles=profiles,
            mode="D_only",
            warmup_samples=0,
        )
        _, rms_score = rms_detector_causal(signal, window=RMS_WINDOW)

        d_seg = dmreda.d[ONSET : ONSET + PLOT_HORIZON]
        rms_seg = rms_score[ONSET : ONSET + PLOT_HORIZON]
        d_segments.append(d_seg)
        rms_segments.append(rms_seg)

        d_early = d_seg[:EARLY_HORIZON]
        rms_early = rms_seg[:EARLY_HORIZON]
        d_slopes.append(float(np.mean(np.diff(d_early))))
        rms_slopes.append(float(np.mean(np.diff(rms_early))))
        d_delta_200.append(float(d_early[-1] - d_early[0]))
        rms_delta_200.append(float(rms_early[-1] - rms_early[0]))

    d_matrix = np.vstack(d_segments)
    rms_matrix = np.vstack(rms_segments)
    mean_d = np.mean(d_matrix, axis=0)
    mean_rms = np.mean(rms_matrix, axis=0)

    summary = {
        "valid_seed_count": N_SEEDS,
        "mean_d_slope_first_200": float(np.mean(d_slopes)),
        "mean_rms_slope_first_200": float(np.mean(rms_slopes)),
        "mean_d_delta_first_200": float(np.mean(d_delta_200)),
        "mean_rms_delta_first_200": float(np.mean(rms_delta_200)),
        "d_rises_faster_by_mean_slope": bool(np.mean(d_slopes) > np.mean(rms_slopes)),
        "d_rises_more_by_delta_200": bool(np.mean(d_delta_200) > np.mean(rms_delta_200)),
        "seed_fraction_d_slope_gt_rms": float(np.mean(np.array(d_slopes) > np.array(rms_slopes))),
        "seed_fraction_d_delta_gt_rms": float(np.mean(np.array(d_delta_200) > np.array(rms_delta_200))),
    }

    report = {
        "condition": {
            "signal": "noise + A*(t-t0)^1.5 / normalization",
            "amplitude_coeff": AMPLITUDE_COEFF,
            "effective_final_amplitude": float(AMPLITUDE_COEFF * 1000.0),
            "noise_std": NOISE_STD,
            "power": POWER,
            "onset": ONSET,
            "seeds": N_SEEDS,
            "plot_horizon": PLOT_HORIZON,
            "early_horizon": EARLY_HORIZON,
        },
        "summary": summary,
        "average_trajectory": {
            "sample_offset": list(range(PLOT_HORIZON)),
            "mean_d": mean_d.tolist(),
            "mean_rms": mean_rms.tolist(),
        },
    }
    OUTPUT_JSON.write_text(json.dumps(report, indent=2), encoding="utf-8")

    x = np.arange(PLOT_HORIZON)
    plt.figure(figsize=(10, 5))
    plt.plot(x, mean_d, label="Raw D(t)", linewidth=2.0)
    plt.plot(x, mean_rms, label="Raw RMS(t)", linewidth=2.0)
    plt.axvspan(0, EARLY_HORIZON, color="grey", alpha=0.12, label="First 200 samples")
    plt.xlabel("Samples after onset")
    plt.ylabel("Raw signal statistic")
    plt.title("Accelerating ramp: raw D(t) vs raw RMS(t), onset-aligned average")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_PNG, dpi=160)
    plt.close()

    print("Threshold-free shape comparison — accelerating ramp")
    print(
        f"mean_d_slope_first_200={summary['mean_d_slope_first_200']:.6f} "
        f"mean_rms_slope_first_200={summary['mean_rms_slope_first_200']:.6f} "
        f"seed_fraction_d_slope_gt_rms={summary['seed_fraction_d_slope_gt_rms']:.4f}"
    )
    print(
        f"mean_d_delta_first_200={summary['mean_d_delta_first_200']:.6f} "
        f"mean_rms_delta_first_200={summary['mean_rms_delta_first_200']:.6f} "
        f"seed_fraction_d_delta_gt_rms={summary['seed_fraction_d_delta_gt_rms']:.4f}"
    )
    print(f"Saved {OUTPUT_JSON}")
    print(f"Saved {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
