"""Offline diagnostic-only scripts."""
