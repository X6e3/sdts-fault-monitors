# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
"""
RMS-matched structural onset test (v2).

Changes in v2:
1) DMREDA bias grid optimization under ARL constraint.
2) Pre-event false alarm margin.
3) Extended ROC metrics: detection_rate, false_alarm_rate, median_delay, expected_delay.
4) OLD vs NEW DMREDA comparison focused on structural_drift and slow_topology_change.
"""

from __future__ import annotations

import copy
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark import (
    EPS,
    EWMA_ALPHA,
    FEATURE_WINDOW,
    GLR_WINDOW,
    GLOBAL_SEED,
    HP_ALPHA,
    PERSISTENCE,
    EWMAMeanVarianceDetector,
    GLRMeanShiftDetector,
    TwoSidedCUSUMDetector,
    VarianceCUSUMDetector,
    augmented_features,
    build_dmreda_model,
    calibrate_threshold_noise,
    gate_score_series,
    mahalanobis_series,
    robust_location_scale,
    robust_variance,
    run_streaming_detector,
    sequential_statistic,
    tune_positive_drift_param,
)


RESULT_JSON = Path("/Users/x6e3/vscode/results/rms_matched_structural_onset_test_v2.json")
PLOT_DIR = Path("/Users/x6e3/vscode/results/rms_matched_structural_onset_test_v2_plots")

SAMPLES = 10_000
RUNS = 500
CAL_RUNS = 80
OPT_RUNS_PER_SCENARIO = 60

ONSET_MIN = 3_000
ONSET_MAX = 6_000
TARGET_ARL = 10_000.0

BASE_PHI = 0.6
BASE_STD = 0.5

AMP_JITTER_SIGMA = 0.05
TIME_JITTER_SIGMA = 0.10

RMS_TOL = 0.02
VAR_TOL = 0.02
CHECK_WINDOW = 1_500

PRE_EVENT_MARGIN_OLD = 0
PRE_EVENT_MARGIN_NEW = 50

BIAS_GRID_FACTORS = np.linspace(0.05, 0.5, 14)
ROC_MULTIPLIERS = np.linspace(0.5, 2.0, 20)

SCENARIOS = (
    "structural_drift",
    "correlation_structure_change",
    "slow_topology_change",
    "entropy_slope_change",
)
FOCUS_SCENARIOS = ("structural_drift", "slow_topology_change")


@dataclass
class DetectorModel:
    name: str
    kind: str
    threshold: float
    arl: float
    payload: Dict[str, object]


def json_default(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def ar1_noise(rng: np.random.Generator, size: int, phi: float = BASE_PHI, std: float = BASE_STD) -> np.ndarray:
    innov_std = std * math.sqrt(max(1.0 - phi * phi, EPS))
    out = np.empty(size, dtype=np.float64)
    out[0] = rng.normal(0.0, std)
    for i in range(1, size):
        out[i] = phi * out[i - 1] + rng.normal(0.0, innov_std)
    return out


def sample_jittered_scale(rng: np.random.Generator, sigma: float) -> float:
    return float(1.0 + rng.normal(0.0, sigma))


def enforce_post_stats(signal: np.ndarray, onset: int) -> np.ndarray:
    out = signal.copy()
    pre = out[max(0, onset - CHECK_WINDOW) : onset]
    post_slice = slice(onset, min(out.size, onset + CHECK_WINDOW))
    post = out[post_slice]

    pre_mean = float(np.mean(pre))
    pre_std = float(np.std(pre) + EPS)
    post_mean = float(np.mean(post))
    post_std = float(np.std(post) + EPS)

    out[post_slice] = (post - post_mean) * (pre_std / post_std) + pre_mean
    out -= float(np.mean(out))
    return out


def stats_gap(signal: np.ndarray, onset: int) -> Dict[str, float]:
    pre = signal[max(0, onset - CHECK_WINDOW) : onset]
    post = signal[onset : min(signal.size, onset + CHECK_WINDOW)]
    pre_mean = float(np.mean(pre))
    post_mean = float(np.mean(post))
    pre_var = float(np.var(pre) + EPS)
    post_var = float(np.var(post) + EPS)
    pre_rms = math.sqrt(float(np.mean(pre**2)) + EPS)
    post_rms = math.sqrt(float(np.mean(post**2)) + EPS)
    return {
        "mean_gap_abs": abs(post_mean - pre_mean),
        "var_gap_rel": abs(post_var - pre_var) / pre_var,
        "rms_gap_rel": abs(post_rms - pre_rms) / pre_rms,
    }


def scenario_structural_drift(rng: np.random.Generator, onset: int) -> np.ndarray:
    t = np.arange(SAMPLES, dtype=np.float64)
    signal = ar1_noise(rng, SAMPLES)
    amp = 0.25 * BASE_STD * sample_jittered_scale(rng, AMP_JITTER_SIGMA)
    base_f = float(rng.uniform(0.01, 0.03))
    alpha = float(rng.uniform(1.0e-6, 4.0e-6))
    time_scale = sample_jittered_scale(rng, TIME_JITTER_SIGMA)
    tau = np.clip(t - onset, 0.0, None)
    phase = 2.0 * math.pi * (base_f * tau * time_scale + 0.5 * alpha * tau * tau * time_scale)
    signal[onset:] += amp * np.sin(phase[onset:])
    return signal


def scenario_correlation_structure_change(rng: np.random.Generator, onset: int) -> np.ndarray:
    pre = ar1_noise(rng, onset, phi=0.8, std=BASE_STD)
    post = ar1_noise(rng, SAMPLES - onset, phi=-0.8, std=BASE_STD)
    signal = np.concatenate([pre, post]).astype(np.float64)
    t = np.arange(SAMPLES - onset, dtype=np.float64)
    amp = 0.08 * BASE_STD * sample_jittered_scale(rng, AMP_JITTER_SIGMA)
    f = float(rng.uniform(0.01, 0.02)) * sample_jittered_scale(rng, TIME_JITTER_SIGMA)
    signal[onset:] += amp * np.sin(2.0 * math.pi * f * t)
    return signal


def scenario_slow_topology_change(rng: np.random.Generator, onset: int) -> np.ndarray:
    t = np.arange(SAMPLES, dtype=np.float64)
    signal = ar1_noise(rng, SAMPLES)
    f0 = float(rng.uniform(0.01, 0.025))
    time_scale = sample_jittered_scale(rng, TIME_JITTER_SIGMA)
    amp3 = 0.28 * sample_jittered_scale(rng, AMP_JITTER_SIGMA)
    ramp = np.zeros_like(t)
    ramp[onset:] = np.linspace(0.0, 1.0, SAMPLES - onset, dtype=np.float64)
    base = np.sin(2.0 * math.pi * f0 * t * time_scale)
    h3 = np.sin(2.0 * math.pi * 3.0 * f0 * t * time_scale)
    topo = base + amp3 * ramp * h3
    topo /= np.sqrt(1.0 + (amp3 * ramp) ** 2 + EPS)
    signal += 0.35 * topo
    return signal


def scenario_entropy_slope_change(rng: np.random.Generator, onset: int) -> np.ndarray:
    signal = ar1_noise(rng, SAMPLES, phi=0.9, std=BASE_STD)
    gamma_max = 0.55 * sample_jittered_scale(rng, AMP_JITTER_SIGMA)
    time_scale = max(0.1, sample_jittered_scale(rng, TIME_JITTER_SIGMA))
    u_std = math.sqrt(3.0) * BASE_STD
    for i in range(onset, SAMPLES):
        frac = (i - onset) / max(1, SAMPLES - onset - 1)
        gamma = max(0.0, min(0.95, gamma_max * frac * time_scale))
        signal[i] += gamma * rng.uniform(-u_std, u_std)
    return signal


SCENARIO_FN = {
    "structural_drift": scenario_structural_drift,
    "correlation_structure_change": scenario_correlation_structure_change,
    "slow_topology_change": scenario_slow_topology_change,
    "entropy_slope_change": scenario_entropy_slope_change,
}


def generate_scenario_run(rng: np.random.Generator, scenario: str) -> Tuple[np.ndarray, int, Dict[str, float]]:
    for _ in range(60):
        onset = int(rng.integers(ONSET_MIN, ONSET_MAX + 1))
        signal = SCENARIO_FN[scenario](rng, onset)
        signal = enforce_post_stats(signal, onset)
        diag = stats_gap(signal, onset)
        if diag["rms_gap_rel"] <= RMS_TOL and diag["var_gap_rel"] <= VAR_TOL and abs(float(np.mean(signal))) <= 0.02:
            return signal, onset, diag
    raise RuntimeError(f"{scenario}: could not satisfy RMS/variance constraints")


def build_hotelling_model(noise_signals: List[np.ndarray]) -> DetectorModel:
    idx_runs: List[np.ndarray] = []
    feat_runs: List[np.ndarray] = []
    lengths: List[int] = []
    for sig in noise_signals:
        idx, feats = augmented_features(sig, FEATURE_WINDOW)
        idx_runs.append(idx)
        feat_runs.append(feats)
        lengths.append(sig.size)
    all_feats = np.vstack(feat_runs)
    mean = np.mean(all_feats, axis=0)
    std = np.std(all_feats, axis=0)
    std_safe = np.where(std < 1e-6, 1.0, std)
    feats_std = [(f - mean) / std_safe for f in feat_runs]
    centroid = np.mean(np.vstack(feats_std), axis=0)
    centered = np.vstack([f - centroid for f in feats_std])
    cov = np.cov(centered, rowvar=False) + 1e-3 * np.eye(centered.shape[1], dtype=np.float64)
    inv_cov = np.linalg.pinv(cov)
    score_runs = [mahalanobis_series(f, centroid, inv_cov) for f in feats_std]
    thr, arl = calibrate_threshold_noise(score_runs, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    return DetectorModel(
        "hotelling_t2",
        "hotelling_t2",
        float(thr),
        float(arl),
        {"mean": mean, "std": std_safe, "centroid": centroid, "inv_cov": inv_cov},
    )


def build_raw_models(noise_signals: List[np.ndarray]) -> Dict[str, DetectorModel]:
    all_noise = np.concatenate(noise_signals)
    mu0, sigma0 = robust_location_scale(all_noise)
    var0 = robust_variance(all_noise, mu0)

    ewma_mean = mu0
    hp_energy = []
    ewma_var = var0
    ewma_var_series = []
    for sample in all_noise:
        ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
        r = sample - ewma_mean
        hp_energy.append(r * r)
        ewma_var = (1.0 - EWMA_ALPHA) * ewma_var + EWMA_ALPHA * (r * r)
        ewma_var_series.append(ewma_var)
    hp_energy_arr = np.asarray(hp_energy, dtype=np.float64)
    ewma_var_arr = np.asarray(ewma_var_series, dtype=np.float64)
    var_scale = 1.4826 * np.median(np.abs(ewma_var_arr - np.median(ewma_var_arr))) + EPS

    idx_runs = [np.arange(sig.size, dtype=np.int64) for sig in noise_signals]
    lengths = [sig.size for sig in noise_signals]
    out: Dict[str, DetectorModel] = {}

    params_mean = tune_positive_drift_param(
        {"mu0": mu0, "k": 0.5 * sigma0},
        "k",
        0.1 * sigma0,
        lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
        noise_signals,
    )
    score_mean = [run_streaming_detector(TwoSidedCUSUMDetector(params_mean["mu0"], params_mean["k"]), sig) for sig in noise_signals]
    thr, arl = calibrate_threshold_noise(score_mean, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    out["cusum_mean"] = DetectorModel("cusum_mean", "cusum_mean", float(thr), float(arl), {"params": params_mean})

    params_var = tune_positive_drift_param(
        {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp_energy_arr, 60.0))},
        "k",
        float(np.median(np.abs(hp_energy_arr - np.median(hp_energy_arr))) + EPS),
        lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
        noise_signals,
    )
    score_var = [run_streaming_detector(VarianceCUSUMDetector(params_var["mu0"], params_var["alpha_hp"], params_var["k"]), sig) for sig in noise_signals]
    thr, arl = calibrate_threshold_noise(score_var, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    out["cusum_variance"] = DetectorModel("cusum_variance", "cusum_variance", float(thr), float(arl), {"params": params_var})

    ewma_params = {"mu0": mu0, "sigma0": sigma0, "var0": var0, "alpha": EWMA_ALPHA, "var_scale": var_scale}
    score_ewma = [
        run_streaming_detector(
            EWMAMeanVarianceDetector(ewma_params["mu0"], ewma_params["sigma0"], ewma_params["var0"], ewma_params["alpha"], ewma_params["var_scale"]),
            sig,
        )
        for sig in noise_signals
    ]
    thr, arl = calibrate_threshold_noise(score_ewma, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    out["ewma"] = DetectorModel("ewma", "ewma", float(thr), float(arl), {"params": ewma_params})

    glr_params = {"mu0": mu0, "sigma0": sigma0, "window": GLR_WINDOW}
    score_glr = [run_streaming_detector(GLRMeanShiftDetector(glr_params["mu0"], glr_params["sigma0"], glr_params["window"]), sig) for sig in noise_signals]
    thr, arl = calibrate_threshold_noise(score_glr, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    out["glr"] = DetectorModel("glr", "glr", float(thr), float(arl), {"params": glr_params})
    return out


def detector_score(
    signal: np.ndarray,
    model: DetectorModel,
    cached_features: Optional[Tuple[np.ndarray, np.ndarray]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    if model.kind == "dmreda":
        idx, feats = cached_features if cached_features is not None else augmented_features(signal, FEATURE_WINDOW)
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        dist = mahalanobis_series(feats_std, model.payload["centroid"], model.payload["inv_cov"])  # type: ignore[index]
        return idx, sequential_statistic(dist, float(model.payload["bias"]))
    if model.kind == "hotelling_t2":
        idx, feats = cached_features if cached_features is not None else augmented_features(signal, FEATURE_WINDOW)
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        return idx, mahalanobis_series(feats_std, model.payload["centroid"], model.payload["inv_cov"])  # type: ignore[index]
    if model.kind == "cusum_mean":
        p = model.payload["params"]  # type: ignore[index]
        return np.arange(signal.size, dtype=np.int64), run_streaming_detector(TwoSidedCUSUMDetector(p["mu0"], p["k"]), signal)
    if model.kind == "cusum_variance":
        p = model.payload["params"]  # type: ignore[index]
        return np.arange(signal.size, dtype=np.int64), run_streaming_detector(VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]), signal)
    if model.kind == "ewma":
        p = model.payload["params"]  # type: ignore[index]
        return np.arange(signal.size, dtype=np.int64), run_streaming_detector(EWMAMeanVarianceDetector(p["mu0"], p["sigma0"], p["var0"], p["alpha"], p["var_scale"]), signal)
    if model.kind == "glr":
        p = model.payload["params"]  # type: ignore[index]
        return np.arange(signal.size, dtype=np.int64), run_streaming_detector(GLRMeanShiftDetector(p["mu0"], p["sigma0"], int(p["window"])), signal)
    raise ValueError(model.kind)


def evaluate_with_threshold(
    signal_len: int,
    onset: int,
    idx: np.ndarray,
    score: np.ndarray,
    threshold: float,
    pre_event_margin: int,
) -> Dict[str, object]:
    trig = gate_score_series(score, threshold, PERSISTENCE, signal_len, idx)
    hits = np.flatnonzero(trig)
    first = None if hits.size == 0 else int(hits[0])
    fp = first is not None and first < (onset - pre_event_margin)
    detect = None
    if first is not None and not fp:
        detect = int(max(first, onset))
    miss = detect is None
    return {"delay": None if miss else float(detect - onset), "miss": miss, "fp": fp}


def summarize_evaluations(rows: List[Dict[str, object]], onsets: List[int]) -> Dict[str, object]:
    delays = np.asarray([math.nan if row["delay"] is None else float(row["delay"]) for row in rows], dtype=np.float64)
    misses = np.asarray([bool(row["miss"]) for row in rows], dtype=bool)
    fps = np.asarray([bool(row["fp"]) for row in rows], dtype=bool)
    success = (~misses) & (~fps)
    valid = delays[np.isfinite(delays)]
    expected = delays.copy()
    for i, onset in enumerate(onsets):
        if fps[i]:
            expected[i] = 0.0
        elif misses[i]:
            expected[i] = float(SAMPLES - onset)
    return {
        "detection_rate": float(np.mean(success)),
        "false_alarm_rate": float(np.mean(fps)),
        "median_detection_delay": float(np.nanmedian(valid)) if valid.size else None,
        "mean_delay": float(np.nanmean(valid)) if valid.size else None,
        "expected_delay": float(np.mean(expected)),
        "delays": [None if not math.isfinite(v) else float(v) for v in delays],
    }


def build_roc(
    score_cache: Dict[str, List[Tuple[np.ndarray, np.ndarray]]],
    thresholds: Dict[str, float],
    onsets: List[int],
    pre_event_margin: int,
) -> Dict[str, List[Dict[str, float]]]:
    roc: Dict[str, List[Dict[str, float]]] = {}
    for det_name, runs in score_cache.items():
        base = thresholds[det_name]
        entries: List[Dict[str, float]] = []
        for mult in ROC_MULTIPLIERS:
            thr = float(base * mult)
            rows = [
                evaluate_with_threshold(SAMPLES, onset, idx, score, thr, pre_event_margin)
                for (idx, score), onset in zip(runs, onsets)
            ]
            summary = summarize_evaluations(rows, onsets)
            entries.append(
                {
                    "multiplier": float(mult),
                    "threshold": thr,
                    "detection_rate": float(summary["detection_rate"]),
                    "false_alarm_rate": float(summary["false_alarm_rate"]),
                    "median_delay": float(summary["median_detection_delay"]) if summary["median_detection_delay"] is not None else math.nan,
                    "expected_delay": float(summary["expected_delay"]),
                }
            )
        roc[det_name] = entries
    return roc


def plot_delay_hist(scenario: str, summary: Dict[str, Dict[str, object]]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    bins = np.linspace(0.0, SAMPLES - ONSET_MIN, 40)
    for name, stats in summary.items():
        vals = [d for d in stats["delays"] if d is not None]  # type: ignore[index]
        if vals:
            ax.hist(vals, bins=bins, alpha=0.35, label=name)
    ax.set_title(f"{scenario} delay distribution")
    ax.set_xlabel("Detection delay (samples)")
    ax.set_ylabel("Count")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8)
    out = PLOT_DIR / f"{scenario}_delay_hist.png"
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return str(out)


def plot_roc_curves(scenario: str, roc: Dict[str, List[Dict[str, float]]]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    for name, rows in roc.items():
        x = [r["false_alarm_rate"] for r in rows]
        y = [r["detection_rate"] for r in rows]
        ax.plot(x, y, marker="o", markersize=3, linewidth=1.2, label=name)
    ax.set_title(f"{scenario} ROC-style")
    ax.set_xlabel("False alarm rate")
    ax.set_ylabel("Detection rate")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8)
    out = PLOT_DIR / f"{scenario}_roc.png"
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return str(out)


def plot_example_trace(
    scenario: str,
    signal: np.ndarray,
    onset: int,
    models: Dict[str, DetectorModel],
    score_cache: Dict[str, Tuple[np.ndarray, np.ndarray]],
) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1 + len(models), 1, figsize=(12, 2.2 * (1 + len(models))), sharex=True)
    axes[0].plot(signal, color="black", linewidth=1.0)
    axes[0].axvline(onset, color="red", linestyle="--", linewidth=1.0)
    axes[0].set_title(f"{scenario} example signal")
    axes[0].grid(alpha=0.2)
    for row, (name, model) in enumerate(models.items(), start=1):
        idx, score = score_cache[name]
        axes[row].plot(idx, score, linewidth=1.0)
        axes[row].axhline(model.threshold, color="red", linestyle="--", linewidth=0.9)
        axes[row].axvline(onset, color="black", linestyle=":", linewidth=0.8)
        axes[row].set_title(name)
        axes[row].grid(alpha=0.2)
    axes[-1].set_xlabel("Sample")
    out = PLOT_DIR / f"{scenario}_example_trace.png"
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)
    return str(out)


def optimize_dmreda_bias(
    dm_old: Dict[str, object],
    noise_signals: List[np.ndarray],
) -> Tuple[Dict[str, object], List[Dict[str, float]]]:
    # noise distances
    idx_runs: List[np.ndarray] = []
    dist_runs: List[np.ndarray] = []
    lengths: List[int] = []
    for sig in noise_signals:
        idx, feats = augmented_features(sig, FEATURE_WINDOW)
        feats_std = (feats - dm_old["mean"]) / dm_old["std"]  # type: ignore[index]
        dist = mahalanobis_series(feats_std, dm_old["centroid"], dm_old["inv_cov"])  # type: ignore[index]
        idx_runs.append(idx)
        dist_runs.append(dist)
        lengths.append(sig.size)
    dist_noise = np.concatenate(dist_runs)
    dist_med = float(np.median(dist_noise))

    # optimization cache on focused scenarios
    opt_rng = np.random.default_rng(GLOBAL_SEED + 88_000)
    opt_signals: List[np.ndarray] = []
    opt_onsets: List[int] = []
    opt_dists: List[Tuple[np.ndarray, np.ndarray]] = []
    for scenario in FOCUS_SCENARIOS:
        for _ in range(OPT_RUNS_PER_SCENARIO):
            signal, onset, _ = generate_scenario_run(opt_rng, scenario)
            idx, feats = augmented_features(signal, FEATURE_WINDOW)
            feats_std = (feats - dm_old["mean"]) / dm_old["std"]  # type: ignore[index]
            dist = mahalanobis_series(feats_std, dm_old["centroid"], dm_old["inv_cov"])  # type: ignore[index]
            opt_signals.append(signal)
            opt_onsets.append(onset)
            opt_dists.append((idx, dist))

    def expected_delay_for(bias: float, threshold: float) -> float:
        rows = [
            evaluate_with_threshold(
                signal.size,
                onset,
                idx,
                sequential_statistic(dist, bias),
                threshold,
                PRE_EVENT_MARGIN_NEW,
            )
            for (signal, onset, (idx, dist)) in zip(opt_signals, opt_onsets, opt_dists)
        ]
        return float(summarize_evaluations(rows, opt_onsets)["expected_delay"])

    grid_report: List[Dict[str, float]] = []
    best = {
        "bias": float(dm_old["bias"]),
        "threshold": float(dm_old["threshold"]),
        "arl": float(dm_old["arl"]),
        "expected_delay": expected_delay_for(float(dm_old["bias"]), float(dm_old["threshold"])),
    }

    for factor in BIAS_GRID_FACTORS:
        bias = float(factor * dist_med)
        seq_noise = [sequential_statistic(dist, bias) for dist in dist_runs]
        threshold, arl = calibrate_threshold_noise(seq_noise, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
        if abs(arl - TARGET_ARL) / TARGET_ARL > 0.10:
            continue
        exp_delay = expected_delay_for(bias, float(threshold))
        entry = {
            "factor": float(factor),
            "bias": bias,
            "threshold": float(threshold),
            "arl": float(arl),
            "expected_delay": exp_delay,
        }
        grid_report.append(entry)
        if exp_delay < best["expected_delay"]:
            best = dict(entry)

    dm_new = copy.deepcopy(dm_old)
    dm_new["bias"] = float(best["bias"])
    dm_new["threshold"] = float(best["threshold"])
    dm_new["arl"] = float(best["arl"])
    dm_new["bias_optimization"] = {"best": best, "grid": grid_report, "noise_distance_median": dist_med}
    return dm_new, grid_report


def main() -> None:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)

    # Global noise bank calibration (equal ARL for all detectors).
    rng_cal = np.random.default_rng(GLOBAL_SEED + 123)
    noise_signals = [ar1_noise(rng_cal, SAMPLES) for _ in range(CAL_RUNS)]

    dm_old = build_dmreda_model(noise_signals, TARGET_ARL)
    dm_new, bias_grid = optimize_dmreda_bias(dm_old, noise_signals)

    static_models = {
        "hotelling_t2": build_hotelling_model(noise_signals),
        **build_raw_models(noise_signals),
    }
    models_old = {"dmreda": DetectorModel("dmreda", "dmreda", float(dm_old["threshold"]), float(dm_old["arl"]), dm_old), **static_models}
    models_new = {"dmreda": DetectorModel("dmreda", "dmreda", float(dm_new["threshold"]), float(dm_new["arl"]), dm_new), **static_models}

    results: Dict[str, object] = {
        "meta": {
            "seed": GLOBAL_SEED,
            "samples": SAMPLES,
            "runs": RUNS,
            "onset_range": [ONSET_MIN, ONSET_MAX],
            "phi": BASE_PHI,
            "sigma": BASE_STD,
            "target_arl": TARGET_ARL,
            "persistence": PERSISTENCE,
            "pre_event_margin_old": PRE_EVENT_MARGIN_OLD,
            "pre_event_margin_new": PRE_EVENT_MARGIN_NEW,
            "amp_jitter_sigma": AMP_JITTER_SIGMA,
            "time_jitter_sigma": TIME_JITTER_SIGMA,
            "rms_tol": RMS_TOL,
            "var_tol": VAR_TOL,
        },
        "dmreda_bias_grid": bias_grid,
        "calibration_old": {name: {"threshold": m.threshold, "arl": m.arl} for name, m in models_old.items()},
        "calibration_new": {name: {"threshold": m.threshold, "arl": m.arl} for name, m in models_new.items()},
        "scenarios_new": {},
        "old_vs_new_dmreda": {},
    }

    print("scenario | detector | detection_rate | median_delay | false_alarm_rate | expected_delay")
    for sidx, scenario in enumerate(SCENARIOS):
        rng = np.random.default_rng(GLOBAL_SEED + 10_000 + 1000 * sidx)
        signals: List[np.ndarray] = []
        onsets: List[int] = []
        diagnostics: List[Dict[str, float]] = []
        feature_cache: List[Tuple[np.ndarray, np.ndarray]] = []
        while len(signals) < RUNS:
            signal, onset, diag = generate_scenario_run(rng, scenario)
            signals.append(signal)
            onsets.append(onset)
            diagnostics.append(diag)
            feature_cache.append(augmented_features(signal, FEATURE_WINDOW))

        # score cache for NEW models (all detectors)
        score_cache_new: Dict[str, List[Tuple[np.ndarray, np.ndarray]]] = {name: [] for name in models_new}
        rows_new: Dict[str, List[Dict[str, object]]] = {name: [] for name in models_new}

        # old/new dmreda rows for comparison
        rows_dm_old: List[Dict[str, object]] = []
        rows_dm_new: List[Dict[str, object]] = []

        for i, (signal, onset) in enumerate(zip(signals, onsets)):
            feats_cached = feature_cache[i]

            # DMREDA distances once; sequentialized with old/new bias
            idx_f, feats = feats_cached
            feats_std = (feats - dm_old["mean"]) / dm_old["std"]  # type: ignore[index]
            dist = mahalanobis_series(feats_std, dm_old["centroid"], dm_old["inv_cov"])  # type: ignore[index]
            seq_old = sequential_statistic(dist, float(dm_old["bias"]))
            seq_new = sequential_statistic(dist, float(dm_new["bias"]))

            # Old vs New DMREDA rows
            rows_dm_old.append(evaluate_with_threshold(signal.size, onset, idx_f, seq_old, float(dm_old["threshold"]), PRE_EVENT_MARGIN_OLD))
            rows_dm_new.append(evaluate_with_threshold(signal.size, onset, idx_f, seq_new, float(dm_new["threshold"]), PRE_EVENT_MARGIN_NEW))

            # New evaluation for all detectors
            score_cache_new["dmreda"].append((idx_f, seq_new))
            rows_new["dmreda"].append(evaluate_with_threshold(signal.size, onset, idx_f, seq_new, models_new["dmreda"].threshold, PRE_EVENT_MARGIN_NEW))

            for name, model in models_new.items():
                if name == "dmreda":
                    continue
                cached = feats_cached if model.kind == "hotelling_t2" else None
                idx, score = detector_score(signal, model, cached)
                score_cache_new[name].append((idx, score))
                rows_new[name].append(evaluate_with_threshold(signal.size, onset, idx, score, model.threshold, PRE_EVENT_MARGIN_NEW))

        summary_new = {name: summarize_evaluations(rows, onsets) for name, rows in rows_new.items()}
        for name, stats in summary_new.items():
            print(
                f"{scenario:26s} | {name:15s} | {stats['detection_rate']:.3f} | "
                f"{str(stats['median_detection_delay']):>12} | {stats['false_alarm_rate']:.3f} | {stats['expected_delay']:.1f}"
            )

        roc_new = build_roc(score_cache_new, {k: m.threshold for k, m in models_new.items()}, onsets, PRE_EVENT_MARGIN_NEW)
        delay_hist_path = plot_delay_hist(scenario, summary_new)
        roc_path = plot_roc_curves(scenario, roc_new)
        rep_idx = 0
        trace_path = plot_example_trace(
            scenario,
            signals[rep_idx],
            onsets[rep_idx],
            models_new,
            {name: score_cache_new[name][rep_idx] for name in models_new},
        )

        results["scenarios_new"][scenario] = {
            "summary": summary_new,
            "roc": roc_new,
            "diagnostics": {
                "rms_gap_rel_median": float(np.median([d["rms_gap_rel"] for d in diagnostics])),
                "rms_gap_rel_max": float(np.max([d["rms_gap_rel"] for d in diagnostics])),
                "var_gap_rel_median": float(np.median([d["var_gap_rel"] for d in diagnostics])),
                "mean_gap_abs_median": float(np.median([d["mean_gap_abs"] for d in diagnostics])),
            },
            "plots": {"delay_hist": delay_hist_path, "roc": roc_path, "example_trace": trace_path},
        }

        if scenario in FOCUS_SCENARIOS:
            results["old_vs_new_dmreda"][scenario] = {
                "old": summarize_evaluations(rows_dm_old, onsets),
                "new": summarize_evaluations(rows_dm_new, onsets),
            }

    print("\nOLD vs NEW DMREDA (focus scenarios)")
    for scenario in FOCUS_SCENARIOS:
        old_stats = results["old_vs_new_dmreda"][scenario]["old"]  # type: ignore[index]
        new_stats = results["old_vs_new_dmreda"][scenario]["new"]  # type: ignore[index]
        print(
            f"{scenario:22s} | OLD det={old_stats['detection_rate']:.3f} fp={old_stats['false_alarm_rate']:.3f} "
            f"med={old_stats['median_detection_delay']} exp={old_stats['expected_delay']:.1f} || "
            f"NEW det={new_stats['detection_rate']:.3f} fp={new_stats['false_alarm_rate']:.3f} "
            f"med={new_stats['median_detection_delay']} exp={new_stats['expected_delay']:.1f}"
        )

    RESULT_JSON.write_text(json.dumps(results, indent=2, default=json_default), encoding="utf-8")
    print(f"\nSaved: {RESULT_JSON}")
    print(f"Plots: {PLOT_DIR}")


if __name__ == "__main__":
    main()
