# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import numpy as np
from deprecated.detectors import rms_detector
from gold_line.support.signal_gen import generate_signal
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

# ==============================
# CUSUM Detector
# ==============================

def cusum_detector(signal, k=0.0):
    """
    Two-sided CUSUM for mean shift.
    k: reference value (drift sensitivity)
    """
    mean_est = np.mean(signal[:500])  # baseline estimate
    std_est = np.std(signal[:500]) + 1e-8

    s_pos = 0
    s_neg = 0
    score = np.zeros_like(signal)

    for i in range(len(signal)):
        x = (signal[i] - mean_est) / std_est
        s_pos = max(0, s_pos + x - k)
        s_neg = min(0, s_neg + x + k)
        score[i] = max(abs(s_pos), abs(s_neg))

    return score

# ==============================
# TEST CONFIG
# ==============================

N = 5000
signal, disturb_idx = generate_signal(
    N,
    disturbance_type="burst",
    amplitude=0.5,
    noise_std=0.3,
    seed=0
)

# --- RMS ---
_, rms_score = rms_detector(signal)

# --- CUSUM ---
cusum_score = cusum_detector(signal, k=0.1)

# --- Labels ---
labels = np.zeros(N)
labels[disturb_idx:] = 1

# --- ROC ---
fpr_rms, tpr_rms, _ = roc_curve(labels, rms_score)
fpr_cus, tpr_cus, _ = roc_curve(labels, cusum_score)

auc_rms = auc(fpr_rms, tpr_rms)
auc_cus = auc(fpr_cus, tpr_cus)

print("RMS AUC:", auc_rms)
print("CUSUM AUC:", auc_cus)

plt.plot(fpr_rms, tpr_rms, label=f"RMS AUC={auc_rms:.3f}")
plt.plot(fpr_cus, tpr_cus, label=f"CUSUM AUC={auc_cus:.3f}")
plt.plot([0,1],[0,1],'--')

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend()
plt.title("ROC Comparison - RMS vs CUSUM")
plt.show()
