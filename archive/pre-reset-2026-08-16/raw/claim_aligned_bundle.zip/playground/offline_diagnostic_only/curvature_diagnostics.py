# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import json
import math
import os
from collections import defaultdict

import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve

from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference, compute_warmup_samples
from gold_line.near_gold_todo.validation_sweep import AMPLITUDE, NOISE_LEVELS, RAMP_LENGTHS, Condition, build_trials


CURVATURE_SEED_COUNT = int(os.environ.get("DMREDA_CURV_SEEDS", "20"))
CURVATURE_WINDOW = int(os.environ.get("DMREDA_CURV_WC", "21"))
CURVATURE_EPS = float(os.environ.get("DMREDA_CURV_EPS", "1e-8"))
RESULT_JSON = "curvature_diagnostics.json"


def build_quadratic_solver(window_size):
    if window_size < 3:
        raise ValueError("CURVATURE_WINDOW must be at least 3")

    tau = np.arange(-(window_size - 1), 1, dtype=float)
    design = np.column_stack((tau ** 2, tau, np.ones(window_size, dtype=float)))
    gram = design.T @ design
    projector = np.linalg.inv(gram) @ design.T
    return tau, projector


def fit_local_quadratic(signal, time_index, projector, window_size):
    if time_index < window_size - 1:
        return math.nan, math.nan, math.nan

    segment = signal[time_index - window_size + 1 : time_index + 1]
    coeffs = projector @ segment
    a, b, c = coeffs

    tau = np.arange(-(window_size - 1), 1, dtype=float)
    fit = a * tau ** 2 + b * tau + c
    residual_energy = float(np.mean((segment - fit) ** 2))
    curvature = float(2.0 * a)
    persistence_score = float(abs(a) / (residual_energy + CURVATURE_EPS))
    return curvature, residual_energy, persistence_score


def empirical_ks_distance(sample_a, sample_b):
    if len(sample_a) == 0 or len(sample_b) == 0:
        return math.nan

    values = np.sort(np.unique(np.concatenate([sample_a, sample_b])))
    cdf_a = np.searchsorted(np.sort(sample_a), values, side="right") / len(sample_a)
    cdf_b = np.searchsorted(np.sort(sample_b), values, side="right") / len(sample_b)
    return float(np.max(np.abs(cdf_a - cdf_b)))


def summarize_distribution(values):
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return {
            "count": 0,
            "mean": math.nan,
            "std": math.nan,
            "median": math.nan,
            "q10": math.nan,
            "q90": math.nan,
        }

    return {
        "count": int(arr.size),
        "mean": float(np.mean(arr)),
        "std": float(np.std(arr)),
        "median": float(np.median(arr)),
        "q10": float(np.quantile(arr, 0.10)),
        "q90": float(np.quantile(arr, 0.90)),
    }


def classify_trigger(event_time, ramp_start, ramp_len, warmup_samples):
    ramp_end = ramp_start + ramp_len
    if event_time < warmup_samples:
        return "ignored_warmup"
    if event_time < ramp_start:
        return "false_alarm"
    if ramp_start <= event_time < ramp_end:
        return "true_ramp"
    return "other_post_event"


def correlation_with_false_alarm(persistence_scores, labels):
    if len(persistence_scores) < 2:
        return math.nan

    x = np.asarray(persistence_scores, dtype=float)
    y = np.asarray(labels, dtype=float)
    if np.std(x) == 0 or np.std(y) == 0:
        return math.nan
    return float(np.corrcoef(x, y)[0, 1])


def threshold_candidate_from_roc(scores, labels):
    if len(np.unique(labels)) < 2:
        return {
            "threshold": math.nan,
            "tpr": math.nan,
            "fpr": math.nan,
            "youden_j": math.nan,
        }

    fpr, tpr, thresholds = roc_curve(labels, scores)
    youden = tpr - fpr
    idx = int(np.argmax(youden))
    return {
        "threshold": float(thresholds[idx]),
        "tpr": float(tpr[idx]),
        "fpr": float(fpr[idx]),
        "youden_j": float(youden[idx]),
    }


def run_curvature_diagnostics():
    warmup_samples = compute_warmup_samples(DEFAULT_PROFILES)
    _, projector = build_quadratic_solver(CURVATURE_WINDOW)

    trigger_logs = []
    grouped = defaultdict(lambda: defaultdict(list))

    for noise_std in NOISE_LEVELS:
        for ramp_len in RAMP_LENGTHS:
            condition = Condition(
                disturbance="ramp",
                noise_std=noise_std,
                amplitude=AMPLITUDE,
                ramp_len=ramp_len,
            )
            trials = build_trials(condition)[:CURVATURE_SEED_COUNT]

            for trial in trials:
                result = compute_dmreda_reference(
                    trial.signal,
                    profiles=DEFAULT_PROFILES,
                    mode="D_or_G",
                )

                for event_time in result.event_times:
                    trigger_class = classify_trigger(
                        event_time,
                        trial.meta.start,
                        ramp_len,
                        warmup_samples,
                    )
                    curvature, residual_energy, persistence_score = fit_local_quadratic(
                        trial.signal,
                        event_time,
                        projector,
                        CURVATURE_WINDOW,
                    )

                    record = {
                        "noise_std": float(noise_std),
                        "ramp_len": int(ramp_len),
                        "seed": int(trial.meta.seed),
                        "time": int(event_time),
                        "class": trigger_class,
                        "D": float(result.d[event_time]),
                        "G": float(result.g[event_time]),
                        "curvature": curvature,
                        "residual_energy": residual_energy,
                        "persistence_score": persistence_score,
                    }
                    trigger_logs.append(record)

                    if trigger_class in {"true_ramp", "false_alarm"}:
                        grouped[trigger_class]["D"].append(record["D"])
                        grouped[trigger_class]["G"].append(record["G"])
                        grouped[trigger_class]["curvature"].append(curvature)
                        grouped[trigger_class]["residual_energy"].append(residual_energy)
                        grouped[trigger_class]["persistence_score"].append(persistence_score)

    true_scores = np.asarray(grouped["true_ramp"]["persistence_score"], dtype=float)
    false_scores = np.asarray(grouped["false_alarm"]["persistence_score"], dtype=float)
    separability_labels = np.concatenate(
        [
            np.ones(len(true_scores), dtype=int),
            np.zeros(len(false_scores), dtype=int),
        ]
    )
    separability_scores = np.concatenate([true_scores, false_scores])

    if len(true_scores) > 0 and len(false_scores) > 0:
        auc = float(roc_auc_score(separability_labels, separability_scores))
    else:
        auc = math.nan

    diagnostics = {
        "seed_count": CURVATURE_SEED_COUNT,
        "warmup_samples": warmup_samples,
        "curvature_window": CURVATURE_WINDOW,
        "epsilon": CURVATURE_EPS,
        "trigger_count": len(trigger_logs),
        "trigger_logs": trigger_logs,
        "distributions": {
            group_name: {
                feature_name: summarize_distribution(values)
                for feature_name, values in feature_map.items()
            }
            for group_name, feature_map in grouped.items()
        },
        "separability": {
            "ks_distance_persistence_score": empirical_ks_distance(true_scores, false_scores),
            "roc_auc_persistence_score": auc,
            "persistence_false_alarm_correlation": correlation_with_false_alarm(
                separability_scores,
                1 - separability_labels,
            ),
            "recommended_threshold_candidate": threshold_candidate_from_roc(
                separability_scores,
                separability_labels,
            ),
        },
    }

    with open(RESULT_JSON, "w", encoding="ascii") as handle:
        json.dump(diagnostics, handle, indent=2)

    return diagnostics


if __name__ == "__main__":
    result = run_curvature_diagnostics()
    print(json.dumps(result["separability"], indent=2))
