# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import numpy as np
from deprecated.core import compute_dmreda
from deprecated.detectors import rms_detector
from gold_line.support.signal_gen import generate_signal
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

N = 5000
signal, disturb_idx = generate_signal(
    N,
    disturbance_type="ramp",
    amplitude=1.0,
    noise_std=0.3,
    seed=0
)

# --- Scores ---
_, rms_score = rms_detector(signal)
dmr_score = compute_dmreda(signal)

# --- Labels ---
labels = np.zeros(N)
labels[disturb_idx:] = 1

# --- ROC ---
fpr_rms, tpr_rms, _ = roc_curve(labels, rms_score)
fpr_dmr, tpr_dmr, _ = roc_curve(labels, dmr_score)

auc_rms = auc(fpr_rms, tpr_rms)
auc_dmr = auc(fpr_dmr, tpr_dmr)

print("RMS AUC:", auc_rms)
print("DMR AUC:", auc_dmr)

plt.plot(fpr_rms, tpr_rms, label=f"RMS AUC={auc_rms:.3f}")
plt.plot(fpr_dmr, tpr_dmr, label=f"DMR AUC={auc_dmr:.3f}")
plt.plot([0,1],[0,1],'--')

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend()
plt.title("ROC Comparison")
plt.show()
