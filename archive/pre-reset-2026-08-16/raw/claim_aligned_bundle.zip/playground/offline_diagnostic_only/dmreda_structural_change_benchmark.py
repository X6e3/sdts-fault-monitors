# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
"""
Large-scale synthetic benchmark for structural change detection.

Outputs:
- /Users/x6e3/vscode/results/benchmark_results.json
- plot files under /Users/x6e3/vscode/results/benchmark_plots/
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Deque, Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

RESULT_JSON = Path("/Users/x6e3/vscode/results/benchmark_results.json")
PLOT_DIR = Path("/Users/x6e3/vscode/results/benchmark_plots")
EPS = 1e-12
GLOBAL_SEED = 42
PERSISTENCE = 3
ARL_BINSEARCH_ITERS = 40
BASE_STD = 0.5
EWMA_ALPHA = 2.0 / (32.0 + 1.0)
HP_ALPHA = 0.1
STATIONARY_DRIFT_TOL = 1e-3

NOISE_MODELS = ("gaussian", "ar1", "pink", "burst", "mixture")
BASELINE_BEHAVIORS = ("constant", "slow_drift", "piecewise")

DISTURBANCE_LEVELS: Dict[str, List[float]] = {
    "mean_shift": [0.1, 0.3, 0.5, 1.0, 2.0],                 # in sigma
    "variance_shift": [1.05, 1.2, 1.4, 1.8, 2.2],            # variance factor
    "slow_drift": [2e-5, 4e-5, 7e-5, 1e-4, 2e-4],            # slope
    "correlation_inversion": [0.9, 0.6, 0.2, -0.2, -0.9],    # rho_post
    "structural_topology_change": [0.1, 0.2, 0.35, 0.5, 0.7],# mixing factor
    "run_length_change": [0.1, 0.2, 0.35, 0.5, 0.8],         # block flip probability
    "phase_shift": [math.pi / 48, math.pi / 24, math.pi / 16, math.pi / 12, math.pi / 8],
    "harmonic_redistribution": [0.05, 0.1, 0.2, 0.3, 0.45],  # transfer fraction
    "rms_matched_structural": [0.08, 0.15, 0.25, 0.35, 0.5], # scramble/warp intensity
}


@dataclass
class DetectorModel:
    name: str
    threshold: float
    arl: float
    params: Dict[str, object]


def json_default(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def persistent_mask(trigger: np.ndarray, persistence: int) -> np.ndarray:
    out = np.zeros_like(trigger, dtype=bool)
    count = 0
    for i, flag in enumerate(trigger):
        if flag:
            count += 1
            if count >= persistence:
                out[i] = True
        else:
            count = 0
    return out


def gate_score_series(
    scores: np.ndarray,
    threshold: float,
    persistence: int,
    sig_len: int,
    indices: Optional[np.ndarray] = None,
) -> np.ndarray:
    trigger = np.zeros(sig_len, dtype=bool)
    if indices is None:
        trigger[: scores.size] = scores > threshold
    else:
        trigger[indices] = scores > threshold
    return persistent_mask(trigger, persistence)


def calibrate_threshold_noise(
    series_runs: List[np.ndarray],
    indices_runs: List[np.ndarray],
    target_arl: float,
    persistence: int,
    signal_lengths: Optional[List[int]] = None,
) -> Tuple[float, float]:
    low = min(float(np.min(s)) for s in series_runs)
    high = max(float(np.max(s)) for s in series_runs) + 1.0
    best_h = high
    best_arl = 0.0
    for _ in range(ARL_BINSEARCH_ITERS):
        mid = 0.5 * (low + high)
        hits: List[int] = []
        for run_idx, (series, idx) in enumerate(zip(series_runs, indices_runs)):
            if idx.size == 0:
                continue
            sig_len = signal_lengths[run_idx] if signal_lengths is not None else (int(idx[-1]) + 1)
            trig = np.zeros(sig_len, dtype=bool)
            trig[idx] = series > mid
            trig = persistent_mask(trig, persistence)
            pos = np.flatnonzero(trig)
            hits.append(int(pos[0]) if pos.size else sig_len)
        arl = float(np.mean(hits))
        if arl >= target_arl:
            best_h = mid
            best_arl = arl
            high = mid
        else:
            low = mid
    return best_h, best_arl


def robust_location_scale(signal: np.ndarray) -> Tuple[float, float]:
    mu0 = float(np.median(signal))
    mad = float(np.median(np.abs(signal - mu0)) + EPS)
    sigma0 = 1.4826 * mad + EPS
    return mu0, sigma0


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=np.float64)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=np.float64)))
    out = np.empty(signal.size, dtype=np.float64)
    for i in range(signal.size):
        j = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[j]
        n = i - j + 1
        out[i] = math.sqrt(total / n)
    return out


def first_after(trigger: np.ndarray, onset: int) -> Optional[int]:
    idx = np.flatnonzero(trigger[onset:])
    return None if idx.size == 0 else int(onset + idx[0])


def first_any(trigger: np.ndarray) -> Optional[int]:
    idx = np.flatnonzero(trigger)
    return None if idx.size == 0 else int(idx[0])


def mean_run_length(sign_seq: np.ndarray) -> float:
    if sign_seq.size == 0:
        return 0.0
    changes = np.flatnonzero(sign_seq[1:] != sign_seq[:-1]) + 1
    boundaries = np.concatenate(([0], changes, [sign_seq.size]))
    lengths = np.diff(boundaries)
    return float(np.mean(lengths))


def sign_entropy(dx: np.ndarray) -> float:
    s = np.sign(dx)
    s[s == 0] = 1
    p_pos = np.mean(s > 0)
    p_neg = 1.0 - p_pos
    return float(-(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS)))


def spectral_ratio(x: np.ndarray, low_frac: float = 0.15) -> float:
    x0 = x - np.mean(x)
    spec = np.fft.rfft(x0)
    e = np.abs(spec) ** 2
    cutoff = max(1, int(low_frac * e.size))
    return float(np.sum(e[:cutoff]) / (np.sum(e) + EPS))


def normalize_post_segment(x: np.ndarray, onset: int, span: int) -> np.ndarray:
    out = x.copy()
    pre0 = max(0, onset - span)
    pre = out[pre0:onset]
    post1 = min(out.size, onset + span)
    post = out[onset:post1]
    pre_mean = float(np.mean(pre))
    pre_std = float(np.std(pre) + EPS)
    post_mean = float(np.mean(post))
    post_std = float(np.std(post) + EPS)
    out[onset:post1] = (post - post_mean) * (pre_std / post_std) + pre_mean
    return out


def make_baseline(rng: np.random.Generator, n: int, kind: str) -> np.ndarray:
    t = np.arange(n, dtype=np.float64)
    if kind == "constant":
        return np.zeros(n, dtype=np.float64)
    if kind == "slow_drift":
        slope = rng.uniform(-2e-4, 2e-4)
        return slope * (t - n / 2.0)
    if kind == "piecewise":
        out = np.zeros(n, dtype=np.float64)
        cuts = sorted(rng.integers(n // 6, 5 * n // 6, size=2).tolist())
        levels = rng.normal(0.0, 0.2, size=3)
        out[: cuts[0]] = levels[0]
        out[cuts[0] : cuts[1]] = levels[1]
        out[cuts[1] :] = levels[2]
        return out
    raise ValueError(kind)


def gaussian_noise_pair(rng: np.random.Generator, n: int, sigma: float, corr: float = 0.7) -> Tuple[np.ndarray, np.ndarray]:
    z1 = rng.normal(0.0, 1.0, size=n)
    z2 = rng.normal(0.0, 1.0, size=n)
    x = sigma * z1
    y = sigma * (corr * z1 + math.sqrt(max(1.0 - corr * corr, EPS)) * z2)
    return x.astype(np.float64), y.astype(np.float64)


def ar1_noise_pair(rng: np.random.Generator, n: int, sigma: float, phi: float = 0.9, corr: float = 0.7) -> Tuple[np.ndarray, np.ndarray]:
    innov_std = sigma * math.sqrt(max(1.0 - phi * phi, EPS))
    x = np.empty(n, dtype=np.float64)
    y = np.empty(n, dtype=np.float64)
    x[0] = rng.normal(0.0, sigma)
    y[0] = rng.normal(0.0, sigma)
    for i in range(1, n):
        z1 = rng.normal(0.0, innov_std)
        z2 = rng.normal(0.0, innov_std)
        e1 = z1
        e2 = corr * z1 + math.sqrt(max(1.0 - corr * corr, EPS)) * z2
        x[i] = phi * x[i - 1] + e1
        y[i] = phi * y[i - 1] + e2
    return x, y


def pink_noise(rng: np.random.Generator, n: int, sigma: float) -> np.ndarray:
    wn = rng.normal(0.0, 1.0, size=n)
    spec = np.fft.rfft(wn)
    freqs = np.fft.rfftfreq(n, d=1.0)
    scale = np.ones_like(freqs)
    scale[1:] = 1.0 / np.sqrt(freqs[1:])
    colored = np.fft.irfft(spec * scale, n=n)
    colored -= np.mean(colored)
    colored /= np.std(colored) + EPS
    return (sigma * colored).astype(np.float64)


def burst_noise(rng: np.random.Generator, n: int, sigma: float) -> np.ndarray:
    x = rng.normal(0.0, sigma, size=n)
    n_burst = max(1, n // 1000)
    idx = rng.integers(0, n, size=n_burst)
    x[idx] += rng.normal(0.0, 6.0 * sigma, size=n_burst)
    return x.astype(np.float64)


def mixture_noise_pair(rng: np.random.Generator, n: int, sigma: float) -> Tuple[np.ndarray, np.ndarray]:
    x = np.zeros(n, dtype=np.float64)
    y = np.zeros(n, dtype=np.float64)
    ptr = 0
    while ptr < n:
        seg = int(rng.integers(300, 1200))
        end = min(n, ptr + seg)
        mode = rng.choice(["gaussian", "ar1", "burst"])
        if mode == "gaussian":
            xs, ys = gaussian_noise_pair(rng, end - ptr, sigma)
        elif mode == "ar1":
            xs, ys = ar1_noise_pair(rng, end - ptr, sigma, phi=float(rng.uniform(0.7, 0.95)))
        else:
            xs = burst_noise(rng, end - ptr, sigma)
            ys = burst_noise(rng, end - ptr, sigma)
        x[ptr:end] = xs
        y[ptr:end] = ys
        ptr = end
    return x, y


def generate_noise_pair(rng: np.random.Generator, n: int, noise_model: str, sigma: float) -> Tuple[np.ndarray, np.ndarray]:
    if noise_model == "gaussian":
        return gaussian_noise_pair(rng, n, sigma)
    if noise_model == "ar1":
        return ar1_noise_pair(rng, n, sigma, phi=0.9)
    if noise_model == "pink":
        return pink_noise(rng, n, sigma), pink_noise(rng, n, sigma)
    if noise_model == "burst":
        return burst_noise(rng, n, sigma), burst_noise(rng, n, sigma)
    if noise_model == "mixture":
        return mixture_noise_pair(rng, n, sigma)
    raise ValueError(noise_model)


def disturbance_inject(
    rng: np.random.Generator,
    kind: str,
    level: float,
    onset: int,
    x: np.ndarray,
    y: np.ndarray,
    sigma: float,
) -> Tuple[np.ndarray, np.ndarray]:
    x2 = x.copy()
    y2 = y.copy()
    n = x.size
    t = np.arange(n - onset, dtype=np.float64)

    if kind == "mean_shift":
        x2[onset:] += level * sigma
        y2[onset:] += 0.6 * level * sigma

    elif kind == "variance_shift":
        fac = math.sqrt(max(level, EPS))
        x2[onset:] *= fac
        y2[onset:] *= 0.9 * fac

    elif kind == "slow_drift":
        x2[onset:] += level * np.arange(n - onset, dtype=np.float64)

    elif kind == "correlation_inversion":
        # keep marginal stats; flip y relation with x after onset
        y2[onset:] = level * x2[onset:] + math.sqrt(max(1.0 - level * level, EPS)) * y2[onset:]

    elif kind == "structural_topology_change":
        # latent mixing change while mean kept near zero
        z = rng.normal(0.0, sigma, size=n - onset)
        alpha = level
        x_mix = (1 - alpha) * x2[onset:] + alpha * np.tanh(y2[onset:] + 0.5 * z)
        x2[onset:] = x_mix

    elif kind == "run_length_change":
        seg = x2[onset:].copy()
        block = 32
        for i in range(0, seg.size, block):
            if rng.random() < level:
                seg[i : i + block] *= -1.0
        # match post segment scale to preserve RMS class
        if np.std(seg) > 0:
            seg *= (np.std(x2[onset:]) / (np.std(seg) + EPS))
        x2[onset:] = seg

    elif kind == "phase_shift":
        f = rng.uniform(0.01, 0.03)
        amp = 0.25 * sigma
        phi = level
        x2[onset:] += amp * np.sin(2.0 * math.pi * f * t + phi)

    elif kind == "harmonic_redistribution":
        seg = x2[onset:].copy()
        spec = np.fft.rfft(seg - np.mean(seg))
        mag = np.abs(spec)
        phase = np.angle(spec)
        nbin = mag.size
        low = slice(1, max(3, nbin // 12))
        mid = slice(max(3, nbin // 8), max(6, nbin // 4))
        transfer = level * float(np.sum(mag[mid]))
        mag[mid] *= (1.0 - level)
        mag[low] += transfer / max(1, mag[low].size)
        warped = np.fft.irfft(mag * np.exp(1j * phase), n=seg.size)
        warped = warped - np.mean(warped)
        warped *= np.std(seg) / (np.std(warped) + EPS)
        x2[onset:] = warped + np.mean(seg)

    elif kind == "rms_matched_structural":
        seg = x2[onset:].copy()
        spec = np.fft.rfft(seg)
        mag = np.abs(spec)
        ph = np.angle(spec)
        rand = rng.uniform(-math.pi, math.pi, size=ph.shape)
        rand[0] = ph[0]
        if seg.size % 2 == 0 and rand.size > 1:
            rand[-1] = ph[-1]
        # smooth phase warp by blending
        new_phase = (1.0 - level) * ph + level * rand
        scrambled = np.fft.irfft(mag * np.exp(1j * new_phase), n=seg.size)
        scrambled -= np.mean(scrambled)
        scrambled *= np.std(seg) / (np.std(scrambled) + EPS)
        x2[onset:] = scrambled + np.mean(seg)

    else:
        raise ValueError(kind)

    # RMS/variance matching for structural classes to keep amplitude stats controlled
    if kind in {"structural_topology_change", "run_length_change", "phase_shift", "harmonic_redistribution", "rms_matched_structural", "correlation_inversion"}:
        span = min(3000, onset, n - onset)
        if span > 32:
            pre = x2[onset - span : onset]
            post = x2[onset : onset + span]
            post = (post - np.mean(post)) * (np.std(pre) / (np.std(post) + EPS)) + np.mean(pre)
            x2[onset : onset + span] = post
    return x2, y2


class RMSDetector:
    def __init__(self, window: int = 64) -> None:
        self.window = window
        self.reset()

    def reset(self) -> None:
        self.buf: Deque[float] = deque(maxlen=self.window)
        self.sum_sq = 0.0

    def update(self, x: float) -> float:
        x2 = x * x
        if len(self.buf) == self.window:
            old = self.buf.popleft()
            self.sum_sq -= old
        self.buf.append(x2)
        self.sum_sq += x2
        return math.sqrt(self.sum_sq / max(1, len(self.buf)))


class CUSUMMeanDetector:
    def __init__(self, mu0: float, k: float) -> None:
        self.mu0 = mu0
        self.k = k
        self.reset()

    def reset(self) -> None:
        self.c_plus = 0.0
        self.c_minus = 0.0

    def update(self, x: float) -> float:
        d = x - self.mu0
        self.c_plus = max(0.0, self.c_plus + d - self.k)
        self.c_minus = max(0.0, self.c_minus - d - self.k)
        return max(self.c_plus, self.c_minus)


class CUSUMVarianceDetector:
    def __init__(self, mu0: float, alpha_hp: float, k: float) -> None:
        self.mu0 = mu0
        self.alpha_hp = alpha_hp
        self.k = k
        self.reset()

    def reset(self) -> None:
        self.ema_mean = self.mu0
        self.s = 0.0

    def update(self, x: float) -> float:
        self.ema_mean = (1 - self.alpha_hp) * self.ema_mean + self.alpha_hp * x
        hp = x - self.ema_mean
        z = hp * hp
        self.s = max(0.0, self.s + z - self.k)
        return self.s


class EWMADetector:
    def __init__(self, mu0: float, sigma0: float, var0: float, alpha: float, var_scale: float) -> None:
        self.mu0 = mu0
        self.sigma0 = sigma0
        self.var0 = var0
        self.alpha = alpha
        self.var_scale = var_scale
        self.reset()

    def reset(self) -> None:
        self.ema_mean = self.mu0
        self.ema_var = self.var0

    def update(self, x: float) -> float:
        self.ema_mean = (1 - self.alpha) * self.ema_mean + self.alpha * x
        r = x - self.ema_mean
        self.ema_var = (1 - self.alpha) * self.ema_var + self.alpha * (r * r)
        s_mean = abs(self.ema_mean - self.mu0) / (self.sigma0 + EPS)
        s_var = abs(self.ema_var - self.var0) / (self.var_scale + EPS)
        return max(s_mean, s_var)


class PageHinkleyDetector:
    def __init__(self, mu0: float, delta: float) -> None:
        self.mu0 = mu0
        self.delta = delta
        self.reset()

    def reset(self) -> None:
        self.mean = self.mu0
        self.count = 0
        self.ph = 0.0

    def update(self, x: float) -> float:
        self.count += 1
        self.mean += (x - self.mean) / self.count
        self.ph = max(0.0, self.ph + (x - self.mean - self.delta))
        return self.ph


class GLRMeanShiftDetector:
    def __init__(self, mu0: float, sigma0: float, window: int = 64) -> None:
        self.mu0 = mu0
        self.sigma0 = sigma0
        self.window = window
        self.reset()

    def reset(self) -> None:
        self.buf: Deque[float] = deque(maxlen=self.window)

    def update(self, x: float) -> float:
        self.buf.append(x)
        vals = list(self.buf)
        running = 0.0
        best = 0.0
        for width, v in enumerate(reversed(vals), start=1):
            running += v - self.mu0
            s = (running * running) / ((self.sigma0 * self.sigma0 * width) + EPS)
            if s > best:
                best = s
        return best


class FeatureTracker:
    def __init__(self, alpha: float = 0.1) -> None:
        self.alpha = alpha
        self.reset()

    def reset(self) -> None:
        self.prev = 0.0
        self.prev_dx = 0.0
        self.absdx_ema = 0.0
        self.curv_ema = 0.0
        self.run_sign = 1.0
        self.run_ema = 0.0
        self.t = 0

    def update(self, x: float) -> Dict[str, float]:
        if self.t == 0:
            dx = 0.0
            d2 = 0.0
        else:
            dx = x - self.prev
            d2 = dx - self.prev_dx
        sign = 1.0 if dx >= 0 else -1.0
        run = self.run_ema + 1.0 if sign == self.run_sign else 1.0
        self.run_sign = sign
        self.run_ema = (1 - self.alpha) * self.run_ema + self.alpha * run
        self.absdx_ema = (1 - self.alpha) * self.absdx_ema + self.alpha * abs(dx)
        self.curv_ema = (1 - self.alpha) * self.curv_ema + self.alpha * abs(d2)
        self.prev = x
        self.prev_dx = dx
        self.t += 1
        return {
            "x": x,
            "dx": dx,
            "d2": d2,
            "absdx_ema": self.absdx_ema,
            "curv_ema": self.curv_ema,
            "run_ema": self.run_ema,
        }


class HotellingT2Detector:
    def __init__(self, mu: np.ndarray, inv_cov: np.ndarray) -> None:
        self.mu = mu
        self.inv_cov = inv_cov
        self.ft = FeatureTracker(alpha=0.1)

    def reset(self) -> None:
        self.ft.reset()

    def update(self, x: float) -> float:
        f = self.ft.update(x)
        v = np.array([f["x"], f["dx"], f["d2"]], dtype=np.float64)
        d = v - self.mu
        return float(max(0.0, d @ self.inv_cov @ d))


class MahalanobisFeatureDetector:
    def __init__(self, mu: np.ndarray, inv_cov: np.ndarray) -> None:
        self.mu = mu
        self.inv_cov = inv_cov
        self.ft = FeatureTracker(alpha=0.1)

    def reset(self) -> None:
        self.ft.reset()

    def update(self, x: float) -> float:
        f = self.ft.update(x)
        v = np.array([f["x"], f["dx"], f["d2"], f["absdx_ema"], f["curv_ema"], f["run_ema"]], dtype=np.float64)
        d = v - self.mu
        return float(max(0.0, d @ self.inv_cov @ d))


class DMREDADetector:
    def __init__(self, a: float, b: float, c: float, k: float) -> None:
        self.a = a
        self.b = b
        self.c = c
        self.k = k
        self.reset()

    def reset(self) -> None:
        self.prev = 0.0
        self.prev_dx = 0.0
        self.pred = 0.0
        self.s = 0.0
        self.t = 0

    def update(self, x: float) -> float:
        if self.t == 0:
            dx = 0.0
            d2 = 0.0
            ent = 0.0
        else:
            dx = x - self.prev
            d2 = dx - self.prev_dx
            self.pred = self.prev + 0.5 * self.prev_dx
            ent = abs(x - self.pred)
        curv = abs(d2)
        vel = abs(dx)
        d_t = self.a * ent + self.b * curv + self.c * vel
        self.s = max(0.0, self.s + d_t - self.k)
        self.prev = x
        self.prev_dx = dx
        self.t += 1
        return self.s


def run_detector(detector: object, x: np.ndarray) -> np.ndarray:
    detector.reset()
    out = np.empty(x.size, dtype=np.float64)
    for i, v in enumerate(x):
        out[i] = detector.update(float(v))
    return out


def detector_drift_rate(scores: np.ndarray) -> float:
    if scores.size <= 1:
        return 0.0
    return float(np.mean(np.diff(scores)))


def tune_positive_drift_param(
    base_params: Dict[str, float],
    key: str,
    step: float,
    detector_factory: Callable[[Dict[str, float]], object],
    noise_signals: List[np.ndarray],
) -> Dict[str, float]:
    params = dict(base_params)
    for _ in range(10):
        scores = [run_detector(detector_factory(params), signal) for signal in noise_signals[:8]]
        drift = float(np.mean([detector_drift_rate(score) for score in scores]))
        if abs(drift) <= STATIONARY_DRIFT_TOL:
            break
        if drift > 0.0:
            params[key] += step
        else:
            params[key] = max(params[key] - step, EPS)
    return params


def fit_feature_stats(noise_runs: List[np.ndarray], kind: str) -> Tuple[np.ndarray, np.ndarray]:
    feats = []
    for x in noise_runs:
        ft = FeatureTracker(alpha=0.1)
        arr = []
        for v in x:
            f = ft.update(float(v))
            if kind == "hotelling_t2":
                arr.append([f["x"], f["dx"], f["d2"]])
            else:
                arr.append([f["x"], f["dx"], f["d2"], f["absdx_ema"], f["curv_ema"], f["run_ema"]])
        feats.append(np.asarray(arr, dtype=np.float64))
    allf = np.vstack(feats)
    mu = np.mean(allf, axis=0)
    cov = np.cov((allf - mu), rowvar=False) + 1e-4 * np.eye(allf.shape[1], dtype=np.float64)
    inv = np.linalg.pinv(cov)
    return mu, inv


def fit_dmreda_k(noise_runs: List[np.ndarray], a: float, b: float, c: float) -> float:
    d_vals = []
    for x in noise_runs:
        prev = 0.0
        prev_dx = 0.0
        for i, v in enumerate(x):
            if i == 0:
                dx = 0.0
                d2 = 0.0
                ent = 0.0
            else:
                dx = v - prev
                d2 = dx - prev_dx
                pred = prev + 0.5 * prev_dx
                ent = abs(v - pred)
            d_vals.append(a * ent + b * abs(d2) + c * abs(dx))
            prev = v
            prev_dx = dx
    return float(np.median(np.asarray(d_vals, dtype=np.float64)))


def build_detector_factories(noise_runs: List[np.ndarray]) -> Dict[str, Callable[[], object]]:
    all_noise = np.concatenate(noise_runs)
    mu0, sigma0 = robust_location_scale(all_noise)
    var0 = float(np.median((all_noise - mu0) ** 2) + EPS)

    # tune mean and variance CUSUM k
    params_mean = tune_positive_drift_param(
        {"mu0": mu0, "k": 0.5 * sigma0},
        "k",
        0.1 * sigma0,
        lambda p: CUSUMMeanDetector(p["mu0"], p["k"]),
        noise_runs,
    )

    # variance reference
    ema = mu0
    hp = []
    for v in all_noise:
        ema = (1 - HP_ALPHA) * ema + HP_ALPHA * v
        hp.append((v - ema) ** 2)
    hp = np.asarray(hp, dtype=np.float64)
    params_var = tune_positive_drift_param(
        {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp, 60.0))},
        "k",
        float(np.median(np.abs(hp - np.median(hp))) + EPS),
        lambda p: CUSUMVarianceDetector(p["mu0"], p["alpha_hp"], p["k"]),
        noise_runs,
    )

    ewma_var_series = []
    ema_mu = mu0
    ema_var = var0
    for v in all_noise:
        ema_mu = (1 - EWMA_ALPHA) * ema_mu + EWMA_ALPHA * v
        r = v - ema_mu
        ema_var = (1 - EWMA_ALPHA) * ema_var + EWMA_ALPHA * (r * r)
        ewma_var_series.append(ema_var)
    ewma_var_arr = np.asarray(ewma_var_series, dtype=np.float64)
    var_scale = 1.4826 * np.median(np.abs(ewma_var_arr - np.median(ewma_var_arr))) + EPS

    mu_t2, inv_t2 = fit_feature_stats(noise_runs, "hotelling_t2")
    mu_mh, inv_mh = fit_feature_stats(noise_runs, "mahal")
    dm_k = fit_dmreda_k(noise_runs, 1.0, 0.8, 0.6)

    return {
        "rms": lambda: RMSDetector(window=64),
        "cusum_mean": lambda: CUSUMMeanDetector(params_mean["mu0"], params_mean["k"]),
        "cusum_variance": lambda: CUSUMVarianceDetector(params_var["mu0"], params_var["alpha_hp"], params_var["k"]),
        "ewma": lambda: EWMADetector(mu0, sigma0, var0, EWMA_ALPHA, var_scale),
        "page_hinkley": lambda: PageHinkleyDetector(mu0, 0.25 * sigma0),
        "glr": lambda: GLRMeanShiftDetector(mu0, sigma0, window=64),
        "hotelling_t2": lambda: HotellingT2Detector(mu_t2, inv_t2),
        "mahalanobis": lambda: MahalanobisFeatureDetector(mu_mh, inv_mh),
        "dmreda": lambda: DMREDADetector(a=1.0, b=0.8, c=0.6, k=dm_k),
    }


def calibrate_models_for_noise_model(
    rng: np.random.Generator,
    noise_model: str,
    cal_runs: int,
    min_len: int,
    max_len: int,
    target_arl: float,
) -> Tuple[Dict[str, DetectorModel], Dict[str, Callable[[], object]]]:
    noise_runs: List[np.ndarray] = []
    for _ in range(cal_runs):
        n = int(rng.integers(min_len, max_len + 1))
        sigma = float(BASE_STD * rng.uniform(0.6, 1.4))
        baseline = make_baseline(rng, n, rng.choice(BASELINE_BEHAVIORS))
        nx, ny = generate_noise_pair(rng, n, noise_model, sigma)
        x = baseline + nx
        noise_runs.append(x.astype(np.float64))

    factories = build_detector_factories(noise_runs)
    idx_runs = [np.arange(x.size, dtype=np.int64) for x in noise_runs]
    lengths = [x.size for x in noise_runs]
    models: Dict[str, DetectorModel] = {}
    for name, factory in factories.items():
        score_runs = [run_detector(factory(), x) for x in noise_runs]
        thr, arl = calibrate_threshold_noise(score_runs, idx_runs, target_arl, PERSISTENCE, lengths)
        models[name] = DetectorModel(name=name, threshold=float(thr), arl=float(arl), params={"noise_model": noise_model})
    return models, factories


def evaluate_one_run(
    signal_len: int,
    onset: int,
    scores: np.ndarray,
    threshold: float,
    rms_change_time: Optional[int],
) -> Dict[str, object]:
    trig = gate_score_series(scores, threshold, PERSISTENCE, signal_len)
    first = first_any(trig)
    fp = first is not None and first < onset
    det = None if fp else first_after(trig, onset)
    miss = det is None
    delay = None if miss else float(det - onset)
    before_rms = (det is not None and rms_change_time is not None and det < rms_change_time)
    return {
        "fp": fp,
        "miss": miss,
        "delay": delay,
        "det_before_rms_change": bool(before_rms),
    }


def summarize_rows(rows: List[Dict[str, object]], lengths: List[int], onsets: List[int]) -> Dict[str, object]:
    delays = np.asarray([math.nan if r["delay"] is None else float(r["delay"]) for r in rows], dtype=np.float64)
    fp = np.asarray([bool(r["fp"]) for r in rows], dtype=bool)
    miss = np.asarray([bool(r["miss"]) for r in rows], dtype=bool)
    valid = delays[np.isfinite(delays)]
    expected = delays.copy()
    for i, n in enumerate(lengths):
        if fp[i]:
            expected[i] = 0.0
        elif miss[i]:
            expected[i] = float(n - onsets[i])
    success = (~fp) & (~miss)
    return {
        "detection_rate": float(np.mean(success)),
        "false_positive_rate": float(np.mean(fp)),
        "median_detection_delay": float(np.nanmedian(valid)) if valid.size else None,
        "mean_detection_delay": float(np.nanmean(valid)) if valid.size else None,
        "expected_delay": float(np.mean(expected)),
        "early_before_rms_change_rate": float(np.mean([bool(r["det_before_rms_change"]) for r in rows])),
        "delay_values": [None if not math.isfinite(v) else float(v) for v in delays],
    }


def rms_change_time(signal: np.ndarray, onset: int, window: int = 64, k: float = 3.0) -> Optional[int]:
    r = trailing_rms(signal, window)
    pre = r[:onset]
    mu = float(np.mean(pre))
    sd = float(np.std(pre) + EPS)
    idx = np.flatnonzero(np.abs(r[onset:] - mu) > k * sd)
    return None if idx.size == 0 else int(onset + idx[0])


def structure_metrics(x: np.ndarray, y: np.ndarray, onset: int, span: int = 2048) -> Dict[str, float]:
    s = min(span, onset, x.size - onset)
    pre_x = x[onset - s : onset]
    post_x = x[onset : onset + s]
    pre_y = y[onset - s : onset]
    post_y = y[onset : onset + s]

    corr_pre = float(np.corrcoef(pre_x, pre_y)[0, 1]) if s > 8 else 0.0
    corr_post = float(np.corrcoef(post_x, post_y)[0, 1]) if s > 8 else 0.0
    corr_change = abs(corr_post - corr_pre)

    curv_pre = float(np.mean(np.abs(np.diff(pre_x, n=2))))
    curv_post = float(np.mean(np.abs(np.diff(post_x, n=2))))
    curv_change = abs(curv_post - curv_pre) / (curv_pre + EPS)

    ent_pre = sign_entropy(np.diff(pre_x))
    ent_post = sign_entropy(np.diff(post_x))
    ent_change = abs(ent_post - ent_pre)

    run_pre = mean_run_length(np.sign(np.diff(pre_x)))
    run_post = mean_run_length(np.sign(np.diff(post_x)))
    run_change = abs(run_post - run_pre) / (run_pre + EPS)

    spec_pre = spectral_ratio(pre_x)
    spec_post = spectral_ratio(post_x)
    spec_change = abs(spec_post - spec_pre)

    score = float(np.mean([corr_change, curv_change, ent_change, run_change, spec_change]))
    return {
        "corr_change": corr_change,
        "curv_change": curv_change,
        "entropy_change": ent_change,
        "runlen_change": run_change,
        "spectral_change": spec_change,
        "structure_change_score": score,
    }


def pearson_corr(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return math.nan
    return float(np.corrcoef(x, y)[0, 1])


def plot_delay_hist(dist: str, det_stats: Dict[str, Dict[str, object]]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    bins = np.linspace(0.0, 5000.0, 40)
    for det, st in det_stats.items():
        vals = [v for v in st["delay_values"] if v is not None]  # type: ignore[index]
        if vals:
            ax.hist(vals, bins=bins, alpha=0.35, label=det)
    ax.set_title(f"{dist}: delay distribution")
    ax.set_xlabel("Delay (samples)")
    ax.set_ylabel("Count")
    ax.legend(fontsize=7)
    ax.grid(alpha=0.3)
    out = PLOT_DIR / f"{dist}_delay_hist.png"
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return str(out)


def plot_roc(dist: str, roc: Dict[str, List[Dict[str, float]]]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    for det, rows in roc.items():
        x = [r["false_positive_rate"] for r in rows]
        y = [r["detection_rate"] for r in rows]
        ax.plot(x, y, marker="o", markersize=2.5, linewidth=1.0, label=det)
    ax.set_title(f"{dist}: ROC sweep")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("Detection rate")
    ax.legend(fontsize=7)
    ax.grid(alpha=0.3)
    out = PLOT_DIR / f"{dist}_roc.png"
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return str(out)


def plot_heatmap(detection_matrix: np.ndarray, row_labels: List[str], col_labels: List[str]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(11, 6))
    im = ax.imshow(detection_matrix, aspect="auto", cmap="viridis")
    ax.set_xticks(np.arange(len(col_labels)))
    ax.set_xticklabels(col_labels, rotation=45, ha="right")
    ax.set_yticks(np.arange(len(row_labels)))
    ax.set_yticklabels(row_labels)
    ax.set_title("Detection rate heatmap (disturbance x detector)")
    fig.colorbar(im, ax=ax, fraction=0.025)
    out = PLOT_DIR / "disturbance_detector_heatmap.png"
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return str(out)


def plot_difficulty_curve(dist: str, levels: List[float], curves: Dict[str, List[float]]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    for det, ys in curves.items():
        ax.plot(levels, ys, marker="o", linewidth=1.2, label=det)
    ax.set_title(f"{dist}: difficulty vs detection rate")
    ax.set_xlabel("Disturbance strength")
    ax.set_ylabel("Detection rate")
    ax.legend(fontsize=7)
    ax.grid(alpha=0.3)
    out = PLOT_DIR / f"{dist}_difficulty_curve.png"
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return str(out)


def plot_structure_scatter(points: Dict[str, List[Tuple[float, float]]]) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    for det, vals in points.items():
        if not vals:
            continue
        x = [v[0] for v in vals]
        y = [v[1] for v in vals]
        ax.scatter(x, y, s=22, alpha=0.7, label=det)
    ax.set_title("Structure-change score vs detection rate")
    ax.set_xlabel("Mean structure_change_score")
    ax.set_ylabel("Detection rate")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7)
    out = PLOT_DIR / "structure_change_scatter.png"
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return str(out)


def final_analysis_text(results: Dict[str, object]) -> List[str]:
    lines: List[str] = []
    per_dist = results["disturbance_summary"]  # type: ignore[index]
    for dist, payload in per_dist.items():
        ranking = payload["ranking_by_detection_rate"]
        top = ranking[0]["detector"] if ranking else "n/a"
        lines.append(f"{dist}: best detection-rate detector = {top}")
    rms_payload = per_dist.get("rms_matched_structural", {})
    dm = rms_payload.get("detectors", {}).get("dmreda", {})
    best = rms_payload.get("ranking_by_detection_rate", [{}])[0].get("detector")
    if dm:
        lines.append(
            "RMS-matched structural: "
            f"DMREDA det={dm.get('detection_rate'):.3f}, fp={dm.get('false_positive_rate'):.3f}, "
            f"median_delay={dm.get('median_detection_delay')}"
        )
    lines.append(
        "Key question: DMREDA behaves as a structure-first detector when detection aligns with high "
        "structure_change_score and early_before_rms_change_rate is high."
    )
    if best == "dmreda":
        lines.append("Under RMS-matched structural disturbance, DMREDA is the top detector in this run.")
    else:
        lines.append(f"Under RMS-matched structural disturbance, top detector is {best}; DMREDA is not dominant.")
    return lines


def main() -> None:
    parser = argparse.ArgumentParser(description="Large synthetic structural benchmark")
    parser.add_argument("--runs-per-setting", type=int, default=40)
    parser.add_argument("--cal-runs", type=int, default=50)
    parser.add_argument("--min-length", type=int, default=10_000)
    parser.add_argument("--max-length", type=int, default=50_000)
    parser.add_argument("--target-arl", type=float, default=10_000.0)
    parser.add_argument("--seed", type=int, default=GLOBAL_SEED)
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    if args.quick:
        args.runs_per_setting = 6
        args.cal_runs = 8
        args.min_length = 10_000
        args.max_length = 14_000

    rng = np.random.default_rng(args.seed)
    target_arl = float(args.target_arl)

    # Calibrate detector thresholds per noise model.
    calibrated: Dict[str, Dict[str, DetectorModel]] = {}
    runtime_factories: Dict[str, Dict[str, Callable[[], object]]] = {}
    print("Calibrating detectors by noise model...")
    for nm in NOISE_MODELS:
        calibrated[nm], runtime_factories[nm] = calibrate_models_for_noise_model(
            rng,
            nm,
            cal_runs=args.cal_runs,
            min_len=args.min_length,
            max_len=args.max_length,
            target_arl=target_arl,
        )
        print(f"  {nm}: " + ", ".join(f"{k} ARL={v.arl:.1f}" for k, v in calibrated[nm].items()))

    detector_names = list(next(iter(calibrated.values())).keys())
    results: Dict[str, object] = {
        "meta": {
            "seed": args.seed,
            "runs_per_setting": args.runs_per_setting,
            "cal_runs": args.cal_runs,
            "length_range": [args.min_length, args.max_length],
            "target_arl": target_arl,
            "noise_models": list(NOISE_MODELS),
            "disturbance_levels": DISTURBANCE_LEVELS,
        },
        "calibration": {
            nm: {dn: {"threshold": dm.threshold, "empirical_arl": dm.arl} for dn, dm in models.items()}
            for nm, models in calibrated.items()
        },
        "settings": {},
        "disturbance_summary": {},
        "plots": {},
    }

    # Per-disturbance accumulators.
    disturbance_rows: Dict[str, Dict[str, List[Dict[str, object]]]] = {
        d: {det: [] for det in detector_names}
        for d in DISTURBANCE_LEVELS
    }
    disturbance_lengths_onsets: Dict[str, Tuple[List[int], List[int]]] = {
        d: ([], [])
        for d in DISTURBANCE_LEVELS
    }
    difficulty_curves: Dict[str, Dict[str, List[float]]] = {
        d: {det: [] for det in detector_names}
        for d in DISTURBANCE_LEVELS
    }
    structure_points: Dict[str, List[Tuple[float, float]]] = {det: [] for det in detector_names}

    print("\nRunning Monte-Carlo benchmark...")
    for dist_kind, levels in DISTURBANCE_LEVELS.items():
        for level in levels:
            key = f"{dist_kind}|{level}"
            setting_rows: Dict[str, List[Dict[str, object]]] = {det: [] for det in detector_names}
            setting_lengths: List[int] = []
            setting_onsets: List[int] = []
            structure_scores: List[float] = []

            # Cache for ROC sweep (score arrays + run metadata)
            roc_cache: Dict[str, List[Tuple[np.ndarray, int, int, float]]] = {det: [] for det in detector_names}
            base_thresholds: Dict[str, List[float]] = {det: [] for det in detector_names}

            for run_idx in range(args.runs_per_setting):
                nm = NOISE_MODELS[run_idx % len(NOISE_MODELS)]
                n = int(rng.integers(args.min_length, args.max_length + 1))
                onset = int(rng.integers(int(0.25 * n), int(0.75 * n)))
                sigma = float(BASE_STD * rng.uniform(0.5, 1.5))
                baseline_kind = str(rng.choice(BASELINE_BEHAVIORS))

                baseline = make_baseline(rng, n, baseline_kind)
                nx, ny = generate_noise_pair(rng, n, nm, sigma)
                x = baseline + nx
                y = 0.6 * baseline + ny
                x, y = disturbance_inject(rng, dist_kind, float(level), onset, x, y, sigma)

                # For RMS-matched structural classes, enforce match (discard+retry if mismatch >2%)
                if dist_kind in {"harmonic_redistribution", "rms_matched_structural", "structural_topology_change", "run_length_change", "phase_shift", "correlation_inversion"}:
                    x = normalize_post_segment(x, onset, span=min(2500, onset, n - onset))
                    g = {
                        "rms_gap_rel": abs(np.std(x[onset:onset + min(2000, n - onset)]) - np.std(x[max(0, onset - min(2000, onset)):onset])) /
                                       (np.std(x[max(0, onset - min(2000, onset)):onset]) + EPS),
                        "var_gap_rel": abs(np.var(x[onset:onset + min(2000, n - onset)]) - np.var(x[max(0, onset - min(2000, onset)):onset])) /
                                       (np.var(x[max(0, onset - min(2000, onset)):onset]) + EPS),
                    }
                    if g["rms_gap_rel"] > 0.02 or g["var_gap_rel"] > 0.02:
                        # one retry replacement
                        x2, y2 = disturbance_inject(rng, dist_kind, float(level), onset, baseline + nx, 0.6 * baseline + ny, sigma)
                        x2 = normalize_post_segment(x2, onset, span=min(2500, onset, n - onset))
                        x, y = x2, y2

                s_metrics = structure_metrics(x, y, onset)
                structure_scores.append(s_metrics["structure_change_score"])

                r_change = rms_change_time(x, onset, window=64, k=3.0)

                for det in detector_names:
                    model = calibrated[nm][det]
                    # Build detector instance matching calibration family.
                    detector = runtime_factories[nm][det]()
                    scores = run_detector(detector, x)
                    row = evaluate_one_run(x.size, onset, scores, model.threshold, r_change)
                    setting_rows[det].append(row)
                    disturbance_rows[dist_kind][det].append(row)
                    roc_cache[det].append((scores, onset, n, float(model.threshold)))
                    base_thresholds[det].append(float(model.threshold))

                setting_lengths.append(n)
                setting_onsets.append(onset)
                disturbance_lengths_onsets[dist_kind][0].append(n)
                disturbance_lengths_onsets[dist_kind][1].append(onset)

            # Setting summary
            summary = {det: summarize_rows(rows, setting_lengths, setting_onsets) for det, rows in setting_rows.items()}
            # ROC for this setting
            roc_setting: Dict[str, List[Dict[str, float]]] = {}
            for det, runs in roc_cache.items():
                entries = []
                for m in np.linspace(0.5, 2.0, 15):
                    rows = []
                    for scores, onset, n, thr_base in runs:
                        rows.append(evaluate_one_run(n, onset, scores, thr_base * float(m), None))
                    st = summarize_rows(rows, [n for _, _, n, _ in runs], [on for _, on, _, _ in runs])
                    entries.append(
                        {
                            "multiplier": float(m),
                            "detection_rate": float(st["detection_rate"]),
                            "false_positive_rate": float(st["false_positive_rate"]),
                            "median_delay": float(st["median_detection_delay"]) if st["median_detection_delay"] is not None else math.nan,
                            "expected_delay": float(st["expected_delay"]),
                        }
                    )
                roc_setting[det] = entries

            # structure score correlation with setting detection rate points
            mean_struct = float(np.mean(structure_scores))
            for det in detector_names:
                structure_points[det].append((mean_struct, float(summary[det]["detection_rate"])))
                difficulty_curves[dist_kind][det].append(float(summary[det]["detection_rate"]))

            results["settings"][key] = {
                "disturbance": dist_kind,
                "level": float(level),
                "summary": summary,
                "roc": roc_setting,
                "mean_structure_change_score": mean_struct,
            }

    # Aggregate per disturbance
    row_labels = []
    heat = []
    for dist_kind in DISTURBANCE_LEVELS:
        lengths, onsets = disturbance_lengths_onsets[dist_kind]
        det_summary = {det: summarize_rows(rows, lengths, onsets) for det, rows in disturbance_rows[dist_kind].items()}
        ranking = sorted(
            [{"detector": d, "detection_rate": float(st["detection_rate"])} for d, st in det_summary.items()],
            key=lambda z: z["detection_rate"],
            reverse=True,
        )
        # average structure score / detection relation per detector across levels
        results["disturbance_summary"][dist_kind] = {
            "detectors": det_summary,
            "ranking_by_detection_rate": ranking,
        }
        row_labels.append(dist_kind)
        heat.append([float(det_summary[d]["detection_rate"]) for d in detector_names])

        results["disturbance_summary"][dist_kind]["plots"] = {
            "delay_hist": plot_delay_hist(dist_kind, det_summary),
            "difficulty_curve": plot_difficulty_curve(dist_kind, DISTURBANCE_LEVELS[dist_kind], difficulty_curves[dist_kind]),
        }

        # ROC aggregated from settings for this disturbance
        roc_agg: Dict[str, List[Dict[str, float]]] = {d: [] for d in detector_names}
        for det in detector_names:
            for m in np.linspace(0.5, 2.0, 15):
                rows = []
                for level in DISTURBANCE_LEVELS[dist_kind]:
                    key = f"{dist_kind}|{level}"
                    setting = results["settings"][key]
                    # find nearest multiplier entry
                    rec = min(setting["roc"][det], key=lambda r: abs(r["multiplier"] - float(m)))
                    rows.append(rec)
                roc_agg[det].append(
                    {
                        "multiplier": float(m),
                        "detection_rate": float(np.mean([r["detection_rate"] for r in rows])),
                        "false_positive_rate": float(np.mean([r["false_positive_rate"] for r in rows])),
                        "median_delay": float(np.mean([r["median_delay"] for r in rows if math.isfinite(r["median_delay"])]))
                        if any(math.isfinite(r["median_delay"]) for r in rows)
                        else math.nan,
                        "expected_delay": float(np.mean([r["expected_delay"] for r in rows])),
                    }
                )
        results["disturbance_summary"][dist_kind]["roc"] = roc_agg
        results["disturbance_summary"][dist_kind]["plots"]["roc"] = plot_roc(dist_kind, roc_agg)

    # Structure sensitivity correlation
    structure_corr = {}
    for det, pts in structure_points.items():
        x = np.asarray([p[0] for p in pts], dtype=np.float64)
        y = np.asarray([p[1] for p in pts], dtype=np.float64)
        structure_corr[det] = pearson_corr(x, y)
    results["structure_sensitivity"] = {
        "correlation_structure_score_vs_detection_rate": structure_corr,
    }

    # Global plots
    results["plots"]["heatmap"] = plot_heatmap(np.asarray(heat, dtype=np.float64), row_labels, detector_names)
    results["plots"]["structure_scatter"] = plot_structure_scatter(structure_points)

    # Final analysis
    results["final_analysis_report"] = final_analysis_text(results)

    RESULT_JSON.write_text(json.dumps(results, indent=2, default=json_default), encoding="utf-8")

    # Console summary table
    print("\nSummary table (disturbance x detector)")
    print("disturbance | detector | detection_rate | median_delay | false_positive_rate | ARL_mean")
    for dist_kind in DISTURBANCE_LEVELS:
        dets = results["disturbance_summary"][dist_kind]["detectors"]
        for det in detector_names:
            st = dets[det]
            # mean ARL over noise models
            arl_vals = [calibrated[nm][det].arl for nm in NOISE_MODELS]
            arl_mean = float(np.mean(arl_vals))
            print(
                f"{dist_kind:22s} | {det:15s} | {st['detection_rate']:.3f} | "
                f"{str(st['median_detection_delay']):>12} | {st['false_positive_rate']:.3f} | {arl_mean:.1f}"
            )

    print(f"\nSaved JSON: {RESULT_JSON}")
    print(f"Saved plots: {PLOT_DIR}")


if __name__ == "__main__":
    main()
