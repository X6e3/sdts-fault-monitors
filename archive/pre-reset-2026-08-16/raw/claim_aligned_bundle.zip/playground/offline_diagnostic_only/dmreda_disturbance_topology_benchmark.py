# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
"""
Topology-aware streaming benchmark for DMREDA vs classical change detectors.
"""

from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark import (
    EPS,
    EWMA_ALPHA,
    FEATURE_WINDOW,
    GLR_WINDOW,
    GLOBAL_SEED,
    HP_ALPHA,
    PERSISTENCE,
    TARGET_ARL,
    EWMAMeanVarianceDetector,
    GLRMeanShiftDetector,
    TwoSidedCUSUMDetector,
    VarianceCUSUMDetector,
    augmented_features,
    build_dmreda_model,
    calibrate_threshold_noise,
    gate_score_series,
    mahalanobis_series,
    robust_location_scale,
    robust_variance,
    run_streaming_detector,
    sequential_statistic,
    tune_positive_drift_param,
)


RESULT_JSON = Path("/Users/x6e3/vscode/results/dmreda_disturbance_topology_benchmark.json")
PLOT_DIR = Path("/Users/x6e3/vscode/results/dmreda_disturbance_topology_plots")

SAMPLES_PER_RUN = 12_000
ONSET_MIN = 4_000
ONSET_MAX = 8_000
NOISE_STD = 0.4
MC_RUNS = 300
CAL_RUNS = 64
TARGET_ARL_LOCAL = 10_000.0
LOCAL_RMS_WINDOW = 1024

FEATURE_NAMES = [
    "run_length",
    "sign_autocorr",
    "zero_cross_density",
    "monotonicity",
    "sign_variance",
    "trend_entropy",
    "slope_mag",
    "norm_cumsum",
    "low_freq_ratio",
    "mean_drift",
]
FEATURE_TRACE_IDS = [0, 1, 8, 9]


@dataclass
class DetectorModel:
    name: str
    kind: str
    threshold: float
    arl: float
    payload: Dict[str, object]


def json_default(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def local_stats(signal: np.ndarray, onset: int, window: int = LOCAL_RMS_WINDOW) -> Dict[str, float]:
    lo = max(0, onset - window)
    hi = min(signal.size, onset + window)
    pre = signal[lo:onset]
    post = signal[onset:hi]
    pre_mean = float(np.mean(pre))
    post_mean = float(np.mean(post))
    pre_var = float(np.var(pre) + EPS)
    post_var = float(np.var(post) + EPS)
    pre_rms = math.sqrt(float(np.mean(pre**2)) + EPS)
    post_rms = math.sqrt(float(np.mean(post**2)) + EPS)
    return {
        "mean_gap": abs(post_mean - pre_mean),
        "var_gap_rel": abs(post_var - pre_var) / pre_var,
        "rms_gap_rel": abs(post_rms - pre_rms) / pre_rms,
        "pre_rms": pre_rms,
        "post_rms": post_rms,
    }


def match_post_rms(signal: np.ndarray, onset: int, window: int = LOCAL_RMS_WINDOW) -> np.ndarray:
    out = signal.copy()
    start = max(0, onset - window)
    pre = out[start:onset]
    post = out[onset : min(out.size, onset + window)]
    pre_rms = math.sqrt(float(np.mean(pre**2)) + EPS)
    post_rms = math.sqrt(float(np.mean(post**2)) + EPS)
    gain = pre_rms / post_rms
    out[onset:] *= gain
    return out


def gaussian_noise(rng: np.random.Generator, size: int, std: float = NOISE_STD) -> np.ndarray:
    return rng.normal(0.0, std, size=size).astype(np.float64)


def ar_process(
    rng: np.random.Generator,
    size: int,
    rho_pre: float,
    rho_post: Optional[float] = None,
    onset: Optional[int] = None,
    innovation_fn: Optional[Callable[[int], np.ndarray]] = None,
) -> np.ndarray:
    if rho_post is None:
        rho_post = rho_pre
    if onset is None:
        onset = size + 1
    sigma_pre = NOISE_STD * math.sqrt(max(1.0 - rho_pre * rho_pre, EPS))
    sigma_post = NOISE_STD * math.sqrt(max(1.0 - rho_post * rho_post, EPS))
    out = np.empty(size, dtype=np.float64)
    out[0] = rng.normal(0.0, NOISE_STD)
    for idx in range(1, size):
        if innovation_fn is None:
            eps = rng.normal(0.0, sigma_pre if idx < onset else sigma_post)
        else:
            eps = float(innovation_fn(idx))
        rho = rho_pre if idx < onset else rho_post
        out[idx] = rho * out[idx - 1] + eps
    return out


def sample_onset(rng: np.random.Generator) -> int:
    return int(rng.integers(ONSET_MIN, ONSET_MAX + 1))


def scenario_structural_drift(rng: np.random.Generator, with_event: bool) -> Tuple[np.ndarray, int, Dict[str, float]]:
    onset = sample_onset(rng)
    t = np.arange(SAMPLES_PER_RUN, dtype=np.float64)
    f0 = float(rng.uniform(0.010, 0.025))
    alpha = float(rng.uniform(1.0e-6, 4.0e-6)) if with_event else 0.0
    phase0 = float(rng.uniform(-math.pi, math.pi))
    tau = np.clip(t - onset, 0.0, None)
    phase = 2.0 * math.pi * (f0 * t + 0.5 * alpha * tau * tau) + phase0
    signal = np.sin(phase) + gaussian_noise(rng, SAMPLES_PER_RUN)
    signal = match_post_rms(signal, onset)
    diag = local_stats(signal, onset)
    diag["f0"] = f0
    diag["alpha"] = alpha
    return signal, onset, diag


def scenario_correlation_structure_change(rng: np.random.Generator, with_event: bool) -> Tuple[np.ndarray, int, Dict[str, float]]:
    onset = sample_onset(rng)
    rho_pre = 0.8
    rho_post = -0.8 if with_event else 0.8
    signal = ar_process(rng, SAMPLES_PER_RUN, rho_pre=rho_pre, rho_post=rho_post, onset=onset)
    signal = match_post_rms(signal, onset)
    diag = local_stats(signal, onset)
    diag["rho_pre"] = rho_pre
    diag["rho_post"] = rho_post
    return signal, onset, diag


def scenario_slow_topology_change(rng: np.random.Generator, with_event: bool) -> Tuple[np.ndarray, int, Dict[str, float]]:
    onset = sample_onset(rng)
    t = np.arange(SAMPLES_PER_RUN, dtype=np.float64)
    f0 = float(rng.uniform(0.010, 0.020))
    phase0 = float(rng.uniform(-math.pi, math.pi))
    beta_max = float(rng.uniform(0.20, 0.40)) if with_event else 0.0
    beta = np.zeros_like(t)
    if with_event:
        beta[onset:] = beta_max * np.linspace(0.0, 1.0, SAMPLES_PER_RUN - onset, dtype=np.float64)
    base = np.sin(2.0 * math.pi * f0 * t + phase0)
    harm = np.sin(2.0 * math.pi * 3.0 * f0 * t + phase0)
    topo = (base + beta * harm) / np.sqrt(1.0 + beta * beta + EPS)
    signal = topo + gaussian_noise(rng, SAMPLES_PER_RUN)
    signal = match_post_rms(signal, onset)
    diag = local_stats(signal, onset)
    diag["beta_max"] = beta_max
    return signal, onset, diag


def scenario_entropy_slope_change(rng: np.random.Generator, with_event: bool) -> Tuple[np.ndarray, int, Dict[str, float]]:
    onset = sample_onset(rng)
    rho = 0.9
    sigma_innov = NOISE_STD * math.sqrt(max(1.0 - rho * rho, EPS))
    gamma_max = float(rng.uniform(0.45, 0.75)) if with_event else 0.0

    def innovation(idx: int) -> float:
        if idx < onset or not with_event:
            g = 0.0
        else:
            g = gamma_max * ((idx - onset) / max(1, SAMPLES_PER_RUN - onset - 1))
        z = rng.normal(0.0, sigma_innov)
        u = rng.uniform(-math.sqrt(3.0) * sigma_innov, math.sqrt(3.0) * sigma_innov)
        return math.sqrt(max(0.0, 1.0 - g * g)) * z + g * u

    signal = ar_process(rng, SAMPLES_PER_RUN, rho_pre=rho, rho_post=rho, onset=onset, innovation_fn=innovation)
    signal = match_post_rms(signal, onset)
    diag = local_stats(signal, onset)
    diag["gamma_max"] = gamma_max
    return signal, onset, diag


SCENARIOS = {
    "structural_drift": scenario_structural_drift,
    "correlation_structure_change": scenario_correlation_structure_change,
    "slow_topology_change": scenario_slow_topology_change,
    "entropy_slope_change": scenario_entropy_slope_change,
}


def build_feature_baseline(noise_signals: List[np.ndarray]) -> Dict[str, object]:
    idx_runs: List[np.ndarray] = []
    feat_runs: List[np.ndarray] = []
    lengths: List[int] = []
    for sig in noise_signals:
        idx, feats = augmented_features(sig, FEATURE_WINDOW)
        idx_runs.append(idx)
        feat_runs.append(feats)
        lengths.append(sig.size)
    all_feats = np.vstack(feat_runs)
    mean = np.mean(all_feats, axis=0)
    std = np.std(all_feats, axis=0)
    std_safe = np.where(std < 1e-6, 1.0, std)
    feats_std = [(f - mean) / std_safe for f in feat_runs]
    centroid = np.mean(np.vstack(feats_std), axis=0)
    centered = np.vstack([f - centroid for f in feats_std])
    cov = np.cov(centered, rowvar=False) + 1e-3 * np.eye(centered.shape[1], dtype=np.float64)
    inv_cov = np.linalg.pinv(cov)
    return {
        "idx_runs": idx_runs,
        "feat_runs": feat_runs,
        "lengths": lengths,
        "mean": mean,
        "std": std_safe,
        "centroid": centroid,
        "inv_cov": inv_cov,
    }


def build_hotelling_model(noise_signals: List[np.ndarray], target_arl: float) -> DetectorModel:
    base = build_feature_baseline(noise_signals)
    score_runs = []
    for feats in base["feat_runs"]:  # type: ignore[index]
        feats_std = (feats - base["mean"]) / base["std"]  # type: ignore[index]
        score_runs.append(mahalanobis_series(feats_std, base["centroid"], base["inv_cov"]))  # type: ignore[index]
    threshold, arl = calibrate_threshold_noise(
        score_runs,
        base["idx_runs"],  # type: ignore[arg-type]
        target_arl,
        PERSISTENCE,
        base["lengths"],  # type: ignore[arg-type]
    )
    return DetectorModel("hotelling_t2", "hotelling_t2", float(threshold), float(arl), base)


def build_raw_models(noise_signals: List[np.ndarray], target_arl: float) -> Dict[str, DetectorModel]:
    all_noise = np.concatenate(noise_signals)
    mu0, sigma0 = robust_location_scale(all_noise)
    var0 = robust_variance(all_noise, mu0)

    ewma_mean = mu0
    hp_energy = []
    ewma_var = var0
    ewma_var_series = []
    for sample in all_noise:
        ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
        residual = sample - ewma_mean
        hp_energy.append(residual * residual)
        ewma_var = (1.0 - EWMA_ALPHA) * ewma_var + EWMA_ALPHA * (residual * residual)
        ewma_var_series.append(ewma_var)
    hp_energy_arr = np.asarray(hp_energy, dtype=np.float64)
    ewma_var_arr = np.asarray(ewma_var_series, dtype=np.float64)
    var_scale = 1.4826 * np.median(np.abs(ewma_var_arr - np.median(ewma_var_arr))) + EPS

    idx_runs = [np.arange(sig.size, dtype=np.int64) for sig in noise_signals]
    lengths = [sig.size for sig in noise_signals]

    models: Dict[str, DetectorModel] = {}

    params_mean = tune_positive_drift_param(
        {"mu0": mu0, "k": 0.5 * sigma0},
        "k",
        0.1 * sigma0,
        lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
        noise_signals,
    )
    scores_mean = [run_streaming_detector(TwoSidedCUSUMDetector(params_mean["mu0"], params_mean["k"]), sig) for sig in noise_signals]
    thr_mean, arl_mean = calibrate_threshold_noise(scores_mean, idx_runs, target_arl, PERSISTENCE, lengths)
    models["cusum_mean"] = DetectorModel("cusum_mean", "cusum_mean", float(thr_mean), float(arl_mean), {"params": params_mean})

    params_var = tune_positive_drift_param(
        {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp_energy_arr, 60.0))},
        "k",
        float(np.median(np.abs(hp_energy_arr - np.median(hp_energy_arr))) + EPS),
        lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
        noise_signals,
    )
    scores_var = [
        run_streaming_detector(VarianceCUSUMDetector(params_var["mu0"], params_var["alpha_hp"], params_var["k"]), sig)
        for sig in noise_signals
    ]
    thr_var, arl_var = calibrate_threshold_noise(scores_var, idx_runs, target_arl, PERSISTENCE, lengths)
    models["cusum_variance"] = DetectorModel("cusum_variance", "cusum_variance", float(thr_var), float(arl_var), {"params": params_var})

    ewma_params = {"mu0": mu0, "sigma0": sigma0, "var0": var0, "alpha": EWMA_ALPHA, "var_scale": var_scale}
    ewma_scores = [
        run_streaming_detector(
            EWMAMeanVarianceDetector(
                ewma_params["mu0"],
                ewma_params["sigma0"],
                ewma_params["var0"],
                ewma_params["alpha"],
                ewma_params["var_scale"],
            ),
            sig,
        )
        for sig in noise_signals
    ]
    thr_ewma, arl_ewma = calibrate_threshold_noise(ewma_scores, idx_runs, target_arl, PERSISTENCE, lengths)
    models["ewma"] = DetectorModel("ewma", "ewma", float(thr_ewma), float(arl_ewma), {"params": ewma_params})

    glr_params = {"mu0": mu0, "sigma0": sigma0, "window": GLR_WINDOW}
    glr_scores = [
        run_streaming_detector(GLRMeanShiftDetector(glr_params["mu0"], glr_params["sigma0"], glr_params["window"]), sig)
        for sig in noise_signals
    ]
    thr_glr, arl_glr = calibrate_threshold_noise(glr_scores, idx_runs, target_arl, PERSISTENCE, lengths)
    models["glr"] = DetectorModel("glr", "glr", float(thr_glr), float(arl_glr), {"params": glr_params})
    return models


def build_models_for_scenario(noise_signals: List[np.ndarray]) -> Dict[str, DetectorModel]:
    dm = build_dmreda_model(noise_signals, TARGET_ARL_LOCAL)
    models = {
        "dmreda": DetectorModel("dmreda", "dmreda", float(dm["threshold"]), float(dm["arl"]), dm),
        "hotelling_t2": build_hotelling_model(noise_signals, TARGET_ARL_LOCAL),
    }
    models.update(build_raw_models(noise_signals, TARGET_ARL_LOCAL))
    return models


def score_detector(
    signal: np.ndarray,
    model: DetectorModel,
    cached_features: Optional[Tuple[np.ndarray, np.ndarray]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    if model.kind == "dmreda":
        idx, feats = cached_features if cached_features is not None else augmented_features(signal, FEATURE_WINDOW)
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        dist = mahalanobis_series(feats_std, model.payload["centroid"], model.payload["inv_cov"])  # type: ignore[index]
        seq = sequential_statistic(dist, float(model.payload["bias"]))  # type: ignore[index]
        return idx, seq
    if model.kind == "hotelling_t2":
        idx, feats = cached_features if cached_features is not None else augmented_features(signal, FEATURE_WINDOW)
        feats_std = (feats - model.payload["mean"]) / model.payload["std"]  # type: ignore[index]
        t2 = mahalanobis_series(feats_std, model.payload["centroid"], model.payload["inv_cov"])  # type: ignore[index]
        return idx, t2
    if model.kind == "cusum_mean":
        p = model.payload["params"]  # type: ignore[index]
        score = run_streaming_detector(TwoSidedCUSUMDetector(p["mu0"], p["k"]), signal)
        return np.arange(signal.size, dtype=np.int64), score
    if model.kind == "cusum_variance":
        p = model.payload["params"]  # type: ignore[index]
        score = run_streaming_detector(VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]), signal)
        return np.arange(signal.size, dtype=np.int64), score
    if model.kind == "ewma":
        p = model.payload["params"]  # type: ignore[index]
        score = run_streaming_detector(EWMAMeanVarianceDetector(p["mu0"], p["sigma0"], p["var0"], p["alpha"], p["var_scale"]), signal)
        return np.arange(signal.size, dtype=np.int64), score
    if model.kind == "glr":
        p = model.payload["params"]  # type: ignore[index]
        score = run_streaming_detector(GLRMeanShiftDetector(p["mu0"], p["sigma0"], int(p["window"])), signal)
        return np.arange(signal.size, dtype=np.int64), score
    raise ValueError(model.kind)


def evaluate_detector_run(
    signal: np.ndarray,
    onset: int,
    model: DetectorModel,
    cached_features: Optional[Tuple[np.ndarray, np.ndarray]] = None,
) -> Dict[str, object]:
    idx, score = score_detector(signal, model, cached_features)
    trigger = gate_score_series(score, model.threshold, PERSISTENCE, signal.size, idx)
    hits = np.flatnonzero(trigger)
    first = None if hits.size == 0 else int(hits[0])
    fp = first is not None and first < onset
    detect = None
    if not fp:
        post = np.flatnonzero(trigger[onset:])
        if post.size:
            detect = int(onset + post[0])
    miss = detect is None
    return {
        "delay": None if miss else float(detect - onset),
        "miss": miss,
        "fp": fp,
        "detect": detect,
    }


def summarize_detector_runs(runs: List[Dict[str, object]], signals: List[np.ndarray], onsets: List[int]) -> Dict[str, object]:
    delays = np.asarray([math.nan if row["delay"] is None else float(row["delay"]) for row in runs], dtype=np.float64)
    misses = np.asarray([bool(row["miss"]) for row in runs], dtype=bool)
    fps = np.asarray([bool(row["fp"]) for row in runs], dtype=bool)
    success = (~misses) & (~fps)
    valid = delays[np.isfinite(delays)]
    unconditional = delays.copy()
    for idx, sig in enumerate(signals):
        if fps[idx]:
            unconditional[idx] = 0.0
        elif misses[idx]:
            unconditional[idx] = float(sig.size - onsets[idx])
    return {
        "detection_rate": float(np.mean(success)),
        "false_positive_rate": float(np.mean(fps)),
        "miss_rate": float(np.mean(misses)),
        "median_delay": float(np.nanmedian(valid)) if valid.size else None,
        "mean_delay": float(np.nanmean(valid)) if valid.size else None,
        "expected_delay": float(np.mean(unconditional)),
        "delays": [None if not math.isfinite(v) else float(v) for v in delays],
    }


def generate_noise_bank(scenario_name: str, runs: int, seed: int) -> List[np.ndarray]:
    rng = np.random.default_rng(seed)
    signals = []
    fn = SCENARIOS[scenario_name]
    for _ in range(runs):
        signal, _, _ = fn(rng, False)
        signals.append(signal)
    return signals


def generate_event_runs(scenario_name: str, runs: int, seed: int) -> Tuple[List[np.ndarray], List[int], List[Dict[str, float]], List[Tuple[np.ndarray, np.ndarray]]]:
    rng = np.random.default_rng(seed)
    fn = SCENARIOS[scenario_name]
    signals: List[np.ndarray] = []
    onsets: List[int] = []
    diags: List[Dict[str, float]] = []
    features: List[Tuple[np.ndarray, np.ndarray]] = []
    for _ in range(runs):
        signal, onset, diag = fn(rng, True)
        signals.append(signal)
        onsets.append(onset)
        diags.append(diag)
        features.append(augmented_features(signal, FEATURE_WINDOW))
    return signals, onsets, diags, features


def representative_index(detector_runs: List[Dict[str, object]]) -> int:
    finite = [(idx, row["delay"]) for idx, row in enumerate(detector_runs) if row["delay"] is not None]
    if not finite:
        return 0
    vals = np.asarray([float(v) for _, v in finite], dtype=np.float64)
    target = float(np.median(vals))
    best_idx, _ = min(finite, key=lambda item: abs(float(item[1]) - target))
    return int(best_idx)


def plot_scenario(
    scenario_name: str,
    summary: Dict[str, Dict[str, object]],
    raw_runs: Dict[str, List[Dict[str, object]]],
    signals: List[np.ndarray],
    onsets: List[int],
    feature_cache: List[Tuple[np.ndarray, np.ndarray]],
) -> str:
    PLOT_DIR.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    # Detection-vs-delay frontier
    for det_name, stats in summary.items():
        md = stats["median_delay"]
        if md is None:
            md = float(SAMPLES_PER_RUN)
        axes[0].scatter(
            float(stats["false_positive_rate"]),
            float(stats["detection_rate"]),
            s=90,
            label=f"{det_name} ({md:.0f})",
        )
    axes[0].set_title(f"{scenario_name}: detection vs FP")
    axes[0].set_xlabel("false_positive_rate")
    axes[0].set_ylabel("detection_rate")
    axes[0].grid(True, alpha=0.3)
    axes[0].legend(fontsize=8)

    # Delay histogram
    bins = np.linspace(0.0, SAMPLES_PER_RUN - ONSET_MIN, 30)
    for det_name, stats in summary.items():
        delays = [d for d in stats["delays"] if d is not None]  # type: ignore[index]
        if delays:
            axes[1].hist(delays, bins=bins, alpha=0.35, label=det_name)
    axes[1].set_title(f"{scenario_name}: delay distribution")
    axes[1].set_xlabel("strict delay (samples)")
    axes[1].set_ylabel("count")
    axes[1].legend(fontsize=8)

    # Feature trajectory for representative DMREDA run
    rep_idx = representative_index(raw_runs["dmreda"])
    idx, feats = feature_cache[rep_idx]
    onset = onsets[rep_idx]
    for feat_id in FEATURE_TRACE_IDS:
        pre = feats[idx < onset, feat_id]
        mu = float(np.mean(pre)) if pre.size else 0.0
        sigma = float(np.std(pre) + EPS) if pre.size else 1.0
        z = (feats[:, feat_id] - mu) / sigma
        axes[2].plot(idx, z, label=FEATURE_NAMES[feat_id], linewidth=1.2)
    axes[2].axvline(onset, color="k", linestyle="--", linewidth=1.0)
    axes[2].set_title(f"{scenario_name}: feature trajectory")
    axes[2].set_xlabel("sample")
    axes[2].set_ylabel("z-score vs pre-onset")
    axes[2].legend(fontsize=8)
    axes[2].grid(True, alpha=0.3)

    fig.tight_layout()
    out_path = PLOT_DIR / f"{scenario_name}.png"
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return str(out_path)


def choose_best_detector(summary: Dict[str, Dict[str, object]]) -> str:
    eligible = {k: v for k, v in summary.items() if float(v["false_positive_rate"]) <= 0.10}
    pool = eligible if eligible else summary
    ranked = sorted(
        pool.items(),
        key=lambda item: (
            -float(item[1]["detection_rate"]),
            float(SAMPLES_PER_RUN if item[1]["median_delay"] is None else item[1]["median_delay"]),
            float(item[1]["false_positive_rate"]),
        ),
    )
    return ranked[0][0]


def main() -> None:
    results: Dict[str, object] = {
        "meta": {
            "seed": GLOBAL_SEED,
            "samples_per_run": SAMPLES_PER_RUN,
            "event_onset_range": [ONSET_MIN, ONSET_MAX],
            "noise_std": NOISE_STD,
            "mc_runs": MC_RUNS,
            "calibration_runs": CAL_RUNS,
            "target_arl": TARGET_ARL_LOCAL,
            "persistence": PERSISTENCE,
        },
        "scenarios": {},
    }

    print("scenario | detector | detection_rate | median_delay | false_positive_rate | mean_delay")
    for scen_idx, scen_name in enumerate(SCENARIOS):
        noise_signals = generate_noise_bank(scen_name, CAL_RUNS, GLOBAL_SEED + 100 * scen_idx)
        models = build_models_for_scenario(noise_signals)
        signals, onsets, diagnostics, feature_cache = generate_event_runs(scen_name, MC_RUNS, GLOBAL_SEED + 10_000 + 100 * scen_idx)

        raw_runs: Dict[str, List[Dict[str, object]]] = {name: [] for name in models}
        for run_idx, (signal, onset) in enumerate(zip(signals, onsets)):
            cached = feature_cache[run_idx]
            for name, model in models.items():
                raw_runs[name].append(
                    evaluate_detector_run(signal, onset, model, cached if model.kind in {"dmreda", "hotelling_t2"} else None)
                )

        summary = {name: summarize_detector_runs(runs, signals, onsets) for name, runs in raw_runs.items()}
        for det_name, stats in summary.items():
            print(
                f"{scen_name:28s} | {det_name:15s} | {stats['detection_rate']:.3f} | "
                f"{str(stats['median_delay']):>12} | {stats['false_positive_rate']:.3f} | {str(stats['mean_delay'])}"
            )

        plot_path = plot_scenario(scen_name, summary, raw_runs, signals, onsets, feature_cache)
        results["scenarios"][scen_name] = {
            "summary": summary,
            "calibration": {
                name: {"arl": model.arl, "threshold": model.threshold}
                for name, model in models.items()
            },
            "diagnostics": {
                "rms_gap_rel_median": float(np.median([d["rms_gap_rel"] for d in diagnostics])),
                "rms_gap_rel_max": float(np.max([d["rms_gap_rel"] for d in diagnostics])),
                "var_gap_rel_median": float(np.median([d["var_gap_rel"] for d in diagnostics])),
                "mean_gap_median": float(np.median([d["mean_gap"] for d in diagnostics])),
            },
            "best_detector": choose_best_detector(summary),
            "plot": plot_path,
        }

    ranking = {scen: payload["best_detector"] for scen, payload in results["scenarios"].items()}  # type: ignore[index]
    results["conclusion"] = {
        "best_by_scenario": ranking,
        "question": "Which detector class performs best under each disturbance topology?",
    }

    RESULT_JSON.write_text(json.dumps(results, indent=2, default=json_default), encoding="utf-8")
    print("\nBest detector by scenario")
    for scen_name, det_name in ranking.items():
        print(f"- {scen_name}: {det_name}")
    print(f"\nSaved: {RESULT_JSON}")


if __name__ == "__main__":
    main()
