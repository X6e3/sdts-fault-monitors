# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import numpy as np
import matplotlib.pyplot as plt
from deprecated.core import compute_dmreda
from deprecated.detectors import rms_detector
from gold_line.support.signal_gen import generate_signal

N = 5000
disturbance = "ramp"
amp = 1.0
noise_std = 0.005
seed = 0

signal, disturb_idx = generate_signal(
    N,
    disturbance,
    amp,
    noise_std,
    seed
)

# --- Scores ---
_, rms_score = rms_detector(signal)
dmr_score = compute_dmreda(signal)

# --- Split pre/post ---
rms_pre = rms_score[:disturb_idx]
rms_post = rms_score[disturb_idx:]

dmr_pre = dmr_score[:disturb_idx]
dmr_post = dmr_score[disturb_idx:]

# --- Cohen's d separation ---
def cohens_d(a, b):
    return (np.mean(b) - np.mean(a)) / np.sqrt(
        (np.var(a) + np.var(b)) / 2
    )
G = np.gradient(dmr_score)

dmr_g_pre = G[:disturb_idx]
dmr_g_post = G[disturb_idx:]

print("DMR slope separation (Cohen d):",
      cohens_d(dmr_g_pre, dmr_g_post))
print("RMS separation (Cohen d):", cohens_d(rms_pre, rms_post))
print("DMR separation (Cohen d):", cohens_d(dmr_pre, dmr_post))

# --- Histogram ---
plt.figure(figsize=(12,5))

plt.subplot(1,2,1)
plt.title("RMS distribution")
plt.hist(rms_pre, bins=60, alpha=0.5, label="pre")
plt.hist(rms_post, bins=60, alpha=0.5, label="post")
plt.legend()

plt.subplot(1,2,2)
plt.title("DMR distribution")
plt.hist(dmr_pre, bins=60, alpha=0.5, label="pre")
plt.hist(dmr_post, bins=60, alpha=0.5, label="post")
plt.legend()

plt.tight_layout()
plt.show()
