# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import json
import math
import os
from collections import Counter, defaultdict
from dataclasses import asdict

import numpy as np
from sklearn.decomposition import PCA
from sklearn.feature_selection import mutual_info_regression
from sklearn.preprocessing import StandardScaler

from deprecated.detectors import rms_event_detector_causal
from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference, compute_warmup_samples
from gold_line.near_gold_todo.validation_sweep import (
    AMPLITUDE,
    NOISE_LEVELS,
    RAMP_LENGTHS,
    Condition,
    build_trials,
    calibrate_rms_threshold,
)


DIAG_SEED_COUNT = int(os.environ.get("DMREDA_DIAG_SEEDS", "20"))
DIAG_SEEDS = tuple(range(DIAG_SEED_COUNT))
ONSET_PRE = 64
ONSET_POST = 128
RESULT_JSON = "ramp_diagnostics.json"


def _safe_corr(x, y):
    if len(x) < 2:
        return math.nan
    if np.std(x) == 0 or np.std(y) == 0:
        return math.nan
    return float(np.corrcoef(x, y)[0, 1])


def _compute_normalized_channels(result):
    d_norm = np.zeros_like(result.d, dtype=float)
    g_norm = np.zeros_like(result.g, dtype=float)

    for state_id, profile in DEFAULT_PROFILES.items():
        mask = result.state == state_id
        d_norm[mask] = result.d[mask] / profile.th_d
        g_norm[mask] = result.g[mask] / profile.th_g

    fast_score = np.maximum(d_norm, g_norm)
    return d_norm, g_norm, fast_score


def _find_candidate_start(pending_mask, event_time):
    start = event_time
    while start > 0 and pending_mask[start - 1]:
        start -= 1
    return start


def run_diagnostics():
    warmup_samples = compute_warmup_samples(DEFAULT_PROFILES)

    correlation_acc = defaultdict(list)
    onset_feature_blocks = []
    onset_target_blocks = []
    onset_mi_inputs = defaultdict(list)

    false_alarm_source_counts = Counter()
    false_alarm_state_counts = Counter()
    false_alarm_noise_counts = Counter()
    false_alarm_ramp_len_counts = Counter()
    false_alarm_strength = defaultdict(list)

    rms_false_alarm_counts = Counter()

    for noise_std in NOISE_LEVELS:
        for ramp_len in RAMP_LENGTHS:
            condition = Condition(
                disturbance="ramp",
                noise_std=noise_std,
                amplitude=AMPLITUDE,
                ramp_len=ramp_len,
            )
            trials = build_trials(condition)
            trials = trials[: len(DIAG_SEEDS)]

            rms_threshold = calibrate_rms_threshold(
                trials,
                warmup_samples=warmup_samples,
            )

            for trial in trials:
                dmr = compute_dmreda_reference(
                    trial.signal,
                    profiles=DEFAULT_PROFILES,
                    mode="D_or_G",
                )
                d_norm, g_norm, fast_score = _compute_normalized_channels(dmr)

                rms = rms_event_detector_causal(
                    trial.signal,
                    threshold=rms_threshold,
                    window=max(profile.w2 for profile in DEFAULT_PROFILES.values()),
                    confirm_window=DEFAULT_PROFILES[0].confirm_base,
                    n_persist=DEFAULT_PROFILES[0].n_min,
                    refractory=DEFAULT_PROFILES[0].refractory,
                    warmup_samples=warmup_samples,
                )
                rms_norm = rms.score / rms_threshold

                valid_slice = slice(warmup_samples, len(trial.signal))
                correlation_acc["d_vs_rms"].append(
                    _safe_corr(d_norm[valid_slice], rms_norm[valid_slice])
                )
                correlation_acc["g_vs_rms"].append(
                    _safe_corr(g_norm[valid_slice], rms_norm[valid_slice])
                )
                correlation_acc["fast_vs_rms"].append(
                    _safe_corr(fast_score[valid_slice], rms_norm[valid_slice])
                )

                onset_start = max(warmup_samples, trial.meta.start - ONSET_PRE)
                onset_end = min(len(trial.signal), trial.meta.start + ONSET_POST)
                onset_slice = slice(onset_start, onset_end)

                features = np.column_stack(
                    [
                        rms_norm[onset_slice],
                        d_norm[onset_slice],
                        g_norm[onset_slice],
                    ]
                )
                onset_feature_blocks.append(features)
                onset_target_blocks.append(fast_score[onset_slice])
                onset_mi_inputs["rms"].append(rms_norm[onset_slice])
                onset_mi_inputs["d"].append(d_norm[onset_slice])
                onset_mi_inputs["g"].append(g_norm[onset_slice])
                onset_mi_inputs["fast"].append(fast_score[onset_slice])

                for event_time in dmr.event_times:
                    if not (warmup_samples <= event_time < trial.meta.start):
                        continue

                    start = _find_candidate_start(dmr.pending, event_time)
                    d_hit = d_norm[start] > 1.0
                    g_hit = g_norm[start] > 1.0

                    if d_hit and g_hit:
                        source = "D_and_G"
                    elif d_hit:
                        source = "D_only"
                    elif g_hit:
                        source = "G_only"
                    else:
                        source = "Neither"

                    false_alarm_source_counts[source] += 1
                    false_alarm_state_counts[int(dmr.state[start])] += 1
                    false_alarm_noise_counts[noise_std] += 1
                    false_alarm_ramp_len_counts[ramp_len] += 1
                    false_alarm_strength["d_norm_start"].append(float(d_norm[start]))
                    false_alarm_strength["g_norm_start"].append(float(g_norm[start]))
                    false_alarm_strength["rms_norm_start"].append(float(rms_norm[start]))
                    false_alarm_strength["fast_score_start"].append(float(fast_score[start]))

                for event_time in rms.event_times:
                    if warmup_samples <= event_time < trial.meta.start:
                        rms_false_alarm_counts["RMS_only"] += 1
                        rms_false_alarm_counts[f"noise_{noise_std:.1f}"] += 1
                        rms_false_alarm_counts[f"ramp_{ramp_len}"] += 1

    onset_features = np.vstack(onset_feature_blocks)
    scaler = StandardScaler()
    onset_features_std = scaler.fit_transform(onset_features)
    pca = PCA(n_components=2)
    pca.fit(onset_features_std)

    feature_names = ["RMS_norm", "D_norm", "G_norm"]
    feature_vectors = pca.components_[:2].T
    pca_alignment = {}
    for left, right in (("RMS_norm", "D_norm"), ("RMS_norm", "G_norm"), ("D_norm", "G_norm")):
        i = feature_names.index(left)
        j = feature_names.index(right)
        vi = feature_vectors[i]
        vj = feature_vectors[j]
        denom = np.linalg.norm(vi) * np.linalg.norm(vj)
        cosine = float(np.dot(vi, vj) / denom) if denom > 0 else math.nan
        pca_alignment[f"{left}_vs_{right}"] = cosine

    onset_target = np.concatenate(onset_target_blocks)
    mi_results = {
        "D_vs_RMS": float(
            mutual_info_regression(
                np.concatenate(onset_mi_inputs["d"]).reshape(-1, 1),
                np.concatenate(onset_mi_inputs["rms"]),
                random_state=0,
            )[0]
        ),
        "G_vs_RMS": float(
            mutual_info_regression(
                np.concatenate(onset_mi_inputs["g"]).reshape(-1, 1),
                np.concatenate(onset_mi_inputs["rms"]),
                random_state=0,
            )[0]
        ),
        "Fast_vs_RMS": float(
            mutual_info_regression(
                np.concatenate(onset_mi_inputs["fast"]).reshape(-1, 1),
                np.concatenate(onset_mi_inputs["rms"]),
                random_state=0,
            )[0]
        ),
        "Fast_vs_DMREDA_target": float(
            mutual_info_regression(
                np.concatenate(onset_mi_inputs["rms"]).reshape(-1, 1),
                onset_target,
                random_state=0,
            )[0]
        ),
    }

    diagnostics = {
        "seed_count": DIAG_SEED_COUNT,
        "warmup_samples": warmup_samples,
        "onset_window": {"pre": ONSET_PRE, "post": ONSET_POST},
        "time_series_correlation": {
            key: {
                "mean": float(np.nanmean(values)),
                "std": float(np.nanstd(values)),
            }
            for key, values in correlation_acc.items()
        },
        "mutual_information_onset": mi_results,
        "pca": {
            "explained_variance_ratio": [float(v) for v in pca.explained_variance_ratio_],
            "components": {
                feature: [float(v) for v in pca.components_[:, idx]]
                for idx, feature in enumerate(feature_names)
            },
            "alignment_cosine": pca_alignment,
        },
        "false_alarm_breakdown": {
            "dmreda_source_counts": dict(false_alarm_source_counts),
            "dmreda_state_counts": dict(false_alarm_state_counts),
            "dmreda_noise_counts": {str(k): int(v) for k, v in false_alarm_noise_counts.items()},
            "dmreda_ramp_len_counts": {str(k): int(v) for k, v in false_alarm_ramp_len_counts.items()},
            "dmreda_strength_mean": {
                key: float(np.mean(values)) if values else math.nan
                for key, values in false_alarm_strength.items()
            },
            "rms_false_alarm_counts": dict(rms_false_alarm_counts),
        },
    }

    with open(RESULT_JSON, "w", encoding="ascii") as handle:
        json.dump(diagnostics, handle, indent=2)

    return diagnostics


if __name__ == "__main__":
    result = run_diagnostics()
    print(json.dumps(result, indent=2))
