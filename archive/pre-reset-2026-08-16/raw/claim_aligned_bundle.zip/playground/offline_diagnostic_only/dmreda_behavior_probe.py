# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
"""
Behavior probe for DMREDA vs classical sequential detectors.

This script is analysis-only. It does not modify detector internals.
It reuses the Gold Line benchmark detectors, persistence gate, and ARL
calibration utilities to probe detector behavior under synthetic scenarios.
"""

from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark import (
    ARL_TOL,
    EPS,
    EWMA_ALPHA,
    FEATURE_WINDOW,
    GLR_WINDOW,
    GLOBAL_SEED,
    HP_ALPHA,
    PERSISTENCE,
    RMS_WINDOW,
    TARGET_ARL,
    EWMAMeanVarianceDetector,
    GLRMeanShiftDetector,
    PageHinkleyDetector,
    TwoSidedCUSUMDetector,
    VarianceCUSUMDetector,
    augmented_features,
    build_dmreda_model,
    build_rms_model,
    calibrate_threshold_noise,
    detector_drift_rate,
    gate_score_series,
    mahalanobis_series,
    perturb_phase_scramble_window_rms_preserved,
    perturb_runlength_structure,
    robust_location_scale,
    robust_variance,
    run_streaming_detector,
    sequential_statistic,
    tune_positive_drift_param,
)


RESULT_PATH = Path("/Users/x6e3/vscode/results/dmreda_behavior_probe_results.json")

STREAM_LEN = 16_000
ONSET = 5_500
CAL_RUNS = 24
HOLDOUT_RUNS = 24
SCENARIO_RUNS = 30
TARGET_STD = 0.05
BOOTSTRAP_RUNS = 1000
RAMP_SLOPES = [2e-4, 4e-4, 8e-4, 1.6e-3, 3.2e-3]

SEED_TAGS = {
    "phase_scramble": 11,
    "runlength_scramble": 12,
    "freq_redistribution": 13,
    "phase_drift": 21,
    "correlation_inversion": 22,
    "micro_ramps": 23,
    "gaussian": 31,
    "ar1": 32,
    "heavy_tail": 33,
    "burst": 34,
}


@dataclass
class DetectorModel:
    name: str
    kind: str
    threshold: float
    arl: float
    payload: Dict[str, object]


def json_default(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        val = value.item()
        if isinstance(val, float) and not math.isfinite(val):
            return None
        return val
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def normalize_std(signal: np.ndarray, target_std: float = TARGET_STD) -> np.ndarray:
    signal = signal.astype(np.float64, copy=True)
    signal -= float(np.mean(signal))
    std = float(np.std(signal) + EPS)
    signal *= target_std / std
    return signal


def gaussian_noise(rng: np.random.Generator, length: int, std: float = TARGET_STD) -> np.ndarray:
    return rng.normal(0.0, std, size=length).astype(np.float64)


def ar1_noise(rng: np.random.Generator, length: int, rho: float = 0.9, std: float = TARGET_STD) -> np.ndarray:
    eps_std = std * math.sqrt(max(1.0 - rho * rho, EPS))
    out = np.empty(length, dtype=np.float64)
    out[0] = rng.normal(0.0, std)
    for idx in range(1, length):
        out[idx] = rho * out[idx - 1] + rng.normal(0.0, eps_std)
    return out


def heavy_tail_noise(rng: np.random.Generator, length: int, std: float = TARGET_STD, df: float = 3.0) -> np.ndarray:
    samples = rng.standard_t(df, size=length).astype(np.float64)
    samples = normalize_std(samples, std)
    return samples


def burst_noise(rng: np.random.Generator, length: int, std: float = TARGET_STD) -> np.ndarray:
    base = rng.normal(0.0, std, size=length).astype(np.float64)
    mask = rng.uniform(size=length) < 0.002
    impulses = rng.normal(0.0, 6.0 * std, size=length).astype(np.float64)
    base[mask] += impulses[mask]
    return base


NOISE_FACTORIES: Dict[str, Callable[[np.random.Generator, int], np.ndarray]] = {
    "gaussian": gaussian_noise,
    "ar1": ar1_noise,
    "heavy_tail": heavy_tail_noise,
    "burst": burst_noise,
}


def generate_noise_bank(noise_name: str, runs: int, seed_offset: int) -> List[np.ndarray]:
    rng = np.random.default_rng(seed_offset)
    factory = NOISE_FACTORIES[noise_name]
    signals = []
    for _ in range(runs):
        signals.append(factory(rng, STREAM_LEN))
    return signals


def first_alarm(trigger: np.ndarray) -> Optional[int]:
    idx = np.flatnonzero(trigger)
    if idx.size == 0:
        return None
    return int(idx[0])


def detect_after_onset(indices: np.ndarray, scores: np.ndarray, threshold: float, sig_len: int, onset: int) -> Tuple[Optional[int], Optional[int]]:
    trigger = gate_score_series(scores, threshold, PERSISTENCE, sig_len, indices)
    any_alarm = first_alarm(trigger)
    after = np.flatnonzero(trigger[onset:])
    after_alarm = None if after.size == 0 else int(onset + after[0])
    return any_alarm, after_alarm


def hotelling_t2_payload(noise_signals: List[np.ndarray]) -> Dict[str, object]:
    idx_runs: List[np.ndarray] = []
    feat_runs: List[np.ndarray] = []
    lengths: List[int] = []
    for sig in noise_signals:
        idx, feats = augmented_features(sig, FEATURE_WINDOW)
        idx_runs.append(idx)
        feat_runs.append(feats)
        lengths.append(sig.size)

    all_feats = np.vstack(feat_runs)
    mean = np.mean(all_feats, axis=0)
    std = np.std(all_feats, axis=0)
    std_safe = np.where(std < 1e-6, 1.0, std)
    feats_std = [(f - mean) / std_safe for f in feat_runs]
    centroid = np.mean(np.vstack(feats_std), axis=0)
    centered = np.vstack([f - centroid for f in feats_std])
    cov = np.cov(centered, rowvar=False) + 1e-3 * np.eye(centered.shape[1], dtype=np.float64)
    inv_cov = np.linalg.pinv(cov)
    t2_runs = [mahalanobis_series(f, centroid, inv_cov) for f in feats_std]
    threshold, arl = calibrate_threshold_noise(t2_runs, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    return {
        "mean": mean,
        "std": std_safe,
        "centroid": centroid,
        "inv_cov": inv_cov,
        "threshold": float(threshold),
        "arl": float(arl),
    }


def scalar_model_from_noise(
    name: str,
    noise_signals: List[np.ndarray],
) -> DetectorModel:
    all_noise = np.concatenate(noise_signals)
    mu0, sigma0 = robust_location_scale(all_noise)
    var0 = robust_variance(all_noise, mu0)

    if name == "page_hinkley":
        params = tune_positive_drift_param(
            {"mu0": mu0, "delta": 0.25 * sigma0},
            "delta",
            0.1 * sigma0,
            lambda p: PageHinkleyDetector(p["mu0"], p["delta"]),
            noise_signals,
        )
        factory = lambda: PageHinkleyDetector(params["mu0"], params["delta"])
    elif name == "cusum_mean":
        params = tune_positive_drift_param(
            {"mu0": mu0, "k": 0.5 * sigma0},
            "k",
            0.1 * sigma0,
            lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
            noise_signals,
        )
        factory = lambda: TwoSidedCUSUMDetector(params["mu0"], params["k"])
    elif name == "cusum_variance":
        ewma_mean = mu0
        hp_energy = []
        for sample in all_noise:
            ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
            residual = sample - ewma_mean
            hp_energy.append(residual * residual)
        hp_energy_arr = np.asarray(hp_energy, dtype=np.float64)
        params = tune_positive_drift_param(
            {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp_energy_arr, 60.0))},
            "k",
            float(np.median(np.abs(hp_energy_arr - np.median(hp_energy_arr))) + EPS),
            lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
            noise_signals,
        )
        factory = lambda: VarianceCUSUMDetector(params["mu0"], params["alpha_hp"], params["k"])
    elif name == "ewma":
        ewma_mean = mu0
        ewma_var = var0
        ewma_var_series = []
        for sample in all_noise:
            ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
            residual = sample - ewma_mean
            ewma_var = (1.0 - EWMA_ALPHA) * ewma_var + EWMA_ALPHA * (residual * residual)
            ewma_var_series.append(ewma_var)
        var_scale = 1.4826 * np.median(np.abs(np.asarray(ewma_var_series) - np.median(ewma_var_series))) + EPS
        params = {"mu0": mu0, "sigma0": sigma0, "var0": var0, "alpha": EWMA_ALPHA, "var_scale": var_scale}
        factory = lambda: EWMAMeanVarianceDetector(
            params["mu0"], params["sigma0"], params["var0"], params["alpha"], params["var_scale"]
        )
    elif name == "glr":
        params = {"mu0": mu0, "sigma0": sigma0, "window": float(GLR_WINDOW)}
        factory = lambda: GLRMeanShiftDetector(params["mu0"], params["sigma0"], int(params["window"]))
    else:
        raise ValueError(name)

    score_runs = [run_streaming_detector(factory(), sig) for sig in noise_signals]
    drift = float(np.mean([detector_drift_rate(score) for score in score_runs]))
    idx_runs = [np.arange(sig.size, dtype=np.int64) for sig in noise_signals]
    lengths = [sig.size for sig in noise_signals]
    threshold, arl = calibrate_threshold_noise(score_runs, idx_runs, TARGET_ARL, PERSISTENCE, lengths)
    if abs(arl - TARGET_ARL) / TARGET_ARL > ARL_TOL:
        raise RuntimeError(f"{name} ARL calibration failed: {arl}")

    return DetectorModel(
        name=name,
        kind="scalar",
        threshold=float(threshold),
        arl=float(arl),
        payload={"params": params, "drift": drift, "factory_name": name},
    )


def build_models(noise_signals: List[np.ndarray]) -> Dict[str, DetectorModel]:
    dm = build_dmreda_model(noise_signals, TARGET_ARL)
    rms = build_rms_model(noise_signals, TARGET_ARL)
    hot = hotelling_t2_payload(noise_signals)
    models = {
        "dmreda": DetectorModel("dmreda", "dmreda", float(dm["threshold"]), float(dm["arl"]), dm),
        "rms": DetectorModel("rms", "rms", float(rms["threshold"]), float(rms["arl"]), rms),
        "page_hinkley": scalar_model_from_noise("page_hinkley", noise_signals),
        "cusum_mean": scalar_model_from_noise("cusum_mean", noise_signals),
        "cusum_variance": scalar_model_from_noise("cusum_variance", noise_signals),
        "ewma": scalar_model_from_noise("ewma", noise_signals),
        "glr": scalar_model_from_noise("glr", noise_signals),
        "hotelling_t2": DetectorModel("hotelling_t2", "hotelling_t2", float(hot["threshold"]), float(hot["arl"]), hot),
    }
    return models


def score_entry(signal: np.ndarray, onset: int, model: DetectorModel) -> Tuple[np.ndarray, np.ndarray]:
    if model.kind == "dmreda":
        idx, feats = augmented_features(signal, FEATURE_WINDOW)
        mean = model.payload["mean"]  # type: ignore[index]
        std = model.payload["std"]  # type: ignore[index]
        centroid = model.payload["centroid"]  # type: ignore[index]
        inv_cov = model.payload["inv_cov"]  # type: ignore[index]
        bias = float(model.payload["bias"])  # type: ignore[index]
        feats_std = (feats - mean) / std
        dist = mahalanobis_series(feats_std, centroid, inv_cov)
        seq = sequential_statistic(dist, bias)
        return idx, seq
    if model.kind == "hotelling_t2":
        idx, feats = augmented_features(signal, FEATURE_WINDOW)
        mean = model.payload["mean"]  # type: ignore[index]
        std = model.payload["std"]  # type: ignore[index]
        centroid = model.payload["centroid"]  # type: ignore[index]
        inv_cov = model.payload["inv_cov"]  # type: ignore[index]
        feats_std = (feats - mean) / std
        t2 = mahalanobis_series(feats_std, centroid, inv_cov)
        return idx, t2
    if model.kind == "rms":
        from gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark import trailing_rms

        rms = trailing_rms(signal, RMS_WINDOW)
        seq = sequential_statistic(np.square(rms, dtype=np.float64), float(model.payload["bias"]))  # type: ignore[index]
        idx = np.arange(signal.size, dtype=np.int64)
        return idx, seq

    params = model.payload["params"]  # type: ignore[index]
    if model.name == "page_hinkley":
        detector = PageHinkleyDetector(params["mu0"], params["delta"])
    elif model.name == "cusum_mean":
        detector = TwoSidedCUSUMDetector(params["mu0"], params["k"])
    elif model.name == "cusum_variance":
        detector = VarianceCUSUMDetector(params["mu0"], params["alpha_hp"], params["k"])
    elif model.name == "ewma":
        detector = EWMAMeanVarianceDetector(
            params["mu0"], params["sigma0"], params["var0"], params["alpha"], params["var_scale"]
        )
    elif model.name == "glr":
        detector = GLRMeanShiftDetector(params["mu0"], params["sigma0"], int(params["window"]))
    else:
        raise ValueError(model.name)
    score = run_streaming_detector(detector, signal)
    idx = np.arange(signal.size, dtype=np.int64)
    return idx, score


def evaluate_signal(signal: np.ndarray, onset: int, model: DetectorModel) -> Dict[str, object]:
    idx, score = score_entry(signal, onset, model)
    trigger = gate_score_series(score, model.threshold, PERSISTENCE, signal.size, idx)
    any_alarm = first_alarm(trigger)
    post = np.flatnonzero(trigger[onset:])
    fp = any_alarm is not None and any_alarm < onset
    detect = None if post.size == 0 or fp else int(onset + post[0])
    miss = detect is None
    delay = None if miss else float(detect - onset)
    return {
        "delay": delay,
        "miss": miss,
        "fp": fp,
        "detect": detect,
        "any_alarm": any_alarm,
    }


def structural_phase_scramble(rng: np.random.Generator, base_signal: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = base_signal.copy()
    pre, post, max_err, mean_err, feat_delta = perturb_phase_scramble_window_rms_preserved(rng, signal, ONSET)
    return signal, {
        "global_rms_pre": float(pre),
        "global_rms_post": float(post),
        "window_rms_max_rel_err": float(max_err),
        "window_rms_mean_rel_err": float(mean_err),
        "feature_delta_l1_mean": float(np.mean(feat_delta)),
    }


def structural_runlength_scramble(rng: np.random.Generator, base_signal: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = base_signal.copy()
    diag, _ = perturb_runlength_structure(rng, signal, ONSET)
    return signal, {k: float(v) if isinstance(v, (int, float)) else float(np.mean(v)) for k, v in diag.items() if k != "feature_delta"}


def structural_freq_redistribution(rng: np.random.Generator, base_signal: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = base_signal.copy()
    seg = signal[ONSET:].copy()
    spectrum = np.fft.rfft(seg)
    mag = np.abs(spectrum)
    phase = np.angle(spectrum)
    bins = np.arange(spectrum.size)
    low = bins[: max(4, spectrum.size // 16)]
    mid = bins[max(4, spectrum.size // 16) : max(8, spectrum.size // 6)]
    if low.size and mid.size:
        transfer = 0.15 * np.sum(mag[mid])
        mag[mid] *= 0.85
        mag[low] += transfer / low.size
    warped = np.fft.irfft(mag * np.exp(1j * phase), n=seg.size)
    warped = normalize_std(warped, float(np.std(seg) + EPS))
    warped += float(np.mean(seg))
    signal[ONSET:] = warped
    pre_rms = math.sqrt(float(np.mean(base_signal[ONSET - 1024 : ONSET] ** 2)) + EPS)
    post_rms = math.sqrt(float(np.mean(signal[ONSET : ONSET + 1024] ** 2)) + EPS)
    return signal, {"rms_gap_rel": abs(post_rms - pre_rms) / pre_rms}


def amplitude_phase_drift(rng: np.random.Generator, base_signal: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = base_signal.copy()
    n = signal.size - ONSET
    t = np.arange(n, dtype=np.float64)
    amp = 0.12
    freq = 0.015
    phase_walk = np.cumsum(rng.normal(0.0, 0.002, size=n))
    tone = amp * np.sin(2.0 * math.pi * freq * t + phase_walk)
    signal[ONSET:] += tone
    signal = normalize_std(signal, TARGET_STD)
    return signal, {"tone_amp": amp}


def amplitude_correlation_inversion(rng: np.random.Generator, base_signal: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = base_signal.copy()
    post = ar1_noise(rng, signal.size - ONSET, rho=-0.85, std=TARGET_STD)
    post += 0.01 * rng.normal(size=post.size)
    post = normalize_std(post, float(np.std(signal[:ONSET]) + EPS))
    signal[ONSET:] = post
    return signal, {"rho_post": -0.85}


def amplitude_micro_ramps(rng: np.random.Generator, base_signal: np.ndarray) -> Tuple[np.ndarray, Dict[str, float]]:
    signal = base_signal.copy()
    block = 64
    amp = 0.08
    for start in range(ONSET, signal.size, block):
        end = min(signal.size, start + block)
        ramp = np.linspace(-amp, amp, end - start, dtype=np.float64)
        ramp -= float(np.mean(ramp))
        signal[start:end] += ramp
    signal = normalize_std(signal, TARGET_STD)
    return signal, {"block": block, "amp": amp}


def ramp_signal(rng: np.random.Generator, slope: float, noise_name: str = "ar1") -> np.ndarray:
    signal = NOISE_FACTORIES[noise_name](rng, STREAM_LEN)
    t = np.arange(STREAM_LEN - ONSET, dtype=np.float64)
    signal[ONSET:] += slope * t
    return signal


def empirical_arl(models: Dict[str, DetectorModel], noise_signals: List[np.ndarray]) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for name, model in models.items():
        alarms = []
        for sig in noise_signals:
            idx, score = score_entry(sig, 0, model)
            trigger = gate_score_series(score, model.threshold, PERSISTENCE, sig.size, idx)
            alarm = first_alarm(trigger)
            alarms.append(sig.size if alarm is None else alarm)
        out[name] = float(np.mean(alarms))
    return out


def summarize_results(records: Dict[str, List[Dict[str, object]]], signals: List[np.ndarray]) -> Dict[str, Dict[str, object]]:
    summary: Dict[str, Dict[str, object]] = {}
    for name, rows in records.items():
        delays = np.asarray([math.nan if r["delay"] is None else float(r["delay"]) for r in rows], dtype=np.float64)
        misses = np.asarray([bool(r["miss"]) for r in rows], dtype=bool)
        fps = np.asarray([bool(r["fp"]) for r in rows], dtype=bool)
        unconditional = delays.copy()
        for idx, sig in enumerate(signals):
            if fps[idx]:
                unconditional[idx] = 0.0
            elif misses[idx]:
                unconditional[idx] = float(sig.size - ONSET)
        valid = delays[np.isfinite(delays)]
        success = (~misses) & (~fps)
        summary[name] = {
            "median_delay": float(np.nanmedian(valid)) if valid.size else None,
            "delay_variance": float(np.nanvar(valid)) if valid.size else None,
            "delay_p10": float(np.nanpercentile(valid, 10)) if valid.size else None,
            "delay_p90": float(np.nanpercentile(valid, 90)) if valid.size else None,
            "detection_rate": float(np.mean(success)),
            "miss_rate": float(np.mean(misses)),
            "fp_rate": float(np.mean(fps)),
            "expected_delay": float(np.mean(unconditional)),
        }
    return summary


def bootstrap_ci_from_deltas(deltas: np.ndarray, seed: int) -> Tuple[float, float]:
    if deltas.size == 0:
        return math.nan, math.nan
    rng = np.random.default_rng(seed)
    medians = np.empty(BOOTSTRAP_RUNS, dtype=np.float64)
    for idx in range(BOOTSTRAP_RUNS):
        sample_idx = rng.integers(0, deltas.size, size=deltas.size)
        medians[idx] = float(np.median(deltas[sample_idx]))
    lo, hi = np.percentile(medians, [2.5, 97.5])
    return float(lo), float(hi)


def question_structural_distortion(models: Dict[str, DetectorModel]) -> Dict[str, object]:
    scenarios = {
        "phase_scramble": structural_phase_scramble,
        "runlength_scramble": structural_runlength_scramble,
        "freq_redistribution": structural_freq_redistribution,
    }
    out: Dict[str, object] = {}
    for scen_name, generator in scenarios.items():
        rng = np.random.default_rng(GLOBAL_SEED + 1000 + SEED_TAGS[scen_name])
        signals = []
        diagnostics = []
        for _ in range(SCENARIO_RUNS):
            base = ar1_noise(rng, STREAM_LEN)
            sig, diag = generator(rng, base)
            signals.append(sig)
            diagnostics.append(diag)
        records = {name: [evaluate_signal(sig, ONSET, model) for sig in signals] for name, model in models.items()}
        out[scen_name] = {
            "diagnostics": diagnostics,
            "summary": summarize_results(records, signals),
        }
    return out


def question_amplitude_blindness(models: Dict[str, DetectorModel]) -> Dict[str, object]:
    scenarios = {
        "phase_drift": amplitude_phase_drift,
        "correlation_inversion": amplitude_correlation_inversion,
        "micro_ramps": amplitude_micro_ramps,
    }
    out: Dict[str, object] = {}
    for scen_name, generator in scenarios.items():
        rng = np.random.default_rng(GLOBAL_SEED + 2000 + SEED_TAGS[scen_name])
        signals = []
        diagnostics = []
        for _ in range(SCENARIO_RUNS):
            base = ar1_noise(rng, STREAM_LEN)
            sig, diag = generator(rng, base)
            signals.append(sig)
            diagnostics.append(diag)
        records = {name: [evaluate_signal(sig, ONSET, model) for sig in signals] for name, model in models.items()}
        failures = {
            name: [idx for idx, row in enumerate(rows) if row["miss"]]
            for name, rows in records.items()
        }
        out[scen_name] = {
            "diagnostics": diagnostics,
            "summary": summarize_results(records, signals),
            "failure_indices": failures,
        }
    return out


def question_noise_robustness(models_gaussian: Dict[str, DetectorModel]) -> Dict[str, object]:
    arl_table = {}
    sensitivity = {}
    for noise_name in ("gaussian", "ar1", "heavy_tail", "burst"):
        holdout = generate_noise_bank(noise_name, HOLDOUT_RUNS, GLOBAL_SEED + 3000 + SEED_TAGS[noise_name])
        arl_table[noise_name] = empirical_arl(models_gaussian, holdout)

        rng = np.random.default_rng(GLOBAL_SEED + 4000 + SEED_TAGS[noise_name])
        signals = []
        for _ in range(SCENARIO_RUNS):
            base = NOISE_FACTORIES[noise_name](rng, STREAM_LEN)
            sig, _ = structural_phase_scramble(rng, base)
            signals.append(sig)
        records = {name: [evaluate_signal(sig, ONSET, model) for sig in signals] for name, model in models_gaussian.items()}
        sensitivity[noise_name] = summarize_results(records, signals)
    return {"empirical_arl": arl_table, "sensitivity": sensitivity}


def question_ramp_latency(models: Dict[str, DetectorModel]) -> Dict[str, object]:
    out: Dict[str, object] = {}
    for slope in RAMP_SLOPES:
        rng = np.random.default_rng(GLOBAL_SEED + int(slope * 1e7))
        signals = [ramp_signal(rng, slope) for _ in range(SCENARIO_RUNS)]
        records = {name: [evaluate_signal(sig, ONSET, model) for sig in signals] for name, model in models.items()}
        out[f"{slope:.6f}"] = summarize_results(records, signals)

    scaling = {}
    for det_name in ("dmreda", "cusum_mean", "cusum_variance", "ewma"):
        xs = []
        ys = []
        for slope in RAMP_SLOPES:
            key = f"{slope:.6f}"
            expected_delay = out[key][det_name]["expected_delay"]
            if expected_delay is None or expected_delay <= 0:
                continue
            xs.append(math.log(slope))
            ys.append(math.log(expected_delay))
        if len(xs) >= 2:
            coeff = np.polyfit(xs, ys, 1)
            scaling[det_name] = {"loglog_slope": float(coeff[0]), "loglog_intercept": float(coeff[1])}
    return {"by_slope": out, "scaling": scaling}


def question_compute_cost() -> Dict[str, object]:
    return {
        "page_hinkley": {
            "ops_per_sample": "~6 arithmetic + 1 division",
            "memory": "~4 scalars",
            "mcu_feasible": True,
        },
        "cusum_mean": {
            "ops_per_sample": "~6 arithmetic",
            "memory": "~3 scalars",
            "mcu_feasible": True,
        },
        "cusum_variance": {
            "ops_per_sample": "~10 arithmetic",
            "memory": "~4 scalars",
            "mcu_feasible": True,
        },
        "ewma": {
            "ops_per_sample": "~12 arithmetic + abs",
            "memory": "~5 scalars",
            "mcu_feasible": True,
        },
        "glr": {
            "ops_per_sample": f"O({GLR_WINDOW}) scan per sample",
            "memory": f"buffer of {GLR_WINDOW} samples",
            "mcu_feasible": "borderline",
        },
        "rms": {
            "ops_per_sample": f"O(1) with rolling sum; current Python path is vectorized",
            "memory": f"ring buffer of {RMS_WINDOW}",
            "mcu_feasible": True,
        },
        "hotelling_t2": {
            "ops_per_sample": f"feature extraction over {FEATURE_WINDOW} + 10x10 quadratic form",
            "memory": "feature window + covariance constants",
            "mcu_feasible": "only with frozen offline covariance and no FFT",
        },
        "dmreda": {
            "ops_per_sample": f"feature extraction over {FEATURE_WINDOW} incl. FFT + Mahalanobis + sequential accumulation",
            "memory": "feature window + whitening constants + sequential state",
            "mcu_feasible": "benchmark path no; core reference yes",
        },
    }


def print_latency_table(title: str, section: Dict[str, object]) -> None:
    print(f"\n{title}")
    for scen_name, payload in section.items():
        print(f"\nScenario: {scen_name}")
        print("detector | median_delay | delay_variance | detection_rate | miss_rate | fp_rate")
        summary = payload["summary"]
        for det_name, metrics in summary.items():
            print(
                f"{det_name:14s} | "
                f"{metrics['median_delay']!s:>12} | "
                f"{metrics['delay_variance']!s:>14} | "
                f"{metrics['detection_rate']:.3f} | "
                f"{metrics['miss_rate']:.3f} | "
                f"{metrics['fp_rate']:.3f}"
            )


def print_arl_table(section: Dict[str, object]) -> None:
    print("\nARL calibration stability")
    models = list(next(iter(section["empirical_arl"].values())).keys())
    print("noise_model | " + " | ".join(models))
    for noise_name, row in section["empirical_arl"].items():
        vals = " | ".join(f"{row[m]:.1f}" for m in models)
        print(f"{noise_name:10s} | {vals}")


def main() -> None:
    gaussian_models = build_models(generate_noise_bank("gaussian", CAL_RUNS, GLOBAL_SEED + 10))
    ar1_models = build_models(generate_noise_bank("ar1", CAL_RUNS, GLOBAL_SEED + 20))

    q1 = question_structural_distortion(ar1_models)
    q2 = question_amplitude_blindness(ar1_models)
    q3 = question_noise_robustness(gaussian_models)
    q4 = question_ramp_latency(ar1_models)
    q5 = question_compute_cost()

    payload = {
        "meta": {
            "seed": GLOBAL_SEED,
            "target_arl": TARGET_ARL,
            "persistence": PERSISTENCE,
            "stream_len": STREAM_LEN,
            "onset": ONSET,
            "calibration_noise": {
                "q1_q2_q4": "ar1",
                "q3": "gaussian",
            },
        },
        "question_1_rms_preserving_structural_distortion": q1,
        "question_2_amplitude_blindness": q2,
        "question_3_noise_robustness": q3,
        "question_4_ramp_latency": q4,
        "question_5_computational_cost": q5,
    }
    RESULT_PATH.write_text(json.dumps(payload, indent=2, default=json_default), encoding="utf-8")

    print_latency_table("QUESTION 1 — RMS-preserving structural distortion", q1)
    print_latency_table("QUESTION 2 — Amplitude blindness scenarios", q2)
    print_arl_table(q3)
    print("\nQUESTION 4 — Ramp latency scaling")
    for slope, section in q4["by_slope"].items():
        print(f"slope={slope} dmreda_expected={section['dmreda']['expected_delay']:.1f} cusum_mean_expected={section['cusum_mean']['expected_delay']:.1f}")
    print("\nQUESTION 5 — Computational cost")
    for det_name, row in q5.items():
        print(f"{det_name}: ops={row['ops_per_sample']}, memory={row['memory']}, mcu={row['mcu_feasible']}")
    print(f"\nSaved: {RESULT_PATH}")


if __name__ == "__main__":
    main()
