# OFFLINE_ANALYSIS_ONLY (NOT FOR CLAIMS; may use sklearn/ROC/etc.)
import json
import math
import os

import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve

from curvature_diagnostics import classify_trigger
from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference, compute_warmup_samples
from gold_line.near_gold_todo.validation_sweep import AMPLITUDE, NOISE_LEVELS, RAMP_LENGTHS, Condition, build_trials


SIGNED_AREA_SEED_COUNT = int(os.environ.get("DMREDA_SIGNED_AREA_SEEDS", "20"))
WZ = 16
HISTORY = 8
EPS = 1e-12
RESULT_JSON = "signed_area_diagnostics.json"


def compute_area_norm_series(signal, window=WZ):
    area_norm = np.full(len(signal), np.nan, dtype=float)

    for t in range(window - 1, len(signal)):
        segment = signal[t - window + 1 : t + 1]
        area_raw = float(np.sum(segment))
        window_rms = float(np.sqrt(np.mean(segment ** 2)) + EPS)
        area_norm[t] = area_raw / (window * window_rms)

    return area_norm


def trailing_mean(values, time_index, history):
    start = max(0, time_index - history + 1)
    window = values[start : time_index + 1]
    if np.all(np.isnan(window)):
        return math.nan
    return float(np.nanmean(window))


def empirical_ks_distance(sample_a, sample_b):
    if len(sample_a) == 0 or len(sample_b) == 0:
        return math.nan

    values = np.sort(np.unique(np.concatenate([sample_a, sample_b])))
    cdf_a = np.searchsorted(np.sort(sample_a), values, side="right") / len(sample_a)
    cdf_b = np.searchsorted(np.sort(sample_b), values, side="right") / len(sample_b)
    return float(np.max(np.abs(cdf_a - cdf_b)))


def best_threshold(scores, labels):
    if len(scores) == 0 or len(np.unique(labels)) < 2:
        return {
            "threshold": math.nan,
            "tpr": math.nan,
            "fpr": math.nan,
            "youden_j": math.nan,
        }

    fpr, tpr, thresholds = roc_curve(labels, scores)
    youden = tpr - fpr
    idx = int(np.argmax(youden))
    return {
        "threshold": float(thresholds[idx]),
        "tpr": float(tpr[idx]),
        "fpr": float(fpr[idx]),
        "youden_j": float(youden[idx]),
    }


def run_signed_area_diagnostics():
    warmup_samples = compute_warmup_samples(DEFAULT_PROFILES)

    true_ramp_scores = []
    false_alarm_scores = []

    for noise_std in NOISE_LEVELS:
        for ramp_len in RAMP_LENGTHS:
            condition = Condition(
                disturbance="ramp",
                noise_std=noise_std,
                amplitude=AMPLITUDE,
                ramp_len=ramp_len,
            )
            trials = build_trials(condition)[:SIGNED_AREA_SEED_COUNT]

            for trial in trials:
                result = compute_dmreda_reference(
                    trial.signal,
                    profiles=DEFAULT_PROFILES,
                    mode="D_or_G",
                )
                area_norm = compute_area_norm_series(trial.signal, window=WZ)

                for event_time in result.event_times:
                    trigger_class = classify_trigger(
                        event_time,
                        trial.meta.start,
                        ramp_len,
                        warmup_samples,
                    )

                    g_mean = trailing_mean(result.g, event_time, HISTORY)
                    signed_area_mean = trailing_mean(area_norm, event_time, HISTORY)
                    if math.isnan(g_mean) or math.isnan(signed_area_mean):
                        continue

                    coupled_score_area = g_mean * abs(signed_area_mean)

                    if trigger_class == "true_ramp":
                        true_ramp_scores.append(coupled_score_area)
                    elif trigger_class == "false_alarm":
                        false_alarm_scores.append(coupled_score_area)

    labels = np.concatenate(
        [
            np.ones(len(true_ramp_scores), dtype=int),
            np.zeros(len(false_alarm_scores), dtype=int),
        ]
    )
    scores = np.concatenate([true_ramp_scores, false_alarm_scores])

    if len(scores) > 0 and len(np.unique(labels)) == 2:
        auc = float(roc_auc_score(labels, scores))
    else:
        auc = math.nan

    threshold = best_threshold(scores, labels)

    result = {
        "auc": auc,
        "ks_distance": empirical_ks_distance(
            np.asarray(true_ramp_scores, dtype=float),
            np.asarray(false_alarm_scores, dtype=float),
        ),
        "best_threshold": threshold["threshold"],
        "tpr": threshold["tpr"],
        "fpr": threshold["fpr"],
        "mean_false_alarm_score": float(np.mean(false_alarm_scores)) if false_alarm_scores else math.nan,
        "mean_true_ramp_score": float(np.mean(true_ramp_scores)) if true_ramp_scores else math.nan,
        "positive_count": int(len(true_ramp_scores)),
        "negative_count": int(len(false_alarm_scores)),
    }

    with open(RESULT_JSON, "w", encoding="ascii") as handle:
        json.dump(result, handle, indent=2)

    return result


if __name__ == "__main__":
    print(json.dumps(run_signed_area_diagnostics(), indent=2))
