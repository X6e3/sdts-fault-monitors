from __future__ import annotations

import math

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 100

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
AR_COEFF = 0.9
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
SLOPE_JITTER_STD = 0.08

PERSISTENCE_K = 3
M_COV = 8
Z_CLIP = 8.0
LOW_FREQ_RATIO = 0.1


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(
    slope: float,
    onset: int,
    duration: int = DRIFT_DURATION,
    ramp_samples: int = RAMP_IN_SAMPLES,
) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    active_len = max(0, min(duration, NUM_SAMPLES - onset))
    if active_len == 0:
        return template

    k = np.arange(active_len, dtype=DTYPE)
    ramp_len = max(1, min(ramp_samples, active_len))
    values = np.empty(active_len, dtype=DTYPE)

    ramp_mask = k < ramp_len
    values[ramp_mask] = 0.5 * slope * (k[ramp_mask] ** 2) / ramp_len
    values[~ramp_mask] = slope * (k[~ramp_mask] - 0.5 * ramp_len)

    template[onset:onset + active_len] = values
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(
                trailing_rms(build_drift_template(mid, REFERENCE_DRIFT_START), RMS_WINDOW)[
                    reference_drift_mask()
                ]
            )
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float) -> float:
    return float(target_std * math.sqrt(1.0 - AR_COEFF**2))


def generate_ar1_noise(
    rng: np.random.Generator,
    target_std: float,
    size: int = NUM_SAMPLES,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    signal = np.empty(size, dtype=DTYPE)
    signal[0] = rng.normal(0.0, target_std)

    for i in range(1, size):
        signal[i] = AR_COEFF * signal[i - 1] + epsilon[i]

    return signal


def generate_drift_signal(
    rng: np.random.Generator,
    base_slope: float,
) -> tuple[np.ndarray, int]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))
    slope_scale = max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    slope = float(base_slope * slope_scale)
    signal = generate_ar1_noise(rng, EVENT_NOISE_STD)
    signal += build_drift_template(slope, onset)
    return signal.astype(DTYPE, copy=False), onset


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def safe_zscore(values: np.ndarray, mean: float, std: float) -> np.ndarray:
    denom = std if std >= 1e-6 else 1.0
    return np.clip((values - mean) / denom, -Z_CLIP, Z_CLIP)


def persistent_bool(mask: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    out = np.zeros_like(mask, dtype=bool)
    count = 0
    for i, flag in enumerate(mask):
        if flag:
            count += 1
            if count >= required:
                out[i] = True
        else:
            count = 0
    return out


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def covariance_manifold_series(signal: np.ndarray, onset: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    indices, features = extract_augmented_features(signal)
    velocity = np.zeros_like(features)
    velocity[1:] = features[1:] - features[:-1]

    windows = np.lib.stride_tricks.sliding_window_view(velocity, M_COV, axis=0)
    local_velocity = np.transpose(windows, (0, 2, 1)).astype(DTYPE, copy=False)
    centered = local_velocity - np.mean(local_velocity, axis=1, keepdims=True)
    covariances = np.einsum("tmk,tml->tkl", centered, centered) / max(M_COV - 1, 1)

    eigenvalues = np.linalg.eigvalsh(covariances)
    trace = np.sum(eigenvalues, axis=1)
    lambda_max = eigenvalues[:, -1]
    anisotropy = lambda_max / (trace + EPS)

    full_anisotropy = np.full(indices.size, np.nan, dtype=DTYPE)
    full_trace = np.full(indices.size, np.nan, dtype=DTYPE)
    full_anisotropy[M_COV - 1 :] = anisotropy
    full_trace[M_COV - 1 :] = trace

    pre_mask = (indices < onset) & np.isfinite(full_anisotropy)
    mean_ratio = float(np.mean(full_anisotropy[pre_mask]))
    std_ratio = float(np.std(full_anisotropy[pre_mask]))
    mean_trace = float(np.mean(full_trace[pre_mask]))
    std_trace = float(np.std(full_trace[pre_mask]))

    z_ratio = np.full(indices.size, np.nan, dtype=DTYPE)
    z_trace = np.full(indices.size, np.nan, dtype=DTYPE)
    finite_ratio = np.isfinite(full_anisotropy)
    finite_trace = np.isfinite(full_trace)
    z_ratio[finite_ratio] = safe_zscore(full_anisotropy[finite_ratio], mean_ratio, std_ratio)
    z_trace[finite_trace] = safe_zscore(full_trace[finite_trace], mean_trace, std_trace)

    return indices, full_anisotropy, z_ratio, z_trace


def evaluate_run(signal: np.ndarray, onset: int) -> dict[str, float]:
    cme_indices, anisotropy, z_ratio, z_trace = covariance_manifold_series(signal, onset)
    drift_event = persistent_bool(np.nan_to_num(z_ratio, nan=-Z_CLIP) > 3.0)
    shock_event = np.nan_to_num(z_trace, nan=-Z_CLIP) > 4.0
    cme_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
    cme_trigger[cme_indices] = drift_event | shock_event

    rms = trailing_rms(signal, RMS_WINDOW)
    rms_threshold = float(np.mean(rms[:onset]) + 3.0 * np.std(rms[:onset]))
    rms_trigger = persistent_bool(rms > rms_threshold)

    t_cme = first_trigger_at_or_after(cme_trigger, onset)
    t_rms = first_trigger_at_or_after(rms_trigger, onset)

    valid_pre_mask = (cme_indices < onset) & np.isfinite(anisotropy)
    valid_post_mask = (
        (cme_indices >= onset)
        & (cme_indices < min(onset + DRIFT_DURATION, NUM_SAMPLES))
        & np.isfinite(anisotropy)
    )

    return {
        "t_cme": math.nan if t_cme is None else float(t_cme),
        "t_rms": math.nan if t_rms is None else float(t_rms),
        "delta_t": math.nan if (t_cme is None or t_rms is None) else float(t_rms - t_cme),
        "cme_fp_samples": float(np.sum(cme_trigger[:onset])),
        "rms_fp_samples": float(np.sum(rms_trigger[:onset])),
        "pre_samples": float(onset),
        "mean_anisotropy_noise": float(np.nanmean(anisotropy[valid_pre_mask])) if np.any(valid_pre_mask) else math.nan,
        "mean_anisotropy_drift": float(np.nanmean(anisotropy[valid_post_mask])) if np.any(valid_post_mask) else math.nan,
    }


def main() -> None:
    base_slope = calibrate_drift_slope()

    delta_t = np.full(N_RUNS, np.nan, dtype=DTYPE)
    mean_anisotropy_noise = np.full(N_RUNS, np.nan, dtype=DTYPE)
    mean_anisotropy_drift = np.full(N_RUNS, np.nan, dtype=DTYPE)

    total_cme_fp_samples = 0.0
    total_rms_fp_samples = 0.0
    total_pre_samples = 0.0

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        signal, onset = generate_drift_signal(rng, base_slope)
        result = evaluate_run(signal, onset)

        delta_t[run_index] = result["delta_t"]
        mean_anisotropy_noise[run_index] = result["mean_anisotropy_noise"]
        mean_anisotropy_drift[run_index] = result["mean_anisotropy_drift"]
        total_cme_fp_samples += result["cme_fp_samples"]
        total_rms_fp_samples += result["rms_fp_samples"]
        total_pre_samples += result["pre_samples"]

    finite_delta = delta_t[np.isfinite(delta_t)]
    mean_delta = float(np.mean(finite_delta)) if finite_delta.size else math.nan
    cme_earlier = 100.0 * float(np.mean(finite_delta > 0.0)) if finite_delta.size else 0.0
    cme_fp_rate = 100.0 * total_cme_fp_samples / max(total_pre_samples, 1.0)
    rms_fp_rate = 100.0 * total_rms_fp_samples / max(total_pre_samples, 1.0)

    print("DMREDA Covariance Manifold Engine")
    print("=================================\n")
    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES       : {NUM_SAMPLES}")
    print(f"FEATURE_WINDOW    : {FEATURE_WINDOW}")
    print(f"RMS_WINDOW        : {RMS_WINDOW}")
    print(f"N_RUNS            : {N_RUNS}")
    print(f"AR(1) rho         : {AR_COEFF:.2f}")
    print(f"Velocity window M : {M_COV}")
    print(f"Persistence       : {PERSISTENCE_K}")
    print(f"Reference slope   : {base_slope:.10f}\n")

    print("Results")
    print("-------")
    print(f"mean_delta_t (RMS - CME)     : {mean_delta:.3f}")
    print(f"percentage_cme_earlier       : {cme_earlier:.2f}%")
    print(f"false_positive_rate (CME)    : {cme_fp_rate:.4f}%")
    print(f"false_positive_rate (RMS)    : {rms_fp_rate:.4f}%")
    print(f"mean_anisotropy_noise        : {float(np.nanmean(mean_anisotropy_noise)):.6f}")
    print(f"mean_anisotropy_drift        : {float(np.nanmean(mean_anisotropy_drift)):.6f}")
    print(f"valid_delta_runs             : {finite_delta.size}/{N_RUNS}\n")

    if cme_earlier > 70.0 and cme_fp_rate <= rms_fp_rate:
        print("COVARIANCE MANIFOLD ENGINE VALIDATED")
    else:
        print("CME NEEDS REFINEMENT")


if __name__ == "__main__":
    main()
