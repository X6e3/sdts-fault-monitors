"""Nested playground dmreda artifacts."""
