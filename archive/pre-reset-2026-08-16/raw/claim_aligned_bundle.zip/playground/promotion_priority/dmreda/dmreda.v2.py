import numpy as np
import os
import sys

# Ensure local modules can be imported.
_HERE = os.path.dirname(os.path.abspath(__file__))
_PROMOTION = os.path.dirname(_HERE)
_PLAYGROUND = os.path.dirname(_PROMOTION)
_ROOT = os.path.dirname(_PLAYGROUND)
for _p in (_HERE, _PROMOTION, _PLAYGROUND, _ROOT):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import importlib.util

generate_signal = None
compute_dmreda = None
rms_detector = None

def _load_attr_from_file(label: str, file_path: str, attr: str):
    """Load `attr` from a specific python file path. Returns (callable_or_None, err_or_None)."""
    try:
        if not os.path.exists(file_path):
            return None, f"missing file: {file_path}"
        spec = importlib.util.spec_from_file_location(label, file_path)
        if spec is None or spec.loader is None:
            return None, f"no spec for: {file_path}"
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not hasattr(module, attr):
            return None, f"{os.path.basename(file_path)} loaded but has no `{attr}`"
        return getattr(module, attr), None
    except Exception as e:
        return None, f"exception while loading {os.path.basename(file_path)}: {repr(e)}"

# Prefer explicit repo-tier files (current repo layout)
generate_signal, _err_sig = _load_attr_from_file(
    "signal_gen",
    os.path.join(_ROOT, "gold_line", "support", "signal_gen.py"),
    "generate_signal",
)
compute_dmreda, _err_core = _load_attr_from_file(
    "core",
    os.path.join(_ROOT, "deprecated", "core.py"),
    "compute_dmreda",
)
rms_detector, _err_det = _load_attr_from_file(
    "detectors",
    os.path.join(_ROOT, "deprecated", "detectors.py"),
    "rms_detector",
)

if "--debug-imports" in sys.argv:
    print("[dmreda.v2] _HERE:", _HERE)
    print("[dmreda.v2] _ROOT:", _ROOT)
    print("[dmreda.v2] exists:", {
        "gold_line/support/signal_gen.py": os.path.exists(os.path.join(_ROOT, "gold_line", "support", "signal_gen.py")),
        "deprecated/core.py": os.path.exists(os.path.join(_ROOT, "deprecated", "core.py")),
        "deprecated/detectors.py": os.path.exists(os.path.join(_ROOT, "deprecated", "detectors.py")),
    })
    print("[dmreda.v2] sys.path[0:5]:", sys.path[:5])
    print("[dmreda.v2] load results:")
    print("  generate_signal:", "OK" if generate_signal else _err_sig)
    print("  compute_dmreda :", "OK" if compute_dmreda else _err_core)
    print("  rms_detector   :", "OK" if rms_detector else _err_det)

# --- Fallbacks (so the benchmark harness always runs) ---
if generate_signal is None:
    print("[dmreda.v2] WARN: Could not import generate_signal. Using fallback generate_signal().")
    def generate_signal(
        N,
        disturbance_type="burst",
        amplitude=0.8,
        noise_std=0.3,
        seed=0,
        disturb_idx=None,
        burst_len=80,
    ):
        rng = np.random.default_rng(seed)
        x = rng.normal(0.0, noise_std, N)
        if disturb_idx is None:
            disturb_idx = N // 2
        if disturbance_type == "step":
            x[disturb_idx:] += amplitude
        elif disturbance_type == "ramp":
            x[disturb_idx:] += np.linspace(0.0, amplitude, N - disturb_idx)
        elif disturbance_type == "drift":
            x[disturb_idx:] += np.linspace(0.0, amplitude, N - disturb_idx)
        else:  # burst
            end = min(N, disturb_idx + burst_len)
            x[disturb_idx:end] += amplitude
        return x, disturb_idx

if rms_detector is None:
    print("[dmreda.v2] WARN: Could not import rms_detector. Using fallback rms_detector().")
    def rms_detector(signal, window=100):
        w = np.ones(window, dtype=float) / float(window)
        rms = np.sqrt(np.convolve(signal**2, w, mode="same"))
        trig = np.zeros_like(signal, dtype=bool)
        return trig, rms

if compute_dmreda is None:
    print("[dmreda.v2] WARN: Could not import compute_dmreda. Using fallback compute_dmreda().")
    def compute_dmreda(signal, W1=11, W2=32, beta=0.02, e_floor=1e-2, d_clip=5.0):
        N = len(signal)
        mu = np.zeros_like(signal, dtype=float)
        half = W1 // 2
        for i in range(N):
            lo = max(0, i - half)
            hi = min(N, i + half + 1)
            mu[i] = np.median(signal[lo:hi])
        e = np.abs(signal - mu)
        E = np.convolve(e, np.ones(W2), mode="same")
        E_b = np.zeros_like(E)
        E_b[0] = E[0]
        for i in range(1, N):
            E_b[i] = beta * E[i] + (1.0 - beta) * E_b[i-1]
        E_b_safe = np.maximum(E_b, e_floor)
        D = (E - E_b_safe) / E_b_safe
        return np.clip(D, -d_clip, d_clip)


# -----------------------------
# Event-level postprocessing
# -----------------------------
def event_postprocess(score, th_on,
                      confirm_len=30,
                      th_confirm=None,
                      area_th=2.0,
                      n_min=10,
                      refractory=120):
    """
    score: array
    th_on: candidate threshold
    th_confirm: confirmation level (defaults to 0.6*th_on)
    confirm_len: samples
    area_th: area threshold over (score - th_confirm)
    n_min: min count of score>th_confirm in confirm window
    refractory: samples lockout after confirm

    Returns:
      event_times: list of confirmed event indices (t_confirm)
      trigger: binary array (1 at confirm time)
    """
    N = len(score)
    if th_confirm is None:
        th_confirm = 0.6 * th_on

    trigger = np.zeros(N, dtype=int)
    event_times = []
    t = 0

    while t < N:
        if score[t] > th_on:  # candidate
            t0 = t
            t1 = min(N, t0 + confirm_len)

            window = score[t0:t1]
            above = window > th_confirm
            area = np.sum(np.maximum(0.0, window - th_confirm))
            cnt = int(np.sum(above))

            if (area >= area_th) and (cnt >= n_min):
                t_confirm = t0
                trigger[t_confirm] = 1
                event_times.append(t_confirm)
                t = t_confirm + refractory
                continue
            else:
                t = t1
                continue
        t += 1

    return event_times, trigger


# -----------------------------
# Metrics
# -----------------------------
def eval_event_metrics(event_times, disturb_idx, det_window=200, pre_len=None):
    """
    event_times: list of event indices
    disturb_idx: disturbance start index
    det_window: must detect within this after disturb start
    pre_len: if given, pre segment is [0, pre_len); else [0, disturb_idx)
    """
    if pre_len is None:
        pre_len = disturb_idx

    # FA_event: any event in pre?
    fa_event = any(t < pre_len for t in event_times)

    # Detection: earliest event in [disturb_idx, disturb_idx + det_window)
    post_events = [t for t in event_times if disturb_idx <= t < disturb_idx + det_window]
    detected = len(post_events) > 0

    latency = (min(post_events) - disturb_idx) if detected else np.nan
    return detected, fa_event, latency


# -----------------------------
# Threshold calibration (event-level)
# -----------------------------
def calibrate_threshold_event(scores, disturb_idx,
                              fp_event_target=0.05,
                              n_grid=60,
                              postprocess_kwargs=None):
    """
    Choose th_on so that FA_event rate ~= fp_event_target on pre-only data.
    Here we do it per-trial using pre segment; but better is global cal over noise-only trials.
    For quick fairness, per-trial calibration is okay if all detectors do it.
    """
    if postprocess_kwargs is None:
        postprocess_kwargs = {}

    pre = scores[:disturb_idx]
    # build threshold grid from high quantiles of pre
    qs = np.linspace(0.80, 0.999, n_grid)
    ths = np.quantile(pre, qs)

    # find smallest threshold that achieves FA_event <= target on this pre segment
    best = ths[-1]
    for th in ths:
        ev, _ = event_postprocess(scores, th, **postprocess_kwargs)
        _, fa, _ = eval_event_metrics(ev, disturb_idx, det_window=1, pre_len=disturb_idx)
        # fa is boolean for this trial; we need probabilistic target
        # so: treat this as "strict": avoid any pre event
        if fa is False:
            best = th
            break

    return float(best)


# -----------------------------
# Detector wrappers
# -----------------------------
def score_rms(signal):
    _, rms_score = rms_detector(signal)  # you already have it
    return rms_score

def score_dmreda(signal):
    D = compute_dmreda(signal)           # you already have it
    return D

def score_cusum(signal, k=0.1, base_len=500):
    mean_est = np.mean(signal[:base_len])
    std_est = np.std(signal[:base_len]) + 1e-8
    s_pos, s_neg = 0.0, 0.0
    score = np.zeros_like(signal, dtype=float)
    for i in range(len(signal)):
        x = (signal[i] - mean_est) / std_est
        s_pos = max(0.0, s_pos + x - k)
        s_neg = min(0.0, s_neg + x + k)
        score[i] = max(abs(s_pos), abs(s_neg))
    return score


# -----------------------------
# Main benchmark
# -----------------------------
def run_benchmark(
    N=5000,
    disturbances=("burst", "ramp", "step", "drift"),
    noise_levels=(0.3, 0.5, 0.7),
    amplitudes=(0.3, 0.5, 0.8, 1.2),
    seeds=range(50),
    det_window=200,
    fp_event_target=0.05
):
    # DMREDA-like postprocess params (tune later)
    pp = dict(confirm_len=40, area_th=2.5, n_min=10, refractory=120)

    detectors = [
        ("RMS", score_rms, {}),
        ("DMREDA", score_dmreda, pp),
        ("CUSUM", lambda s: score_cusum(s, k=0.1), pp),
    ]

    print("=== EVENT-LEVEL BENCHMARK ===")
    print(f"det_window={det_window} samples | fp_event_target~{fp_event_target}\n")

    for disturbance in disturbances:
        print(f"\n===== {disturbance.upper()} =====")

        for noise_std in noise_levels:
            print(f"\nNoise STD = {noise_std}")

            for amp in amplitudes:
                print(f"\nAmplitude = {amp}")

                for name, score_fn, postproc_kwargs in detectors:
                    dets = []
                    fas = []
                    lats = []

                    for seed in seeds:
                        try:
                            # Newer signature (keyword args)
                            signal, disturb_idx = generate_signal(
                                N,
                                disturbance_type=disturbance,
                                amplitude=amp,
                                noise_std=noise_std,
                                seed=seed,
                            )
                        except TypeError:
                            # Older signature (positional args): (N, disturbance, amplitude, noise_std, seed)
                            signal, disturb_idx = generate_signal(N, disturbance, amp, noise_std, seed)

                        score = score_fn(signal)
                        # Safety: keep calibration stable even if a detector produces NaN/inf
                        score = np.nan_to_num(score, nan=0.0, posinf=0.0, neginf=0.0)

                        # event-level calibration on pre segment
                        th = calibrate_threshold_event(
                            score, disturb_idx,
                            fp_event_target=fp_event_target,
                            postprocess_kwargs=postproc_kwargs
                        )

                        event_times, _ = event_postprocess(score, th, **postproc_kwargs)
                        detected, fa, lat = eval_event_metrics(
                            event_times, disturb_idx, det_window=det_window
                        )

                        dets.append(int(detected))
                        fas.append(int(fa))
                        lats.append(lat)

                    det_rate = float(np.mean(dets))
                    fa_rate = float(np.mean(fas))
                    med_lat = float(np.nanmedian(lats)) if np.any(~np.isnan(lats)) else np.nan

                    print(f"{name:7s} | Det={det_rate:.2f} | FA_event={fa_rate:.2f} | Lat_med={med_lat:.1f}")

if __name__ == "__main__":
    # Quick sanity run (should print a table)
    run_benchmark(
        N=5000,
        disturbances=("burst", "ramp"),
        noise_levels=(0.3, 0.5),
        amplitudes=(0.5, 0.8, 1.2),
        seeds=range(10),
        det_window=200,
        fp_event_target=0.05,
    )
