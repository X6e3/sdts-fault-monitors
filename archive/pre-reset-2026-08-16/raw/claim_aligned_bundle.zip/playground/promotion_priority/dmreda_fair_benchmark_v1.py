from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
DEFAULT_N_RUNS = 100

BASE_NOISE_STD = 0.5
EPS = 1e-12
LOW_FREQ_RATIO = 0.1
PERSISTENCE_DEFAULT = 3
CUSUM_DELTA_FACTOR = 0.1
REG_COV = 1e-6

RHO_VALUES = (0.8, 0.9, 0.95)
NOISE_SCALE_VALUES = (1.0, 1.5)
FEATURE_WINDOW_VALUES = (64, 32)
PERSISTENCE_VALUES = (2, 3)
SCENARIOS = ("drift", "step_relax", "harmonic_drift", "drift_impulses")

DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
DRIFT_DURATION = 2_000
SLOPE_JITTER_STD = 0.08
AMPLITUDE_JITTER = 0.05
TIME_JITTER = 0.10

OUTPUT_PATH = Path("/Users/x6e3/vscode/dmreda_fair_benchmark_v1_results.json")


@dataclass(frozen=True)
class SweepConfig:
    rho: float
    noise_scale: float
    feature_window: int
    persistence: int

    @property
    def config_id(self) -> str:
        return (
            f"rho={self.rho:.2f}|noise={self.noise_scale:.1f}|"
            f"fw={self.feature_window}|p={self.persistence}"
        )


@dataclass
class DetectorMetrics:
    mean_delay: float
    median_delay: float
    earlier_pct: float | None
    fp_sample_rate: float
    fp_run_rate: float
    measured_arl: float
    amp_jitter_shift: float
    time_jitter_shift: float


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fair DMREDA structural benchmark.")
    parser.add_argument(
        "--fairness-mode",
        choices=("arl", "fp-rate"),
        default="arl",
        help="Calibration mode. Default: arl",
    )
    parser.add_argument(
        "--target-arl",
        type=float,
        default=10_000.0,
        help="Noise-only mean time to false alarm target for ARL mode.",
    )
    parser.add_argument(
        "--target-fp",
        type=float,
        default=0.2,
        help="Noise-only false positive sample rate target in percent for fp-rate mode.",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=DEFAULT_N_RUNS,
        help="Monte Carlo runs per configuration and scenario.",
    )
    parser.add_argument(
        "--disable-rms",
        action="store_true",
        help="Skip RMS baseline and report absolute DMREDA delay only.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=OUTPUT_PATH,
        help="JSON output path.",
    )
    return parser.parse_args()


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)
    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)
    return rms


def build_sigma_profile(rng: np.random.Generator, noise_scale: float) -> np.ndarray:
    knots = np.linspace(0, NUM_SAMPLES - 1, 8, dtype=np.int64)
    levels = 1.0 + rng.normal(0.0, 0.12, size=knots.size).astype(DTYPE)
    levels = np.clip(levels, 0.65, 1.45)
    profile = np.interp(np.arange(NUM_SAMPLES, dtype=DTYPE), knots.astype(DTYPE), levels)
    walk = np.cumsum(rng.normal(0.0, 0.002, size=NUM_SAMPLES).astype(DTYPE))
    walk -= np.mean(walk)
    profile *= np.clip(1.0 + walk, 0.7, 1.5)
    return noise_scale * profile.astype(DTYPE, copy=False)


def ar1_signal_with_profile(
    rng: np.random.Generator,
    rho: float,
    sigma_profile: np.ndarray,
) -> np.ndarray:
    signal = np.empty(NUM_SAMPLES, dtype=DTYPE)
    signal[0] = rng.normal(0.0, BASE_NOISE_STD * sigma_profile[0])
    for i in range(1, NUM_SAMPLES):
        target_std = BASE_NOISE_STD * sigma_profile[i]
        epsilon_std = target_std * math.sqrt(max(1.0 - rho**2, 1e-12))
        signal[i] = rho * signal[i - 1] + rng.normal(0.0, epsilon_std)
    return signal


def harmonic_contamination(
    rng: np.random.Generator,
    amplitude_scale: float,
) -> np.ndarray:
    t = np.arange(NUM_SAMPLES, dtype=DTYPE)
    frequency = rng.uniform(0.002, 0.015)
    phase = rng.uniform(0.0, 2.0 * math.pi)
    amplitude = amplitude_scale * rng.uniform(0.04, 0.12) * BASE_NOISE_STD
    return (amplitude * np.sin(2.0 * math.pi * frequency * t + phase)).astype(DTYPE, copy=False)


def generate_noise_family(
    rng: np.random.Generator,
    rho: float,
    noise_scale: float,
    with_harmonic: bool = True,
) -> np.ndarray:
    sigma_profile = build_sigma_profile(rng, noise_scale)
    signal = ar1_signal_with_profile(rng, rho, sigma_profile)
    if with_harmonic:
        signal += harmonic_contamination(rng, noise_scale)
    return signal.astype(DTYPE, copy=False)


def smooth_ramp(length: int, ramp_len: int) -> np.ndarray:
    t = np.arange(length, dtype=DTYPE)
    ramp = np.clip(t / max(ramp_len, 1), 0.0, 1.0)
    return (3.0 * ramp**2 - 2.0 * ramp**3).astype(DTYPE, copy=False)


def drift_template(rng: np.random.Generator, onset: int, noise_scale: float) -> np.ndarray:
    length = NUM_SAMPLES - onset
    slope = (0.0012 * noise_scale) * max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    ramp = smooth_ramp(length, RAMP_IN_SAMPLES)
    t = np.arange(length, dtype=DTYPE)
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    template[onset:] = slope * t * ramp
    return template


def step_relax_template(rng: np.random.Generator, onset: int, noise_scale: float) -> np.ndarray:
    length = NUM_SAMPLES - onset
    amplitude = noise_scale * BASE_NOISE_STD * rng.uniform(1.0, 1.8)
    tau = rng.uniform(120.0, 320.0)
    t = np.arange(length, dtype=DTYPE)
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    template[onset:] = amplitude * np.exp(-t / tau)
    return template


def harmonic_drift_template(rng: np.random.Generator, onset: int, noise_scale: float) -> np.ndarray:
    length = NUM_SAMPLES - onset
    t = np.arange(length, dtype=DTYPE)
    ramp = smooth_ramp(length, RAMP_IN_SAMPLES)
    base_freq = rng.uniform(0.002, 0.01)
    phase0 = rng.uniform(0.0, 2.0 * math.pi)
    phase_drift = rng.uniform(1.0e-5, 4.0e-5)
    amplitude = noise_scale * BASE_NOISE_STD * rng.uniform(0.35, 0.8)
    phase = 2.0 * math.pi * base_freq * t + phase0 + phase_drift * (t**2)
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    template[onset:] = amplitude * ramp * np.sin(phase)
    return template


def drift_impulses_template(rng: np.random.Generator, onset: int, noise_scale: float) -> np.ndarray:
    template = drift_template(rng, onset, noise_scale)
    impulse_count = int(rng.integers(3, 8))
    for _ in range(impulse_count):
        center = int(rng.integers(onset + 50, min(NUM_SAMPLES - 1, onset + DRIFT_DURATION)))
        width = int(rng.integers(1, 4))
        amplitude = noise_scale * BASE_NOISE_STD * rng.uniform(0.4, 0.9)
        template[center : center + width] += amplitude
    return template


def generate_scenario_signal(
    rng: np.random.Generator,
    scenario: str,
    config: SweepConfig,
) -> tuple[np.ndarray, int]:
    signal = generate_noise_family(rng, config.rho, config.noise_scale, with_harmonic=True)
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))

    if scenario == "drift":
        signal += drift_template(rng, onset, config.noise_scale)
    elif scenario == "step_relax":
        signal += step_relax_template(rng, onset, config.noise_scale)
    elif scenario == "harmonic_drift":
        signal += harmonic_drift_template(rng, onset, config.noise_scale)
    elif scenario == "drift_impulses":
        signal += drift_impulses_template(rng, onset, config.noise_scale)
    else:
        raise ValueError(f"Unknown scenario: {scenario}")

    return signal.astype(DTYPE, copy=False), onset


def extract_augmented_features(signal: np.ndarray, feature_window: int) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, feature_window).astype(DTYPE, copy=False)
    valid_indices = np.arange(feature_window - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(feature_window, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)
    return valid_indices, features


def standardize(features: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    std_safe = np.where(std < 1e-6, 1.0, std)
    standardized = (features - mean) / std_safe
    return np.nan_to_num(standardized, nan=0.0, posinf=0.0, neginf=0.0)


def mahalanobis_series(
    features_std: np.ndarray,
    centroid: np.ndarray,
    inv_cov: np.ndarray,
) -> np.ndarray:
    delta = features_std - centroid
    quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    return np.clip(quadratic, 0.0, None)


def sequential_statistic(distances: np.ndarray, bias: float) -> np.ndarray:
    out = np.zeros_like(distances, dtype=DTYPE)
    accum = 0.0
    for i, d in enumerate(distances):
        accum = max(0.0, accum + (float(d) - bias))
        out[i] = accum
    return out


def persistent_mask(mask: np.ndarray, persistence: int) -> np.ndarray:
    out = np.zeros_like(mask, dtype=bool)
    count = 0
    for i, flag in enumerate(mask):
        if flag:
            count += 1
            if count >= persistence:
                out[i] = True
        else:
            count = 0
    return out


def first_trigger_at_or_after(mask: np.ndarray, onset: int) -> int | None:
    hit = np.flatnonzero(mask[onset:])
    if hit.size == 0:
        return None
    return int(onset + hit[0])


def apply_amplitude_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    scale = 1.0 + rng.normal(0.0, AMPLITUDE_JITTER, size=signal.size).astype(DTYPE)
    return (signal * scale).astype(DTYPE, copy=False)


def apply_time_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    t = np.arange(signal.size, dtype=DTYPE)
    offsets = rng.uniform(-TIME_JITTER, TIME_JITTER, size=signal.size).astype(DTYPE)
    jittered_t = np.clip(t + offsets, 0.0, signal.size - 1.0)
    return np.interp(t, jittered_t, signal).astype(DTYPE, copy=False)


def estimate_arl_from_trigger_runs(trigger_runs: list[np.ndarray]) -> float:
    first_hits = np.empty(len(trigger_runs), dtype=DTYPE)
    for i, trigger in enumerate(trigger_runs):
        idx = np.flatnonzero(trigger)
        first_hits[i] = float(NUM_SAMPLES if idx.size == 0 else idx[0])
    return float(np.mean(first_hits))


def estimate_fp_sample_rate(trigger_runs: list[np.ndarray]) -> float:
    total = sum(int(np.sum(trigger)) for trigger in trigger_runs)
    return 100.0 * total / (len(trigger_runs) * NUM_SAMPLES)


def calibrate_threshold(
    series_runs: list[np.ndarray],
    index_runs: list[np.ndarray],
    persistence: int,
    fairness_mode: str,
    target_arl: float,
    target_fp_percent: float,
) -> tuple[float, float, float]:
    low = min(float(np.min(series)) for series in series_runs)
    high = max(float(np.max(series)) for series in series_runs) + 1.0
    best_threshold = high
    best_arl = 0.0
    best_fp = 0.0

    for _ in range(50):
        mid = 0.5 * (low + high)
        trigger_runs: list[np.ndarray] = []
        for series, indices in zip(series_runs, index_runs):
            trigger = np.zeros(NUM_SAMPLES, dtype=bool)
            trigger[indices] = persistent_mask(series > mid, persistence)
            trigger_runs.append(trigger)

        arl = estimate_arl_from_trigger_runs(trigger_runs)
        fp_rate = estimate_fp_sample_rate(trigger_runs)

        if fairness_mode == "arl":
            meets = arl >= target_arl
        else:
            meets = fp_rate <= target_fp_percent

        if meets:
            best_threshold = mid
            best_arl = arl
            best_fp = fp_rate
            high = mid
        else:
            low = mid

    return float(best_threshold), float(best_arl), float(best_fp)


def build_dmreda_model(
    noise_signals: list[np.ndarray],
    feature_window: int,
    persistence: int,
    fairness_mode: str,
    target_arl: float,
    target_fp_percent: float,
) -> dict[str, object]:
    noise_indices: list[np.ndarray] = []
    noise_features: list[np.ndarray] = []
    for signal in noise_signals:
        indices, features = extract_augmented_features(signal, feature_window)
        noise_indices.append(indices)
        noise_features.append(features)

    all_features = np.vstack(noise_features).astype(DTYPE, copy=False)
    mean = np.mean(all_features, axis=0)
    std = np.std(all_features, axis=0)
    standardized = [standardize(features, mean, std) for features in noise_features]
    centroid = np.mean(np.vstack(standardized), axis=0)
    centered = np.vstack([block - centroid for block in standardized]).astype(DTYPE, copy=False)
    cov = np.cov(centered, rowvar=False) + REG_COV * np.eye(centered.shape[1], dtype=DTYPE)
    inv_cov = np.linalg.pinv(cov)

    d_runs = [mahalanobis_series(block, centroid, inv_cov) for block in standardized]
    k_ref = float(np.mean(np.concatenate(d_runs)))
    bias = k_ref * (1.0 + CUSUM_DELTA_FACTOR)
    s_runs = [sequential_statistic(d_values, bias) for d_values in d_runs]
    threshold, measured_arl, measured_fp = calibrate_threshold(
        s_runs,
        noise_indices,
        persistence,
        fairness_mode,
        target_arl,
        target_fp_percent,
    )

    return {
        "feature_mean": mean,
        "feature_std": std,
        "centroid": centroid,
        "inv_cov": inv_cov,
        "bias": bias,
        "threshold": threshold,
        "measured_arl": measured_arl,
        "measured_fp": measured_fp,
    }


def build_rms_model(
    noise_signals: list[np.ndarray],
    persistence: int,
    fairness_mode: str,
    target_arl: float,
    target_fp_percent: float,
) -> dict[str, float]:
    series_runs = [trailing_rms(signal, RMS_WINDOW) for signal in noise_signals]
    index_runs = [np.arange(NUM_SAMPLES, dtype=np.int64) for _ in noise_signals]
    threshold, measured_arl, measured_fp = calibrate_threshold(
        series_runs,
        index_runs,
        persistence,
        fairness_mode,
        target_arl,
        target_fp_percent,
    )
    return {
        "threshold": threshold,
        "measured_arl": measured_arl,
        "measured_fp": measured_fp,
    }


def detector_metrics_from_delays(
    delays: np.ndarray,
    earlier_pct: float | None,
    fp_sample_rate: float,
    fp_run_rate: float,
    measured_arl: float,
    amp_shift: float,
    time_shift: float,
) -> DetectorMetrics:
    finite = delays[np.isfinite(delays)]
    return DetectorMetrics(
        mean_delay=float(np.mean(finite)) if finite.size else math.nan,
        median_delay=float(np.median(finite)) if finite.size else math.nan,
        earlier_pct=earlier_pct,
        fp_sample_rate=fp_sample_rate,
        fp_run_rate=fp_run_rate,
        measured_arl=measured_arl,
        amp_jitter_shift=amp_shift,
        time_jitter_shift=time_shift,
    )


def evaluate_dmreda_signal(
    signal: np.ndarray,
    onset: int,
    model: dict[str, object],
    feature_window: int,
    persistence: int,
) -> tuple[int | None, np.ndarray]:
    indices, features = extract_augmented_features(signal, feature_window)
    features_std = standardize(
        features,
        model["feature_mean"],  # type: ignore[arg-type]
        model["feature_std"],  # type: ignore[arg-type]
    )
    d_values = mahalanobis_series(
        features_std,
        model["centroid"],  # type: ignore[arg-type]
        model["inv_cov"],  # type: ignore[arg-type]
    )
    s_values = sequential_statistic(d_values, float(model["bias"]))
    trigger = np.zeros(NUM_SAMPLES, dtype=bool)
    trigger[indices] = persistent_mask(s_values > float(model["threshold"]), persistence)
    return first_trigger_at_or_after(trigger, onset), trigger


def evaluate_rms_signal(
    signal: np.ndarray,
    onset: int,
    model: dict[str, float],
    persistence: int,
) -> tuple[int | None, np.ndarray]:
    series = trailing_rms(signal, RMS_WINDOW)
    trigger = persistent_mask(series > float(model["threshold"]), persistence)
    return first_trigger_at_or_after(trigger, onset), trigger


def mean_abs_shift(base: np.ndarray, perturbed: np.ndarray) -> float:
    mask = np.isfinite(base) & np.isfinite(perturbed)
    if not np.any(mask):
        return math.nan
    return float(np.mean(np.abs(base[mask] - perturbed[mask])))


def evaluate_scenario(
    scenario: str,
    config: SweepConfig,
    runs: int,
    dmreda_model: dict[str, object],
    rms_model: dict[str, float] | None,
) -> dict[str, object]:
    dm_delays = np.full(runs, np.nan, dtype=DTYPE)
    rms_delays = np.full(runs, np.nan, dtype=DTYPE)
    dm_base_times = np.full(runs, np.nan, dtype=DTYPE)
    dm_amp_times = np.full(runs, np.nan, dtype=DTYPE)
    dm_time_times = np.full(runs, np.nan, dtype=DTYPE)
    rms_base_times = np.full(runs, np.nan, dtype=DTYPE)
    rms_amp_times = np.full(runs, np.nan, dtype=DTYPE)
    rms_time_times = np.full(runs, np.nan, dtype=DTYPE)

    dm_fp_samples = 0
    dm_fp_runs = 0
    rms_fp_samples = 0
    rms_fp_runs = 0
    total_pre_samples = 0
    dm_earlier_count = 0

    for run_index in range(runs):
        rng = np.random.default_rng(SEED + 50_000 + run_index)
        signal, onset = generate_scenario_signal(rng, scenario, config)

        dm_time, dm_trigger = evaluate_dmreda_signal(
            signal, onset, dmreda_model, config.feature_window, config.persistence
        )
        dm_base_times[run_index] = math.nan if dm_time is None else float(dm_time)
        if dm_time is not None:
            dm_delays[run_index] = float(dm_time - onset)

        dm_fp_count = int(np.sum(dm_trigger[:onset]))
        dm_fp_samples += dm_fp_count
        dm_fp_runs += int(dm_fp_count > 0)

        if rms_model is not None:
            rms_time, rms_trigger = evaluate_rms_signal(signal, onset, rms_model, config.persistence)
            rms_base_times[run_index] = math.nan if rms_time is None else float(rms_time)
            if rms_time is not None:
                rms_delays[run_index] = float(rms_time - onset)
            rms_fp_count = int(np.sum(rms_trigger[:onset]))
            rms_fp_samples += rms_fp_count
            rms_fp_runs += int(rms_fp_count > 0)
            if dm_time is not None and rms_time is not None and dm_time < rms_time:
                dm_earlier_count += 1

        amp_signal = apply_amplitude_jitter(signal, rng)
        amp_time, _ = evaluate_dmreda_signal(
            amp_signal, onset, dmreda_model, config.feature_window, config.persistence
        )
        dm_amp_times[run_index] = math.nan if amp_time is None else float(amp_time)

        time_signal = apply_time_jitter(signal, rng)
        time_time, _ = evaluate_dmreda_signal(
            time_signal, onset, dmreda_model, config.feature_window, config.persistence
        )
        dm_time_times[run_index] = math.nan if time_time is None else float(time_time)

        if rms_model is not None:
            amp_rms_time, _ = evaluate_rms_signal(amp_signal, onset, rms_model, config.persistence)
            time_rms_time, _ = evaluate_rms_signal(time_signal, onset, rms_model, config.persistence)
            rms_amp_times[run_index] = math.nan if amp_rms_time is None else float(amp_rms_time)
            rms_time_times[run_index] = math.nan if time_rms_time is None else float(time_rms_time)

        total_pre_samples += onset

    dm_metrics = detector_metrics_from_delays(
        delays=dm_delays,
        earlier_pct=None if rms_model is None else 100.0 * dm_earlier_count / runs,
        fp_sample_rate=100.0 * dm_fp_samples / max(total_pre_samples, 1),
        fp_run_rate=100.0 * dm_fp_runs / runs,
        measured_arl=float(dmreda_model["measured_arl"]),
        amp_shift=mean_abs_shift(dm_base_times, dm_amp_times),
        time_shift=mean_abs_shift(dm_base_times, dm_time_times),
    )

    result: dict[str, object] = {"dmreda": asdict(dm_metrics)}

    if rms_model is not None:
        rms_metrics = detector_metrics_from_delays(
            delays=rms_delays,
            earlier_pct=0.0,
            fp_sample_rate=100.0 * rms_fp_samples / max(total_pre_samples, 1),
            fp_run_rate=100.0 * rms_fp_runs / runs,
            measured_arl=float(rms_model["measured_arl"]),
            amp_shift=mean_abs_shift(rms_base_times, rms_amp_times),
            time_shift=mean_abs_shift(rms_base_times, rms_time_times),
        )
        result["rms"] = asdict(rms_metrics)

    return result


def budget_failure(
    metrics: DetectorMetrics,
    fairness_mode: str,
    target_arl: float,
    target_fp_percent: float,
) -> bool:
    if fairness_mode == "arl":
        return metrics.measured_arl < 0.95 * target_arl
    return metrics.fp_sample_rate > 1.25 * target_fp_percent


def main() -> None:
    args = parse_args()
    output_path: Path = args.output

    rows: list[dict[str, object]] = []
    json_rows: list[dict[str, object]] = []
    breakpoints: list[dict[str, object]] = []

    for rho in RHO_VALUES:
        for noise_scale in NOISE_SCALE_VALUES:
            noise_signals = [
                generate_noise_family(
                    np.random.default_rng(SEED + 100_000 + i),
                    rho,
                    noise_scale,
                    with_harmonic=True,
                )
                for i in range(args.runs)
            ]

            for feature_window in FEATURE_WINDOW_VALUES:
                for persistence in PERSISTENCE_VALUES:
                    config = SweepConfig(
                        rho=rho,
                        noise_scale=noise_scale,
                        feature_window=feature_window,
                        persistence=persistence,
                    )

                    dmreda_model = build_dmreda_model(
                        noise_signals=noise_signals,
                        feature_window=feature_window,
                        persistence=persistence,
                        fairness_mode=args.fairness_mode,
                        target_arl=args.target_arl,
                        target_fp_percent=args.target_fp,
                    )

                    rms_model = None
                    if not args.disable_rms:
                        rms_model = build_rms_model(
                            noise_signals=noise_signals,
                            persistence=persistence,
                            fairness_mode=args.fairness_mode,
                            target_arl=args.target_arl,
                            target_fp_percent=args.target_fp,
                        )

                    scenario_payload: dict[str, object] = {}
                    for scenario in SCENARIOS:
                        scenario_result = evaluate_scenario(
                            scenario=scenario,
                            config=config,
                            runs=args.runs,
                            dmreda_model=dmreda_model,
                            rms_model=rms_model,
                        )
                        scenario_payload[scenario] = scenario_result

                        dm_metrics = DetectorMetrics(**scenario_result["dmreda"])  # type: ignore[arg-type]
                        rms_delay = (
                            DetectorMetrics(**scenario_result["rms"]).mean_delay  # type: ignore[arg-type]
                            if "rms" in scenario_result
                            else math.nan
                        )

                        delay_explodes = (
                            (not math.isfinite(dm_metrics.mean_delay))
                            or
                            (math.isfinite(rms_delay) and dm_metrics.mean_delay > rms_delay * 1.5)
                            or dm_metrics.mean_delay > 2_500.0
                        )
                        fp_fail = budget_failure(
                            dm_metrics,
                            args.fairness_mode,
                            args.target_arl,
                            args.target_fp,
                        )
                        if delay_explodes or fp_fail:
                            breakpoints.append(
                                {
                                    "config_id": config.config_id,
                                    "scenario": scenario,
                                    "delay_explodes": delay_explodes,
                                    "fp_constraint_failed": fp_fail,
                                    "mean_delay": dm_metrics.mean_delay,
                                    "fp_sample_rate": dm_metrics.fp_sample_rate,
                                    "measured_arl": dm_metrics.measured_arl,
                                }
                            )

                        severity_budget = (
                            max(0.0, args.target_arl - dm_metrics.measured_arl)
                            if args.fairness_mode == "arl"
                            else max(0.0, dm_metrics.fp_sample_rate - args.target_fp)
                        )
                        rows.append(
                            {
                                "config_id": config.config_id,
                                "scenario": scenario,
                                "rho": rho,
                                "noise_scale": noise_scale,
                                "feature_window": feature_window,
                                "persistence": persistence,
                                "mean_delay": dm_metrics.mean_delay,
                                "earlier_pct": dm_metrics.earlier_pct,
                                "fp_sample_rate": dm_metrics.fp_sample_rate,
                                "measured_arl": dm_metrics.measured_arl,
                                "amp_shift": dm_metrics.amp_jitter_shift,
                                "time_shift": dm_metrics.time_jitter_shift,
                                "severity_budget": severity_budget,
                            }
                        )

                    json_rows.append(
                        {
                            "config": asdict(config),
                            "dmreda_model": {
                                "threshold": float(dmreda_model["threshold"]),
                                "measured_arl": float(dmreda_model["measured_arl"]),
                                "measured_fp": float(dmreda_model["measured_fp"]),
                                "bias": float(dmreda_model["bias"]),
                            },
                            "rms_model": None
                            if rms_model is None
                            else {
                                "threshold": float(rms_model["threshold"]),
                                "measured_arl": float(rms_model["measured_arl"]),
                                "measured_fp": float(rms_model["measured_fp"]),
                            },
                            "scenarios": scenario_payload,
                        }
                    )

    rows.sort(
        key=lambda row: (
            row["severity_budget"],
            float("inf") if not math.isfinite(float(row["mean_delay"])) else float(row["mean_delay"]),
        ),
        reverse=True,
    )

    print("DMREDA Fair Benchmark v1")
    print("========================\n")
    print("Configuration")
    print("-------------")
    print(f"fairness_mode : {args.fairness_mode}")
    print(f"target_arl    : {args.target_arl}")
    print(f"target_fp     : {args.target_fp}%")
    print(f"runs          : {args.runs}")
    print(f"rms_enabled   : {not args.disable_rms}\n")

    header = (
        f"{'config':<34} | {'scenario':<14} | {'delay':>8} | {'earlier%':>8} | "
        f"{'fp%':>8} | {'arl':>8} | {'amp':>8} | {'time':>8}"
    )
    print("Worst-Case Summary")
    print("------------------")
    print(header)
    print("-" * len(header))
    for row in rows:
        earlier_text = "n/a" if row["earlier_pct"] is None else f"{row['earlier_pct']:.2f}"
        print(
            f"{row['config_id']:<34} | {row['scenario']:<14} | {row['mean_delay']:8.1f} | "
            f"{earlier_text:>8} | {row['fp_sample_rate']:8.4f} | {row['measured_arl']:8.1f} | "
            f"{row['amp_shift']:8.1f} | {row['time_shift']:8.1f}"
        )

    print("\nVerdict")
    print("-------")
    if breakpoints:
        print("Detector breaks under the following config/scenario pairs:")
        for item in breakpoints:
            reasons = []
            if item["delay_explodes"]:
                reasons.append("delay_explodes")
            if item["fp_constraint_failed"]:
                reasons.append("fp_constraint_failed")
            print(
                f"{item['config_id']} | {item['scenario']} | "
                f"{', '.join(reasons)} | delay={item['mean_delay']:.1f} | "
                f"fp={item['fp_sample_rate']:.4f}% | arl={item['measured_arl']:.1f}"
            )
    else:
        print("No breakpoint condition triggered.")

    output_payload = {
        "config": {
            "fairness_mode": args.fairness_mode,
            "target_arl": args.target_arl,
            "target_fp_percent": args.target_fp,
            "runs": args.runs,
            "rms_enabled": not args.disable_rms,
            "rho_values": list(RHO_VALUES),
            "noise_scale_values": list(NOISE_SCALE_VALUES),
            "feature_window_values": list(FEATURE_WINDOW_VALUES),
            "persistence_values": list(PERSISTENCE_VALUES),
            "scenarios": list(SCENARIOS),
        },
        "results": json_rows,
        "worst_case_rows": rows,
        "verdict": {
            "breakpoints": breakpoints,
            "break_count": len(breakpoints),
        },
    }
    output_path.write_text(json.dumps(output_payload, indent=2), encoding="utf-8")

    print("\nFAIR BENCHMARK COMPLETE")


if __name__ == "__main__":
    main()
