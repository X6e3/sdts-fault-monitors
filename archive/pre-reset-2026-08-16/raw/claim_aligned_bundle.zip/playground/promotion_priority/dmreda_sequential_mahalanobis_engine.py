from __future__ import annotations

import math

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 200

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
AR_COEFF = 0.9
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
SLOPE_JITTER_STD = 0.08

PERSISTENCE_K = 3
REG_COV = 1e-6
LOW_FREQ_RATIO = 0.1


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(
    slope: float,
    onset: int,
    duration: int = DRIFT_DURATION,
    ramp_samples: int = RAMP_IN_SAMPLES,
) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    active_len = max(0, min(duration, NUM_SAMPLES - onset))
    if active_len == 0:
        return template

    k = np.arange(active_len, dtype=DTYPE)
    ramp_len = max(1, min(ramp_samples, active_len))
    values = np.empty(active_len, dtype=DTYPE)

    ramp_mask = k < ramp_len
    values[ramp_mask] = 0.5 * slope * (k[ramp_mask] ** 2) / ramp_len
    values[~ramp_mask] = slope * (k[~ramp_mask] - 0.5 * ramp_len)

    template[onset:onset + active_len] = values
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(
                trailing_rms(build_drift_template(mid, REFERENCE_DRIFT_START), RMS_WINDOW)[
                    reference_drift_mask()
                ]
            )
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float) -> float:
    return float(target_std * math.sqrt(1.0 - AR_COEFF**2))


def generate_ar1_noise(
    rng: np.random.Generator,
    target_std: float,
    size: int = NUM_SAMPLES,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    signal = np.empty(size, dtype=DTYPE)
    signal[0] = rng.normal(0.0, target_std)

    for i in range(1, size):
        signal[i] = AR_COEFF * signal[i - 1] + epsilon[i]

    return signal


def generate_drift_signal(
    rng: np.random.Generator,
    base_slope: float,
) -> tuple[np.ndarray, int]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))
    slope_scale = max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    slope = float(base_slope * slope_scale)
    signal = generate_ar1_noise(rng, EVENT_NOISE_STD)
    signal += build_drift_template(slope, onset)
    return signal.astype(DTYPE, copy=False), onset


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy_val = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy_val,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def persistent_bool(mask: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    out = np.zeros_like(mask, dtype=bool)
    count = 0
    for i, flag in enumerate(mask):
        if flag:
            count += 1
            if count >= required:
                out[i] = True
        else:
            count = 0
    return out


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def mahalanobis_series(features: np.ndarray, mu_noise: np.ndarray, inv_cov: np.ndarray) -> np.ndarray:
    delta = features - mu_noise
    quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    return np.clip(quadratic, 0.0, None)


def sequential_statistic(distances: np.ndarray, k_ref: float) -> np.ndarray:
    s = np.zeros_like(distances, dtype=DTYPE)
    accum = 0.0
    for i, d in enumerate(distances):
        accum = max(0.0, accum + (float(d) - k_ref))
        s[i] = accum
    return s


def main() -> None:
    base_slope = calibrate_drift_slope()

    run_indices: list[np.ndarray] = []
    run_features: list[np.ndarray] = []
    run_onsets: list[int] = []
    run_signals: list[np.ndarray] = []
    pre_onset_feature_blocks: list[np.ndarray] = []

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        signal, onset = generate_drift_signal(rng, base_slope)
        indices, features = extract_augmented_features(signal)
        pre_mask = indices < onset

        run_signals.append(signal)
        run_onsets.append(onset)
        run_indices.append(indices)
        run_features.append(features)
        pre_onset_feature_blocks.append(features[pre_mask])

    all_pre_features = np.vstack(pre_onset_feature_blocks).astype(DTYPE, copy=False)
    mu_noise = np.mean(all_pre_features, axis=0)
    cov_noise = np.cov(all_pre_features, rowvar=False) + REG_COV * np.eye(all_pre_features.shape[1], dtype=DTYPE)
    inv_cov = np.linalg.pinv(cov_noise)

    pre_dist_blocks: list[np.ndarray] = []
    run_distances: list[np.ndarray] = []

    for indices, features, onset in zip(run_indices, run_features, run_onsets):
        distances = mahalanobis_series(features, mu_noise, inv_cov)
        run_distances.append(distances)
        pre_dist_blocks.append(distances[indices < onset])

    all_pre_dist = np.concatenate(pre_dist_blocks).astype(DTYPE, copy=False)
    k_ref = float(np.mean(all_pre_dist))
    d_threshold = float(np.mean(all_pre_dist) + 4.0 * np.std(all_pre_dist))

    pre_s_blocks: list[np.ndarray] = []
    run_sequential: list[np.ndarray] = []

    for distances, indices, onset in zip(run_distances, run_indices, run_onsets):
        s_values = sequential_statistic(distances, k_ref)
        run_sequential.append(s_values)
        pre_s_blocks.append(s_values[indices < onset])

    all_pre_s = np.concatenate(pre_s_blocks).astype(DTYPE, copy=False)
    h_threshold = float(np.mean(all_pre_s) + 4.0 * np.std(all_pre_s))

    sme_delta = np.full(N_RUNS, np.nan, dtype=DTYPE)
    static_delta = np.full(N_RUNS, np.nan, dtype=DTYPE)

    sme_fp_samples = 0
    sme_fp_runs = 0
    static_fp_samples = 0
    static_fp_runs = 0
    rms_fp_samples = 0
    rms_fp_runs = 0
    total_pre_samples = 0

    for run_index in range(N_RUNS):
        signal = run_signals[run_index]
        onset = run_onsets[run_index]
        indices = run_indices[run_index]
        distances = run_distances[run_index]
        s_values = run_sequential[run_index]

        rms = trailing_rms(signal, RMS_WINDOW)
        rms_threshold = float(np.mean(rms[:onset]) + 3.0 * np.std(rms[:onset]))
        rms_trigger = persistent_bool(rms > rms_threshold)

        static_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        sme_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        static_trigger[indices] = persistent_bool(distances > d_threshold)
        sme_trigger[indices] = persistent_bool(s_values > h_threshold)

        t_rms = first_trigger_at_or_after(rms_trigger, onset)
        t_static = first_trigger_at_or_after(static_trigger, onset)
        t_sme = first_trigger_at_or_after(sme_trigger, onset)

        if t_rms is not None and t_static is not None:
            static_delta[run_index] = float(t_rms - t_static)
        if t_rms is not None and t_sme is not None:
            sme_delta[run_index] = float(t_rms - t_sme)

        static_fp_count = int(np.sum(static_trigger[:onset]))
        sme_fp_count = int(np.sum(sme_trigger[:onset]))
        rms_fp_count = int(np.sum(rms_trigger[:onset]))

        static_fp_samples += static_fp_count
        sme_fp_samples += sme_fp_count
        rms_fp_samples += rms_fp_count

        static_fp_runs += int(static_fp_count > 0)
        sme_fp_runs += int(sme_fp_count > 0)
        rms_fp_runs += int(rms_fp_count > 0)
        total_pre_samples += onset

    finite_sme = sme_delta[np.isfinite(sme_delta)]
    finite_static = static_delta[np.isfinite(static_delta)]

    sme_mean_delta = float(np.mean(finite_sme)) if finite_sme.size else math.nan
    sme_median_delta = float(np.median(finite_sme)) if finite_sme.size else math.nan
    sme_earlier = 100.0 * float(np.mean(finite_sme > 0.0)) if finite_sme.size else 0.0
    sme_fp_sample_rate = 100.0 * sme_fp_samples / max(total_pre_samples, 1)
    sme_fp_run_rate = 100.0 * sme_fp_runs / N_RUNS

    static_mean_delta = float(np.mean(finite_static)) if finite_static.size else math.nan
    static_median_delta = float(np.median(finite_static)) if finite_static.size else math.nan
    static_earlier = 100.0 * float(np.mean(finite_static > 0.0)) if finite_static.size else 0.0
    static_fp_sample_rate = 100.0 * static_fp_samples / max(total_pre_samples, 1)
    static_fp_run_rate = 100.0 * static_fp_runs / N_RUNS

    rms_fp_sample_rate = 100.0 * rms_fp_samples / max(total_pre_samples, 1)
    rms_fp_run_rate = 100.0 * rms_fp_runs / N_RUNS

    print("DMREDA Sequential Mahalanobis Engine")
    print("====================================\n")
    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES       : {NUM_SAMPLES}")
    print(f"FEATURE_WINDOW    : {FEATURE_WINDOW}")
    print(f"RMS_WINDOW        : {RMS_WINDOW}")
    print(f"N_RUNS            : {N_RUNS}")
    print(f"AR(1) rho         : {AR_COEFF:.2f}")
    print(f"Persistence       : {PERSISTENCE_K}")
    print(f"k reference       : {k_ref:.6f}")
    print(f"Static D threshold: {d_threshold:.6f}")
    print(f"Sequential h      : {h_threshold:.6f}\n")

    print("Sequential Mahalanobis Engine")
    print("-----------------------------")
    print(f"mean_delta_t               : {sme_mean_delta:.3f}")
    print(f"median_delta_t             : {sme_median_delta:.3f}")
    print(f"percentage_sme_earlier     : {sme_earlier:.2f}%")
    print(f"false_positive_sample_rate : {sme_fp_sample_rate:.4f}%")
    print(f"false_positive_run_rate    : {sme_fp_run_rate:.2f}%\n")

    print("Static Mahalanobis")
    print("------------------")
    print(f"mean_delta_t               : {static_mean_delta:.3f}")
    print(f"median_delta_t             : {static_median_delta:.3f}")
    print(f"percentage_static_earlier  : {static_earlier:.2f}%")
    print(f"false_positive_sample_rate : {static_fp_sample_rate:.4f}%")
    print(f"false_positive_run_rate    : {static_fp_run_rate:.2f}%\n")

    print("RMS Baseline")
    print("------------")
    print(f"false_positive_sample_rate : {rms_fp_sample_rate:.4f}%")
    print(f"false_positive_run_rate    : {rms_fp_run_rate:.2f}%\n")

    if sme_earlier > static_earlier and sme_fp_sample_rate <= static_fp_sample_rate:
        print("SEQUENTIAL MAHALANOBIS VALIDATED")
    else:
        print("SME NEEDS REFINEMENT")


if __name__ == "__main__":
    main()
