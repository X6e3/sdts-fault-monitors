from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 100

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
SLOPE_JITTER_STD = 0.08

PERSISTENCE_K = 3
LOW_FREQ_RATIO = 0.1

RHO_VALUES = (0.8, 0.9, 0.95, 0.98)
NOISE_STD_SCALES = (1.0, 1.5, 2.0)
FEATURE_WINDOW_VALUES = (64, 32)

ORIGINAL_FEATURE_NAMES = (
    "run_length_mean",
    "sign_autocorr_lag1",
    "zero_cross_density",
    "local_monotonicity_ratio",
    "sign_variance",
    "trend_entropy",
)
NEW_FEATURE_NAMES = (
    "linreg_slope_mag",
    "norm_cumsum_mag",
    "low_freq_energy_ratio",
    "window_mean_drift",
)
AUGMENTED_FEATURE_NAMES = ORIGINAL_FEATURE_NAMES + NEW_FEATURE_NAMES


@dataclass(frozen=True)
class Config:
    rho: float
    noise_scale: float
    feature_window: int


@dataclass
class ConfigResult:
    rho: float
    noise_scale: float
    window: int
    mean_mahal_distance: float
    mean_delta_t: float
    fp_sample_rate: float
    classification: str


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(
    slope: float,
    onset: int,
    duration: int = DRIFT_DURATION,
    ramp_samples: int = RAMP_IN_SAMPLES,
) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    active_len = max(0, min(duration, NUM_SAMPLES - onset))
    if active_len == 0:
        return template

    k = np.arange(active_len, dtype=DTYPE)
    ramp_len = max(1, min(ramp_samples, active_len))
    values = np.empty(active_len, dtype=DTYPE)

    ramp_mask = k < ramp_len
    values[ramp_mask] = 0.5 * slope * (k[ramp_mask] ** 2) / ramp_len
    values[~ramp_mask] = slope * (k[~ramp_mask] - 0.5 * ramp_len)

    template[onset:onset + active_len] = values
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(
                trailing_rms(build_drift_template(mid, REFERENCE_DRIFT_START), RMS_WINDOW)[
                    reference_drift_mask()
                ]
            )
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float, rho: float) -> float:
    return float(target_std * math.sqrt(max(1.0 - rho**2, 1e-12)))


def generate_ar1_noise(
    rng: np.random.Generator,
    target_std: float,
    rho: float,
    size: int = NUM_SAMPLES,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std, rho)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    signal = np.empty(size, dtype=DTYPE)
    signal[0] = rng.normal(0.0, target_std)

    for i in range(1, size):
        signal[i] = rho * signal[i - 1] + epsilon[i]

    return signal


def generate_noise_signal(rng: np.random.Generator, rho: float, noise_scale: float) -> np.ndarray:
    return generate_ar1_noise(rng, NOISE_ONLY_STD * noise_scale, rho)


def generate_drift_signal(
    rng: np.random.Generator,
    base_slope: float,
    rho: float,
    noise_scale: float,
) -> tuple[np.ndarray, int]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))
    slope_scale = max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    slope = float(base_slope * slope_scale)
    signal = generate_ar1_noise(rng, EVENT_NOISE_STD * noise_scale, rho)
    signal += build_drift_template(slope, onset)
    return signal.astype(DTYPE, copy=False), onset


def extract_augmented_features(signal: np.ndarray, feature_window: int) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, feature_window).astype(DTYPE, copy=False)
    valid_indices = np.arange(feature_window - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(feature_window, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def standardize(features: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    std_safe = np.where(std < 1e-6, 1.0, std)
    standardized = (features - mean) / std_safe
    return np.nan_to_num(standardized, nan=0.0, posinf=0.0, neginf=0.0)


def mahalanobis_distance_series(
    features_std: np.ndarray,
    centroid: np.ndarray,
    inv_cov: np.ndarray,
) -> np.ndarray:
    delta = features_std - centroid
    quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    quadratic = np.clip(quadratic, 0.0, None)
    return np.sqrt(quadratic)


def persistent_trigger_mask(exceeds: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    trigger = np.zeros_like(exceeds, dtype=bool)
    count = 0
    for i, flag in enumerate(exceeds):
        if flag:
            count += 1
            if count >= required:
                trigger[i] = True
        else:
            count = 0
    return trigger


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def classify_boundary(mean_mahal_distance: float) -> str:
    if mean_mahal_distance >= 4.0:
        return "STRONG"
    if mean_mahal_distance >= 2.0:
        return "MODERATE"
    return "COLLAPSE"


def build_noise_model(
    noise_feature_list: list[np.ndarray],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    noise_features = np.vstack(noise_feature_list).astype(DTYPE, copy=False)
    noise_mean = np.mean(noise_features, axis=0)
    noise_std = np.std(noise_features, axis=0)
    noise_standardized = standardize(noise_features, noise_mean, noise_std)
    noise_centroid = np.mean(noise_standardized, axis=0)

    centered_noise = noise_standardized - noise_centroid
    covariance = np.cov(centered_noise, rowvar=False) + 1e-6 * np.eye(
        noise_standardized.shape[1], dtype=DTYPE
    )
    inv_cov = np.linalg.pinv(covariance)
    noise_distance = mahalanobis_distance_series(noise_standardized, noise_centroid, inv_cov)
    threshold = float(np.quantile(noise_distance, 0.995))
    return noise_mean, noise_std, noise_centroid, inv_cov, threshold


def evaluate_configuration(config: Config, base_slope: float) -> ConfigResult:
    noise_signals: list[np.ndarray] = []
    drift_signals: list[np.ndarray] = []
    onset_list: list[int] = []
    noise_feature_list: list[np.ndarray] = []

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        noise_signal = generate_noise_signal(rng, config.rho, config.noise_scale)
        drift_signal, onset = generate_drift_signal(rng, base_slope, config.rho, config.noise_scale)

        noise_signals.append(noise_signal)
        drift_signals.append(drift_signal)
        onset_list.append(onset)
        noise_feature_list.append(extract_augmented_features(noise_signal, config.feature_window)[1])

    noise_mean, noise_std, noise_centroid, inv_cov, mahal_threshold = build_noise_model(noise_feature_list)

    delta_t_values = np.full(N_RUNS, np.nan, dtype=DTYPE)
    mahal_distances = np.full(N_RUNS, np.nan, dtype=DTYPE)
    noise_trigger_samples = 0

    for run_index in range(N_RUNS):
        noise_signal = noise_signals[run_index]
        drift_signal = drift_signals[run_index]
        onset = onset_list[run_index]

        noise_rms = trailing_rms(noise_signal, RMS_WINDOW)
        drift_rms = trailing_rms(drift_signal, RMS_WINDOW)
        rms_threshold = float(np.mean(noise_rms) + 3.0 * np.std(noise_rms))

        drift_rms_trigger = persistent_trigger_mask(drift_rms > rms_threshold)

        noise_indices, noise_features = extract_augmented_features(noise_signal, config.feature_window)
        _, drift_features = extract_augmented_features(drift_signal, config.feature_window)
        noise_std_features = standardize(noise_features, noise_mean, noise_std)
        drift_std_features = standardize(drift_features, noise_mean, noise_std)

        noise_mahal = mahalanobis_distance_series(noise_std_features, noise_centroid, inv_cov)
        drift_mahal = mahalanobis_distance_series(drift_std_features, noise_centroid, inv_cov)

        noise_mahal_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        drift_mahal_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        noise_mahal_trigger[noise_indices] = persistent_trigger_mask(noise_mahal > mahal_threshold)
        drift_mahal_trigger[noise_indices] = persistent_trigger_mask(drift_mahal > mahal_threshold)

        t_rms = first_trigger_at_or_after(drift_rms_trigger, onset)
        t_mahal = first_trigger_at_or_after(drift_mahal_trigger, onset)
        if t_rms is not None and t_mahal is not None:
            delta_t_values[run_index] = float(t_rms - t_mahal)

        drift_centroid = np.mean(drift_std_features, axis=0)
        diff = drift_centroid - noise_centroid
        mahal_distances[run_index] = math.sqrt(max(float(diff @ inv_cov @ diff), 0.0))
        noise_trigger_samples += int(np.sum(noise_mahal_trigger))

    mean_mahal_distance = float(np.nanmean(mahal_distances))
    finite_delta = delta_t_values[np.isfinite(delta_t_values)]
    mean_delta_t = float(np.mean(finite_delta)) if finite_delta.size else math.nan
    fp_sample_rate = 100.0 * noise_trigger_samples / (N_RUNS * NUM_SAMPLES)

    return ConfigResult(
        rho=config.rho,
        noise_scale=config.noise_scale,
        window=config.feature_window,
        mean_mahal_distance=mean_mahal_distance,
        mean_delta_t=mean_delta_t,
        fp_sample_rate=fp_sample_rate,
        classification=classify_boundary(mean_mahal_distance),
    )


def print_results(results: list[ConfigResult]) -> None:
    print("DMREDA Breaking Point Test")
    print("==========================\n")
    print("Configuration sweep")
    print("-------------------")
    print(f"N_RUNS       : {N_RUNS}")
    print(f"PERSISTENCE  : {PERSISTENCE_K}")
    print(f"rho_values   : {list(RHO_VALUES)}")
    print(f"noise_scales : {list(NOISE_STD_SCALES)}")
    print(f"windows      : {list(FEATURE_WINDOW_VALUES)}\n")

    header = (
        f"{'rho':>5} | {'noise_scale':>11} | {'window':>6} | {'mean_mahal_distance':>19} | "
        f"{'mean_delta_t':>12} | {'fp_sample_rate':>14} | {'class':>9}"
    )
    print(header)
    print("-" * len(header))
    for row in results:
        print(
            f"{row.rho:5.2f} | {row.noise_scale:11.2f} | {row.window:6d} | "
            f"{row.mean_mahal_distance:19.6f} | {row.mean_delta_t:12.3f} | "
            f"{row.fp_sample_rate:14.3f}% | {row.classification:>9}"
        )
    print()
    print("DMREDA robustness boundary test complete")


def main() -> None:
    base_slope = calibrate_drift_slope()
    results: list[ConfigResult] = []

    for rho in RHO_VALUES:
        for noise_scale in NOISE_STD_SCALES:
            for feature_window in FEATURE_WINDOW_VALUES:
                config = Config(rho=rho, noise_scale=noise_scale, feature_window=feature_window)
                results.append(evaluate_configuration(config, base_slope))

    results.sort(key=lambda item: item.mean_mahal_distance)
    print_results(results)


if __name__ == "__main__":
    main()
