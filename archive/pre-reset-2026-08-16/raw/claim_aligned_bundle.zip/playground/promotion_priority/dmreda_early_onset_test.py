from __future__ import annotations

import math

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 100

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

DRIFT_START = 3_200
DRIFT_END = 4_800

LOW_FREQ_RATIO = 0.1

ORIGINAL_FEATURE_NAMES = (
    "run_length_mean",
    "sign_autocorr_lag1",
    "zero_cross_density",
    "local_monotonicity_ratio",
    "sign_variance",
    "trend_entropy",
)
NEW_FEATURE_NAMES = (
    "linreg_slope_mag",
    "norm_cumsum_mag",
    "low_freq_energy_ratio",
    "window_mean_drift",
)
AUGMENTED_FEATURE_NAMES = ORIGINAL_FEATURE_NAMES + NEW_FEATURE_NAMES


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(slope: float) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    length = DRIFT_END - DRIFT_START
    template[DRIFT_START:DRIFT_END] = slope * np.arange(length, dtype=DTYPE)
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.01

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(trailing_rms(build_drift_template(mid), RMS_WINDOW)[DRIFT_START:DRIFT_END])
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def generate_noise_signal(rng: np.random.Generator) -> np.ndarray:
    return rng.normal(0.0, NOISE_ONLY_STD, size=NUM_SAMPLES).astype(DTYPE)


def generate_drift_signal(rng: np.random.Generator, slope: float) -> np.ndarray:
    return rng.normal(0.0, EVENT_NOISE_STD, size=NUM_SAMPLES).astype(DTYPE) + build_drift_template(slope)


def sanitize_sign(values: np.ndarray) -> np.ndarray:
    signs = np.sign(values).astype(np.int8)
    if signs.size == 0:
        return signs

    nonzero = np.flatnonzero(signs)
    if nonzero.size == 0:
        signs[:] = 1
        return signs

    signs[: nonzero[0]] = signs[nonzero[0]]
    for i in range(nonzero[0] + 1, signs.size):
        if signs[i] == 0:
            signs[i] = signs[i - 1]

    return signs


def mean_run_length(signs: np.ndarray) -> float:
    if signs.size == 0:
        return 0.0

    lengths = []
    current = 1
    for i in range(1, signs.size):
        if signs[i] == signs[i - 1]:
            current += 1
        else:
            lengths.append(current)
            current = 1
    lengths.append(current)
    return float(np.mean(lengths))


def sign_autocorr_lag1(signs: np.ndarray) -> float:
    if signs.size < 2:
        return 0.0
    x = signs[:-1].astype(DTYPE)
    y = signs[1:].astype(DTYPE)
    x_centered = x - np.mean(x)
    y_centered = y - np.mean(y)
    denom = math.sqrt(float(np.sum(x_centered**2) * np.sum(y_centered**2))) + EPS
    return float(np.sum(x_centered * y_centered) / denom)


def zero_cross_density(signs: np.ndarray) -> float:
    if signs.size < 2:
        return 0.0
    crossings = np.sum(signs[1:] != signs[:-1])
    return float(crossings / (signs.size - 1))


def local_monotonicity_ratio(dx: np.ndarray) -> float:
    return float(abs(np.sum(dx)) / (np.sum(np.abs(dx)) + EPS))


def trend_entropy(signs: np.ndarray) -> float:
    _, counts = np.unique(signs, return_counts=True)
    probabilities = counts.astype(DTYPE) / np.sum(counts)
    entropy = -np.sum(probabilities * np.log2(probabilities + EPS))
    max_entropy = math.log2(len(probabilities)) if len(probabilities) > 1 else 1.0
    return float(entropy / max_entropy)


def linear_regression_slope(window: np.ndarray) -> float:
    n = window.size
    t = np.arange(n, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = window - np.mean(window)
    denom = float(np.sum(t_centered**2)) + EPS
    return float(np.sum(t_centered * y_centered) / denom)


def low_frequency_energy_ratio(window: np.ndarray) -> float:
    centered = window - np.mean(window)
    spectrum = np.fft.rfft(centered)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.size)))
    return float(np.sum(energy[:cutoff]) / (np.sum(energy) + EPS))


def augmented_feature_vector(window: np.ndarray) -> np.ndarray:
    dx = np.diff(window)
    dx_signs = sanitize_sign(dx)
    window_rms = math.sqrt(float(np.mean(window**2))) + EPS
    window_energy = float(np.sum(window**2)) + EPS
    slope = linear_regression_slope(window)
    cumulative = np.cumsum(window, dtype=DTYPE)

    return np.array(
        [
            mean_run_length(dx_signs),
            sign_autocorr_lag1(dx_signs),
            zero_cross_density(dx_signs),
            local_monotonicity_ratio(dx),
            float(np.var(dx_signs.astype(DTYPE))),
            trend_entropy(dx_signs),
            abs(slope) / window_rms,
            float(np.max(np.abs(cumulative)) / window_energy),
            low_frequency_energy_ratio(window),
            float(abs(np.mean(window)) / window_rms),
        ],
        dtype=DTYPE,
    )


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy_val = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy_val,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def standardize(features: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    std_safe = np.where(std < 1e-6, 1.0, std)
    standardized = (features - mean) / std_safe
    return np.nan_to_num(standardized, nan=0.0, posinf=0.0, neginf=0.0)


def mahalanobis_timeseries(
    noise_signal: np.ndarray,
    drift_signal: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    noise_indices, noise_features = extract_augmented_features(noise_signal)
    drift_indices, drift_features = extract_augmented_features(drift_signal)
    _ = noise_indices

    noise_mean = np.mean(noise_features, axis=0)
    noise_std = np.std(noise_features, axis=0)

    noise_standardized = standardize(noise_features, noise_mean, noise_std)
    drift_standardized = standardize(drift_features, noise_mean, noise_std)
    noise_centroid = np.mean(noise_standardized, axis=0)

    centered_noise = noise_standardized - noise_centroid
    covariance = np.cov(centered_noise, rowvar=False) + 1e-6 * np.eye(noise_standardized.shape[1], dtype=DTYPE)
    inv_cov = np.linalg.pinv(covariance)

    def distance_series(features_std: np.ndarray) -> np.ndarray:
        delta = features_std - noise_centroid
        quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
        quadratic = np.clip(quadratic, 0.0, None)
        return np.sqrt(quadratic)

    noise_distance = distance_series(noise_standardized)
    drift_distance = distance_series(drift_standardized)
    threshold = float(np.quantile(noise_distance, 0.995))
    return noise_distance, drift_distance, threshold


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def first_trigger_before(mask: np.ndarray, stop_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices < stop_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def histogram_text(values: np.ndarray, bins: int = 12) -> str:
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return "No finite delta_t values."

    counts, edges = np.histogram(finite, bins=bins)
    max_count = max(int(np.max(counts)), 1)
    lines = []
    for count, left, right in zip(counts, edges[:-1], edges[1:]):
        bar_len = int(round(40.0 * count / max_count))
        bar = "#" * bar_len
        lines.append(f"{left:8.1f} .. {right:8.1f} | {count:3d} | {bar}")
    return "\n".join(lines)


def main() -> None:
    drift_slope = calibrate_drift_slope()

    delta_t = np.full(N_RUNS, np.nan, dtype=DTYPE)
    rms_false_positive_runs = 0
    mahal_false_positive_runs = 0
    rms_false_positive_samples = 0
    mahal_false_positive_samples = 0
    total_noise_samples = N_RUNS * NUM_SAMPLES
    early_count = 0
    valid_delta_count = 0

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        noise_signal = generate_noise_signal(rng)
        drift_signal = generate_drift_signal(rng, drift_slope)

        noise_rms = trailing_rms(noise_signal, RMS_WINDOW)
        drift_rms = trailing_rms(drift_signal, RMS_WINDOW)
        rms_threshold = float(np.mean(noise_rms) + 3.0 * np.std(noise_rms))

        noise_rms_trigger = noise_rms > rms_threshold
        drift_rms_trigger = drift_rms > rms_threshold

        noise_mahal, drift_mahal, mahal_threshold = mahalanobis_timeseries(noise_signal, drift_signal)
        mahal_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

        noise_mahal_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        drift_mahal_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        noise_mahal_trigger[mahal_indices] = noise_mahal > mahal_threshold
        drift_mahal_trigger[mahal_indices] = drift_mahal > mahal_threshold

        t_rms_trigger = first_trigger_at_or_after(drift_rms_trigger, DRIFT_START)
        t_mahal_trigger = first_trigger_at_or_after(drift_mahal_trigger, DRIFT_START)

        if first_trigger_before(noise_rms_trigger, NUM_SAMPLES) is not None:
            rms_false_positive_runs += 1
        if first_trigger_before(noise_mahal_trigger, NUM_SAMPLES) is not None:
            mahal_false_positive_runs += 1
        rms_false_positive_samples += int(np.sum(noise_rms_trigger))
        mahal_false_positive_samples += int(np.sum(noise_mahal_trigger))

        if t_rms_trigger is not None and t_mahal_trigger is not None:
            delta_t[run_index] = float(t_rms_trigger - t_mahal_trigger)
            valid_delta_count += 1
            if t_mahal_trigger < t_rms_trigger:
                early_count += 1

    finite_delta = delta_t[np.isfinite(delta_t)]
    mean_delta = float(np.mean(finite_delta)) if finite_delta.size else math.nan
    median_delta = float(np.median(finite_delta)) if finite_delta.size else math.nan
    early_fraction = 100.0 * early_count / max(valid_delta_count, 1)
    rms_false_positive_rate = 100.0 * rms_false_positive_runs / N_RUNS
    mahal_false_positive_rate = 100.0 * mahal_false_positive_runs / N_RUNS
    rms_false_positive_sample_rate = 100.0 * rms_false_positive_samples / total_noise_samples
    mahal_false_positive_sample_rate = 100.0 * mahal_false_positive_samples / total_noise_samples

    stable = (
        finite_delta.size >= 0.8 * N_RUNS
        and mean_delta > 0.0
        and median_delta > 0.0
        and early_fraction >= 60.0
        and mahal_false_positive_sample_rate <= 1.0
    )

    print("DMREDA Early Onset Test")
    print("=======================\n")
    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES    : {NUM_SAMPLES}")
    print(f"RMS_WINDOW     : {RMS_WINDOW}")
    print(f"FEATURE_WINDOW : {FEATURE_WINDOW}")
    print(f"N_RUNS         : {N_RUNS}")
    print(f"Drift slope    : {drift_slope:.10f}\n")

    print("Results")
    print("-------")
    print(f"Mean delta_t                         : {mean_delta:.3f}")
    print(f"Median delta_t                       : {median_delta:.3f}")
    print(f"Mahalanobis earlier than RMS         : {early_fraction:.2f}%")
    print(f"RMS false positive sample rate       : {rms_false_positive_sample_rate:.3f}%")
    print(f"Mahalanobis false positive sample rate: {mahal_false_positive_sample_rate:.3f}%")
    print(f"RMS false positive run rate          : {rms_false_positive_rate:.2f}%")
    print(f"Mahalanobis false positive run rate  : {mahal_false_positive_rate:.2f}%")
    print(f"Valid delta_t runs                   : {finite_delta.size}/{N_RUNS}\n")

    print("delta_t histogram")
    print("-----------------")
    print(histogram_text(delta_t))
    print()

    if stable:
        print("Mahalanobis early advantage confirmed")
    else:
        print("Mahalanobis early advantage not confirmed")


if __name__ == "__main__":
    main()
