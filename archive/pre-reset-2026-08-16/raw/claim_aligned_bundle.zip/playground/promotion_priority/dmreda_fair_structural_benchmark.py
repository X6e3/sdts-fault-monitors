from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 200

BASELINE_RHO = 0.4
DRIFT_RHO = 0.9
BASELINE_STD = 0.5
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200

PERSISTENCE_K = 3
REG_COV = 1e-6
LOW_FREQ_RATIO = 0.1
ARL_TARGET = float(NUM_SAMPLES)
SEQUENTIAL_DELTA_FACTOR = 0.1

LOW_FREQ = 0.006
SINE_AMPLITUDE = 0.35
PHASE_DRIFT_RATE = 2.0e-5


@dataclass
class DetectorSummary:
    name: str
    mean_delay: float
    median_delay: float
    earlier_pct: float
    fp_sample_rate: float
    fp_run_rate: float
    arl: float


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)
    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)
    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_reference_drift_template(slope: float) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    length = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
    template[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = slope * np.arange(length, dtype=DTYPE)
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_reference_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02
    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(trailing_rms(build_reference_drift_template(mid), RMS_WINDOW)[reference_drift_mask()])
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid
    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float, rho: float) -> float:
    return float(target_std * math.sqrt(max(1.0 - rho**2, 1e-12)))


def generate_ar1_segment(
    rng: np.random.Generator,
    size: int,
    rho: float,
    target_std: float,
    initial_state: float,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std, rho)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    out = np.empty(size, dtype=DTYPE)
    prev = float(initial_state)
    for i in range(size):
        prev = rho * prev + float(epsilon[i])
        out[i] = prev
    return out


def generate_noise_signal(rng: np.random.Generator) -> np.ndarray:
    signal = np.empty(NUM_SAMPLES, dtype=DTYPE)
    signal[0] = rng.normal(0.0, BASELINE_STD)
    epsilon_std = ar1_epsilon_std(BASELINE_STD, BASELINE_RHO)
    epsilon = rng.normal(0.0, epsilon_std, size=NUM_SAMPLES - 1).astype(DTYPE)
    for i in range(1, NUM_SAMPLES):
        signal[i] = BASELINE_RHO * signal[i - 1] + epsilon[i - 1]
    return signal


def structural_component(length: int, target_rms: float) -> np.ndarray:
    t = np.arange(length, dtype=DTYPE)
    ramp = np.clip(t / max(RAMP_IN_SAMPLES, 1), 0.0, 1.0)
    phase = 2.0 * math.pi * LOW_FREQ * t + PHASE_DRIFT_RATE * (t**2)
    component = (SINE_AMPLITUDE * target_rms) * ramp * np.sin(phase)
    return component.astype(DTYPE, copy=False)


def generate_structural_drift_signal(
    rng: np.random.Generator,
) -> tuple[np.ndarray, int, float, float, float]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))

    signal = np.empty(NUM_SAMPLES, dtype=DTYPE)
    signal[0] = rng.normal(0.0, BASELINE_STD)

    epsilon_std_pre = ar1_epsilon_std(BASELINE_STD, BASELINE_RHO)
    for i in range(1, onset):
        signal[i] = BASELINE_RHO * signal[i - 1] + rng.normal(0.0, epsilon_std_pre)

    post_len = NUM_SAMPLES - onset
    post_segment = generate_ar1_segment(rng, post_len, DRIFT_RHO, BASELINE_STD, signal[onset - 1])
    post_segment += structural_component(post_len, BASELINE_STD)

    signal[onset:] = post_segment
    pre_band_start = max(0, onset - min(1000, onset))
    post_band_start = min(NUM_SAMPLES, onset + RMS_WINDOW)
    post_band_end = min(NUM_SAMPLES, post_band_start + 1000)

    for _ in range(4):
        rms = trailing_rms(signal, RMS_WINDOW)
        mean_rms_pre = float(np.mean(rms[pre_band_start:onset]))
        mean_rms_post = (
            float(np.mean(rms[post_band_start:post_band_end]))
            if post_band_end > post_band_start
            else mean_rms_pre
        )
        scale = mean_rms_pre / (mean_rms_post + EPS)
        signal[onset:] *= scale

    rms = trailing_rms(signal, RMS_WINDOW)
    mean_rms_pre = float(np.mean(rms[pre_band_start:onset]))
    mean_rms_post = float(np.mean(rms[post_band_start:post_band_end])) if post_band_end > post_band_start else math.nan
    rel_change = 100.0 * abs(mean_rms_post - mean_rms_pre) / (mean_rms_pre + EPS)
    return signal.astype(DTYPE, copy=False), onset, mean_rms_pre, mean_rms_post, rel_change


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy_val = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy_val,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def persistent_bool(mask: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    out = np.zeros_like(mask, dtype=bool)
    count = 0
    for i, flag in enumerate(mask):
        if flag:
            count += 1
            if count >= required:
                out[i] = True
        else:
            count = 0
    return out


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def first_alarm_time_from_series(series: np.ndarray, threshold: float, indices: np.ndarray) -> int | None:
    trigger = persistent_bool(series > threshold)
    hit = np.flatnonzero(trigger)
    if hit.size == 0:
        return None
    return int(indices[hit[0]])


def estimate_arl(series_runs: list[np.ndarray], index_runs: list[np.ndarray], threshold: float) -> float:
    alarm_times = np.empty(len(series_runs), dtype=DTYPE)
    for i, (series, indices) in enumerate(zip(series_runs, index_runs)):
        alarm_time = first_alarm_time_from_series(series, threshold, indices)
        alarm_times[i] = float(NUM_SAMPLES if alarm_time is None else alarm_time)
    return float(np.mean(alarm_times))


def calibrate_threshold_for_arl(
    series_runs: list[np.ndarray],
    index_runs: list[np.ndarray],
    arl_target: float = ARL_TARGET,
) -> tuple[float, float]:
    low = min(float(np.min(series)) for series in series_runs)
    high = max(float(np.max(series)) for series in series_runs) + 1.0
    best_h = high
    best_arl = estimate_arl(series_runs, index_runs, best_h)

    for _ in range(50):
        mid = 0.5 * (low + high)
        arl_mid = estimate_arl(series_runs, index_runs, mid)
        if arl_mid >= arl_target:
            best_h = mid
            best_arl = arl_mid
            high = mid
        else:
            low = mid

    return float(best_h), float(best_arl)


def mahalanobis_series(features: np.ndarray, mu_noise: np.ndarray, inv_cov: np.ndarray) -> np.ndarray:
    delta = features - mu_noise
    quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    return np.clip(quadratic, 0.0, None)


def sequential_statistic(distances: np.ndarray, bias: float) -> np.ndarray:
    s = np.zeros_like(distances, dtype=DTYPE)
    accum = 0.0
    for i, d in enumerate(distances):
        accum = max(0.0, accum + (float(d) - bias))
        s[i] = accum
    return s


def detector_summary(
    name: str,
    trigger_runs: list[np.ndarray],
    onset_list: list[int],
    rms_trigger_runs: list[np.ndarray],
    measured_arl: float,
) -> DetectorSummary:
    delay_values = np.full(len(trigger_runs), np.nan, dtype=DTYPE)
    earlier_count = 0
    fp_samples = 0
    fp_runs = 0
    total_pre_samples = 0

    for i, (trigger, onset, rms_trigger) in enumerate(zip(trigger_runs, onset_list, rms_trigger_runs)):
        t_det = first_trigger_at_or_after(trigger, onset)
        t_rms = first_trigger_at_or_after(rms_trigger, onset)

        if t_det is not None:
            delay_values[i] = float(t_det - onset)
        if t_det is not None and (t_rms is None or t_det < t_rms):
            earlier_count += 1

        fp_count = int(np.sum(trigger[:onset]))
        fp_samples += fp_count
        fp_runs += int(fp_count > 0)
        total_pre_samples += onset

    finite_delay = delay_values[np.isfinite(delay_values)]
    return DetectorSummary(
        name=name,
        mean_delay=float(np.mean(finite_delay)) if finite_delay.size else math.nan,
        median_delay=float(np.median(finite_delay)) if finite_delay.size else math.nan,
        earlier_pct=100.0 * earlier_count / len(trigger_runs),
        fp_sample_rate=100.0 * fp_samples / max(total_pre_samples, 1),
        fp_run_rate=100.0 * fp_runs / len(trigger_runs),
        arl=measured_arl,
    )


def main() -> None:
    _ = calibrate_reference_slope()

    noise_signals: list[np.ndarray] = []
    noise_rms_series: list[np.ndarray] = []
    noise_feature_indices: list[np.ndarray] = []
    noise_features: list[np.ndarray] = []

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + 10_000 + run_index)
        signal = generate_noise_signal(rng)
        indices, features = extract_augmented_features(signal)
        noise_signals.append(signal)
        noise_rms_series.append(trailing_rms(signal, RMS_WINDOW))
        noise_feature_indices.append(indices)
        noise_features.append(features)

    rms_index_runs = [np.arange(NUM_SAMPLES, dtype=np.int64) for _ in range(N_RUNS)]
    rms_threshold, rms_arl = calibrate_threshold_for_arl(noise_rms_series, rms_index_runs)

    all_noise_features = np.vstack(noise_features).astype(DTYPE, copy=False)
    mu_noise = np.mean(all_noise_features, axis=0)
    cov_noise = np.cov(all_noise_features, rowvar=False) + REG_COV * np.eye(
        all_noise_features.shape[1], dtype=DTYPE
    )
    inv_cov = np.linalg.pinv(cov_noise)

    noise_d_runs = [mahalanobis_series(features, mu_noise, inv_cov) for features in noise_features]
    k_ref = float(np.mean(np.concatenate(noise_d_runs)))
    bias = k_ref * (1.0 + SEQUENTIAL_DELTA_FACTOR)
    noise_s_runs = [sequential_statistic(d_values, bias) for d_values in noise_d_runs]
    sequential_threshold, sequential_arl = calibrate_threshold_for_arl(noise_s_runs, noise_feature_indices)

    structural_signals: list[np.ndarray] = []
    onset_list: list[int] = []
    rms_trigger_runs: list[np.ndarray] = []
    sequential_trigger_runs: list[np.ndarray] = []
    rms_pre_values: list[float] = []
    rms_post_values: list[float] = []
    rms_rel_changes: list[float] = []

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        signal, onset, mean_rms_pre, mean_rms_post, rel_change = generate_structural_drift_signal(rng)
        indices, features = extract_augmented_features(signal)
        d_values = mahalanobis_series(features, mu_noise, inv_cov)
        s_values = sequential_statistic(d_values, bias)

        rms_trigger = persistent_bool(trailing_rms(signal, RMS_WINDOW) > rms_threshold)
        sequential_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        sequential_trigger[indices] = persistent_bool(s_values > sequential_threshold)

        structural_signals.append(signal)
        onset_list.append(onset)
        rms_trigger_runs.append(rms_trigger)
        sequential_trigger_runs.append(sequential_trigger)
        rms_pre_values.append(mean_rms_pre)
        rms_post_values.append(mean_rms_post)
        rms_rel_changes.append(rel_change)

    rms_summary = detector_summary(
        name="RMS",
        trigger_runs=rms_trigger_runs,
        onset_list=onset_list,
        rms_trigger_runs=rms_trigger_runs,
        measured_arl=rms_arl,
    )
    sequential_summary = detector_summary(
        name="SequentialMahalanobis",
        trigger_runs=sequential_trigger_runs,
        onset_list=onset_list,
        rms_trigger_runs=rms_trigger_runs,
        measured_arl=sequential_arl,
    )

    ranked = sorted(
        [rms_summary, sequential_summary],
        key=lambda row: (row.mean_delay if math.isfinite(row.mean_delay) else float("inf")),
    )

    print("Fair Structural Benchmark")
    print("=========================\n")
    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES            : {NUM_SAMPLES}")
    print(f"RMS_WINDOW             : {RMS_WINDOW}")
    print(f"FEATURE_WINDOW         : {FEATURE_WINDOW}")
    print(f"N_RUNS                 : {N_RUNS}")
    print(f"Baseline rho           : {BASELINE_RHO:.2f}")
    print(f"Drift rho              : {DRIFT_RHO:.2f}")
    print(f"Persistence            : {PERSISTENCE_K}")
    print(f"Sequential delta factor: {SEQUENTIAL_DELTA_FACTOR:.2f}\n")

    print("Energy Invariance Check")
    print("-----------------------")
    print(f"Mean RMS before drift  : {float(np.mean(rms_pre_values)):.6f}")
    print(f"Mean RMS after drift   : {float(np.mean(rms_post_values)):.6f}")
    print(f"Relative RMS change %  : {float(np.mean(rms_rel_changes)):.3f}\n")

    print("Detector Details")
    print("----------------")
    for row in [rms_summary, sequential_summary]:
        print(f"{row.name}")
        print(f"  Mean delay          : {row.mean_delay:.3f}")
        print(f"  Median delay        : {row.median_delay:.3f}")
        print(f"  Earlier than RMS %  : {row.earlier_pct:.2f}")
        print(f"  FP sample rate      : {row.fp_sample_rate:.4f}%")
        print(f"  FP run rate         : {row.fp_run_rate:.2f}%")
        print(f"  ARL                 : {row.arl:.2f}\n")

    print("FAIR STRUCTURAL BENCHMARK COMPLETE\n")
    print("Ranked Summary")
    print("--------------")
    print(f"{'Detector':<24} | {'Mean Delay':>10} | {'Earlier %':>9} | {'FP Rate':>10} | {'ARL':>10}")
    print("-" * 76)
    for row in ranked:
        print(
            f"{row.name:<24} | {row.mean_delay:10.3f} | {row.earlier_pct:9.2f} | "
            f"{row.fp_sample_rate:9.4f}% | {row.arl:10.2f}"
        )


if __name__ == "__main__":
    main()
