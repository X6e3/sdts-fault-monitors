from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 200

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
AR_COEFF = 0.9
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
SLOPE_JITTER_STD = 0.08

PERSISTENCE_K = 3
REG_COV = 1e-6
ARL_TARGET = float(NUM_SAMPLES)
DELTA_FACTORS = (0.0, 0.1, 0.2, 0.3)

LOW_FREQ_RATIO = 0.1


@dataclass
class DetectorMetrics:
    mean_delay: float
    median_delay: float
    mean_delta_t: float
    median_delta_t: float
    earlier_pct_vs_rms: float
    fp_sample_rate: float
    fp_run_rate: float


@dataclass
class SequentialResult:
    delta_factor: float
    delta_value: float
    h_value: float
    achieved_arl: float
    metrics: DetectorMetrics


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(
    slope: float,
    onset: int,
    duration: int = DRIFT_DURATION,
    ramp_samples: int = RAMP_IN_SAMPLES,
) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    active_len = max(0, min(duration, NUM_SAMPLES - onset))
    if active_len == 0:
        return template

    k = np.arange(active_len, dtype=DTYPE)
    ramp_len = max(1, min(ramp_samples, active_len))
    values = np.empty(active_len, dtype=DTYPE)

    ramp_mask = k < ramp_len
    values[ramp_mask] = 0.5 * slope * (k[ramp_mask] ** 2) / ramp_len
    values[~ramp_mask] = slope * (k[~ramp_mask] - 0.5 * ramp_len)

    template[onset:onset + active_len] = values
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(
                trailing_rms(build_drift_template(mid, REFERENCE_DRIFT_START), RMS_WINDOW)[
                    reference_drift_mask()
                ]
            )
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float) -> float:
    return float(target_std * math.sqrt(1.0 - AR_COEFF**2))


def generate_ar1_noise(
    rng: np.random.Generator,
    target_std: float,
    size: int = NUM_SAMPLES,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    signal = np.empty(size, dtype=DTYPE)
    signal[0] = rng.normal(0.0, target_std)

    for i in range(1, size):
        signal[i] = AR_COEFF * signal[i - 1] + epsilon[i]

    return signal


def generate_noise_signal(rng: np.random.Generator) -> np.ndarray:
    return generate_ar1_noise(rng, NOISE_ONLY_STD)


def generate_drift_signal(
    rng: np.random.Generator,
    base_slope: float,
) -> tuple[np.ndarray, int]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))
    slope_scale = max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    slope = float(base_slope * slope_scale)
    signal = generate_ar1_noise(rng, EVENT_NOISE_STD)
    signal += build_drift_template(slope, onset)
    return signal.astype(DTYPE, copy=False), onset


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy_val = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy_val,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def persistent_bool(mask: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    out = np.zeros_like(mask, dtype=bool)
    count = 0
    for i, flag in enumerate(mask):
        if flag:
            count += 1
            if count >= required:
                out[i] = True
        else:
            count = 0
    return out


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def first_alarm_time_from_series(
    series: np.ndarray,
    threshold: float,
    indices: np.ndarray,
    persistence: int = PERSISTENCE_K,
) -> int | None:
    trigger = persistent_bool(series > threshold, required=persistence)
    hit = np.flatnonzero(trigger)
    if hit.size == 0:
        return None
    return int(indices[hit[0]])


def estimate_arl(
    series_runs: list[np.ndarray],
    indices_runs: list[np.ndarray],
    threshold: float,
) -> float:
    alarm_times = np.empty(len(series_runs), dtype=DTYPE)
    for i, (series, indices) in enumerate(zip(series_runs, indices_runs)):
        alarm_time = first_alarm_time_from_series(series, threshold, indices)
        alarm_times[i] = float(NUM_SAMPLES if alarm_time is None else alarm_time)
    return float(np.mean(alarm_times))


def calibrate_threshold_for_arl(
    series_runs: list[np.ndarray],
    indices_runs: list[np.ndarray],
    arl_target: float = ARL_TARGET,
) -> tuple[float, float]:
    global_max = max(float(np.max(series)) for series in series_runs)
    global_min = min(float(np.min(series)) for series in series_runs)

    low = global_min
    high = max(global_max + 1.0, 1.0)
    best_h = high
    best_arl = estimate_arl(series_runs, indices_runs, best_h)

    for _ in range(50):
        mid = 0.5 * (low + high)
        arl_mid = estimate_arl(series_runs, indices_runs, mid)
        if arl_mid >= arl_target:
            best_h = mid
            best_arl = arl_mid
            high = mid
        else:
            low = mid

    return float(best_h), float(best_arl)


def mahalanobis_series(features: np.ndarray, mu_noise: np.ndarray, inv_cov: np.ndarray) -> np.ndarray:
    delta = features - mu_noise
    quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    return np.clip(quadratic, 0.0, None)


def sequential_statistic(distances: np.ndarray, bias: float) -> np.ndarray:
    s = np.zeros_like(distances, dtype=DTYPE)
    accum = 0.0
    for i, d in enumerate(distances):
        accum = max(0.0, accum + (float(d) - bias))
        s[i] = accum
    return s


def compute_detector_metrics(
    detector_runs: list[np.ndarray],
    detector_indices: list[np.ndarray],
    detector_threshold: float,
    run_onsets: list[int],
    run_signals: list[np.ndarray],
) -> DetectorMetrics:
    delay_values = np.full(len(detector_runs), np.nan, dtype=DTYPE)
    delta_t_values = np.full(len(detector_runs), np.nan, dtype=DTYPE)

    fp_samples = 0
    fp_runs = 0
    total_pre_samples = 0
    earlier_count = 0
    valid_count = 0

    for i, (series, indices, onset, signal) in enumerate(
        zip(detector_runs, detector_indices, run_onsets, run_signals)
    ):
        trigger = np.zeros(NUM_SAMPLES, dtype=bool)
        trigger[indices] = persistent_bool(series > detector_threshold)

        rms = trailing_rms(signal, RMS_WINDOW)
        rms_threshold = float(np.mean(rms[:onset]) + 3.0 * np.std(rms[:onset]))
        rms_trigger = persistent_bool(rms > rms_threshold)

        t_detector = first_trigger_at_or_after(trigger, onset)
        t_rms = first_trigger_at_or_after(rms_trigger, onset)

        if t_detector is not None:
            delay_values[i] = float(t_detector - onset)
        if t_detector is not None and t_rms is not None:
            delta_t_values[i] = float(t_rms - t_detector)
            valid_count += 1
            if t_detector < t_rms:
                earlier_count += 1

        fp_count = int(np.sum(trigger[:onset]))
        fp_samples += fp_count
        fp_runs += int(fp_count > 0)
        total_pre_samples += onset

    finite_delay = delay_values[np.isfinite(delay_values)]
    finite_delta = delta_t_values[np.isfinite(delta_t_values)]

    return DetectorMetrics(
        mean_delay=float(np.mean(finite_delay)) if finite_delay.size else math.nan,
        median_delay=float(np.median(finite_delay)) if finite_delay.size else math.nan,
        mean_delta_t=float(np.mean(finite_delta)) if finite_delta.size else math.nan,
        median_delta_t=float(np.median(finite_delta)) if finite_delta.size else math.nan,
        earlier_pct_vs_rms=100.0 * earlier_count / max(valid_count, 1),
        fp_sample_rate=100.0 * fp_samples / max(total_pre_samples, 1),
        fp_run_rate=100.0 * fp_runs / len(detector_runs),
    )


def main() -> None:
    base_slope = calibrate_drift_slope()

    drift_signals: list[np.ndarray] = []
    drift_onsets: list[int] = []
    drift_feature_indices: list[np.ndarray] = []
    drift_features: list[np.ndarray] = []
    pre_onset_feature_blocks: list[np.ndarray] = []

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        signal, onset = generate_drift_signal(rng, base_slope)
        indices, features = extract_augmented_features(signal)
        pre_mask = indices < onset

        drift_signals.append(signal)
        drift_onsets.append(onset)
        drift_feature_indices.append(indices)
        drift_features.append(features)
        pre_onset_feature_blocks.append(features[pre_mask])

    all_pre_features = np.vstack(pre_onset_feature_blocks).astype(DTYPE, copy=False)
    mu_noise = np.mean(all_pre_features, axis=0)
    cov_noise = np.cov(all_pre_features, rowvar=False) + REG_COV * np.eye(
        all_pre_features.shape[1], dtype=DTYPE
    )
    inv_cov = np.linalg.pinv(cov_noise)

    noise_signals: list[np.ndarray] = []
    noise_indices_runs: list[np.ndarray] = []
    noise_d_runs: list[np.ndarray] = []

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + 10_000 + run_index)
        noise_signal = generate_noise_signal(rng)
        indices, features = extract_augmented_features(noise_signal)
        d_values = mahalanobis_series(features, mu_noise, inv_cov)
        noise_signals.append(noise_signal)
        noise_indices_runs.append(indices)
        noise_d_runs.append(d_values)

    all_noise_d = np.concatenate(noise_d_runs).astype(DTYPE, copy=False)
    k_ref = float(np.mean(all_noise_d))

    static_threshold, static_arl = calibrate_threshold_for_arl(noise_d_runs, noise_indices_runs)

    drift_d_runs: list[np.ndarray] = [
        mahalanobis_series(features, mu_noise, inv_cov) for features in drift_features
    ]

    static_metrics = compute_detector_metrics(
        drift_d_runs,
        drift_feature_indices,
        static_threshold,
        drift_onsets,
        drift_signals,
    )

    sequential_results: list[SequentialResult] = []

    for delta_factor in DELTA_FACTORS:
        delta_value = float(delta_factor * k_ref)
        bias = k_ref + delta_value
        noise_s_runs = [sequential_statistic(d_values, bias) for d_values in noise_d_runs]
        h_value, achieved_arl = calibrate_threshold_for_arl(noise_s_runs, noise_indices_runs)

        drift_s_runs = [sequential_statistic(d_values, bias) for d_values in drift_d_runs]
        metrics = compute_detector_metrics(
            drift_s_runs,
            drift_feature_indices,
            h_value,
            drift_onsets,
            drift_signals,
        )

        sequential_results.append(
            SequentialResult(
                delta_factor=delta_factor,
                delta_value=delta_value,
                h_value=h_value,
                achieved_arl=achieved_arl,
                metrics=metrics,
            )
        )

    feasible_results = [row for row in sequential_results if row.achieved_arl >= ARL_TARGET - 1e-6]
    selection_pool = feasible_results if feasible_results else sequential_results
    recommended = min(
        selection_pool,
        key=lambda row: (
            row.metrics.mean_delay if math.isfinite(row.metrics.mean_delay) else float("inf"),
            -row.metrics.earlier_pct_vs_rms,
            row.metrics.fp_sample_rate,
        ),
    )

    print("DMREDA Sequential Calibrated")
    print("============================\n")
    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES       : {NUM_SAMPLES}")
    print(f"FEATURE_WINDOW    : {FEATURE_WINDOW}")
    print(f"RMS_WINDOW        : {RMS_WINDOW}")
    print(f"N_RUNS            : {N_RUNS}")
    print(f"AR(1) rho         : {AR_COEFF:.2f}")
    print(f"Persistence       : {PERSISTENCE_K}")
    print(f"k reference       : {k_ref:.6f}")
    print(f"Static threshold  : {static_threshold:.6f}")
    print(f"Static ARL        : {static_arl:.2f}\n")

    print("ARL Table")
    print("---------")
    header_arl = f"{'delta_factor':>12} | {'delta':>12} | {'h':>12} | {'ARL':>10}"
    print(header_arl)
    print("-" * len(header_arl))
    for row in sequential_results:
        print(
            f"{row.delta_factor:12.2f} | {row.delta_value:12.6f} | "
            f"{row.h_value:12.6f} | {row.achieved_arl:10.2f}"
        )
    print()

    print("Delay Table")
    print("-----------")
    header_delay = (
        f"{'detector':>12} | {'delta':>12} | {'mean_delay':>12} | {'median_delay':>12} | "
        f"{'mean_delta_t':>12} | {'earlier_pct':>12} | {'fp_sample':>10} | {'fp_run':>8}"
    )
    print(header_delay)
    print("-" * len(header_delay))
    print(
        f"{'STATIC':>12} | {'-':>12} | {static_metrics.mean_delay:12.3f} | "
        f"{static_metrics.median_delay:12.3f} | {static_metrics.mean_delta_t:12.3f} | "
        f"{static_metrics.earlier_pct_vs_rms:12.2f} | {static_metrics.fp_sample_rate:9.4f}% | "
        f"{static_metrics.fp_run_rate:7.2f}%"
    )
    for row in sequential_results:
        metrics = row.metrics
        print(
            f"{'SEQUENTIAL':>12} | {row.delta_value:12.6f} | {metrics.mean_delay:12.3f} | "
            f"{metrics.median_delay:12.3f} | {metrics.mean_delta_t:12.3f} | "
            f"{metrics.earlier_pct_vs_rms:12.2f} | {metrics.fp_sample_rate:9.4f}% | "
            f"{metrics.fp_run_rate:7.2f}%"
        )
    print()

    print("Recommended Setting")
    print("-------------------")
    print(f"delta_factor : {recommended.delta_factor:.2f}")
    print(f"delta_value  : {recommended.delta_value:.6f}")
    print(f"h            : {recommended.h_value:.6f}")
    print(f"ARL          : {recommended.achieved_arl:.2f}")
    print(f"mean_delay   : {recommended.metrics.mean_delay:.3f}")
    print(f"median_delay : {recommended.metrics.median_delay:.3f}")
    print(f"earlier_pct  : {recommended.metrics.earlier_pct_vs_rms:.2f}%")
    print(f"fp_sample    : {recommended.metrics.fp_sample_rate:.4f}%")
    print(f"fp_run       : {recommended.metrics.fp_run_rate:.2f}%\n")

    print("SEQUENTIAL CALIBRATED")
    if (
        recommended.metrics.earlier_pct_vs_rms > static_metrics.earlier_pct_vs_rms
        and recommended.metrics.fp_sample_rate <= static_metrics.fp_sample_rate
    ):
        print("SEQUENTIAL MAHALANOBIS VALIDATED")
    else:
        print("SME NEEDS REFINEMENT")


if __name__ == "__main__":
    main()
