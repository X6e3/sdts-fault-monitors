from __future__ import annotations

import math

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 200

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
AR_COEFF = 0.9
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
SLOPE_JITTER_STD = 0.08

PERSISTENCE_K = 3
AMPLITUDE_JITTER = 0.05
TIME_JITTER = 0.10

LOW_FREQ_RATIO = 0.1

ORIGINAL_FEATURE_NAMES = (
    "run_length_mean",
    "sign_autocorr_lag1",
    "zero_cross_density",
    "local_monotonicity_ratio",
    "sign_variance",
    "trend_entropy",
)
NEW_FEATURE_NAMES = (
    "linreg_slope_mag",
    "norm_cumsum_mag",
    "low_freq_energy_ratio",
    "window_mean_drift",
)
AUGMENTED_FEATURE_NAMES = ORIGINAL_FEATURE_NAMES + NEW_FEATURE_NAMES


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(
    slope: float,
    onset: int,
    duration: int = DRIFT_DURATION,
    ramp_samples: int = RAMP_IN_SAMPLES,
) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    active_len = max(0, min(duration, NUM_SAMPLES - onset))
    if active_len == 0:
        return template

    k = np.arange(active_len, dtype=DTYPE)
    ramp_len = max(1, min(ramp_samples, active_len))
    values = np.empty(active_len, dtype=DTYPE)

    ramp_mask = k < ramp_len
    values[ramp_mask] = 0.5 * slope * (k[ramp_mask] ** 2) / ramp_len
    values[~ramp_mask] = slope * (k[~ramp_mask] - 0.5 * ramp_len)

    template[onset:onset + active_len] = values
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(
                trailing_rms(build_drift_template(mid, REFERENCE_DRIFT_START), RMS_WINDOW)[
                    reference_drift_mask()
                ]
            )
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float) -> float:
    return float(target_std * math.sqrt(1.0 - AR_COEFF**2))


def generate_ar1_noise(
    rng: np.random.Generator,
    target_std: float,
    size: int = NUM_SAMPLES,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    signal = np.empty(size, dtype=DTYPE)
    signal[0] = rng.normal(0.0, target_std)

    for i in range(1, size):
        signal[i] = AR_COEFF * signal[i - 1] + epsilon[i]

    return signal


def generate_noise_signal(rng: np.random.Generator) -> np.ndarray:
    return generate_ar1_noise(rng, NOISE_ONLY_STD)


def generate_drift_signal(
    rng: np.random.Generator,
    base_slope: float,
) -> tuple[np.ndarray, int, float]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))
    slope_scale = max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    slope = float(base_slope * slope_scale)
    signal = generate_ar1_noise(rng, EVENT_NOISE_STD)
    signal += build_drift_template(slope, onset)
    return signal.astype(DTYPE, copy=False), onset, slope


def sanitize_sign(values: np.ndarray) -> np.ndarray:
    signs = np.sign(values).astype(np.int8)
    if signs.size == 0:
        return signs

    nonzero = np.flatnonzero(signs)
    if nonzero.size == 0:
        signs[:] = 1
        return signs

    signs[: nonzero[0]] = signs[nonzero[0]]
    for i in range(nonzero[0] + 1, signs.size):
        if signs[i] == 0:
            signs[i] = signs[i - 1]

    return signs


def mean_run_length(signs: np.ndarray) -> float:
    if signs.size == 0:
        return 0.0

    lengths = []
    current = 1
    for i in range(1, signs.size):
        if signs[i] == signs[i - 1]:
            current += 1
        else:
            lengths.append(current)
            current = 1
    lengths.append(current)
    return float(np.mean(lengths))


def sign_autocorr_lag1(signs: np.ndarray) -> float:
    if signs.size < 2:
        return 0.0
    x = signs[:-1].astype(DTYPE)
    y = signs[1:].astype(DTYPE)
    x_centered = x - np.mean(x)
    y_centered = y - np.mean(y)
    denom = math.sqrt(float(np.sum(x_centered**2) * np.sum(y_centered**2))) + EPS
    return float(np.sum(x_centered * y_centered) / denom)


def zero_cross_density(signs: np.ndarray) -> float:
    if signs.size < 2:
        return 0.0
    crossings = np.sum(signs[1:] != signs[:-1])
    return float(crossings / (signs.size - 1))


def local_monotonicity_ratio(dx: np.ndarray) -> float:
    return float(abs(np.sum(dx)) / (np.sum(np.abs(dx)) + EPS))


def trend_entropy(signs: np.ndarray) -> float:
    _, counts = np.unique(signs, return_counts=True)
    probabilities = counts.astype(DTYPE) / np.sum(counts)
    entropy = -np.sum(probabilities * np.log2(probabilities + EPS))
    max_entropy = math.log2(len(probabilities)) if len(probabilities) > 1 else 1.0
    return float(entropy / max_entropy)


def linear_regression_slope(window: np.ndarray) -> float:
    n = window.size
    t = np.arange(n, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = window - np.mean(window)
    denom = float(np.sum(t_centered**2)) + EPS
    return float(np.sum(t_centered * y_centered) / denom)


def low_frequency_energy_ratio(window: np.ndarray) -> float:
    centered = window - np.mean(window)
    spectrum = np.fft.rfft(centered)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.size)))
    return float(np.sum(energy[:cutoff]) / (np.sum(energy) + EPS))


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy_val = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy_val,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def standardize(features: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    std_safe = np.where(std < 1e-6, 1.0, std)
    standardized = (features - mean) / std_safe
    return np.nan_to_num(standardized, nan=0.0, posinf=0.0, neginf=0.0)


def compute_mahalanobis_model(
    noise_signal: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    noise_indices, noise_features = extract_augmented_features(noise_signal)
    noise_mean = np.mean(noise_features, axis=0)
    noise_std = np.std(noise_features, axis=0)
    noise_standardized = standardize(noise_features, noise_mean, noise_std)
    noise_centroid = np.mean(noise_standardized, axis=0)

    centered_noise = noise_standardized - noise_centroid
    covariance = np.cov(centered_noise, rowvar=False) + 1e-6 * np.eye(
        noise_standardized.shape[1], dtype=DTYPE
    )
    inv_cov = np.linalg.pinv(covariance)

    noise_distance = mahalanobis_distance_series(noise_standardized, noise_centroid, inv_cov)
    threshold = float(np.quantile(noise_distance, 0.995))
    return noise_indices, noise_mean, noise_std, noise_centroid, inv_cov, threshold


def mahalanobis_distance_series(
    features_std: np.ndarray,
    centroid: np.ndarray,
    inv_cov: np.ndarray,
) -> np.ndarray:
    delta = features_std - centroid
    quadratic = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    quadratic = np.clip(quadratic, 0.0, None)
    return np.sqrt(quadratic)


def persistent_trigger_mask(exceeds: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    trigger = np.zeros_like(exceeds, dtype=bool)
    count = 0
    for i, flag in enumerate(exceeds):
        if flag:
            count += 1
            if count >= required:
                trigger[i] = True
        else:
            count = 0
    return trigger


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def histogram_text(values: np.ndarray, bins: int = 12) -> str:
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return "No finite delta_t values."

    counts, edges = np.histogram(finite, bins=bins)
    max_count = max(int(np.max(counts)), 1)
    lines = []
    for count, left, right in zip(counts, edges[:-1], edges[1:]):
        bar_len = int(round(40.0 * count / max_count))
        lines.append(f"{left:8.1f} .. {right:8.1f} | {count:3d} | {'#' * bar_len}")
    return "\n".join(lines)


def apply_amplitude_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    scale = 1.0 + rng.normal(0.0, AMPLITUDE_JITTER, size=signal.size).astype(DTYPE)
    return signal * scale


def apply_time_jitter(signal: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    t = np.arange(signal.size, dtype=DTYPE)
    offsets = rng.uniform(-TIME_JITTER, TIME_JITTER, size=signal.size).astype(DTYPE)
    jittered_t = np.clip(t + offsets, 0.0, signal.size - 1.0)
    return np.interp(t, jittered_t, signal).astype(DTYPE)


def detector_timeseries(
    noise_signal: np.ndarray,
    drift_signal: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    noise_rms = trailing_rms(noise_signal, RMS_WINDOW)
    drift_rms = trailing_rms(drift_signal, RMS_WINDOW)
    rms_threshold = float(np.mean(noise_rms) + 3.0 * np.std(noise_rms))

    noise_rms_trigger = persistent_trigger_mask(noise_rms > rms_threshold)
    drift_rms_trigger = persistent_trigger_mask(drift_rms > rms_threshold)

    noise_indices, noise_mean, noise_std, noise_centroid, inv_cov, mahal_threshold = compute_mahalanobis_model(
        noise_signal
    )
    noise_features = standardize(extract_augmented_features(noise_signal)[1], noise_mean, noise_std)
    drift_features = standardize(extract_augmented_features(drift_signal)[1], noise_mean, noise_std)

    noise_mahal = mahalanobis_distance_series(noise_features, noise_centroid, inv_cov)
    drift_mahal = mahalanobis_distance_series(drift_features, noise_centroid, inv_cov)

    noise_mahal_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
    drift_mahal_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
    noise_mahal_trigger[noise_indices] = persistent_trigger_mask(noise_mahal > mahal_threshold)
    drift_mahal_trigger[noise_indices] = persistent_trigger_mask(drift_mahal > mahal_threshold)

    return noise_rms_trigger, drift_rms_trigger, noise_mahal_trigger, drift_mahal_trigger, rms_threshold


def evaluate_detectors(
    noise_signal: np.ndarray,
    drift_signal: np.ndarray,
    onset: int,
) -> dict[str, float]:
    noise_rms_trigger, drift_rms_trigger, noise_mahal_trigger, drift_mahal_trigger, _ = detector_timeseries(
        noise_signal,
        drift_signal,
    )

    t_rms = first_trigger_at_or_after(drift_rms_trigger, onset)
    t_mahal = first_trigger_at_or_after(drift_mahal_trigger, onset)

    result = {
        "t_rms": math.nan if t_rms is None else float(t_rms),
        "t_mahal": math.nan if t_mahal is None else float(t_mahal),
        "delay_rms": math.nan if t_rms is None else float(t_rms - onset),
        "delay_mahal": math.nan if t_mahal is None else float(t_mahal - onset),
        "noise_rms_fp_samples": float(np.sum(noise_rms_trigger)),
        "noise_mahal_fp_samples": float(np.sum(noise_mahal_trigger)),
        "noise_rms_fp_run": float(np.any(noise_rms_trigger)),
        "noise_mahal_fp_run": float(np.any(noise_mahal_trigger)),
    }

    if t_rms is not None and t_mahal is not None:
        result["delta_t"] = float(t_rms - t_mahal)
    else:
        result["delta_t"] = math.nan

    return result


def stability_summary(base: np.ndarray, perturbed: np.ndarray) -> tuple[float, int]:
    mask = np.isfinite(base) & np.isfinite(perturbed)
    if not np.any(mask):
        return math.nan, 0
    return float(np.mean(np.abs(base[mask] - perturbed[mask]))), int(np.sum(mask))


def main() -> None:
    base_slope = calibrate_drift_slope()

    delta_t = np.full(N_RUNS, np.nan, dtype=DTYPE)
    t_rms = np.full(N_RUNS, np.nan, dtype=DTYPE)
    t_mahal = np.full(N_RUNS, np.nan, dtype=DTYPE)
    delay_rms = np.full(N_RUNS, np.nan, dtype=DTYPE)
    delay_mahal = np.full(N_RUNS, np.nan, dtype=DTYPE)
    true_onset = np.zeros(N_RUNS, dtype=np.int64)

    amp_t_rms = np.full(N_RUNS, np.nan, dtype=DTYPE)
    amp_t_mahal = np.full(N_RUNS, np.nan, dtype=DTYPE)
    amp_delta_t = np.full(N_RUNS, np.nan, dtype=DTYPE)

    time_t_rms = np.full(N_RUNS, np.nan, dtype=DTYPE)
    time_t_mahal = np.full(N_RUNS, np.nan, dtype=DTYPE)
    time_delta_t = np.full(N_RUNS, np.nan, dtype=DTYPE)

    rms_false_positive_runs = 0
    mahal_false_positive_runs = 0
    rms_false_positive_samples = 0
    mahal_false_positive_samples = 0
    total_noise_samples = N_RUNS * NUM_SAMPLES

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        noise_signal = generate_noise_signal(rng)
        drift_signal, onset, slope = generate_drift_signal(rng, base_slope)
        _ = slope
        true_onset[run_index] = onset

        base_result = evaluate_detectors(noise_signal, drift_signal, onset)
        t_rms[run_index] = base_result["t_rms"]
        t_mahal[run_index] = base_result["t_mahal"]
        delay_rms[run_index] = base_result["delay_rms"]
        delay_mahal[run_index] = base_result["delay_mahal"]
        delta_t[run_index] = base_result["delta_t"]

        rms_false_positive_runs += int(base_result["noise_rms_fp_run"])
        mahal_false_positive_runs += int(base_result["noise_mahal_fp_run"])
        rms_false_positive_samples += int(base_result["noise_rms_fp_samples"])
        mahal_false_positive_samples += int(base_result["noise_mahal_fp_samples"])

        amp_drift_signal = apply_amplitude_jitter(drift_signal, rng)
        amp_result = evaluate_detectors(noise_signal, amp_drift_signal, onset)
        amp_t_rms[run_index] = amp_result["t_rms"]
        amp_t_mahal[run_index] = amp_result["t_mahal"]
        amp_delta_t[run_index] = amp_result["delta_t"]

        time_drift_signal = apply_time_jitter(drift_signal, rng)
        time_result = evaluate_detectors(noise_signal, time_drift_signal, onset)
        time_t_rms[run_index] = time_result["t_rms"]
        time_t_mahal[run_index] = time_result["t_mahal"]
        time_delta_t[run_index] = time_result["delta_t"]

    finite_delta = delta_t[np.isfinite(delta_t)]
    mean_delta = float(np.mean(finite_delta)) if finite_delta.size else math.nan
    median_delta = float(np.median(finite_delta)) if finite_delta.size else math.nan
    earlier_fraction = 100.0 * float(np.mean(finite_delta > 0.0)) if finite_delta.size else 0.0

    mean_delay_rms = float(np.nanmean(delay_rms))
    mean_delay_mahal = float(np.nanmean(delay_mahal))

    rms_false_positive_sample_rate = 100.0 * rms_false_positive_samples / total_noise_samples
    mahal_false_positive_sample_rate = 100.0 * mahal_false_positive_samples / total_noise_samples
    rms_false_positive_run_rate = 100.0 * rms_false_positive_runs / N_RUNS
    mahal_false_positive_run_rate = 100.0 * mahal_false_positive_runs / N_RUNS

    amp_rms_shift, amp_rms_valid = stability_summary(t_rms, amp_t_rms)
    amp_mahal_shift, amp_mahal_valid = stability_summary(t_mahal, amp_t_mahal)
    amp_delta_shift, amp_delta_valid = stability_summary(delta_t, amp_delta_t)

    time_rms_shift, time_rms_valid = stability_summary(t_rms, time_t_rms)
    time_mahal_shift, time_mahal_valid = stability_summary(t_mahal, time_t_mahal)
    time_delta_shift, time_delta_valid = stability_summary(delta_t, time_delta_t)

    fp_acceptable = mahal_false_positive_sample_rate <= 1.0

    print("DMREDA Early Onset Test v2")
    print("==========================\n")

    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES           : {NUM_SAMPLES}")
    print(f"RMS_WINDOW            : {RMS_WINDOW}")
    print(f"FEATURE_WINDOW        : {FEATURE_WINDOW}")
    print(f"N_RUNS                : {N_RUNS}")
    print(f"AR(1) coefficient     : {AR_COEFF:.2f}")
    print(f"Persistence windows   : {PERSISTENCE_K}")
    print(f"Reference drift slope : {base_slope:.10f}")
    print(f"Drift onset range     : [{DRIFT_ONSET_MIN}, {DRIFT_ONSET_MAX}]")
    print(f"Ramp-in samples       : {RAMP_IN_SAMPLES}\n")

    print("Results")
    print("-------")
    print(f"Mean delta_t                          : {mean_delta:.3f}")
    print(f"Median delta_t                        : {median_delta:.3f}")
    print(f"Mahalanobis earlier than RMS          : {earlier_fraction:.2f}%")
    print(f"Mean RMS detection delay after onset  : {mean_delay_rms:.3f}")
    print(f"Mean Mahalanobis delay after onset    : {mean_delay_mahal:.3f}")
    print(f"RMS false positive sample rate        : {rms_false_positive_sample_rate:.3f}%")
    print(f"Mahalanobis false positive sample rate: {mahal_false_positive_sample_rate:.3f}%")
    print(f"RMS false positive run rate           : {rms_false_positive_run_rate:.2f}%")
    print(f"Mahalanobis false positive run rate   : {mahal_false_positive_run_rate:.2f}%")
    print(f"Valid delta_t runs                    : {finite_delta.size}/{N_RUNS}\n")

    print("Stability Under Amplitude Jitter")
    print("-------------------------------")
    print(f"RMS trigger shift mean   : {amp_rms_shift:.3f} samples ({amp_rms_valid} valid)")
    print(f"Mahalanobis shift mean   : {amp_mahal_shift:.3f} samples ({amp_mahal_valid} valid)")
    print(f"delta_t shift mean       : {amp_delta_shift:.3f} samples ({amp_delta_valid} valid)\n")

    print("Stability Under Time Jitter")
    print("---------------------------")
    print(f"RMS trigger shift mean   : {time_rms_shift:.3f} samples ({time_rms_valid} valid)")
    print(f"Mahalanobis shift mean   : {time_mahal_shift:.3f} samples ({time_mahal_valid} valid)")
    print(f"delta_t shift mean       : {time_delta_shift:.3f} samples ({time_delta_valid} valid)\n")

    print("delta_t histogram")
    print("-----------------")
    print(histogram_text(delta_t))
    print()

    if mean_delta > 0.0 and fp_acceptable:
        print("DMREDA v2 early advantage survives stress test")
    else:
        print("DMREDA v2 advantage not stable")


if __name__ == "__main__":
    main()
