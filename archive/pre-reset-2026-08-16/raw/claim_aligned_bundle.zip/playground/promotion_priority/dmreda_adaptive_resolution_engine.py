from __future__ import annotations

import math

import numpy as np


SEED = 7
NUM_SAMPLES = 10_000
TS = 1.0
DTYPE = np.float64
RMS_WINDOW = 32
FEATURE_WINDOW = 64
N_RUNS = 200

NOISE_ONLY_STD = 0.5
EVENT_NOISE_STD = 0.25
AR_COEFF = 0.9
EPS = 1e-12

BURST_START = 4_300
BURST_WIDTH = 192
BURST_AMPLITUDE = 1.2

REFERENCE_DRIFT_START = 3_200
REFERENCE_DRIFT_END = 4_800
DRIFT_DURATION = REFERENCE_DRIFT_END - REFERENCE_DRIFT_START
DRIFT_ONSET_MIN = 2_500
DRIFT_ONSET_MAX = 5_000
RAMP_IN_SAMPLES = 200
SLOPE_JITTER_STD = 0.08

PERSISTENCE_K = 3
Z_CLIP = 8.0
LOW_FREQ_RATIO = 0.1

REGIME_NOISE = 0
REGIME_ABRUPT = 1
REGIME_DRIFT = 2
REGIME_POSITION = 3
REGIME_LABELS = {
    REGIME_NOISE: "NOISE",
    REGIME_ABRUPT: "ABRUPT_EVENT",
    REGIME_DRIFT: "DRIFT_EVENT",
    REGIME_POSITION: "POSITION_SHIFT",
}


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=DTYPE)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=DTYPE)))
    rms = np.empty(signal.size, dtype=DTYPE)

    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)

    return rms


def build_burst_template() -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    half_width = BURST_WIDTH // 2
    template[BURST_START:BURST_START + half_width] = BURST_AMPLITUDE
    template[BURST_START + half_width:BURST_START + BURST_WIDTH] = -BURST_AMPLITUDE
    return template


def build_drift_template(
    slope: float,
    onset: int,
    duration: int = DRIFT_DURATION,
    ramp_samples: int = RAMP_IN_SAMPLES,
) -> np.ndarray:
    template = np.zeros(NUM_SAMPLES, dtype=DTYPE)
    active_len = max(0, min(duration, NUM_SAMPLES - onset))
    if active_len == 0:
        return template

    k = np.arange(active_len, dtype=DTYPE)
    ramp_len = max(1, min(ramp_samples, active_len))
    values = np.empty(active_len, dtype=DTYPE)

    ramp_mask = k < ramp_len
    values[ramp_mask] = 0.5 * slope * (k[ramp_mask] ** 2) / ramp_len
    values[~ramp_mask] = slope * (k[~ramp_mask] - 0.5 * ramp_len)

    template[onset:onset + active_len] = values
    return template


def burst_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[BURST_START:BURST_START + BURST_WIDTH] = True
    return mask


def reference_drift_mask() -> np.ndarray:
    mask = np.zeros(NUM_SAMPLES, dtype=bool)
    mask[REFERENCE_DRIFT_START:REFERENCE_DRIFT_END] = True
    return mask


def calibrate_drift_slope() -> float:
    target = float(np.mean(trailing_rms(build_burst_template(), RMS_WINDOW)[burst_mask()]))
    low = 0.0
    high = 0.02

    for _ in range(60):
        mid = 0.5 * (low + high)
        drift_rms = float(
            np.mean(
                trailing_rms(build_drift_template(mid, REFERENCE_DRIFT_START), RMS_WINDOW)[
                    reference_drift_mask()
                ]
            )
        )
        if drift_rms < target:
            low = mid
        else:
            high = mid

    return 0.5 * (low + high)


def ar1_epsilon_std(target_std: float) -> float:
    return float(target_std * math.sqrt(1.0 - AR_COEFF**2))


def generate_ar1_noise(
    rng: np.random.Generator,
    target_std: float,
    size: int = NUM_SAMPLES,
) -> np.ndarray:
    epsilon_std = ar1_epsilon_std(target_std)
    epsilon = rng.normal(0.0, epsilon_std, size=size).astype(DTYPE)
    signal = np.empty(size, dtype=DTYPE)
    signal[0] = rng.normal(0.0, target_std)

    for i in range(1, size):
        signal[i] = AR_COEFF * signal[i - 1] + epsilon[i]

    return signal


def generate_drift_signal(
    rng: np.random.Generator,
    base_slope: float,
) -> tuple[np.ndarray, int]:
    onset = int(rng.integers(DRIFT_ONSET_MIN, DRIFT_ONSET_MAX + 1))
    slope_scale = max(0.2, 1.0 + rng.normal(0.0, SLOPE_JITTER_STD))
    slope = float(base_slope * slope_scale)
    signal = generate_ar1_noise(rng, EVENT_NOISE_STD)
    signal += build_drift_template(slope, onset)
    return signal.astype(DTYPE, copy=False), onset


def extract_augmented_features(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, FEATURE_WINDOW).astype(DTYPE, copy=False)
    valid_indices = np.arange(FEATURE_WINDOW - 1, NUM_SAMPLES, dtype=np.int64)

    dx = np.diff(windows, axis=1)
    dx_signs = np.sign(dx).astype(DTYPE, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length_mean = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=DTYPE))

    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_centered = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_centered = x_next - np.mean(x_next, axis=1, keepdims=True)
    autocorr_denom = np.sqrt(
        np.sum(x_prev_centered**2, axis=1) * np.sum(x_next_centered**2, axis=1)
    ) + EPS
    sign_autocorr = np.sum(x_prev_centered * x_next_centered, axis=1) / autocorr_denom

    zero_cross = np.mean(changes, axis=1, dtype=DTYPE)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_variance = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=DTYPE)
    p_neg = 1.0 - p_pos
    trend_entropy = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    window_rms = np.sqrt(np.mean(windows**2, axis=1)) + EPS
    window_energy = np.sum(windows**2, axis=1) + EPS

    t = np.arange(FEATURE_WINDOW, dtype=DTYPE)
    t_centered = t - np.mean(t)
    y_centered = windows - np.mean(windows, axis=1, keepdims=True)
    slope = np.sum(y_centered * t_centered, axis=1) / (np.sum(t_centered**2) + EPS)

    cumulative = np.cumsum(windows, axis=1, dtype=DTYPE)
    norm_cumsum_mag = np.max(np.abs(cumulative), axis=1) / window_energy

    centered_windows = windows - np.mean(windows, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered_windows, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(windows, axis=1)) / window_rms

    features = np.column_stack(
        (
            run_length_mean,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_variance,
            trend_entropy,
            np.abs(slope) / window_rms,
            norm_cumsum_mag,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(DTYPE, copy=False)

    return valid_indices, features


def persistent_regime(regime_series: np.ndarray, required: int = PERSISTENCE_K) -> np.ndarray:
    persistent = np.zeros_like(regime_series, dtype=np.int8)
    run_regime = REGIME_NOISE
    run_count = 0

    for i, regime in enumerate(regime_series):
        if regime != REGIME_NOISE and regime == run_regime:
            run_count += 1
        elif regime != REGIME_NOISE:
            run_regime = int(regime)
            run_count = 1
        else:
            run_regime = REGIME_NOISE
            run_count = 0

        if run_count >= required:
            persistent[i] = run_regime

    return persistent


def first_trigger_at_or_after(mask: np.ndarray, start_index: int) -> int | None:
    indices = np.flatnonzero(mask)
    indices = indices[indices >= start_index]
    if indices.size == 0:
        return None
    return int(indices[0])


def safe_zscore(values: np.ndarray, mean: float, std: float) -> np.ndarray:
    denom = std if std >= 1e-6 else 1.0
    z = (values - mean) / denom
    return np.clip(z, -Z_CLIP, Z_CLIP)


def are_regime_series(signal: np.ndarray, onset: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    indices, features = extract_augmented_features(signal)
    pre_mask = indices < onset

    mu_noise = np.mean(features[pre_mask], axis=0)
    e_pos = np.linalg.norm(features - mu_noise, axis=1)

    velocity = np.zeros_like(features)
    velocity[1:] = features[1:] - features[:-1]
    e_vel = np.linalg.norm(velocity, axis=1)

    acceleration = np.zeros_like(features)
    acceleration[1:] = velocity[1:] - velocity[:-1]
    e_curv = np.linalg.norm(acceleration, axis=1) / (e_vel + EPS)

    mean_pos = float(np.mean(e_pos[pre_mask]))
    std_pos = float(np.std(e_pos[pre_mask]))
    mean_vel = float(np.mean(e_vel[pre_mask]))
    std_vel = float(np.std(e_vel[pre_mask]))
    mean_curv = float(np.mean(e_curv[pre_mask]))
    std_curv = float(np.std(e_curv[pre_mask]))

    z_pos = safe_zscore(e_pos, mean_pos, std_pos)
    z_vel = safe_zscore(e_vel, mean_vel, std_vel)
    z_curv = safe_zscore(e_curv, mean_curv, std_curv)

    regime = np.full(indices.size, REGIME_NOISE, dtype=np.int8)
    abrupt_mask = (z_curv > 4.0) & (z_curv > z_vel)
    drift_mask = (z_vel > 4.0) & (z_vel > z_curv)
    position_mask = (z_pos > 4.0) & ~(abrupt_mask | drift_mask)

    regime[abrupt_mask] = REGIME_ABRUPT
    regime[drift_mask] = REGIME_DRIFT
    regime[position_mask] = REGIME_POSITION

    persistent = persistent_regime(regime)
    return indices, persistent, z_pos, z_vel, z_curv


def evaluate_run(signal: np.ndarray, onset: int) -> dict[str, float]:
    are_indices, persistent_regimes, z_pos, z_vel, z_curv = are_regime_series(signal, onset)
    are_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
    are_trigger[are_indices] = persistent_regimes != REGIME_NOISE

    rms = trailing_rms(signal, RMS_WINDOW)
    rms_threshold = float(np.mean(rms[:onset]) + 3.0 * np.std(rms[:onset]))
    rms_exceeds = rms > rms_threshold
    rms_trigger = np.zeros(NUM_SAMPLES, dtype=bool)
    count = 0
    for i, flag in enumerate(rms_exceeds):
        if flag:
            count += 1
            if count >= PERSISTENCE_K:
                rms_trigger[i] = True
        else:
            count = 0

    t_are = first_trigger_at_or_after(are_trigger, onset)
    t_rms = first_trigger_at_or_after(rms_trigger, onset)

    post_mask = are_indices >= onset
    regime_counts = np.bincount(persistent_regimes[post_mask], minlength=4)
    dominant_regime = int(np.argmax(regime_counts[1:]) + 1) if np.sum(regime_counts[1:]) > 0 else REGIME_NOISE

    return {
        "t_are": math.nan if t_are is None else float(t_are),
        "t_rms": math.nan if t_rms is None else float(t_rms),
        "delta_t": math.nan if (t_are is None or t_rms is None) else float(t_rms - t_are),
        "delay_are": math.nan if t_are is None else float(t_are - onset),
        "delay_rms": math.nan if t_rms is None else float(t_rms - onset),
        "are_fp_samples": float(np.sum(are_trigger[:onset])),
        "rms_fp_samples": float(np.sum(rms_trigger[:onset])),
        "pre_samples": float(onset),
        "dominant_regime": float(dominant_regime),
        "mean_z_pos_post": float(np.mean(z_pos[post_mask])) if np.any(post_mask) else math.nan,
        "mean_z_vel_post": float(np.mean(z_vel[post_mask])) if np.any(post_mask) else math.nan,
        "mean_z_curv_post": float(np.mean(z_curv[post_mask])) if np.any(post_mask) else math.nan,
    }


def main() -> None:
    base_slope = calibrate_drift_slope()

    delta_t = np.full(N_RUNS, np.nan, dtype=DTYPE)
    delay_are = np.full(N_RUNS, np.nan, dtype=DTYPE)
    delay_rms = np.full(N_RUNS, np.nan, dtype=DTYPE)
    dominant_regimes = np.full(N_RUNS, REGIME_NOISE, dtype=np.int8)
    mean_z_pos_post = np.full(N_RUNS, np.nan, dtype=DTYPE)
    mean_z_vel_post = np.full(N_RUNS, np.nan, dtype=DTYPE)
    mean_z_curv_post = np.full(N_RUNS, np.nan, dtype=DTYPE)

    are_fp_samples = 0.0
    rms_fp_samples = 0.0
    total_pre_samples = 0.0

    for run_index in range(N_RUNS):
        rng = np.random.default_rng(SEED + run_index)
        signal, onset = generate_drift_signal(rng, base_slope)
        result = evaluate_run(signal, onset)

        delta_t[run_index] = result["delta_t"]
        delay_are[run_index] = result["delay_are"]
        delay_rms[run_index] = result["delay_rms"]
        dominant_regimes[run_index] = int(result["dominant_regime"])
        mean_z_pos_post[run_index] = result["mean_z_pos_post"]
        mean_z_vel_post[run_index] = result["mean_z_vel_post"]
        mean_z_curv_post[run_index] = result["mean_z_curv_post"]
        are_fp_samples += result["are_fp_samples"]
        rms_fp_samples += result["rms_fp_samples"]
        total_pre_samples += result["pre_samples"]

    finite_delta = delta_t[np.isfinite(delta_t)]
    mean_delta = float(np.mean(finite_delta)) if finite_delta.size else math.nan
    earlier_fraction = 100.0 * float(np.mean(finite_delta > 0.0)) if finite_delta.size else 0.0
    are_fp_rate = 100.0 * are_fp_samples / max(total_pre_samples, 1.0)
    rms_fp_rate = 100.0 * rms_fp_samples / max(total_pre_samples, 1.0)
    regime_hist = np.bincount(dominant_regimes, minlength=4)

    print("DMREDA Adaptive Resolution Engine")
    print("=================================\n")
    print("Configuration")
    print("-------------")
    print(f"NUM_SAMPLES       : {NUM_SAMPLES}")
    print(f"FEATURE_WINDOW    : {FEATURE_WINDOW}")
    print(f"RMS_WINDOW        : {RMS_WINDOW}")
    print(f"N_RUNS            : {N_RUNS}")
    print(f"AR(1) coefficient : {AR_COEFF:.2f}")
    print(f"Persistence       : {PERSISTENCE_K}")
    print(f"Z clip            : +/-{Z_CLIP:.1f}")
    print(f"Reference slope   : {base_slope:.10f}\n")

    print("Results")
    print("-------")
    print(f"Mean delta_t (RMS - ARE)       : {mean_delta:.3f}")
    print(f"ARE earlier than RMS           : {earlier_fraction:.2f}%")
    print(f"Mean ARE delay after onset     : {float(np.nanmean(delay_are)):.3f}")
    print(f"Mean RMS delay after onset     : {float(np.nanmean(delay_rms)):.3f}")
    print(f"ARE false positive sample rate : {are_fp_rate:.4f}%")
    print(f"RMS false positive sample rate : {rms_fp_rate:.4f}%")
    print(f"Mean post-onset Z_pos          : {float(np.nanmean(mean_z_pos_post)):.3f}")
    print(f"Mean post-onset Z_vel          : {float(np.nanmean(mean_z_vel_post)):.3f}")
    print(f"Mean post-onset Z_curv         : {float(np.nanmean(mean_z_curv_post)):.3f}")
    print(f"Valid delta runs               : {finite_delta.size}/{N_RUNS}\n")

    print("Dominant persistent regime counts")
    print("--------------------------------")
    for regime_id in (REGIME_NOISE, REGIME_ABRUPT, REGIME_DRIFT, REGIME_POSITION):
        print(f"{REGIME_LABELS[regime_id]:<15}: {int(regime_hist[regime_id])}")


if __name__ == "__main__":
    main()
