# Deprecated

These files are preserved for traceability only.

They are non-causal, leakage-prone, or otherwise unsafe for claim-grade evaluation.

Rule:

- do not use anything in this folder for detector claims
- do not benchmark against these files as if they were fair baselines
