import numpy as np

from gold_line.core.dmreda_reference import (
    DEFAULT_PROFILES,
    DEFAULT_TRANSITIONS,
    DMREDAProfile,
    DMREDAResult,
    RegimeTransition,
    compute_dmreda_reference,
)


def compute_dmreda(signal):
    """Legacy prototype score.

    This path is kept for backwards compatibility with the existing scripts.
    It is non-causal because both the median window and energy convolution use
    future samples.
    """

    n = len(signal)

    w1 = 11
    w2 = 32
    beta = 0.02

    mu = np.zeros_like(signal)
    half = w1 // 2

    for i in range(n):
        if i < half or i > n - half - 1:
            mu[i] = signal[i]
        else:
            mu[i] = np.median(signal[i - half : i + half + 1])

    e = np.abs(signal - mu)

    e_sum = np.convolve(e, np.ones(w2), mode="same")

    e_baseline = np.zeros_like(e_sum)
    e_baseline[0] = e_sum[0]

    for i in range(1, n):
        e_baseline[i] = beta * e_sum[i] + (1 - beta) * e_baseline[i - 1]

    e_baseline_safe = np.maximum(e_baseline, 1e-2)

    d = (e_sum - e_baseline_safe) / e_baseline_safe
    d = np.clip(d, -5, 5)

    return d


__all__ = [
    "DEFAULT_PROFILES",
    "DEFAULT_TRANSITIONS",
    "DMREDAProfile",
    "DMREDAResult",
    "RegimeTransition",
    "compute_dmreda",
    "compute_dmreda_reference",
]
