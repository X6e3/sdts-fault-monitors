"""Deprecated non-causal or claim-risk scripts."""
