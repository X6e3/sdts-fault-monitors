import numpy as np
from deprecated.core import compute_dmreda
from deprecated.detectors import rms_detector
from gold_line.support.signal_gen import generate_signal

# ======================================
# SETTINGS
# ======================================

N = 5000
noise_levels = [0.2, 0.3, 0.5]
amplitudes = [0.5, 0.8, 1.2, 1.5, 2.0]
disturbances = ["step", "ramp", "burst", "drift"]
seeds = range(30)

fp_target = 0.01

# ======================================
# UTILS
# ======================================

def measure_latency(trigger, disturb_idx):
    idx = np.where(trigger[disturb_idx:] == 1)[0]
    if len(idx) == 0:
        return np.nan
    return idx[0]

def detection_rate(latencies):
    return np.sum(~np.isnan(latencies)) / len(latencies)

def calibrate_threshold(score, disturb_idx):
    pre = score[:disturb_idx]
    return np.quantile(pre, 1 - fp_target)

# ======================================
# BENCHMARK
# ======================================

print("============== DMREDA BENCHMARK ==============")

for disturbance in disturbances:

    print(f"\n=== {disturbance.upper()} ===")

    for noise_std in noise_levels:

        print(f"\nNoise STD: {noise_std}")

        for amp in amplitudes:

            rms_lat = []
            dmr_lat = []

            for seed in seeds:

                signal, disturb_idx = generate_signal(
                    N,
                    disturbance,
                    amp,
                    noise_std,
                    seed
                )

                # ----- SCORES -----
                _, rms_score = rms_detector(signal)
                dmr_score = compute_dmreda(signal)

                # ----- Equal FP threshold -----
                rms_th = calibrate_threshold(rms_score, disturb_idx)
                dmr_th = calibrate_threshold(dmr_score, disturb_idx)

                # ----- Triggers -----
                rms_trigger = rms_score > rms_th
                dmr_trigger = dmr_score > dmr_th

                # ----- Latency -----
                rms_lat.append(measure_latency(rms_trigger, disturb_idx))
                dmr_lat.append(measure_latency(dmr_trigger, disturb_idx))

            rms_lat = np.array(rms_lat)
            dmr_lat = np.array(dmr_lat)

            print(f"\nAmplitude {amp}")
            print("RMS  mean:", np.nanmean(rms_lat),
                  "std:", np.nanstd(rms_lat),
                  "det_rate:", detection_rate(rms_lat))

            print("DMR  mean:", np.nanmean(dmr_lat),
                  "std:", np.nanstd(dmr_lat),
                  "det_rate:", detection_rate(dmr_lat))
