from dataclasses import dataclass

import numpy as np
from deprecated.core import compute_dmreda, compute_dmreda_reference


def _trailing_mean(values, window):

    csum = np.concatenate(([0.0], np.cumsum(values, dtype=float)))
    out = np.zeros(len(values), dtype=float)

    for t in range(len(values)):
        start = max(0, t - window + 1)
        count = t - start + 1
        out[t] = (csum[t + 1] - csum[start]) / count

    return out


def rms_detector(signal, window=100, threshold=2.5):

    rms = np.sqrt(np.convolve(signal**2,
                              np.ones(window)/window,
                              mode='same'))

    trigger = rms > threshold
    return trigger, rms


def rms_detector_causal(signal, window=100, threshold=2.5):

    rms = np.sqrt(_trailing_mean(signal**2, window))
    trigger = rms > threshold

    return trigger, rms


@dataclass
class RMSEventResult:
    score: np.ndarray
    confirmed: np.ndarray
    event_times: list
    threshold: float
    confirm_window: int
    refractory: int
    warmup_samples: int


def rms_event_detector_causal(
    signal,
    *,
    threshold,
    window=32,
    confirm_window=20,
    n_persist=6,
    refractory=80,
    warmup_samples=0,
):

    _, score = rms_detector_causal(signal, window=window, threshold=threshold)

    confirmed = np.zeros(len(score), dtype=bool)
    event_times = []

    pending = False
    pending_count = 0
    pending_elapsed = 0
    refractory_remaining = 0

    for t, value in enumerate(score):
        if refractory_remaining > 0:
            refractory_remaining -= 1

        if pending:
            pending_elapsed += 1
            pending_count += int(value > threshold)

            if pending_count >= n_persist:
                confirmed[t] = True
                if t >= warmup_samples:
                    event_times.append(t)
                refractory_remaining = refractory
                pending = False
                pending_count = 0
                pending_elapsed = 0
            elif pending_elapsed >= confirm_window:
                pending = False
                pending_count = 0
                pending_elapsed = 0

        if (not pending) and (refractory_remaining == 0) and (value > threshold):
            pending = True
            pending_count = 1
            pending_elapsed = 1

            if pending_count >= n_persist:
                confirmed[t] = True
                if t >= warmup_samples:
                    event_times.append(t)
                refractory_remaining = refractory
                pending = False
                pending_count = 0
                pending_elapsed = 0

    return RMSEventResult(
        score=score,
        confirmed=confirmed,
        event_times=event_times,
        threshold=threshold,
        confirm_window=confirm_window,
        refractory=refractory,
        warmup_samples=warmup_samples,
    )


def dmreda_detector(signal, threshold=0.2):

    D = compute_dmreda(signal)
    trigger = D > threshold

    return trigger, D


def dmreda_reference_detector(signal, threshold=None, **kwargs):

    result = compute_dmreda_reference(signal, **kwargs)
    if threshold is None:
        trigger = result.confirmed.copy()
    else:
        trigger = result.d > threshold

    return trigger, result
