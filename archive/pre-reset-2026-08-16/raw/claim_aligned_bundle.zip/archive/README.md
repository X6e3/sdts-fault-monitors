# Legacy Archive Map

The pre-finalization repository root is retained for provenance. No legacy
file was deleted or moved during finalization.

## Historical-only surfaces

- `.dmreda_run_backups/`: exploratory synthetic results, sweeps, plots, and
  diagnostic artifacts. They are not TEP claim evidence and do not recover the
  Stage 3.3 κ=2.5 selection lineage.
- `playground/`: experimental and diagnostic code.
- `deprecated/`: preserved obsolete implementations.
- `dmreda/` and root wrappers: compatibility paths, not canonical ownership.
- root result JSON/CSV/plot artifacts: prior experiments of mixed provenance.
- `gold_line/structural_manifold/`: a separate covariance/Mahalanobis/CUSUM
  family, not a version or port of canonical Core.
- external `dmreda-stage3-current-20260805.tar.gz`: quarantined ad-hoc snapshot;
  campaign source/test bytes differ from authoritative commit `7fb1fe26...`.

## Active and immutable surfaces

- `../current_claim/`: finalization engineering candidate and reports.
- `../experimental/finalization/`: spent-data ablations and state witnesses.
- `../frozen_history/`: immutable Stage 3.3 negative evidence and verified Git
  bundle.
- `../gold_line/core/dmreda_reference_clean.py`: historical canonical Core.

**[STRONG INFERENCE]** A later repository split should move historical-only
surfaces into a content-addressed archive after backup/retention approval. This
pass inventories them but deliberately preserves every byte.
