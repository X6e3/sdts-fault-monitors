# DMREDA Repo Audit: Playground Ranking

Static audit only. No network access. No benchmark results were recomputed for this report.

Ranking rule for this file:
- Top entries are the most scientifically valuable Playground artifacts and the closest to promotion.
- Lower entries are either scientifically weaker, claim-risky, or clearly offline-only diagnostics.
- Every scored file below failed at least one Gold Line criterion.

## Promotion-Priority Playground Files

### 1. `dmreda_fair_benchmark_v1.py`

Score: 19/25
- Causality: 5
- Calibration fairness: 4
- Event-level evaluation: 4
- Reproducibility: 5
- Portability alignment: 1

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- The manifold detector runtime still depends on FFT-derived features and covariance inversion: `np.fft.rfft` at `dmreda_fair_benchmark_v1.py:285`, `np.linalg.pinv` in `build_dmreda_model()` at `:420-466`.
- It is scientifically careful about fairness and ARL/FP matching, but the runtime path is not MCU-feasible as claimed.
- RMS is fairer than in older scripts, but the DMREDA-style branch is still a separate heavy manifold detector family, not the cleaned core detector.

What would promote it:
- Replace FFT `low_freq_energy_ratio` with the IIR low-pass energy proxy already shown in `dmreda_core_test.c`.
- Freeze whitening offline or reduce to diagonal robust scaling.
- Make the benchmark explicitly subordinate to the clean DMREDA core, or state clearly that it evaluates a separate manifold detector family.

---

### 2. `dmreda_sequential_calibrated.py`

Score: 18/25
- Causality: 5
- Calibration fairness: 4
- Event-level evaluation: 4
- Reproducibility: 4
- Portability alignment: 1

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- The detector family is statistically serious, but it centers and calibrates a Mahalanobis manifold path using `np.mean`, `np.cov`, and `np.linalg.pinv` at `dmreda_sequential_calibrated.py:407-411`.
- The sequential bias is still built from `k_ref = mean(D_noise)` and `bias = k_ref + delta` at `dmreda_sequential_calibrated.py:427` and `:446-447`, which is not robust enough for a Gold Line sequential standard.
- It is not the cleaned DMREDA core; it is a separate manifold detector benchmark.

What would promote it:
- Replace mean-based centering with robust centering and zero-drift validation under H0.
- Freeze or simplify whitening.
- Reposition it as a comparator benchmark, not as the repo's main deployable line.

---

### 3. `dmreda_early_onset_test_v2.py`

Score: 17/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 4
- Portability alignment: 2

Hard flags:
- `LEAKAGE`
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- Runtime feature path includes FFT and covariance inversion: `np.fft.rfft` at `dmreda_early_onset_test_v2.py:292`, `np.linalg.pinv` at `:333-336`.
- Thresholding uses noise-only percentiles from the same run context rather than a separate calibration bank: `threshold = float(np.quantile(noise_distance, 0.995))` at `dmreda_early_onset_test_v2.py:339`.
- It is a strong stress-test script, but not a benchmark-grade deployment claim path.

What would promote it:
- Split calibration into separate noise-only runs with explicit ARL targeting.
- Replace FFT/covariance runtime pieces with bounded embedded proxies.
- Keep it as a benchmark harness only after it consumes frozen detector constants.

---

### 4. `dmreda_fair_structural_benchmark.py`

Score: 17/25
- Causality: 5
- Calibration fairness: 4
- Event-level evaluation: 4
- Reproducibility: 4
- Portability alignment: 0

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- Strong benchmark discipline is visible, including ARL-style calibration at `dmreda_fair_structural_benchmark.py:290-312`.
- The runtime path still depends on FFT features and covariance inversion: `np.fft.rfft` at `:228`, `np.linalg.pinv` at `:392`.
- The script makes performance-comparison claims around a detector family that is not MCU-reduced.

What would promote it:
- Same minimal diff as the other manifold benchmarks: IIR low-frequency proxy, frozen/diagonal whitening, and explicit separation from the cleaned core line.

---

### 5. `dmreda_breaking_point_test.py`

Score: 17/25
- Causality: 5
- Calibration fairness: 3
- Event-level evaluation: 3
- Reproducibility: 5
- Portability alignment: 1

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- Useful boundary-mapping benchmark.
- Still uses FFT and covariance inversion in the runtime feature path: `np.fft.rfft` at `dmreda_breaking_point_test.py:233`, `np.cov` / `np.linalg.pinv` at `:314-317`.
- Good stress mapping, but not a deployable detector claim path.

What would promote it:
- Reduce the runtime feature path to frozen constants and bounded causal features.
- Keep the stress-sweep framing, but benchmark only a portable detector core.

---

### 6. `dmreda_sequential_mahalanobis_engine.py`

Score: 16/25
- Causality: 5
- Calibration fairness: 3
- Event-level evaluation: 4
- Reproducibility: 4
- Portability alignment: 0

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- It has proper sequential accumulation and persistence logic: `persistent_bool()` / `sequential_statistic()` at `dmreda_sequential_mahalanobis_engine.py:214-241`.
- It still depends on FFT-derived features and covariance inversion: `np.fft.rfft` at `:189`, `np.linalg.pinv` at `:274`.
- It is a separate detector family from the DMREDA core.

What would promote it:
- Freeze the manifold transform offline.
- Replace the runtime feature stack with bounded embedded approximations.
- Narrow the claim to "comparator engine" unless it becomes a true portable runtime.

---

### 7. `dmreda_covariance_manifold_engine.py`

Score: 15/25
- Causality: 5
- Calibration fairness: 3
- Event-level evaluation: 4
- Reproducibility: 3
- Portability alignment: 0

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- Uses rolling covariance and eigenvalue structure in the runtime path: local covariance at `dmreda_covariance_manifold_engine.py:241-251`, anisotropy detection at `:279`.
- FFT-derived features remain in the upstream feature extractor: `np.fft.rfft` at `:190`.
- This is far from MCU-feasible without redesign.

What would promote it:
- Not a minimal-diff promotion. The covariance/eigen pipeline would need to be replaced with a bounded anisotropy proxy.
- Treat as research-only until then.

---

### 8. `dmreda_directional_manifold_engine.py`

Score: 15/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 3
- Portability alignment: 1

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- Uses vector-norm dynamics over augmented features: `np.linalg.norm` at `dmreda_directional_manifold_engine.py:275` and `:283`.
- FFT feature extraction remains upstream at `:201`.
- Detection logic is deterministic, but the runtime manifold is too heavy for the stated embedded target.

What would promote it:
- Keep only the directional-coherence concept.
- Re-express it over a much smaller bounded feature set computed without FFT.

---

### 9. `dmreda_adaptive_resolution_engine.py`

Score: 15/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 3
- Portability alignment: 1

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- The ARE concept is deterministic, but it is built on vector norms over manifold position/velocity/curvature: `np.linalg.norm` at `dmreda_adaptive_resolution_engine.py:265-273`.
- FFT feature extraction remains upstream at `:200`.
- This is a new engine family, not the stabilized DMREDA line.

What would promote it:
- Freeze the engine as an offline analysis prototype or reduce it to a very small scalar regime controller.
- Do not mix it with Gold Line DMREDA claims until portability is demonstrated.

---

### 10. `dmreda_manifold_curvature_test.py`

Score: 15/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 3
- Portability alignment: 1

Hard flags:
- `HEAVY_RUNTIME`
- `CLAIM_RISK`

Why it is not Gold Line:
- Curvature-on-feature-manifold is deterministic, but the feature extractor still uses FFT (`dmreda_manifold_curvature_test.py:189`) and vector norms (`:255-256`).
- It is useful as a regime-shift hypothesis test, not as a portable detector claim.

What would promote it:
- Reduce curvature to a bounded scalar proxy over a small causal feature set.
- Keep it as a secondary comparator, not the main repo line.

---

### 11. `dmreda/dmreda.v2.py`

Score: 13/25
- Causality: 2
- Calibration fairness: 2
- Event-level evaluation: 3
- Reproducibility: 3
- Portability alignment: 3

Hard flags:
- `NON_CAUSAL`
- `CLAIM_RISK`

Why it is not Gold Line:
- It imports the legacy non-causal `compute_dmreda()` path through `core.py`.
- It includes fallback detector implementations and a heuristic `event_postprocess()` at `dmreda/dmreda.v2.py:112`, which makes it a compatibility sandbox rather than a canonical line.

What would promote it:
- Remove all fallback logic.
- Import only `dmreda_reference_clean.py`.
- Delete the legacy non-causal score path from its dependency chain.

---

### 12. `benchmark.py`

Score: 8/25
- Causality: 1
- Calibration fairness: 1
- Event-level evaluation: 1
- Reproducibility: 2
- Portability alignment: 3

Hard flags:
- `LEAKAGE`
- `NON_CAUSAL`
- `CLAIM_RISK`

Why it is not Gold Line:
- It uses the legacy non-causal `compute_dmreda()` and non-causal RMS path (`benchmark.py:65-66`).
- Thresholds are calibrated from the same event trace pre-onset region (`benchmark.py:31-33`).
- It counts first threshold crossing latency only; there is no event gate, no refractory, and no ARL.

What would promote it:
- Promotion is not worth the diff. Replace this script entirely with `benchmark_reference.py` or `validation_sweep.py`.

## OFFLINE DIAGNOSTIC ONLY

These files are useful for exploration or attribution, but they should not be used for deployable claims. They should eventually live under `playground/` and carry the header `# OFFLINE_ANALYSIS_ONLY`.

| file | score /25 | hard flags | why not Gold | promotion path |
|---|---:|---|---|---|
| `compare_rms_cbdd.py` | 12 | `ML_IMPORT`, `HEAVY_RUNTIME`, `CLAIM_RISK` | Imports `LinearDiscriminantAnalysis` at `compare_rms_cbdd.py:13`; also uses FFT, covariance inverse, PCA-style geometry. | Do not promote as-is. Strip sklearn and runtime-heavy geometry or keep offline only. |
| `curvature_diagnostics.py` | 11 | `ML_IMPORT`, `HEAVY_RUNTIME` | sklearn ROC import at `curvature_diagnostics.py:7`, matrix inverse at `:25-26`, ROC thresholding at `:109-117`. | Keep as offline trigger attribution only. |
| `ramp_diagnostics.py` | 10 | `ML_IMPORT`, `HEAVY_RUNTIME` | Imports `PCA`, `mutual_info_regression`, `StandardScaler` at `ramp_diagnostics.py:8-10`. | Keep offline only; do not cite for detector claims. |
| `signed_area_diagnostics.py` | 10 | `ML_IMPORT`, `SAMPLE_ROC_ONLY` | sklearn ROC/AUC only. | Offline only. |
| `signed_area_robustness.py` | 10 | `ML_IMPORT`, `SAMPLE_ROC_ONLY` | Offline separability/AUC study using sklearn metrics. | Offline only. |
| `coupled_score_analysis.py` | 10 | `ML_IMPORT`, `SAMPLE_ROC_ONLY` | Coupled-score ROC study only. | Offline only. |
| `roc_test.py` | 4 | `ML_IMPORT`, `SAMPLE_ROC_ONLY`, `NON_CAUSAL` | Uses sklearn ROC directly on non-causal `compute_dmreda()` and non-causal RMS (`roc_test.py:2-5`, `:26-30`). | Do not promote. Replace with event-level benchmark logic. |
| `roc_cusum_test.py` | 5 | `ML_IMPORT`, `SAMPLE_ROC_ONLY` | Sample ROC only. | Do not promote. |
| `score_analysis.py` | 4 | `CLAIM_RISK` | Histogram/Cohen's d only; no event logic or fair calibration. | Keep only as quick descriptive analysis. |

## Legacy and Superseded Claim-Risk Files

| file | score /25 | hard flags | why not Gold | minimal-diff promotion |
|---|---:|---|---|---|
| `core.py` | 7 | `NON_CAUSAL` | Explicitly labels `compute_dmreda()` as non-causal because median and convolution use future samples (`core.py:13-19`). | None. Deprecate and stop importing it in claim scripts. |
| `detectors.py` | 11 | `NON_CAUSAL`, `CLAIM_RISK` | Mixes non-causal `rms_detector()` with causal wrappers; threshold-only `dmreda_detector()` is not benchmark-grade. | Keep only `rms_event_detector_causal()` and deprecate the rest. |
| `dmreda_early_onset_test.py` | 15 | `LEAKAGE`, `HEAVY_RUNTIME`, `CLAIM_RISK` | Uses FFT features and covariance inversion; threshold from in-run noise quantile (`dmreda_early_onset_test.py:253`, `:301`, `:311`). | Separate noise-bank calibration and bounded runtime features. |

## ATRE v1 Family

These are useful concept-stage scripts, but they are not Gold because they rely on threshold heuristics, sample exceedance logic, or uncalibrated Monte Carlo summaries.

| file | score /25 | hard flags | note |
|---|---:|---|---|
| `atre v1/atre_final_test.py` | 12 | `CLAIM_RISK` | CUSUM-style final test, but hard-coded `k` and `h`; no ARL calibration. |
| `atre v1/atre_ar_montecarlov2.1.py` | 11 | `CLAIM_RISK` | Useful sweep, but threshold is still `mu + k_sigma * sigma` on evaluated runs. |
| `atre v1/atre_ar_robustness.py` | 10 | `CLAIM_RISK` | AR order robustness scan; false alarms are boolean threshold crossings. |
| `atre v1/atre_ar_montecarlov2.py` | 10 | `CLAIM_RISK` | Monte Carlo with sample false-alarm rate only. |
| `atre v1/atre_ar_montecarlo.py` | 9 | `CLAIM_RISK` | Fixed threshold `pre_mean * 3`; no calibrated alarm semantics. |
| `atre v1/atre_glr_test.py` | 8 | `CLAIM_RISK` | Quantile threshold on `max(glr)` without event gate or ARL matching. |
| `atre v1/atre_ar_sim.py` | 6 | `OFFLINE_DIAGNOSTIC_ONLY` | Visualization-first concept simulation. |
| `atre v1/atre_v1_sim.py` | 6 | `OFFLINE_DIAGNOSTIC_ONLY` | Earliest concept-stage simulation; not a benchmark harness. |

## Bottom Line

- The Playground tier is not junk. The top entries are serious research artifacts.
- The promotion frontier is clear:
  - keep causality
  - remove leakage
  - standardize event-level ARL calibration
  - freeze or simplify heavy manifold runtime operations
- The biggest immediate demotion signals are:
  - same-trial pre-onset calibration
  - sample ROC/AUC in place of event FP
  - non-causal `compute_dmreda()`
  - any sklearn import in a claim-adjacent script
