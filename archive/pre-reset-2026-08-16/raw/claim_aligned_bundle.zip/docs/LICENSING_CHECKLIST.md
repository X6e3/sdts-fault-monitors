# Licensing Checklist

## Publication status

**BLOCKED.** The imported source checkpoint has no repository-level license,
citation file, or documented dataset redistribution grant. Nothing in this
checklist grants permission to publish. A checked item must be supported by a
recorded source, reviewer, date, and decision.

## Code ownership and license

- [ ] Select a code license that covers the canonical Python and C sources.
- [ ] Add the complete license text as root `LICENSE`.
- [ ] Decide whether SPDX identifiers are required in source files.
- [ ] Identify the owner or authorized licensor of every canonical source file.
- [ ] Review contributor permission where a file has more than one author.
- [ ] Review copied or adapted algorithms and code for third-party obligations.
- [ ] Confirm that compatibility wrappers may be redistributed under the same
      terms as their canonical targets.
- [ ] Record the disposition of historical code that is intentionally excluded
      from the public export.

## Dataset and derived-result rights

- [ ] Identify the authoritative PQD-16c source, owner, dataset version, and
      citation.
- [ ] Record the dataset license or terms of use from an authoritative source.
- [ ] Determine whether the dataset archive may be redistributed.
- [ ] Determine whether waveform subsets, cached archives, golden data, plots,
      tables, and aggregate benchmark results are derivative works subject to
      dataset restrictions.
- [ ] Record any attribution, notice, or citation required in a publication.
- [ ] Confirm that automated download through Kaggle complies with the dataset
      and Kaggle terms applicable at publication time.
- [ ] Exclude all dataset archives until every preceding item is resolved.

The local file named `pqd16c.zip` audited during Stage 2 is not accepted as the
scientific dataset. It contains one numeric member named `dummy.csv`, has no
license or README member, and is classified only as an internal synthetic smoke
fixture. It must not be published or described as PQD-16c validation data.

## Dependencies and bundled material

- [x] Pin Python, NumPy, SciPy, Matplotlib, and Kaggle versions in the clean
      reproducibility environment. The direct pins and tested 25-distribution
      freeze are recorded under `repro/structural_manifold/`.
- [ ] Add package artifact hashes or a hash-locked resolver output for the
      tested platform; exact installed versions alone do not authenticate the
      artifacts.
- [ ] Record the license and notice requirements for every pinned dependency and
      transitive dependency.
- [ ] Confirm that no virtual environment, wheel cache, compiled extension,
      shared library, font bundle, or package test data enters the export.
- [ ] Include required third-party notices without copying an embedded
      environment.
- [ ] Review compiler/runtime redistribution obligations for any distributed
      executable. The current public export must contain no executable binary.

## Fixtures, documentation, and generated artifacts

- [ ] Record the generator, input provenance, configuration hash, and reviewer
      for each immutable golden fixture.
- [ ] Confirm that each fixture can be redistributed independently of a private
      or restricted dataset.
- [ ] Review documentation figures, screenshots, and tables for third-party or
      personal content.
- [ ] Preserve negative findings while excluding raw private or restricted
      inputs.
- [ ] Mark synthetic smoke output distinctly from engineering validation and
      scientific evidence.

## Identity, citation, and provenance

- [ ] Obtain a verified author name and verified email or GitHub noreply address
      for future public commits.
- [ ] Add `CITATION.cff` with the approved author list and project citation.
- [ ] Record the immutable source archive hash and internal source checkpoint.
- [ ] Record the complete Stage 2 commit list without rewriting imported
      history.
- [ ] Document which artifacts were excluded and why.
- [ ] Obtain final approval of `docs/PUBLIC_PROVENANCE.md` from the authorized
      project owner.

## Release gate

Before publication, all of the following must be true:

1. The code license, dataset decision, author identity, citation, and provenance
   items above are resolved.
2. The export was produced only from `PUBLIC_EXPORT_MANIFEST.txt` and contains
   nothing matched by `PUBLIC_EXPORT_EXCLUSIONS.txt`.
3. A redacted secret/path/identity scan and a binary/large-file scan pass on the
   exact export tree and its proposed public Git history.
4. The exported source and reproducibility package pass their documented tests
   in a clean environment.
5. An export SHA-256 manifest is stored with the release record.

Approval record:

```text
Code-license decision:       UNRESOLVED
Dataset-license decision:    UNRESOLVED
Verified author decision:    UNRESOLVED
Citation review:             UNRESOLVED
Provenance review:           UNRESOLVED
Final publication approval:  UNRESOLVED
```
