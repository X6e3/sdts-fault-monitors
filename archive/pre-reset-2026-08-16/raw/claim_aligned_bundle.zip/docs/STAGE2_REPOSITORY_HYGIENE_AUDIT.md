# Stage 2 Repository Hygiene Audit

## Audit checkpoint and scope

```text
Audit date:       2026-08-03
Starting commit:  145277854ecbd1a8ded8ca2667680cb415d9f8bf
Branch:           fix/dmreda-stage2-evaluation-integrity
Method:           read-only inventory and redacted heuristic content scan
```

The audit covered tracked source, ignored generated output, the internal backup,
the embedded historical environment, dataset-cache discovery, Git identity,
large/binary files, licensing files, and publication manifests. No file was
deleted, moved, rewritten, or published during the audit.

## Secret and credential scan

The redacted heuristic scan found:

- no private-key header;
- no AWS, GitHub, or Slack token pattern;
- no generic credential assignment containing a value;
- no private email address in repository file content;
- no `kaggle.json` or repository credential file;
- one variable-name-only Kaggle credential reference in the imported
  Structural Manifold prerequisite text;
- no supplied legacy hostname/email string in the imported worktree.

The active benchmark no longer advertises credential variables at import time
and imports Kaggle only inside the explicit download path. The final active-tree
scan found only the test that deliberately removes `KAGGLE_USERNAME` and
`KAGGLE_KEY` before the no-authentication check, plus filename/policy references
to `kaggle.json`; no credential values were found.

This result is limited to the patterns and readable files inspected. It is not a
guarantee that no secret exists. Before publication, run a dedicated secret
scanner against the exact allowlisted tree and its proposed public Git history.
Scanner logs must redact values and report only path, line, and category.

## Absolute machine paths

The canonical Core and Structural Manifold packages contain no absolute user
path. Nineteen redacted absolute macOS user-path occurrences remain in thirteen
noncanonical source files:

```text
gold_line/near_gold_todo/dmreda_delay_benchmark_v2.py:53
playground/offline_diagnostic_only/dmreda_behavior_probe.py:57
playground/offline_diagnostic_only/dmreda_disturbance_topology_benchmark.py:50-51
playground/offline_diagnostic_only/dmreda_equal_fa_recalibrated_sweep.py:22
playground/offline_diagnostic_only/dmreda_feature_space_benchmark.py:43
playground/offline_diagnostic_only/dmreda_operating_map_analysis.py:30
playground/offline_diagnostic_only/dmreda_structural_change_benchmark.py:6-7,27-28
playground/offline_diagnostic_only/pre_threshold_divergence_accel_ramp.py:21
playground/offline_diagnostic_only/pre_threshold_divergence_burst.py:22
playground/offline_diagnostic_only/raw_shape_comparison_accel_ramp.py:19
playground/offline_diagnostic_only/rms_matched_structural_onset_test.py:51-52
playground/offline_diagnostic_only/rms_matched_structural_onset_test_v2.py:56-57
playground/promotion_priority/dmreda_fair_benchmark_v1.py:41
```

Generated results and logs contain 193 additional path lines across 38 files;
the backup contains 58 across five files. These values were not copied into this
report. The affected experimental trees and generated artifacts are excluded
from public export. If a script is later promoted, its output path must become
repository-relative or CLI-owned and import-time directory creation must be
removed.

## Size, environment, cache, and binary inventory

Observed at the audit checkpoint:

```text
Tracked files:                         187
Tracked backup files:                  96
Tracked backup bytes:                  44,776,597
Tracked generated PNG files:           64
Tracked generated JSON/CSV files:      32
Embedded historical environment:       8,697 files, approximately 262 MiB
Ignored generated results:             approximately 44 MiB
Byte-identical result/backup copies:    101 files, approximately 43.5 MiB
```

The internal backup includes an arm64 Mach-O executable at
`.dmreda_run_backups/20260311_054101/results/dmreda_core_test`. An ignored copy
also exists under `results/`. Binary string inspection found no absolute user
path, email-like string, or supplied legacy hostname, but the executable remains
machine-specific generated output and is excluded.

The embedded environment contains platform-specific compiled extensions,
shared libraries, package caches, and thousands of machine-path records. It is
ignored internally and must not be used to build or populate the clean
reproducibility package.

Python caches and OS/editor artifacts were also present but ignored. The current
`.gitignore` covers root results, PQD caches, the old environment, Python caches,
editor noise, and logs. It does not make an already-tracked backup safe for
publication and does not replace the public allowlist.

## Dataset-cache finding

The canonical module searches `<repository>/pqd16c_cache/pqd16c.zip`, while the
only local archive was under the ignored generated-results cache. The local
archive contains only `dummy.csv`, has no license member, and matches the hash
recorded by an existing one-run output. It is classified as an internal
synthetic smoke fixture, not the PQD-16c dataset. Both the archive and generated
outputs are excluded from publication.

## Backups and historical artifacts

The tracked backup, generated results, deprecated experiments, compatibility
paths, archived negative findings, and historical binary are preserved in the
internal research history. Stage 2 does not delete, untrack, or rewrite them.

Public export is a distinct allowlisted tree. In particular:

- tracked internal artifacts remain available for audit and rollback;
- no backup, result, cache, environment, archive, or executable crosses the
  public boundary;
- excluding an artifact does not reinterpret a failed or negative experiment;
- `.gitignore` is not relied upon as a publication boundary.

## Licensing and author identity

No root license, citation file, provenance manifest, or dataset license record
was present at audit start. Publication remains blocked under
`docs/LICENSING_CHECKLIST.md`.

The imported working history contains one source-snapshot commit using a
local-invalid audit identity. The supplied legacy author string is not present
in this imported history. Existing authorship must not be rewritten. A verified
address or GitHub noreply address must be selected for future public-facing
commits, and that decision must be recorded before export.

## Public-export decision

Use `PUBLIC_EXPORT_MANIFEST.txt` as an allowlist and
`PUBLIC_EXPORT_EXCLUSIONS.txt` as a fail-closed exclusion layer. Publication is
blocked until all of these are satisfied:

1. code and dataset licensing decisions are documented;
2. a verified public author identity and citation are approved;
3. package artifact hashes are added to the otherwise validated clean pinned
   environment, and the reproducibility package passes again from those
   authenticated artifacts;
4. dataset-dependent claims reference a licensed archive hash, not the dummy
   cache;
5. the exact export passes redacted secret/path/metadata, binary, archive, and
   large-file scans;
6. the final Stage 2 commit list and export SHA-256 manifest are recorded.

## Audit limitations

- The scan was heuristic and did not substitute for a dedicated secret scanner.
- No network access was used to verify current Kaggle terms or dataset license.
- No historical embedded environment was activated.
- No complete scientific dataset run was performed.
- Dependency versions were frozen, but downloaded package artifact hashes were
  not captured.
- A generated artifact's filename or existing hash does not establish its
  scientific validity.
