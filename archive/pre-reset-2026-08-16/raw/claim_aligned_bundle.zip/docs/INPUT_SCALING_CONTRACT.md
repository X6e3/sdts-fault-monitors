# DMREDA Core FSM Input Scaling Contract

## Contract

The canonical Core FSM consumes a finite one-dimensional stream in one fixed,
externally calibrated unit system:

```text
x_core[t] = (x_raw[t] - offset_fixed) / scale_fixed
```

`scale_fixed` is finite and positive. `offset_fixed` and `scale_fixed` are
chosen before the evaluated stream begins from sensor calibration, a training
partition, or a dedicated noise-only calibration bank. They remain unchanged
for the complete capture and for every trace compared under one frozen profile.

`apply_fixed_input_scale()` implements only this affine transformation. It does
not estimate parameters.

## What is forbidden

- fitting offset or scale on the evaluated trace;
- using future samples to normalize earlier samples;
- per-event or per-scenario rescaling;
- mixing sensor units under one threshold/profile without an explicit conversion;
- silently changing ADC gain, physical units, or preprocessing between calibration and evaluation.

## Why this is required

`D` is normalized by the adaptive energy baseline, but the regime signal `r`
is derived from raw absolute deviation and `e_floor` is expressed in input
units. The complete FSM is therefore not globally amplitude-scale invariant.
Changing raw amplitude without updating the fixed external calibration can
change regime transitions, confirmation timing, and event count.

This is an explicit design constraint, not a claim of scale invariance.

## Required run metadata

- raw sensor unit and conversion;
- fixed offset and scale;
- calibration source identifier and hash;
- ADC range/gain or upstream digital gain;
- Core FSM profile/configuration hash;
- clipping/saturation policy;
- missing/non-finite sample policy.

The current reference rejects NaN and infinity. Saturation and missing-sample
recovery remain caller responsibilities.
