# Public Provenance Record

## Publication status

**BLOCKED.** This record identifies the imported checkpoint, but final Stage 2
commits, licensing, citation, and verified public author identity remain release
gates.

## Immutable input

```text
Archive name:       dmreda-stabilized-source.zip
Archive SHA-256:    323ca1e18bea5522ff3df5822735d3a0c626f0c2765b33edad61157689153b63
Archive source root: vscode/
Input policy:       immutable; never modified or overwritten
```

The archive was extracted to an isolated working copy. Git history was created
for the audit because the supplied checkpoint did not provide usable upstream
commit provenance in the working copy.

## Internal Git checkpoint

```text
Starting commit: 145277854ecbd1a8ded8ca2667680cb415d9f8bf
Starting subject: chore: import immutable stabilized source snapshot
Stage 2 branch:  fix/dmreda-stage2-evaluation-integrity
Imported commits visible at audit start: 1
```

The import commit uses a local-invalid audit identity. Existing history must not
be amended, squashed, or rewritten to manufacture upstream provenance. Future
public-facing commits require a separately verified address or GitHub noreply
address. The complete final Stage 2 commit list must be copied from the final
Stage 2 report into the release record after the last implementation commit and
before export. Keeping this field unresolved inside an in-progress commit
avoids a self-referential or incomplete provenance list.

After the project owner verifies the chosen identity, configure future commits
locally without altering existing commits:

```bash
git config --local user.name "Can Koç"
git config --local user.email "<verified-address-or-GitHub-noreply-address>"
```

The placeholder must never be committed literally, and no address should be
guessed from machine metadata.

## Canonical authority boundaries

- DMREDA Core FSM authority belongs to
  `gold_line/core/dmreda_reference_clean.py`.
- The fixed C99 source is a declared subset mirror under `gold_line/core/`; it
  does not expand the Core FSM claim beyond its tested subset.
- `gold_line/structural_manifold/` is a separate Structural Manifold research
  family. Its compatibility filenames are not Core FSM implementations.
- Historical, playground, near-gold, backup, and generated-result trees remain
  preserved internally but are not public claim authority.

## Dataset checkpoint found during audit

The only local file named as a PQD cache was found below the ignored generated
results tree, not at the canonical cache path:

```text
Archive SHA-256: 002e1ddb8bf71d7772daf450f6710c6df7c6ab1fd385a3ef6ada784f65c16a4a
Member count:    1
Member name:     dummy.csv
Member SHA-256:  4d8a636c3e808de6d803f2355e38b04b08992b858bf074f728e3d2e1ff7bd638
Member shape:    1280 rows, one numeric column
License member:  none
```

Existing one-run output records the same archive hash. This establishes only
the provenance of an internal synthetic smoke run. It is not evidence that the
complete PQD-16c dataset was available, and it must not be described as a PQD
scientific benchmark. The cached archive and all derived generated output are
excluded from public export pending dataset provenance and licensing.

## Preservation and export policy

Internal preservation and public publication are separate operations:

- The immutable source archive, tracked backup results, compiled historical
  binary, deprecated environment, exploratory scripts, logs, and negative
  findings are not deleted or rewritten by Stage 2.
- Public export is constructed from the explicit allowlist in
  `PUBLIC_EXPORT_MANIFEST.txt`.
- `PUBLIC_EXPORT_EXCLUSIONS.txt` removes internal history, data, generated
  output, machine metadata, credentials, environments, caches, and binaries.
- Exclusion from the public export does not reinterpret or erase a negative
  result.

## Public provenance statement template

The final public release should carry a statement equivalent to:

> This release was derived from the immutable archive
> `dmreda-stabilized-source.zip` with SHA-256
> `323ca1e18bea5522ff3df5822735d3a0c626f0c2765b33edad61157689153b63`.
> The archive was imported at internal commit
> `145277854ecbd1a8ded8ca2667680cb415d9f8bf`. Stage 2 changes are listed in
> the accompanying commit and export manifests. Historical generated results,
> embedded environments, cached datasets, and binaries were preserved in the
> internal research workspace but intentionally excluded from this public
> source release. Dataset-derived scientific claims require their own recorded
> dataset hash, license, configuration hash, and clean-environment run record.

## Unresolved release fields

```text
Final Stage 2 commit list:          UNRESOLVED
Public export tree SHA-256:         UNRESOLVED
Export file SHA-256 manifest:       UNRESOLVED
Code license:                       UNRESOLVED
Dataset license/redistribution:     UNRESOLVED
Approved citation:                  UNRESOLVED
Verified future commit identity:    UNRESOLVED
Authorized publication approval:    UNRESOLVED
```
