# DMREDA Stage 3.1 — Central Dataset-Admission Integration Gate

Date: 2026-08-04

Branch checkpoint: `831f22aba8c6d5bc5a343e722fb0b5e44649b61d`

Decision: approve a reusable, fail-closed dataset-admission framework and a
metadata/provenance-only acquisition of SKAB v0.9.0 outside Git. Do not admit a
dataset, freeze a scientific protocol, open any A/B/C/D bank, or execute a
detector at this gate.

## Preserved scientific state

- Stage 3 remains blocked at dataset authority.
- Banks A, B, C, and D are sealed.
- There is no detector ranking, disturbed outcome, or claim-grade result.
- The canonical Core FSM source hash remains
  `f0a6d72132f8e5ecfadc5d0b9f4f2374b6d417e49f94246c9764bfb21505a4ae`.
- The local SKAB `valve1/0.csv` recording and its previously selected channel
  remain contaminated by prior tuning and cannot be treated as blind evidence.
- The local NASA IMS derivative remains provenance-only.
- No canonical equation, profile threshold, event semantic, warm-up policy,
  Python/C parity implementation, or historical result may change.

## Consolidated read-only findings

| Workstream | Classification | Finding | Central resolution |
|---|---|---|---|
| Authority discovery | reproducibility issue | Ten plausible sequential-sensor candidates were screened. Only TEP, full SKAB, and HAI justified deep screening. | Preserve all candidates and negative findings in a versioned inventory. Deep-screen no additional candidates in this campaign. |
| TEP V1 | intentional design constraint | Harvard Dataverse documents 500 RNG-state runs, disjoint train/test seeds, three-minute cadence, and fixed fault injection. Its custom terms bind the user on access/download. | `human_access_required`; no autonomous payload download. Simulation-specific claims would also require explicit scope labeling. |
| SKAB v0.9.0 | open scientific question | Thirty-five experiments and native labels are authoritative, but only one recording is entirely anomaly-free. Prior tuning contaminated `valve1/0.csv`, cadence is not release-wide uniform, and meaningful A/B/C allocation leaves Bank D underpowered. | Acquire the small official tag only for hash/member/cadence/session audit. Maximum level in this campaign is `exploratory` unless the audit falsifies the independence/power concerns. |
| HAI 22.04 | open scientific question | Six normal and four attack files contain long sequences and authoritative attack intervals, but the highest defensible disturbed unit is at most four acquisition files. License wording is not represented by a separately versioned license asset. | Metadata-only deep screen. Do not download roughly 766 MB because cluster-level power cannot support the primary claim. |
| SWaT | intentional design constraint | Official access requires identity, request, and terms acceptance. | `human_access_required`; do not request or download autonomously. |
| MetroPT, NASA IMS, Paderborn, hydraulic, MIMII, CWRU | evaluation-semantics bug | Publicity or sample count can obscure single-recording structure, recording-wide faults, absent onsets, or unresolved rights. | Record explicit `provenance_only`, `exploratory`, or `rejected` decisions. Samples/windows must not be counted as independent episodes. |
| Detector fairness | intentional design constraint | A fixed scalar channel, Bank-A-only affine scaling, causal prefix processing, native event semantics, and matched achieved risk are required. | Encode these as immutable contracts and guards; do not add dataset-specific detector logic. |
| Current Stage 3 artifacts | missing test | Existing artifacts prove the blocked state but do not implement reusable admission, split, lineage, preprocessing-freeze, or seal enforcement. | Add small standard-library modules plus characterization tests. Preserve existing blocked schemas. |
| Repository hygiene | repository hygiene issue | Raw payloads, acquisition paths, credentials, archives, and recovery bundles must remain outside Git. | Add tracked-path policy tests and store only source identifiers, sizes, hashes, and redacted acquisition records. |

No correctness bug was found in the canonical Core FSM during this gate. No
misleading detector-superiority claim was found. The unresolved questions are
dataset authority, independent-unit power, onset semantics, cadence, and manual
terms acceptance—not detector behavior.

## Approved modifications

| Exact affected file | Observed behavior | Required behavior | Preserved invariant | Falsifying test | Historical schema impact |
|---|---|---|---|---|---|
| `stage3/admission/contracts.py` | No reusable authority, license, adapter, preprocessing, or access contract exists. | Validate explicit admission levels, authority/license state, immutable source identity, fixed channel/scaling, and calibration-label boundaries using finite strict values. | No detector math or existing artifact meaning changes. | Invalid status/license, non-finite scale, mutable freeze, or calibration label access must raise. | New v1 schema only. |
| `stage3/admission/serialization.py` | Strict JSON is implemented only inside individual scripts/tests. | Provide canonical JSON bytes, atomic writes, SHA-256 binding, no NaN/Inf, and machine-path rejection. | Existing JSON files remain byte-for-byte unchanged. | NaN, infinity, macOS/Linux user-home paths, or local-file URI markers must be rejected. | New helper; no old schema change. |
| `stage3/admission/splits.py` | Empty split manifest has no reusable builder. | Assign whole independent recordings deterministically; reject identity, content-hash, and parent-lineage overlap across banks. | No pseudo-independent windows; Bank D remains sealed. | Duplicate recording/hash/lineage or a seed-dependent mismatch must fail. | New v1 split contract; existing blocked manifest remains historical. |
| `stage3/admission/seals.py` | Seal state is documentary rather than executable. | Require admitted authority plus frozen dataset/split/channel/scaling/config/protocol/source bindings; emit one audit event; reject reopening. | No bank opens implicitly and Bank D cannot open before freeze. | Any missing/mismatched binding or second open attempt must fail. | New audit-event schema only. |
| `stage3/admission/guards.py` | Result absence is tested, but scientific output/ranking authorization is not reusable. | Deny scientific output below `claim_grade_admitted`; deny ranking when achieved-risk matching fails; validate complete hash bindings. | FP, miss, delay, censoring, and native event semantics remain owned by Stage 2 modules. | Exploratory data, failed risk match, or incomplete binding must fail closed. | New guard schema only. |
| `stage3/admission/adapters.py` | No common adapter interface exists. | Define independent IDs, indices/timestamps, raw scalar data, units, sample rate, intervals, labels, gaps, session/device metadata, source hashes, and adapter hash without loading data in the base contract. | Raw data is immutable; no full-trace normalization or label-driven channel choice. | An adapter omitting required authority fields cannot validate. | New interface only. |
| `stage3/schemas/dataset-authority.schema.json` | Authority fields are spread across one blocked manifest. | Publish a human-inspectable strict schema covering source, version, terms, hashes, raw/derived history, identities, labels, cadence, channel, A/B/C/D suitability, blockers, and human access. | Missing metadata remains missing; it is never inferred. | Schema-contract tests compare required fields and enums to code. | New schema v1.0.0. |
| `tests/stage3/test_admission_contracts.py` | Requirements 1–6 and 12–16 are not encoded generically. | Test strict JSON, non-finite/path/raw-payload guards, authority/license validation, frozen channel/scaling, prefix causality, and calibration label denial. | Existing Stage 2 tests are not weakened. | Each forbidden input must produce a deterministic failure. | Tests only. |
| `tests/stage3/test_split_and_seal_contracts.py` | Requirements 7–11 and 17 are not encoded. | Test unique independent IDs, no bank/hash/lineage overlap, deterministic reproduction, and Bank D seal/audit behavior. | Whole-recording ownership is mandatory. | Cross-bank aliases or premature/repeated Bank D access must fail. | Tests only. |
| `tests/stage3/test_scientific_output_guards.py` | Requirements 18–25 are distributed or documentary. | Reuse Stage 2 first-alarm/censoring functions and test ownership, no FP redemption/delay, conditional-delay filtering, explicit censoring, hash binding, risk-match ranking guard, and admission-level output guard. | Stage 2 metric definitions remain canonical. | Early FP plus later alarm must remain FP; blocked/risk-unmatched output must be denied. | Tests only. |
| `tests/stage3/test_repository_dataset_hygiene.py` | No focused Stage 3 tracked-payload check exists. | Reject tracked raw dataset/archive/credential/cache/venv/recovery payloads while allowing schemas and aggregate result CSVs. | Historical tracked material is preserved and not reclassified as new science. | A synthetic forbidden tracked-path inventory must fail. | Tests only. |
| `stage3/datasets/candidate-inventory.json` | Broad search evidence is prose-only. | Record at least ten candidates, primary locators, access/license state, sequential/identity/onset/scalar facts, size, and preliminary verdict. | No local absolute paths or raw data. | Strict schema and required-candidate tests. | New v1 inventory. |
| `stage3/datasets/admission-decisions.json` | No Stage 3.1 central machine-readable decision exists. | Record TEP `human_access_required`, SKAB pending acquisition then exploratory/provenance result, HAI exploratory, and all other negative decisions. | No dataset becomes admitted merely through fame or file presence. | Full-gate count must remain zero unless all machine-checkable gates pass. | New v1 decisions. |
| `docs/stage3/DMREDA_STAGE3_DATASET_AUTHORITY_REPORT.md` | Existing report covers only the earlier local audit. | Add primary-source candidate table, deep screens, conflicting observations, central resolutions, and exact acquisition packet. | Negative and blocked findings remain visible. | Artifact contract requires no admission or results without matching manifests. | Documentation only. |
| `repro/stage3/stage3_1_environment.json`, `repro/stage3/stage3_1_commands.txt`, `repro/stage3/STAGE3_1_SHA256SUMS` | Stage 3.1 commands and environment are not recorded. | Record OS/architecture/Python/Git, read-only source queries, acquisition hashes, verification commands, and final tracked-artifact hashes. | No credentials, machine paths, or raw payloads. | Strict JSON/path/checksum tests. | New reproducibility records. |
| `RESUME_STAGE3.md`, `SESSION_STATUS.md` | Continuation records exist only in an external recovery snapshot. | Record the final branch/HEAD, clean/dirty state, sealed banks, authority block, completed work, and exact next safe action without machine paths. | Not a scientific protocol-freeze or final result. | Resume/status contract asserts Bank D sealed and zero result rows. | New operational records. |

## One-to-one required-test ownership

1–2 strict JSON and finite values: `test_admission_contracts.py`.
3 machine-path rejection: `test_admission_contracts.py`.
4 raw payload absent from Git: `test_repository_dataset_hygiene.py`.
5–6 authority and license validation: `test_admission_contracts.py`.
7–11 recording uniqueness, bank/hash/lineage separation, deterministic split:
`test_split_and_seal_contracts.py`.
12–16 channel/scaling freeze, prefix causality, no full-trace normalization,
and no calibration-label access: `test_admission_contracts.py`.
17 Bank D seal: `test_split_and_seal_contracts.py`.
18–22 first-event ownership, FP/miss delay rules, conditional delay, and
censoring: `test_scientific_output_guards.py`, using the Stage 2 metric module.
23 hash binding: `test_scientific_output_guards.py`.
24 risk-match ranking guard: `test_scientific_output_guards.py`.
25 admission-level scientific-output guard: `test_scientific_output_guards.py`.

## Admission and execution decision

The implementation phase may now begin. It may create the approved framework,
tests, manifests, and documentation. It may acquire only the official SKAB
v0.9.0 tag into an audit directory outside Git, inspect it there, and record
hashes and negative findings. It may not download TEP or SWaT, acquire HAI,
freeze a detector protocol, fit scaling, select thresholds, open any bank, run
detectors, or generate scientific outcomes unless a later central gate proves a
dataset is `claim_grade_admitted`.
