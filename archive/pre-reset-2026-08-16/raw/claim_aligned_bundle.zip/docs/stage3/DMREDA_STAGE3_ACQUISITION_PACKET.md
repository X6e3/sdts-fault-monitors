# DMREDA Stage 3.1 Acquisition Packet

Date: 2026-08-04

This packet is operational guidance, not authorization to accept terms, open a
bank, or run a detector. Raw payloads belong in an immutable audit root outside
Git. Substitute a private external path for `$DATASET_AUDIT_ROOT`; never record
that path in a tracked manifest.

## Candidate 1: TEP Rieth V1

Authority record: [DOI 10.7910/DVN/6C3JR1](https://doi.org/10.7910/DVN/6C3JR1)

Access status: `human_access_required`.

Required human action:

1. Open the official DOI record.
2. Read the custom dataset terms presented by Harvard Dataverse.
3. Deliberately accept them only if their research-use and storage conditions
   are acceptable.
4. Download exactly the four V1 files through the authorized interface.

Automation must not click through, impersonate acceptance, reuse browser
credentials, or bypass access controls.

Expected publisher metadata:

```text
TEP_FaultFree_Testing.RData   47327663   38ad9810fc871026157086ae2c2f0ee9
TEP_FaultFree_Training.RData  24678017   ec126484534331f85001d8c4ebce6d17
TEP_Faulty_Testing.RData     836882037   556bdb64c83021bc0c5f92e427753565
TEP_Faulty_Training.RData    494063194   c5f594d54c47e620ff877feb58407fda
```

After manual acquisition, use read-only verification:

```sh
export DATASET_AUDIT_ROOT=/private/path/outside/git/tep-rieth-v1
find "$DATASET_AUDIT_ROOT" -maxdepth 1 -type f -name '*.RData' -print
stat -f '%N %z' "$DATASET_AUDIT_ROOT"/*.RData
md5 "$DATASET_AUDIT_ROOT"/*.RData
shasum -a 256 "$DATASET_AUDIT_ROOT"/*.RData
file "$DATASET_AUDIT_ROOT"/*.RData
```

Stop if any filename, size, or publisher MD5 differs. Record the source time,
HTTP metadata, local SHA-256, and exact terms/version. Do not load the files into
a detector. The next central gate must first approve an adapter, variable rule,
independent identity, and leakage-safe split proposal.

## Candidate 2: SWaT

Authority page: [SUTD iTrust SWaT](https://www.sutd.edu.sg/itrust/itrust-labs/datasets/dataset-characteristics/swat/)

Access status: `human_access_required`.

The owner requires an organizational request and explicit terms acceptance.
No request, credential use, form submission, or download was performed in this
campaign. If access is later granted, preserve the release name, terms, owner
correspondence, original payload hash, session/recording structure, and label
documentation outside Git before any admission claim.

## Completed isolated acquisition: SKAB v0.9.0

This command sequence reproduces the authorized small-tag acquisition. It does
not authorize scientific evaluation:

```sh
export DATASET_AUDIT_ROOT=/private/path/outside/git/skab-v0.9.0
mkdir -p "$DATASET_AUDIT_ROOT"
curl --fail --location --retry 3 \
  --dump-header "$DATASET_AUDIT_ROOT/retrieval-headers.txt" \
  --output "$DATASET_AUDIT_ROOT/SKAB-0.9.0.tar.gz" \
  'https://codeload.github.com/waico/SKAB/tar.gz/refs/tags/v0.9.0'
shasum -a 256 "$DATASET_AUDIT_ROOT/SKAB-0.9.0.tar.gz"
git ls-remote --tags https://github.com/waico/SKAB.git refs/tags/v0.9.0
tar -tzvf "$DATASET_AUDIT_ROOT/SKAB-0.9.0.tar.gz"
```

Expected archive SHA-256:

```text
288813774f29e06e98a3250f1aa9de455292b06db8d1ef022863a76cf348b910
```

Extraction is allowed only into a new directory under the outside-Git audit
root after the archive member safety pass. The tracked acquisition record and
58-member hash manifest are:

```text
stage3/datasets/acquisition/skab-v0.9.0.json
stage3/datasets/acquisition/skab-v0.9.0-member-sha256.json
```

SKAB remains `exploratory`; acquisition did not open A/B/C/D and did not make
the release admissible.

## Non-acquisition decisions

- HAI 22.04 was not downloaded because four disturbed acquisition files cannot
  provide the intended recording-level power, irrespective of byte volume.
- NASA IMS was not downloaded in this pass because no authoritative onset and
  sufficiently clear underlying terms were established.
- MetroPT-3, Paderborn, hydraulic condition monitoring, MIMII, and CWRU were
  stopped at their documented independence, event-timing, size, or license
  limitations.

No payload from an external disk, recovery package, prior dataset audit, or
temporary download may be moved into Git.
