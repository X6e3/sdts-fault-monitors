# DMREDA Stage 3.2 Corrected Scientific Blocker Report

Status: **stopped before protocol freeze and before Testing value access**

## Verdict

The corrected Stage 3.2 engineering framework is implemented and its complete repository suite passes, but the claim-grade TEP campaign cannot start. Primary sources do not unambiguously establish whether Faulty Testing sample label `160` or `161` is the first affected observation. Selecting either boundary would invent scientific metadata. The protocol therefore remains unfrozen and all scientific evaluation banks remain sealed.

## Corrected identity

DMREDA is treated as a causal, deterministic, bounded-state temporal evidence representation and arbitration core:

1. Layer A validates causal representation traces;
2. Layer B validates pending, confirmation, refractory, and external event authority;
3. Layer C applies the frozen core as a TEP `xmeas_7` assurance channel.

RMS, CUSUM, and EWMA are classical scalar evidence references under matched achieved normal false-authority risk. They do not define DMREDA and do not receive its native event mechanism.

## Established engineering evidence

- Frozen TEP scaling, kappa, effective profiles, transitions, and Core kwargs are immutable and hashable.
- Only `th_d`, `th_g`, `th_d2`, and `th_a` are multiplied by `2.5`.
- Warm-up leaves representation traces unchanged and changes only authority consequences.
- Complete-run first-event ownership, explicit censoring, and valid-detection-only delays remain enforced.
- Scalar-reference thresholds can be selected from exact score-derived candidates by FP-count, restricted-time-sum, and conservative threshold tie-breaking.
- Runtime output containment rejects Git worktrees, symlink escapes, raw archives, credentials, and overwrite attempts.
- Scalar extraction validates exact object/schema/identity/order/finiteness and emits no detector outcomes.
- Per-fault execution is deterministic, resumable only from complete hash-bound checkpoints, and serial/parallel equivalent on synthetic fixtures.
- Paired analysis preserves the full 3-by-3 outcome table and never merges early false authority into miss or delay.
- Bank D admission is derived from verified artifacts; opening is a distinct one-time exclusive audit event.
- The full repository suite passes `142/142` tests at the implementation checkpoint.

A passing test establishes only its encoded contract. It is not a TEP scientific result.

## Dataset and access state

- All four local V1 RData files match their expected byte counts, publisher MD5 values, and local SHA-256 manifest.
- FaultFree Training was schema-inspected and has historical calibration use.
- In the interrupted Stage 3.2 run, all four archives were byte-read for integrity; FaultFree Training alone was deserialized for schema inspection.
- FaultFree Testing was not deserialized in this campaign.
- Faulty Testing was not deserialized, extracted, or evaluated.
- No detector outcome, ranking, calibration result, normal-gate result, or fault result was produced.

## Scientific gates

| Gate | Status |
|---|---|
| Raw integrity | passed |
| Corrected source contracts | passed in synthetic/engineering tests |
| Dataset primary-source identity | verified |
| Exact onset authority | failed: source conflict |
| Scientific protocol freeze | not attempted because onset gate failed |
| Independent normal false authority | not evaluated |
| RMS/CUSUM/EWMA matched-risk admission | not evaluated |
| Bank D admission | denied by missing protocol/onset |
| Bank D opening | sealed/unopened |
| Scientific reproduction | not applicable |

## Claim boundary

Established: the repository implements and tests the corrected representation/arbitration contracts and fail-closed experiment infrastructure.

Not established: independent TEP normal false-authority control, comparator admission, post-disturbance authority coverage, evidence beyond scalar reference channels, fault-class performance, delay, ranking, or scientific reproducibility.

The next project claim should remain engineering-level: DMREDA is a causal, deterministic, bounded-state temporal evidence representation and arbitration core with a tested claim-grade evaluation harness. It must not claim TEP validation or detector superiority.

## Exact next action

Obtain unambiguous release-author or generator-level evidence binding the published V1 sample label to the first affected Faulty Testing value. Then revalidate the onset record, freeze the first corrected protocol without changing any numerical setting, and only afterward open FaultFree Testing for the preregistered normal-risk gate.
