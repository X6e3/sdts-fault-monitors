# DMREDA Stage 3.2 Onset Authority V2

Status: **unresolved; non-selective dual-boundary fallback defined**

Decision: `C. unresolved_but_dual_boundary_permitted`

Evidence cutoff: 2026-08-05

## Scope and access guard

This audit resolved only source provenance and label/index semantics. It did not deserialize FaultFree Testing or Faulty Testing, read Testing values to infer signal behavior, run DMREDA or a scalar evidence reference, or produce an outcome row. Bank D remains `sealed_unopened`.

The prior `protocol/onset_mapping.json` remains an unresolved blocker record. It is not replaced by a falsely resolved mapping.

## Central decision

No exact Rieth V1 generator, author-supplied generation wrapper, event log, or explicit author statement identifying the first affected published `sample` label was located. The strongest source-level implementation evidence favors final normal label `160`, first affected label `161`, and Python index `160`, but the code-to-Rieth-V1 identity needed to elevate that inference to claim-grade authority is absent.

The two admissible mappings therefore remain:

| Mapping | Final pre-fault label | First affected label | Python onset index |
|---|---:|---:|---:|
| `label_160_index_159` | 159 | 160 | 159 |
| `label_161_index_160` | 160 | 161 | 160 |

Neither mapping is uniquely primary. Outcome-dependent selection is prohibited.

## Rieth V1 release identity

The authoritative [Harvard Dataverse V1 release](https://doi.org/10.7910/DVN/6C3JR1) is version `1.0`, released 2017-07-06, by Cory A. Rieth, Ben D. Amsel, Randy Tran, and Maia B. Cook of Pacific Science and Engineering Group, Inc. Its public inventory contains exactly four RData files. It contains no generator, source archive, wrapper, README, seed list, event log, or sample-construction code.

The release metadata establishes one-based Testing labels `1..960`, a three-minute cadence, 48-hour Testing trajectories, and fault introduction eight hours into Faulty Testing. It does not state whether the value emitted at the eight-hour boundary was generated before or after the injection took effect. File presence and elapsed-time wording therefore do not decide the boundary.

Metadata snapshot SHA-256:

`a52a38d8a22932edb1effbce7913d20247e8f2bfc617ac11693e6822a6dc9aa3`

The actual companion publication is [Rieth et al., “Issues and Advances in Anomaly Detection Evaluation for Joint Human-Automated Systems”](https://doi.org/10.1007/978-3-319-60384-1_6). The accessible publisher record provides bibliographic provenance but no generator or unambiguous stored-label mapping.

## Strongest generator-lineage evidence

The [MIT Braatz Group Tennessee Eastman archive](https://web.mit.edu/braatzgroup/TE_process.zip) is an authoritative predecessor simulator artifact:

- archive SHA-256: `3ae9d9578cd0883ed81ee3c2b911f85e57e367016e08bd5f1bde963694e4c111`;
- archive member: `TE_process/temain_mod.f.txt`;
- member SHA-256: `31b83c17f8d52332d6f6fe46d9da3ee7131de2d018bb83945453350bf635c8b6`;
- convenient byte-identical archival source: [`temain_mod.f` at commit `df23f0a`](https://github.com/camaramm/tennessee-eastman-profBraatz/blob/df23f0ae22127db9c1d954ba456788c4d4c5470d/temain_mod.f).

The exact relevant code and order are:

| Source line | Operation | Index implication |
|---:|---|---|
| 220 | `NPTS = 172800` | 48 hours at one-second integration steps |
| 226 | `SSPTS = 3600 * 8` | fault flag boundary is internal step 28,800 |
| 232 | `DELTAT = 1. / 3600.` | one-second integration step |
| 365 | `DO 1000 I = 1, NPTS` | Fortran loop counter `I` is one-based |
| 366–368 | `IF (I.GE.SSPTS) IDV(12)=1` | flag is active beginning at `I=28800` |
| 401–406 | output when `MOD(I,180)==0` | emitted ordinal is `I/180` |
| 403 | `CALL OUTPUT` | current `XMEAS` is emitted |
| 408 | `CALL INTGTR(...)` | integration occurs only after output |
| 1336–1357 | `OUTPUT` writes `XMEAS` and `XMV` | emitted row contains the pre-integration state |
| 1376–1382 | `INTGTR` calls `TEFUNC`, advances time, updates `YY` | the active disturbance first affects process evolution after label 160 is written |

For this exact program:

1. At `I=28,800`, the fault flag becomes active.
2. Because `28,800 / 180 = 160`, the same loop iteration emits output ordinal 160.
3. That output precedes `TEFUNC` and the state update under the active flag.
4. The next emitted process vector is at `I=28,980`, ordinal 161.

Thus this implementation supports final normal label `160`, first affected label `161`, and zero-based Python onset index `160`.

## Why the generator evidence is supporting, not decisive

The MIT source predates Rieth V1 and represents the older single-run Braatz lineage. It does not construct Rieth’s `faultNumber`, `simulationRun`, or `sample` columns; does not implement the 500-run release wrapper; and does not bind its source revision, seeds, or output-ordering transformation to DOI `10.7910/DVN/6C3JR1`.

The GitHub copy is byte-identical to the inspected MIT member, but it is a post-release archive maintained outside the Rieth author group. Byte identity verifies the inspected predecessor source, not its use in generating Rieth V1.

The necessary scientific statement is therefore conditional: **if Rieth V1 retained this output-before-integration ordering, label 161 is the first affected recorded value.** The antecedent is not established by the release.

## Conflicting wording reconciled

The [Lu et al. Tennessee Eastman paper](https://web.mit.edu/braatzgroup/Lu_JProcessControl_2018.pdf) is useful supporting context but is not the Rieth V1 generator or companion publication.

| Passage | Literal convention | Supported mapping | Limitation |
|---|---|---|---|
| Testing fault introduced “after 160 samples (8 h)” | 160 complete normal observations | label 161 / index 160 | does not state stored-label construction |
| Fault 4 step change “at the 160th sample” | one-based affected sample ordinal | label 160 / index 159 | conflicts with completed-count wording |
| Fault 1 changes “after the 160th sample” | first changed value follows ordinal 160 | label 161 / index 160 | may describe observed response, not injection assignment |
| Figures/captions place the fault at 160 | plotted coordinate or shorthand | tends toward label 160 / index 159 | axis origin and inclusivity are unstated |

The predecessor code offers a coherent explanation for both phrasings: the fault flag is enabled during the iteration associated with output label 160, while the first output after fault-active evolution is label 161. That reconciliation remains an inference because the paper and code are not proven Rieth V1 generation authority.

## Frozen dual-boundary fallback design

The hash-bound `onset_mapping_candidate.json` freezes the following pre-outcome rules:

1. Evaluate both Python onset indices `159` and `160`.
2. Keep every evidence-channel and event-authority configuration identical between boundaries.
3. Report both complete result sets.
4. Expose every trajectory whose mutually exclusive outcome or delay classification changes.
5. Prohibit choosing a boundary after observing outcomes.
6. Treat neither result as uniquely primary.
7. Separate boundary-sensitive from boundary-insensitive conclusions.
8. Keep Bank D sealed until the fallback is reviewed and adopted by a separately frozen full protocol.

This document freezes a defensible fallback design; it does not itself freeze the full Stage 3 protocol or authorize Testing value access.

## Next permitted phase

Review and adopt the dual-boundary contract in the corrected Stage 3 protocol, implement and test its two-boundary result binding and changed-trajectory disclosure, then freeze the full protocol at a new source commit. Until that completes, the next permitted work is protocol/engineering work only. FaultFree Testing and Faulty Testing remain inaccessible for scientific evaluation.
