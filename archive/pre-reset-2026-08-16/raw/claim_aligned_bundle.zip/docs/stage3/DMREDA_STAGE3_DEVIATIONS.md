# DMREDA Stage 3 Invalidation and Deviation Log

Status: **scientific execution blocked before protocol freeze**

## INVALID-001 — Restored Stage 2 suite was not self-contained

- Observed: 2026-08-03, before Stage 3 source edits.
- Starting commit: `a098005d34b973f1ed63177b4ea20d4a5bda8d1f`.
- Command: pinned CPython 3.12.13 `-m unittest discover -s tests -v`.
- Outcome: 54 tests run; 53 passed; one error.
- Failing test: `StructuralManifoldReproducibilityTests.test_explicit_archive_is_content_identified`.
- Cause: the test required ignored, untracked `results/pqd16c_cache/pqd16c.zip`.
- Classification: undeclared external test fixture / non-hermetic normal-CI test.
- Not classified as: bundle corruption, dataset corruption or Core FSM algorithm regression.
- Repair: commit `365d93352d1043b80d1f84a6f5a26346477c3a79` creates a temporary deterministic ZIP within the test and verifies content sensitivity.
- Post-repair outcome: 54 of 54 tests passed with the same pinned interpreter.
- Scientific effect: none. The temporary fixture is test plumbing and is not dataset evidence.

## BLOCK-001 — Dataset authority gate failed

- No inspected candidate provides the complete authority, acquisition identity, onset and independent normal-bank contract.
- The Stage 2 dummy remains synthetic smoke only.
- The inspected public mirror has an exact archive hash but no verified original-source chain, acquisition identities or onset intervals; its 100 normal rows collapse to one unique waveform.
- Consequence: no Banks A-D were opened; no threshold or detector configuration was frozen; no risk matching, disturbed evaluation, confidence interval, contingency table or ranking was computed.

## BLOCK-002 — X63-R contains authentic SKAB bytes but not a claim-grade split

- Observed: 2026-08-03, during the required additional external-disk pass.
- Mount: `/Volumes/X63-R`.
- Access: read-only command set; no source file, directory or archive was changed or extracted in place.
- Authentic candidate: SKAB v0.9.0 `data/valve1/0.csv`, SHA-256 `16af3f71313a23dd33d9b7b8065d836d05c3f9257588881cc7fbe07c076d9dc8`, exactly matching the official tagged file.
- Gate failure: one local recording, zero independent normal recordings, irregular timestamp gaps, no machine/session serial, no frozen channel policy and extensive prior MGDE use. It cannot support recording-disjoint A/B/C/D roles.
- NASA lead: local derived RMS CSV SHA-256 `fcd5dfdeaf1d95247aa6de3a3d5ab3f504a2a6ca061e0d661a762f3566d6a06b`; raw archive absent; complete-trace normalization; onset and labels generated locally by a 3-sigma sustained-exceedance rule.
- PQD-16c result: all loose and nested caches are the same synthetic dummy archive, SHA-256 `002e1ddb8bf71d7772daf450f6710c6df7c6ab1fd385a3ef6ada784f65c16a4a`.
- Isolated handling: minimum serious-candidate and provenance files were copied to `work/stage3/dataset-audit/x63r`, outside Git; every source/copy pair is byte-identical.
- Scientific effect: the earlier wording “no authentic dataset is available” is narrowed to “no authentic dataset package passes the full Stage 3 gate.” The scientific execution state remains blocked before protocol freeze and Bank A.

## Protocol deviations

None. No protocol-freeze commit exists, so there is no frozen scientific protocol from which to deviate.

## Invalid scientific runs

None. No Stage 3 scientific detector run was started.
