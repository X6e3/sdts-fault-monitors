# DMREDA Stage 3.1 Dataset Authority Report

Date: 2026-08-04

Status: **blocked at dataset authority**

This report records the central admission decision for the Stage 3.1 dataset
campaign. Ten public sequential-sensor datasets were screened, three received
deep authority review, and one small release was acquired into an isolated
audit directory outside Git. No dataset reached `claim_grade_admitted`.
Consequently no protocol was frozen, no A/B/C/D bank was populated or opened,
and no detector was executed.

## Decision summary

| Decision | Count | Datasets |
|---|---:|---|
| `claim_grade_admitted` | 0 | none |
| `claim_grade_candidate` | 2 | TEP Rieth V1; SWaT |
| `exploratory` | 6 | SKAB v0.9.0; HAI 22.04; MetroPT-3; Paderborn; UCI hydraulic; MIMII |
| `provenance_only` | 1 | NASA IMS Bearings |
| `rejected` | 1 | CWRU Bearing Data Center |

The two candidates are not admission-ready. TEP requires deliberate acceptance
of publisher terms before acquisition. SWaT requires an institutional request
and terms acceptance. Public availability or scientific popularity was not
treated as a substitute for license, onset, independence, and normal-risk
evidence.

## Authority method

The audit followed four independent read-only questions before central
resolution:

1. Is the source controlled by the owner, publisher, or cited institution?
2. Are access and research-use terms explicit enough to permit acquisition?
3. Can the highest defensible independent unit populate recording-disjoint
   calibration, risk, and disturbed-evaluation roles?
4. Can every detector receive the same causal scalar information without
   label-dependent channel selection or full-trace normalization?

Sample count was never used as a proxy for independent experimental units.
Intervals nested in one acquisition remain correlated episodes from that
acquisition. One recording sliced into many windows remains one recording.

## Candidate inventory

The machine-readable source of record is
`stage3/datasets/candidate-inventory.json`.

| Dataset | Domain and authority | Sequence / independent unit | Normal and event authority | License/access | Central level |
|---|---|---|---|---|---|
| [TEP Rieth V1](https://doi.org/10.7910/DVN/6C3JR1) | Tennessee Eastman simulation, Harvard Dataverse | 500 RNG-distinct simulation runs per partition/condition; train and test RNG states are separated | 1,000 fault-free runs across train/test; publisher-defined injection at sample 20 or 160 | custom publisher terms require human acceptance | `claim_grade_candidate` |
| [SKAB v0.9.0](https://github.com/waico/SKAB/tree/v0.9.0) | physical water-loop experiments, official tagged repository | 35 experiment CSVs | one wholly normal recording; 34 disturbed recordings with supplied interval/changepoint labels | GPL-3.0 repository license; no separate dataset-specific license asset | `exploratory` |
| [HAI 22.04](https://github.com/icsdataset/hai/tree/master/hai-22.04) | hardware-in-the-loop industrial control, official repository | six normal and four attack acquisition files from one testbed | 58 supplied attack intervals nested within four disturbed acquisitions | repository text declares CC BY-SA 4.0; no separately versioned license asset in the release subtree | `exploratory` |
| [SWaT](https://www.sutd.edu.sg/itrust/itrust-labs/datasets/dataset-characteristics/swat/) | physical secure-water-treatment testbed, SUTD iTrust | multi-day acquisitions described by owner | owner describes normal days and attack intervals | institutional request and terms acceptance | `claim_grade_candidate` |
| [MetroPT-3](https://archive.ics.uci.edu/dataset/791/metropt%2B3%2Bdataset) | train air-production unit, UCI/INESC TEC | one train/compressor trace | maintenance intervals exist, while UCI describes the table as unlabeled | CC BY 4.0 | `exploratory` |
| [NASA IMS Bearings](https://data.nasa.gov/dataset/ims-bearings) | run-to-failure vibration, NASA catalog / University of Cincinnati IMS | three experiments reported outside the local derivative | no dataset-supplied onset established from the authority record | underlying terms unresolved in this audit | `provenance_only` |
| [Paderborn Bearing DataCenter](https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter) | bearing vibration/current, university source | bearing state, operating setting, repeated measurement | faults pre-exist recordings; no within-recording onset | research-use terms | `exploratory` |
| [UCI Hydraulic Condition Monitoring](https://archive.ics.uci.edu/dataset/447/condition%2Bmonitoring%2Bof%2Bhydraulic%2Bsystems) | hydraulic test-rig cycles | 2,205 consecutive cycles without authoritative independent-session resets | cycle-wide condition labels; no within-cycle onset | CC BY 4.0 | `exploratory` |
| [MIMII public 1.0](https://zenodo.org/records/3384388) | industrial machine acoustics, Hitachi/Zenodo | machine ID and audio clips; session independence unresolved | condition applies to whole clip; no within-clip onset | CC BY-SA 4.0 | `exploratory` |
| [CWRU Bearing Data Center](https://engineering.case.edu/bearingdatacenter/download-data-file) | seeded bearing faults, university source | fault/load/acquisition file | fault exists for the full recording; no causal onset | dataset license unresolved | `rejected` |

## Deep authority screening

### TEP Rieth V1

Evidence supporting authority and structure:

- the DOI resolves to the publisher-controlled Harvard Dataverse record;
- V1 identifies four RData payloads totaling 1,402,950,911 bytes;
- the publisher describes separate training and testing random-number states;
- `simulationRun` supplies a defensible trajectory identity;
- three-minute sampling and fixed injection samples are documented;
- fault-free and faulty trajectories are separate, allowing structurally
  recording-disjoint A/B/C/D assignment.

Publisher file metadata recorded before acquisition:

| File | Bytes | Publisher MD5 |
|---|---:|---|
| `TEP_FaultFree_Testing.RData` | 47,327,663 | `38ad9810fc871026157086ae2c2f0ee9` |
| `TEP_FaultFree_Training.RData` | 24,678,017 | `ec126484534331f85001d8c4ebce6d17` |
| `TEP_Faulty_Testing.RData` | 836,882,037 | `556bdb64c83021bc0c5f92e427753565` |
| `TEP_Faulty_Training.RData` | 494,063,194 | `c5f594d54c47e620ff877feb58407fda` |

Evidence against immediate admission:

- the Dataverse access flow presents custom terms that bind the downloader;
- automated acceptance would exceed this campaign's authority;
- no local SHA-256 or member hashes exist before lawful acquisition;
- a scalar variable, units, affine scaling rule, split, and scientific protocol
  are not frozen;
- findings would validate behavior on a published simulator, not physical
  plant universality.

Resolution: `claim_grade_candidate`, `human_access_required`. Do not download
until the user deliberately reviews and accepts the official terms.

### SKAB v0.9.0

The official tag was the only payload acquired in this campaign. It remained
outside Git and was inspected without detector access.

| Evidence | Observed value |
|---|---|
| Source tag commit | `80bac4a00d9cd2a277a6fda8f6a6d5936b892bd2` |
| Archive bytes | 10,886,351 |
| Archive SHA-256 | `288813774f29e06e98a3250f1aa9de455292b06db8d1ef022863a76cf348b910` |
| Members | 67 total; 58 regular files; 9 directories |
| Expanded regular-file bytes | 17,332,804 |
| Archive safety | no absolute, parent-traversal, duplicate, link, encrypted, or special members |
| CSV recordings | 35 total; 34 disturbed; one wholly anomaly-free |
| Samples | 46,806 |
| Exact duplicate CSVs | zero |
| Cadence | all 35 recordings contain gaps; 2,549 gap transitions; 3,223 missing elapsed seconds |
| Non-finite sensor values | none observed |
| Non-positive timestamp deltas | none observed |
| Known contaminated member | `data/valve1/0.csv`, SHA-256 `16af3f71313a23dd33d9b7b8065d836d05c3f9257588881cc7fbe07c076d9dc8` |

The archive supplies native anomaly intervals and changepoints, but it does not
supply enough wholly normal independent recordings to populate separate A, B,
and C normal-risk roles while retaining a statistically useful disturbed D
bank. Using pre-onset pieces of disturbed recordings as independent normal runs
would create lineage leakage. The previously examined `valve1/0.csv` and its
Current channel are not blind. Every recording has timing gaps, and the frozen
handling policy for those gaps does not exist.

Two release-level inconsistencies were preserved rather than repaired:

- `data/README.md` describes valve filenames with a different index convention
  from the 0-based paths in the archive;
- the README calls one field `RateRMS`, while the CSV header is
  `Volume Flow RateRMS`.

Resolution: `exploratory`. Authenticity and labels are established; claim-grade
independence, normal-risk allocation, cadence policy, and blindness are not.

### HAI 22.04

Evidence supporting authority and causal use:

- the official repository identifies six continuous normal files and four
  attack files;
- timestamps are one-second observations and the release documents SCADA tags;
- 58 attack intervals and attack metadata are dataset-supplied;
- the normal files provide approximately 279 hours of exposure.

Evidence against claim-grade admission:

- the 58 intervals are nested in only four disturbed acquisition files;
- the highest defensible independent disturbed unit is therefore at most four;
- all data originate from one HIL testbed;
- an attack-command start is not automatically the first physical manifestation
  on whichever scalar channel would be frozen;
- channel selection among 86 tags remains unresolved;
- acquiring roughly 766 MB would not cure the independent-unit limitation.

Resolution: `exploratory`; metadata-only deep screen. No HAI payload was
downloaded.

## Statistical and fairness resolution

The admission framework now requires:

- whole-recording assignment before any windowing;
- unique recording ID, content hash, and parent-lineage across banks;
- a deterministic split seed and an explicit exclusion reason for every
  unassigned recording;
- a scalar channel selected without evaluation performance;
- Bank-A-only fixed affine scaling with no full-trace normalization;
- causal prefix equivalence and no calibration access to evaluation labels;
- native event semantics and complete-trace first-event ownership;
- hash-bound dataset, split, preprocessing, detector, protocol, and source
  state before Bank D can open;
- denial of detector ranking when achieved-risk matching fails.

These are engineering controls. Their tests do not establish dataset authority
or a scientific detector result.

## Central admission decision

No dataset passed all gates. Therefore:

- protocol-freeze status: **not frozen**;
- matched-risk calibration status: **not run**;
- Bank A: **sealed**;
- Bank B: **sealed**;
- Bank C: **sealed**;
- Bank D: **sealed**;
- detector execution count: **zero**;
- per-run scientific outcome count: **zero**;
- detector ranking count: **zero**.

## Claim matrix

| Class | Stage 3.1 statement |
|---|---|
| Established engineering facts | strict authority records, immutable preprocessing contracts, whole-recording split guards, hash binding, first-event outcome guards, and a fail-closed Bank D seal are implemented and tested |
| Authoritative dataset facts | the SKAB tag/archive identity and member hashes are verified; TEP and HAI structures are documented by primary sources; access restrictions are explicit |
| Dataset-specific scientific findings | none; no detector touched any bank or acquired candidate |
| Mechanism evidence | none added; prior Core FSM evidence remains unchanged |
| Exploratory results | authority/cadence/independence characterization only, not detector performance |
| Underpowered findings | SKAB normal-bank allocation and HAI disturbed acquisition count are inadequate for the preregistered claim form |
| Negative findings | no screened dataset was currently admissible; raw sample volume did not overcome missing independent units or onset authority |
| Invalidated runs | none; no scientific run began |
| Unverified hypotheses | whether DMREDA provides useful matched-risk behavior on TEP or an independently powered physical dataset |
| Prohibited claims | universal superiority, physical-plant validation from TEP alone, claim-grade SKAB/HAI evaluation, and any delay/ranking claim from the blocked package |

## Exact next action

The shortest defensible continuation is a deliberate human review of the
official TEP V1 terms. If accepted, acquire exactly the four publisher-listed
files into the outside-Git audit root, verify publisher MD5 and local SHA-256,
then implement a read-only adapter and establish recording identity before
proposing a split. Dataset authority must be re-run centrally after those
hashes exist. No bank may be opened and no channel, scale, risk target, or
detector threshold may be fitted during acquisition.

If terms are not accepted, continuation requires new independent recordings,
authoritative provenance, usable licensing, and dataset-supplied event timing.
SKAB, the local NASA derivative, HAI, and windowed fragments must not be promoted
to claim-grade evidence to avoid the block.
