# DMREDA Stage 3.2 TEP Onset Authority Decision

Status: **unresolved source conflict — scientific protocol not frozen**

Retrieval date: 2026-08-05

## Direct evidence

The [Harvard Dataverse V1 record](https://dataverse.harvard.edu/api/datasets/:persistentId/?persistentId=doi%3A10.7910%2FDVN%2F6C3JR1) identifies testing sample labels `1..960`, a three-minute cadence, and fault introduction eight hours into Faulty Testing.

An [official MIT Braatz-group paper](https://web.mit.edu/braatzgroup/Lu_JProcessControl_2018.pdf) describes the test fault as introduced “after 160 samples (8 h).” Combined with one-based sample labels, that wording supports:

- final normal label: `160`;
- first affected label: `161`;
- zero-based Python onset: `160`.

The same primary paper later describes a fault change “at the 160th sample.” That wording supports the incompatible mapping:

- final normal label: `159`;
- first affected label: `160`;
- zero-based Python onset: `159`.

The release metadata gives an elapsed duration but does not explicitly settle whether the boundary observation belongs to the normal or affected regime. The two mappings differ by one sample and affect delay accounting at the boundary.

## Central decision

The operational interpretation `label 161 / Python index 160` is better supported by the count phrase “after 160 samples,” but it is an inference in the presence of conflicting primary wording. It is therefore recorded as `derived_with_source_conflict`, not as authoritative dataset-supplied onset.

Stage 3.2 requires an unambiguous authoritative onset before its first scientific protocol can freeze. Detector outputs, favorable metrics, or convention in secondary papers may not resolve the ambiguity. Consequently:

- FaultFree Testing is not deserialized or evaluated;
- Faulty Testing is not deserialized, extracted, or evaluated;
- the scientific protocol remains unfrozen;
- normal-risk and comparator-admission gates are not run;
- Bank D remains sealed.

## Exact unblock condition

Obtain a release-author or generator-level statement that explicitly identifies the first affected value in the published V1 `sample` column, or a versioned generator/event log that deterministically binds injection time to the emitted sample label. The evidence must distinguish label `160` from label `161` without examining detector outcomes.

## Channel authority

The primary TEP dictionaries identify measurement 7 (`xmeas_7`) as reactor pressure, with unit `kPa`. The captured primary table does not support the more specific phrase “kPa gauge”; that phrase remains prohibited.
