# DMREDA Stage 3 Preregistration

> **BLOCKED DRAFT — NOT A PROTOCOL FREEZE**

Dataset authority failed on 2026-08-03. This document records the protocol that can be specified without evaluation data and exposes every unresolved field. It does not authorize calibration, threshold selection, Bank C inspection or Bank D evaluation.

`protocol_freeze_commit`: `null`

`protocol_status`: `blocked_before_freeze`

`bank_d_opened`: `false`

## Scientific scope

The defensible claim under test is limited to whether the canonical DMREDA Core FSM provides a causal, deterministic and bounded-state mechanism whose dataset-specific event behavior differs meaningfully from credible causal scalar baselines at matched achieved false-alarm risk.

This protocol does not test universal detector superiority. A result in which DMREDA ties or loses is scientifically valid and must remain visible.

### Primary questions

1. At matched achieved false-alarm risk, how do canonical Core detection rate and conditional delay compare with trailing RMS, two-sided CUSUM and EWMA mean-shift baselines on each anomaly class?
2. Does `G` add measurable event-level information beyond `D` under frozen `D_ONLY`, `G_ONLY` and `D_OR_G` configurations?
3. Which classes produce reliable detection, late detection, misses, false positives, no advantage or worse behavior than simpler baselines?
4. How well do frozen calibration and event behavior transport across available normal recordings, fixed scaling changes, operating regimes, devices and sessions?

No secondary scientific question is registered while this document is blocked.

## Dataset authority

Selected dataset: **unset**

Archive hash: **unset**

Member hashes: **unset**

License authority: **unverified**

Selection rationale: no candidate passed all mandatory conditions. See `stage3/datasets/dataset-provenance.json`.

External-disk authority note: X63-R contains an authentic official-tag-matched SKAB file, but only one local recording. Authentic file identity does not satisfy the independent-normal and recording-disjoint four-bank contract. The local NASA IMS lead is a complete-trace-normalized derivative with algorithmically generated onset labels. Neither candidate authorizes selection, preprocessing freeze or bank opening. See `stage3/datasets/x63r-discovery.json`.

Before a future freeze, the selected dataset must provide:

- authoritative source, owner/licensor, version, citation and archive/member hashes;
- terms that authorize local scientific evaluation;
- scalar sequential sensor samples with unit, channel and sample-rate authority;
- native recording/acquisition boundaries and highest-level group identities;
- sufficient independent normal data for three disjoint calibration/risk roles;
- event labels with a frozen onset or interval policy;
- a channel-selection rule that does not inspect evaluation outcomes.

Raw data must remain outside Git.

## Split contract

Split at the highest independent acquisition unit available, in this order when present: machine, subject, device, session, acquisition file, recording. Derived, adjacent or overlapping windows from one acquisition group may not cross roles.

The four roles are:

- Bank A: fixed input scaling, declared nuisance parameters and any preregistered Core profile-selection rule.
- Bank B: threshold or discrete operating-point refinement on normal-only data.
- Bank C: untouched common normal holdout used once for achieved finite-horizon false-alarm risk.
- Bank D: sealed disturbed evaluation used once after every preceding gate passes.

Current bank memberships are empty. Current bank hashes are null. No bank has been opened.

A future split manifest must bind every member to dataset member hash, acquisition-group identity, recording identity, role and any derivation lineage. It must reject exact duplicates, shared parents, overlapping ranges and adjacent fragments assigned across banks. Similarity diagnostics must be recorded but may not override known lineage.

## Input and preprocessing contract

Canonical Core input remains:

```text
x_core[t] = (x_raw[t] - offset_fixed) / scale_fixed
```

`offset_fixed` and `scale_fixed` must come only from authoritative sensor calibration or Bank A. Per-trace fitting, complete-trace normalization, event-centred normalization, class-dependent scaling, threshold-specific preprocessing and future samples are prohibited.

The following fields remain unset until a dataset passes authority:

- raw unit and physical quantity;
- channel and channel-selection rule;
- source sample rate;
- ADC/physical conversion;
- fixed offset and scale;
- calibration source and hash;
- clipping and saturation policy;
- missing-sample policy;
- resampling policy.

If resampling is required, its offline or causal role and its delay units must be explicit. Offline noncausal resampling may not be described as embedded runtime behavior.

## Detector set and native semantics

Required primary detectors:

1. Canonical DMREDA Core FSM from `gold_line/core/dmreda_reference_clean.py`.
2. Causal trailing RMS from `gold_line/benchmarks/fair_baseline_scaffold.py`.
3. Causal two-sided CUSUM from the same baseline scaffold.
4. Causal EWMA mean shift from the same baseline scaffold.

DMREDA retains native `D/G → pending area/count → confirmation → refractory → event` authority. Raw `D` or `G` may not be thresholded through the baseline gate and called canonical DMREDA.

Baselines may retain their shared score-threshold/persistence/refractory gate. Fairness is matched achieved risk on the same Bank C, not identical internal logic.

Structural Manifold is a separate secondary family and is not in the primary Stage 3 comparison.

Dataset-specific profile, mode instances, fixed scaling, baseline parameters, thresholds and configuration hashes remain unset. See `stage3/protocol/detector-configurations.json`.

## Event and onset contract

For one event episode per trace:

- first authority-bearing confirmed event before onset is a false-positive run;
- first authority-bearing confirmed event at or after onset is a valid detection;
- no confirmed event is a miss and right-censored event-time run;
- a later event cannot redeem an early false positive;
- detection delay exists only for valid detections and equals `first_alarm - onset`.

Warm-up suppresses event authority only and may not alter Core representation traces.

For interval labels, onset, end, tolerance, after-end handling, trace construction and reset policy must be frozen before evaluation. If recordings contain multiple events, either one independent non-overlapping episode must be constructed without adjacent-context leakage or an explicit multi-event matcher must be implemented and tested. No multi-event policy is selected in the blocked state.

## Matched achieved operating risk

Thresholds are selected on Bank B. Frozen detectors are evaluated on the same independent normal recordings in Bank C exactly once. Zero post-Bank-C threshold refinement is the default.

At least one feasible finite-horizon target is required; two are preferred only if normal horizon and recording count support them. Targets and threshold grids remain unset because observable horizons are unknown.

The default acceptance rule, subject to confirmation before freeze, is achieved restricted mean time to first false alarm within ±10% of target. If discreteness makes this unattainable, the attainable tolerance must be declared before Bank D and without inspecting disturbed outcomes.

For every detector and target report:

- independent Bank C recording/group count;
- total normal samples and time;
- calibration horizon per run;
- first confirmed alarm time and censoring indicator per run;
- censoring count and rate;
- restricted mean time to first alarm;
- mean observed first-alarm time;
- false-positive run rate;
- confirmed alarms per million samples and per hour when rate is known;
- target, achieved value, deviation and risk-match verdict;
- uncertainty respecting acquisition groups.

No extrapolation beyond the observed horizon and no classical uncensored ARL terminology are permitted without a separately frozen survival model and assumptions.

If risk matching fails, detection-delay ranking is not an authorized primary comparison. The unmatched results remain visible.

## Primary disturbed-evaluation metrics

Per dataset, anomaly class, detector and operating target:

- independent evaluation-group and event-episode count;
- valid detections, false-positive runs and misses;
- detection, false-positive and miss rates;
- conditional mean and median delay plus p10/p50/p90;
- conditioning population for every delay summary;
- censoring count and rate;
- achieved normal-bank risk and target deviation;
- host execution time per sample as engineering context only;
- the established Stage 2 persistent-state result, without converting it into total RAM or MCU timing.

FP, miss and delay may not be combined into an unnamed score. Any penalized utility would be secondary and would require explicit penalties before freeze; none is registered now.

## Statistical analysis

The resampling unit is the highest independent acquisition group, not a sample or overlapping window.

Planned 95% uncertainty methods:

- exact binomial intervals or acquisition-group bootstrap for detection, false-positive and miss rates;
- acquisition-group bootstrap for marginal delay summaries;
- paired acquisition-group bootstrap for detector differences;
- paired 3×3 outcome contingency tables over `false_positive`, `detected` and `missed`;
- delay differences only on jointly valid detections, with joint-valid `n` reported.

Bootstrap replicate count, seed list and interval implementation remain unset until group structure is known. Seed values must be frozen in `stage3/protocol/seed-manifest.json` before Bank C.

No p-value is a primary decision rule. Any future hypothesis test must predeclare hypothesis, independent unit, assumptions, effect size and confidence interval.

Target at least 30 independent event-bearing episodes for each primary class where available. Classes below 30 remain in all outputs and are labelled underpowered or exploratory; they may not be pooled solely to improve significance.

## Required mechanism and robustness analyses

After a valid primary evaluation, run frozen:

- `D_ONLY`, `G_ONLY` and `D_OR_G` ablations;
- raw-trigger, pending, confirmation and refractory mechanism summaries;
- deterministic equal-energy impulse, burst, step, ramp and oscillation probes as mechanism evidence only;
- immediate same-sample re-arm versus next-sample-only re-arm only if separately registered, without changing canonical policy;
- correct fixed calibration, calibration mismatch, fixed offset, clipping, missing samples, sample drops, quantization, additive/coloured noise, drift and available device/session/domain shifts.

Robustness transformations may not be retuned individually. Equivalent scaling, calibration mismatch and actual domain shift are separate experiments.

## Leakage and falsification gates

Before Bank D, all active adapters and preprocessing must pass:

1. prefix-causality;
2. no evaluated-trace normalization;
3. no acquisition-group identity overlap;
4. no duplicate/derived/adjacent content across banks;
5. no label access during normal-bank calibration;
6. complete-trace first-alarm ownership;
7. no future feature access;
8. no evaluation-driven channel, profile, detector or class selection;
9. frozen source, dataset, split, protocol, environment, configuration and seed hashes;
10. atomic strict outputs with schema version.

Required negative controls are normal-only evaluation, onset/label permutation, pre-onset-only detector runs, deliberately weak/impossible event cases and at least one signal family where a simple baseline should be competitive. Suspiciously favourable negative controls stop the run.

## Protocol-freeze gate

The protocol may be frozen only after dataset authority, split independence, onset, normal-bank sufficiency, configurations, targets, tolerance, statistical seeds, exact commands and all leakage tests are complete.

The required dedicated commit subject remains:

```text
docs: freeze Stage 3 scientific validation protocol
```

That commit does not exist on this blocked branch. `protocol_freeze_commit` and protocol SHA-256 remain null in all scientific manifests.

After a future freeze, primary metrics, detector set, thresholds, class inclusion and preprocessing may not change. Any bug after Bank D opens invalidates the run and requires a separate branch and explicit rerun decision.

## Stop rules

Scientific execution stops if any of the following holds: baseline restore failure, dataset authority or license uncertainty, unpreventable group leakage, undefined onset, insufficient independent normal data, failed risk matching, underpowered intended claim, post-open detector change, serious leakage, nondeterministic rerun or compute exhaustion.

Current stop reasons are that no candidate combines authority with recording-level split sufficiency; the sole authentic SKAB file has one previously studied recording and no independent normal recordings; the NASA derivative has no bound raw archive and no native onset authority; and every PQD-16c cache is synthetic. The repaired hermetic test and the completed X63-R search do not remove these scientific blockers.

## Exact commands and deviations

Commands are recorded in `repro/stage3/command-log.txt`. Invalidations and deviations are recorded in `docs/stage3/DMREDA_STAGE3_DEVIATIONS.md`.
