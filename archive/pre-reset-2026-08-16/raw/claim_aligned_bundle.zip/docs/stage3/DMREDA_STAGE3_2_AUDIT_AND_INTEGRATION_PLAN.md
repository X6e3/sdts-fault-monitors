# DMREDA Stage 3.2 Audit and Central Integration Gate

Status: approved for conservative implementation after power-interruption recovery

Source checkpoint: `438550c3cfe94ee53887e958b8af42dfca411eb0`

## Corrected scientific identity

Stage 3.2 validates DMREDA as a causal, deterministic, bounded-state temporal evidence representation and arbitration core. The scientific structure is:

1. Layer A: representation validation for the causal `mu`, `e`, `E1`, energy-baseline, `D`, `G`, regime, and evidence traces;
2. Layer B: arbitration and external event-authority validation for pending, confirmation, refractory, and first-event ownership;
3. Layer C: a frozen scalar TEP `xmeas_7` assurance-channel application.

Trailing RMS, two-sided CUSUM, and EWMA are classical scalar evidence references. They retain their shared external score gate and do not define DMREDA's identity or replace its native event authority.

## Read-only audit resolution

The canonical Core already preserves causal representation updates before warm-up authority, mutually exclusive first-event ownership, explicit finite-horizon censoring, native pending/confirmation/refractory semantics, and fixed-family separation. Existing tests establish those encoded properties. They do not establish the missing TEP-specific configuration, exact complete-run risk calibration, runtime output containment, resumable execution, paired inference, or artifact-derived Bank D authorization.

No protocol was frozen before this gate. FaultFree Testing and Faulty Testing were not deserialized in the interrupted Stage 3.2 run. All four raw archives were integrity-hash-read; FaultFree Training alone was deserialized for schema inspection. Faulty Testing values remain unopened and Bank D remains sealed.

## Modification gate

| Classification | Exact affected file | Observed current behavior | Required behavior | Invariant preserved | Falsifying test | Historical schema impact |
|---|---|---|---|---|---|---|
| missing test / reproducibility issue | `stage3/tep/configuration.py`; `tests/stage3/test_tep_configuration.py` | No immutable effective-profile builder binds the frozen TEP scale, kappa, Core kwargs, or unchanged transitions. | Build fresh profiles by replacing only `th_d`, `th_g`, `th_d2`, and `th_a`; expose deterministic hashes and snapshots. | Canonical equations, default values, `DEFAULT_PROFILES`, `DEFAULT_TRANSITIONS`, warm-up, mode, and event semantics remain unchanged. | Mutation, wrong-field multiplication, transition drift, non-deterministic hash, and warm-up representation-invariance tests. | New Stage 3.2 schema only; historical outputs unchanged. |
| evaluation-semantics bug / missing capability | `gold_line/benchmarks/fair_baseline_scaffold.py`; `tests/test_stage3_run_risk_calibration.py` | Historical calibration uses RMTA-only bisection and fits nuisance center/scale from the bank. | Add a separate exact, score-derived, complete-run risk calibration API with lexicographic integer objective and fixed post-affine center `0`, scale `1`; retain the old API unchanged. | Existing baseline score APIs and historical calibration results remain unchanged; strict `score > threshold` and shared baseline gate stay frozen. | Equality-boundary, all-alarm, all-censored, duplicate-score, each tie-break level, stable bank hash, and selected-gate replay tests. | Adds a versioned Stage 3.2 calibration result; no historical schema change. |
| repository hygiene issue / correctness guard | `stage3/tep/output_guard.py`; `tests/stage3/test_tep_output_guard.py` | Tracked-path hygiene exists, but runtime writers can target the repository and artifact type is not enforced. | Resolve real paths, require large/scalar/trajectory outputs outside all Git worktrees, reject forbidden payload types, and use atomic writes. | Repository source/docs/tests remain writable; raw and derived TEP payloads never enter Git. | Symlink escape, repository target, raw archive, trajectory JSONL/CSV, allowed external root, and atomic replacement tests. | New runtime guard record only. |
| reproducibility issue / missing test | `stage3/tep/checkpoints.py`, `stage3/tep/runner.py`; `tests/stage3/test_tep_runner.py` | No transactional per-trajectory/per-fault resume contract or serial/parallel equivalence. | Bind ordered identities, inputs, protocol, onset, runner, and detector configs; reject partial/stale/duplicate checkpoints; preserve deterministic order. | Canonical detector functions and float64 behavior remain unchanged. | Interrupted final line, stale hash, duplicate identity, resume without duplication, exact serial/parallel outcome parity, and deterministic rerun tests. | New Stage 3.2 checkpoint/result schemas only. |
| evaluation-semantics bug / missing capability | `stage3/tep/statistics.py`; `tests/stage3/test_tep_statistics.py` | Core outcomes are valid, but no TEP recording-level summaries, full paired 3-by-3 tables, exact gates, deterministic bootstrap, or Holm families exist. | Report FP/detection/miss separately, valid-detection conditional delays only, explicit censoring, complete paired tables, deterministic per-endpoint seeds, Wilson/bootstrap intervals, and null inferential results when invalid. | A false positive owns the run; FP and miss never receive delay; independent unit is a trajectory/episode. | FP rescue, zero-delay contamination, exact 0.02/48-sample boundaries, all-zero paired differences, order-independent bootstrap, and Holm tests. | New versioned Stage 3.2 analysis schemas only. |
| correctness guard / missing test | `stage3/tep/seals.py`; `tests/stage3/test_tep_seals.py` | Generic Stage 3 seal accepts caller-supplied booleans and conflates admission with opening. | Derive an immutable admission decision from verified artifacts, then create a separate one-time atomic opening event immediately before Faulty Testing access. | Generic historical seal remains available; Bank D cannot open early or reopen. | Missing file, bad hash, failed test/gate, unfrozen config, onset ambiguity, retuning, output-guard failure, double-open, and tampered event tests. | New Stage 3.2 admission/open schemas only. |
| reproducibility issue | `scripts/stage3/extract_tep_xmeas7.R`, `stage3/tep/extraction.py`; synthetic contract tests | No claim-grade TEP scalar extractor exists. | Validate exact object/schema/identity/order/finiteness, extract only four authorized columns, write outside Git, and bind source/script/output hashes without detector calculations. | Frozen channel/scaling and raw immutability remain unchanged. | Wrong object/dimensions/key/order/nonfinite/channel/output-root cases. | New extraction manifest; raw data remains external. |
| misleading terminology / scientific policy | outside-Git canonical protocol plus `docs/stage3/DMREDA_STAGE3_2_SCIENTIFIC_IDENTITY.md` | Earlier primary question was detector-centric. | Freeze the corrected Layer A/B/C evidence-core identity and describe scalar references as matched-false-authority evidence channels. | Frozen numerical configuration and partitions do not change. | Protocol schema asserts identity, native DMREDA authority, reference roles, and no-retuning declaration. | First valid Stage 3.2 protocol; no valid prior protocol is overwritten. |
| open scientific question | outside-Git `protocol/onset_authority.md` and `protocol/onset_mapping.json` | Local evidence does not establish whether testing label 160 or 161 is first affected. | Resolve from authoritative documentation before Faulty Testing values are opened; otherwise stop. | Detector outcomes cannot determine onset. | Source/hash/base/index consistency validation; unresolved status denies admission. | New onset authority record only. |
| intentional design constraint | canonical Core and historical results | Same-sample pending timeout/re-arm and mixed regime-tick trace boundary are characterized current behavior. | Preserve and document; do not invent new policy during Stage 3.2. | Python/C and historical behavior remain unchanged. | Existing boundary tests plus protocol declaration. | None. |

## Integration decisions

- The protocol is the first corrected Stage 3.2 protocol, not a cosmetic V2. It binds the preceding scientific source commit; a separate freeze manifest records its own hashes.
- Baseline structural parameters are fixed. After the already frozen affine transform, CUSUM/EWMA reference location and scale are fixed to `0` and `1`; only the scalar decision threshold is calibrated. This is the conservative interpretation of “calibrate only the scalar threshold.”
- Risk selection uses exact FP counts and restricted-time sums under the existing zero-based first-alarm/full-horizon-censor convention. Floating-point rates are descriptive, not gate authorities.
- The normal gates are machine-evaluated using integer conditions: DMREDA FP count at most 25/500; each reference FP-count difference at most 10/500; each restricted-time-sum difference at most `48 * 500`.
- Bank D authorization and opening are separate records. Metadata/integrity access is distinct from scientific value deserialization.
- Fault-class inference remains class-specific unless authoritative RNG-lineage evidence justifies broader pooling. Samples and overlapping windows are never treated as independent trials.
- Generated trajectories and results stay outside Git. Only source, tests, schemas, and sanitized documentation are committed.

Implementation may begin only from this centralized allocation. Parallel edits must have non-overlapping file ownership and are integrated and tested by the primary agent.
