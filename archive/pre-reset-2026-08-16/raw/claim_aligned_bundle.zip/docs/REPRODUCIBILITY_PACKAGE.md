# Reproducibility Package Contract

## Purpose and claim boundary

The reproducibility package must make a recorded DMREDA or Structural Manifold
run independently inspectable. It is not itself scientific validation, and a
synthetic smoke run must never be presented as dataset evidence.

The package has three explicit validation levels:

1. `synthetic_smoke`: import, CLI, deterministic execution, schema, and wrapper
   checks on local synthetic input;
2. `engineering_validation`: canonical Python/C fixtures, randomized parity,
   memory/build reports, and boundary characterization;
3. `dataset_evaluation`: a licensed, hashed dataset and a frozen disjoint
   calibration/evaluation protocol.

A result must state exactly one level. Passing a lower level does not establish
a higher one.

## Required package files

```text
repro/structural_manifold/
  README.md
  runtime.txt
  requirements.txt
  requirements.lock
  dataset-manifest.json
  config-smoke.json
  smoke.py
  validation-record.json
```

The public test package additionally contains the canonical sources, wrappers,
tests, and immutable fixtures selected by `PUBLIC_EXPORT_MANIFEST.txt`.

## Clean environment contract

`runtime.txt` and `requirements.lock` must record and pin:

- Python version;
- NumPy version;
- SciPy version;
- Matplotlib version;
- Kaggle version when download support is included;
- exact installed-distribution versions for the tested platform.

Stage 2 did not capture package artifact hashes. Exact installed versions are
frozen, but a future release must add a hash-locked resolver output or an
artifact manifest before claiming supply-chain reproducibility.

Each run manifest records:

- operating system and version;
- target architecture;
- Python executable/version;
- dependency versions;
- NumPy BLAS/LAPACK configuration where observable;
- compiler and flags for C artifacts;
- source commit and relevant source-file hashes.

The historical embedded environment under `deprecated/env/` is neither an
installation source nor reproducibility evidence. It must not be activated,
copied, or published. Historical package metadata may inform investigation but
does not define approved pins.

## Dataset contract

`dataset-manifest.json` must include:

```text
dataset identifier and authoritative source
dataset version or retrieval timestamp
archive SHA-256
selected member names and SHA-256 values
waveform shape/channel selection
sampling-rate source and resampling policy
license and redistribution decision
calibration/evaluation partition identifiers
validation level
```

Offline mode is fail-closed: it must never authenticate, instantiate a download
client, or access the network. A missing or invalid archive terminates the run
with a clear error. Cache discovery must be explicit through a dataset/archive
argument or documented cache directory; unrelated files named `pqd16c.zip` are
not accepted without manifest validation.

The audited archive containing only `dummy.csv` is permitted, if retained at
all, solely as a named `synthetic_smoke` fixture. It cannot satisfy the dataset
contract.

## Configuration and seed contract

The configuration hash must cover every behavior-affecting value, including:

- feature and detector parameters;
- calibration and evaluation horizons/run counts;
- warm-up, persistence, confirmation, refractory, and reset policies;
- target and achieved finite-horizon false-alarm behavior;
- noise and disturbance generator parameters;
- seed schedule definition and actual run seeds;
- dataset/member hashes;
- input scaling contract identifier;
- output schema version.

The canonicalized configuration encoding must be documented. A test must prove
that key order does not change the hash and that changing any declared behavior
parameter does.

## Run manifest and output schema

Every run produces a machine-readable manifest containing:

```text
validation_level
schema_version
source_commit and source hashes
command and working-directory policy
runtime/dependency/platform record
dataset manifest hash
configuration and configuration hash
seed schedule and actual seeds
detector key, native event mechanism, warm-up, and reset policy
per-run onset, trace length, first alarm, outcome, censoring, and valid delay
output file hashes
start/end timestamps and exit status
known limitations
```

Unavailable numeric values are JSON `null`, never `NaN` or an invented zero.
New Structural Manifold output uses the `structural_manifold` detector key.
Legacy `dmreda` keys may be migrated only when a reader positively identifies
the old Structural Manifold schema; they are never a generic alias for the Core
FSM.

All output paths are owned by one explicit output directory. Writes must be
atomic where practical, and tests must prove that a run writes nowhere outside
its temporary output tree.

## Required validation sequence

Run in a newly created environment, without the historical embedded
environment:

1. import the canonical Structural Manifold module;
2. run canonical `--help`;
3. run both Python compatibility-wrapper `--help` paths;
4. verify cached/offline operation with Kaggle unavailable and no network call;
5. verify optional Matplotlib and SciPy failure paths are explicit;
6. run the deterministic synthetic smoke configuration twice;
7. compare normalized outputs and hashes from both runs;
8. run the same smoke configuration through canonical and wrapper paths and
   compare JSON/CSV content;
9. inspect schema version, detector keys, outcomes, and provenance fields;
10. run one complete small benchmark using a validated local input manifest;
11. when the licensed full dataset is available, run the frozen disjoint
    calibration/evaluation protocol and record its archive hash.

The C compatibility source and canonical Structural Manifold C harness must also
compile separately and produce equivalent deterministic output. That test does
not make either source a DMREDA Core FSM port.

## Packaging and verification

The release builder must:

1. construct a fresh tree only from `PUBLIC_EXPORT_MANIFEST.txt`;
2. reject everything matched by `PUBLIC_EXPORT_EXCLUSIONS.txt`;
3. fail on missing license, citation, verified provenance, or required package
   files;
4. run redacted secret, absolute-path, personal-metadata, binary, archive, and
   large-file scans;
5. execute the clean-environment validation sequence;
6. generate an export SHA-256 manifest;
7. compare the final tree with the allowlist at file level.

## Current status

At the Stage 2 audit checkpoint:

- a separate CPython 3.12.13 environment was created without activating or
  copying `deprecated/env/`;
- direct dependency pins and a complete 25-distribution installed-environment
  freeze were recorded;
- canonical import, canonical and compatibility `--help`, deterministic
  synthetic smoke, schema inspection, and wrapper byte-equivalence passed;
- canonical and wrapper small-benchmark outputs were byte-identical;
- strict offline discovery and lazy optional imports were exercised without a
  Kaggle authentication attempt;
- the complete PQD-16c dataset was unavailable;
- the only local archive was the synthetic dummy cache;
- package artifact hashes, authoritative dataset provenance, dataset licensing,
  and a full scientific benchmark remain unresolved.

Observed false positives and target deviations are retained in
`repro/structural_manifold/validation-record.json`; they are not converted into
a ranking. The remaining unresolved items must not be hidden by passing smoke
tests or generated result filenames.
