# Canonical DMREDA Definition and Evaluation Contract

## Canonical source

The canonical algorithm is **DMREDA Core FSM**, implemented by
`compute_dmreda_reference()` in
`gold_line/core/dmreda_reference_clean.py`.

`gold_line/core/dmreda_reference.py` is an earlier reference retained for
provenance. It is not the target for new changes.

## Runtime data path

```text
fixed external scaling
→ causal trailing median mu
→ instantaneous L1 deviation e
→ trailing energy E1
→ EMA energy baseline
→ bounded normalized deviation D
→ finite-lag smoothed growth G
→ bounded regime FSM
→ pending evidence area/count
→ confirmation
→ refractory
→ event_times
```

All signal windows are trailing. The returned arrays have one value per input
sample and `event_times` equals the indices where `confirmed` is true.

## Warm-up authority boundary

Default warm-up is:

```text
max(max_profile_w1, max_profile_w2) + max_profile_confirm_max
```

For the default profiles this is 92 samples. Samples `0..91` update internal
signal and regime traces. Candidate creation, pending accumulation,
confirmation, and events are prohibited. The first eligible sample is index 92.

Warm-up is an event-authority boundary, not a representation switch. For the
same input and configuration, changing warm-up from 0 to 92 must leave `mu`,
`e`, `E1`, energy baseline, `D`, `G`, `r`, `a`, and regime state bit-identical.
Only candidate, pending, confirmation, event, and refractory consequences may
differ. The regression test uses a trace that previously exposed pending-state
feedback into adaptive `m` selection.

An explicit `warmup_samples=0` is supported for controlled diagnostics and is
not the claim-grade default.

## C mirror boundary

`gold_line/core/dmreda_streaming_fixed.h/.c` is a sample-by-sample, no-heap C99
mirror of a fixed subset. It locks the Python reference to profile/state 0,
`m=4`, confirmation length 20, no regime tick within the trace, and warm-up 92.
Modes and warm-up values are test controls; the claim-bearing default remains
the declared fixed configuration. The C API accepts a wider bounded
configuration surface, but unlisted combinations are experimental rather than
an expansion of the embedded claim.

The C source enforces a compile-time 1 KiB maximum for its persistent state
structure. The verified arm64 macOS ABI reports 136 bytes for configuration,
984 bytes for persistent state, and 112 bytes for one output. The 984-byte value
is not total runtime RAM: it excludes stack, caller buffers, runtime/linker
overhead, and target-specific sections. The host report records 120 bytes of
known median scratch, a 144-byte compiler static stack estimate for
`dmreda_fixed_step`, and binary sections. MCU peak stack, WCET, and energy are
not measured.

Parity tests compare `mu`, `e`, `E1`, energy baseline, `D`, `G`, `r`, `a`,
pending, confirmation, and event indices. Float traces permit a `5e-12`
absolute tolerance because Python prefix sums and the bounded C ring sum have a
different addition order. Event/state traces must match exactly.

Eight human-inspectable immutable fixtures are checked independently against
Python and C. Normal CI additionally runs 100 deterministic seeds across all
three event modes, warm-up values 0/1/91/92/93, ring boundaries, and ten signal
families. Long/high-amplitude stress is opt-in because accumulated floating-point
addition-order differences require a separately declared tolerance; discrete
authority traces remain exact.

## Boundary characterization

- A pending candidate may time out and immediately re-arm on the same sample if
  the fast trigger remains true. Python and C agree. Stage 2 preserves this as
  an unresolved design choice rather than inventing a new policy.
- Confirmation is permitted on the last sample of the inclusive confirmation
  window.
- A refractory interval of `R` reopens authority at confirmation index plus
  `R` in the canonical Core implementation.
- `refractory=0` grants at most one confirmation authority per sample.
- An event entirely inside warm-up is ignored. A disturbance that begins in
  warm-up may confirm afterward because its causal representation state is
  inherited; pending evidence itself restarts at the warm-up boundary.

## Separate algorithmic family

`gold_line/structural_manifold/` is not the Core FSM. It uses a multivariate
sliding feature vector, full covariance model, pseudo-inverse, Mahalanobis
distance, and sequential accumulation. Its C separability harness stores large
feature sets for a laboratory experiment. Historical filenames remain wrappers
only.

## False-positive accounting

Evaluation finds the first confirmed alarm on the complete trace:

1. first alarm before onset: false-positive run, no later detection credit;
2. no alarm: miss;
3. first alarm at/after onset: detection, delay = alarm - onset.

Searching only at or after onset is forbidden because it erases false positives.
The same rule is used by strict evaluation and ROC sweeps.

## Baseline fairness

`gold_line/benchmarks/fair_baseline_scaffold.py` supplies RMS, two-sided CUSUM,
and EWMA score paths. Those score baselines share an external
warm-up/persistence/refractory gate. DMREDA Core does not: it retains native
`D/G → pending area/count → confirmation → refractory` authority. Fairness
therefore means disjoint calibration/evaluation data and matched achieved
false-alarm behavior, not an identical gate.

Noise-only calibration is finite-horizon and right-censored. Active schemas
report the per-run horizon and first confirmed alarm, censoring indicators,
censoring count/rate, restricted mean time to first alarm, mean observed first
alarm time, threshold, target value, achieved value, and target deviation. The
historical `ARL` name may appear only as an explicitly documented compatibility
alias for that restricted mean; it is not an uncensored classical ARL estimate.

The scaffold is not evidence that the Core FSM wins. Core configuration
calibration, dataset selection, run count, confidence intervals, compute/memory
measurements, and negative results still belong in each experiment protocol.

## Compatibility and history

- `gold_line/benchmarks/dmreda_pqd16c_streaming_benchmark.py` wraps the renamed Structural Manifold benchmark.
- root `dmreda_pqd16c_streaming_benchmark.py` is also a compatibility wrapper.
- `gold_line/support/dmreda_core_test.c` includes the renamed separability harness.
- `playground/`, `deprecated/`, `near_gold_todo/`, `.dmreda_run_backups/`, and `results/` remain preserved.

## Validation

```bash
python3 -m gold_line.core.dmreda_reference_clean
python3 -m unittest discover -s tests -v
```

The test suite also compiles the C mirror with `-std=c99 -Wall -Wextra -Werror`.
