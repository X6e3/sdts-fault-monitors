# DMREDA fixed-subset host memory report

Measured: `2026-08-03T11:29:33.750985+00:00`

Compiler: `Apple clang version 17.0.0 (clang-1700.0.13.5)`
Target: `arm64-apple-darwin24.6.0`
Flags: `-std=c99 -O2 -Wall -Wextra -Werror`

## Structures and scratch

- `sizeof(DmredaFixedConfig)`: 136 bytes
- `sizeof(DmredaFixedState)`: 984 bytes
- `sizeof(DmredaFixedOutput)`: 112 bytes
- known median `sorted[]` scratch: 120 bytes

## Static stack estimates

- `dmreda_fixed_default_config`: 0 bytes (static)
- `dmreda_fixed_init`: 32 bytes (static)
- `dmreda_fixed_step`: 144 bytes (static)
- `main`: 1424 bytes (static)

## Binary sections

- core object `.text`/`__text`: 1792 bytes
- core object `.data`/`__data`: 0 bytes
- core object `.bss`/`__bss`: 0 bytes
- linked CLI `.text`/`__text`: 3232 bytes
- linked CLI `.data`/`__data`: 0 bytes
- linked CLI `.bss`/`__bss`: 0 bytes

## Claim boundary

The verified persistent runtime state structure occupies 984 bytes on the tested arm64 ABI.

- ABI alignment and compiler choices can change structure sizes.
- sizeof(DmredaFixedState) is persistent state, not total runtime RAM.
- Local stack, caller-owned input/output buffers, C runtime, and link-time overhead are not included in sizeof(state).
- The sorted[DMREDA_FIXED_MAX_W1] median array is known local scratch; compiler stack-usage values are build-specific static estimates.
- MCU peak stack, WCET, energy, interrupt interaction, and target linker sections remain unmeasured.
