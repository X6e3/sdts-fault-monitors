#!/usr/bin/env python3
"""Run resumable phases of the frozen DMREDA Stage 3.3 campaign.

The command intentionally requires all three roots.  No personal filesystem
location is embedded in source or emitted scientific artifacts.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


def _repository_on_path(repository_root: Path) -> None:
    value = str(repository_root.resolve(strict=True))
    if value not in sys.path:
        sys.path.insert(0, value)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Execute guarded, resumable phases of the DMREDA Stage 3.3 "
            "dual-boundary evidence-core validation campaign."
        )
    )
    parser.add_argument(
        "phase",
        choices=(
            "prefreeze",
            "normal",
            "bank-d",
            "ablations",
            "reproduce",
            "finalize",
            "all",
        ),
        help="single campaign phase, or the complete gated sequence",
    )
    parser.add_argument(
        "--repository-root",
        type=Path,
        required=True,
        help="clean DMREDA Git worktree",
    )
    parser.add_argument(
        "--dataset-root",
        type=Path,
        required=True,
        help="external immutable Rieth V1 dataset root",
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        required=True,
        help="existing external Stage 3 scientific-output root",
    )
    parser.add_argument(
        "--recovery-root",
        type=Path,
        required=True,
        help="existing private recovery root, disjoint from Git/data/output",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        choices=range(1, 9),
        metavar="1..8",
        help="bounded process-worker count (default: 4)",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    _repository_on_path(arguments.repository_root)

    from stage3.admission.serialization import canonical_json_bytes
    from stage3.tep.campaign import (
        CampaignPaths,
        finalize_campaign_state,
        run_ablations,
        run_bank_d_primary,
        run_full_campaign,
        run_normal_gate,
        run_prefreeze,
        run_reproduction,
    )

    paths = CampaignPaths(
        repository_root=arguments.repository_root,
        dataset_root=arguments.dataset_root,
        output_root=arguments.output_root,
        recovery_root=arguments.recovery_root,
    )
    if arguments.phase == "prefreeze":
        result = run_prefreeze(paths)
    elif arguments.phase == "normal":
        summary, seal = run_normal_gate(paths, workers=arguments.workers)
        result = {"normal_summary": summary, "bank_d_admission": seal}
    elif arguments.phase == "bank-d":
        rows = run_bank_d_primary(paths, workers=arguments.workers)
        result = {"status": "complete", "trajectory_result_rows": len(rows)}
    elif arguments.phase == "ablations":
        result = run_ablations(paths, workers=arguments.workers)
    elif arguments.phase == "reproduce":
        result = run_reproduction(paths, workers=arguments.workers)
    elif arguments.phase == "finalize":
        result = finalize_campaign_state(paths)
    else:
        result = run_full_campaign(paths, workers=arguments.workers)
    sys.stdout.buffer.write(canonical_json_bytes(dict(result)) + b"\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
