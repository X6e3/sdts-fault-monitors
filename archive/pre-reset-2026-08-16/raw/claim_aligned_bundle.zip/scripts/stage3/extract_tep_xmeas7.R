#!/usr/bin/env Rscript

# Standalone, fail-closed extraction of the frozen TEP scalar channel.  This
# script performs no calibration, thresholding, event detection, or scoring.

fail <- function(message) {
  stop(message, call. = FALSE)
}

parse_cli <- function(arguments) {
  allowed <- c(
    "source",
    "output",
    "external-root",
    "expected-object",
    "expected-rows",
    "expected-columns",
    "expected-fault-numbers",
    "expected-runs-per-fault",
    "expected-samples-per-run"
  )
  if (length(arguments) %% 2L != 0L) {
    fail("arguments must be supplied as --name value pairs")
  }
  parsed <- list()
  if (length(arguments) > 0L) {
    for (index in seq.int(1L, length(arguments), by = 2L)) {
      flag <- arguments[[index]]
      if (!startsWith(flag, "--")) {
        fail(paste0("unexpected positional argument: ", flag))
      }
      name <- substring(flag, 3L)
      if (!(name %in% allowed)) {
        fail(paste0("unsupported argument: --", name))
      }
      if (!is.null(parsed[[name]])) {
        fail(paste0("duplicate argument: --", name))
      }
      parsed[[name]] <- arguments[[index + 1L]]
    }
  }
  missing <- setdiff(allowed, names(parsed))
  if (length(missing) > 0L) {
    fail(paste0("missing required arguments: ", paste(missing, collapse = ", ")))
  }
  parsed
}

parse_positive_integer <- function(value, field) {
  if (!grepl("^[1-9][0-9]*$", value)) {
    fail(paste0(field, " must be a positive integer"))
  }
  parsed <- suppressWarnings(as.numeric(value))
  if (!is.finite(parsed) || parsed > .Machine$integer.max) {
    fail(paste0(field, " is outside the supported integer range"))
  }
  as.integer(parsed)
}

parse_fault_numbers <- function(value) {
  if (!grepl("^(0|[1-9][0-9]*)(,(0|[1-9][0-9]*))*$", value)) {
    fail("expected-fault-numbers must be a comma-separated integer list")
  }
  parsed <- as.integer(strsplit(value, ",", fixed = TRUE)[[1L]])
  if (anyDuplicated(parsed) != 0L || !identical(parsed, sort(parsed))) {
    fail("expected-fault-numbers must be unique and sorted")
  }
  parsed
}

has_git_marker <- function(path) {
  marker <- file.path(path, ".git")
  link_target <- Sys.readlink(marker)
  has_link <- any(!is.na(link_target) & nzchar(link_target))
  file.exists(marker) || dir.exists(marker) || has_link
}

git_worktree_root <- function(path) {
  current <- if (dir.exists(path)) path else dirname(path)
  current <- normalizePath(current, winslash = "/", mustWork = TRUE)
  repeat {
    if (has_git_marker(current)) {
      return(current)
    }
    parent <- dirname(current)
    if (identical(parent, current)) {
      return(NA_character_)
    }
    current <- parent
  }
}

is_within <- function(path, root) {
  identical(path, root) || startsWith(path, paste0(root, "/"))
}

authorize_output <- function(output, external_root) {
  if (!dir.exists(external_root)) {
    fail("external root must be an existing directory")
  }
  root <- normalizePath(external_root, winslash = "/", mustWork = TRUE)
  if (!is.na(git_worktree_root(root))) {
    fail("external root is inside a Git worktree")
  }

  output_link <- Sys.readlink(output)
  output_is_link <- any(!is.na(output_link) & nzchar(output_link))
  if (file.exists(output) || dir.exists(output) || output_is_link) {
    fail("refusing to overwrite an existing or symlinked output")
  }
  parent_input <- dirname(output)
  if (!dir.exists(parent_input)) {
    fail("output parent must be an existing directory")
  }
  parent <- normalizePath(parent_input, winslash = "/", mustWork = TRUE)
  destination <- file.path(parent, basename(output))
  if (!is_within(destination, root)) {
    fail("output escapes the designated external root")
  }
  if (!is.na(git_worktree_root(parent))) {
    fail("output is inside a Git worktree")
  }

  relative <- substring(destination, nchar(root) + 2L)
  parts <- tolower(strsplit(relative, "/", fixed = TRUE)[[1L]])
  forbidden_parts <- c(
    ".cache", ".git", ".venv", "__pycache__", "archive", "archives",
    "cache", "caches", "credentials", "dataset-audit", "downloads", "raw",
    "raw-data", "raw_data", "raw_datasets", "venv", "venvs"
  )
  if (any(parts %in% forbidden_parts)) {
    fail("output path contains a forbidden payload directory")
  }
  output_name <- tolower(basename(destination))
  forbidden_names <- c(
    ".env", "credentials.json", "id_ed25519", "id_rsa", "kaggle.json", ".netrc"
  )
  if (output_name %in% forbidden_names) {
    fail("credential output names are forbidden")
  }
  if (!endsWith(output_name, ".csv.gz")) {
    fail("scalar extraction output must use the .csv.gz suffix")
  }
  if (endsWith(output_name, ".tar.gz")) {
    fail("archive outputs are forbidden")
  }
  destination
}

validate_integer_identity <- function(values, field, allow_zero) {
  if (!is.numeric(values) || any(!is.finite(values))) {
    fail(paste0(field, " must be finite numeric data"))
  }
  if (any(values != floor(values))) {
    fail(paste0(field, " must contain integers"))
  }
  if (allow_zero) {
    if (any(values < 0)) fail(paste0(field, " must be non-negative"))
  } else {
    if (any(values < 1)) fail(paste0(field, " must be positive"))
  }
}

main <- function() {
  arguments <- parse_cli(commandArgs(trailingOnly = TRUE))
  source <- arguments[["source"]]
  if (!file.exists(source) || dir.exists(source)) {
    fail("source must be one existing RData file")
  }
  if (!grepl("\\.rdata$", source, ignore.case = TRUE)) {
    fail("source must use the .RData suffix")
  }
  source <- normalizePath(source, winslash = "/", mustWork = TRUE)
  output <- authorize_output(
    arguments[["output"]], arguments[["external-root"]]
  )
  if (identical(source, output)) {
    fail("source and output must differ")
  }

  expected_object <- arguments[["expected-object"]]
  if (!grepl("^[A-Za-z][A-Za-z0-9_.]*$", expected_object)) {
    fail("expected-object is not a valid R object name")
  }
  expected_rows <- parse_positive_integer(
    arguments[["expected-rows"]], "expected-rows"
  )
  expected_columns <- parse_positive_integer(
    arguments[["expected-columns"]], "expected-columns"
  )
  expected_faults <- parse_fault_numbers(
    arguments[["expected-fault-numbers"]]
  )
  expected_runs <- parse_positive_integer(
    arguments[["expected-runs-per-fault"]], "expected-runs-per-fault"
  )
  expected_samples <- parse_positive_integer(
    arguments[["expected-samples-per-run"]], "expected-samples-per-run"
  )
  implied_rows <- length(expected_faults) * expected_runs * expected_samples
  if (implied_rows != expected_rows) {
    fail("expected identity cardinalities do not equal expected-rows")
  }

  environment <- new.env(parent = baseenv())
  loaded <- load(source, envir = environment)
  if (!identical(loaded, expected_object)) {
    fail("RData must contain exactly the one expected object")
  }
  value <- get(expected_object, envir = environment, inherits = FALSE)
  if (!identical(class(value), "data.frame")) {
    fail("expected object must have exact class data.frame")
  }
  if (nrow(value) != expected_rows || ncol(value) != expected_columns) {
    fail("source object dimensions do not match the frozen expectation")
  }
  if (anyDuplicated(names(value)) != 0L) {
    fail("source object contains duplicate column names")
  }
  selected_columns <- c("faultNumber", "simulationRun", "sample", "xmeas_7")
  if (!all(selected_columns %in% names(value))) {
    fail("source object is missing a required identity or scalar column")
  }
  if (!all(vapply(value, is.numeric, logical(1L)))) {
    fail("every source column must be numeric")
  }
  finite_columns <- vapply(value, function(column) all(is.finite(column)), logical(1L))
  if (!all(finite_columns)) {
    fail("source object contains NA, NaN, or infinite values")
  }

  validate_integer_identity(value$faultNumber, "faultNumber", TRUE)
  validate_integer_identity(value$simulationRun, "simulationRun", FALSE)
  validate_integer_identity(value$sample, "sample", FALSE)
  observed_faults <- sort(unique(as.integer(value$faultNumber)))
  if (!identical(observed_faults, expected_faults)) {
    fail("faultNumber values differ from the frozen expectation")
  }

  ordering <- order(
    value$faultNumber, value$simulationRun, value$sample,
    method = "radix", na.last = NA
  )
  selected <- data.frame(
    faultNumber = as.integer(value$faultNumber[ordering]),
    simulationRun = as.integer(value$simulationRun[ordering]),
    sample = as.integer(value$sample[ordering]),
    xmeas_7 = as.numeric(value$xmeas_7[ordering]),
    check.names = FALSE
  )
  rm(value)

  cursor <- 1L
  expected_sample_sequence <- seq_len(expected_samples)
  for (fault in expected_faults) {
    for (run in seq_len(expected_runs)) {
      ending <- cursor + expected_samples - 1L
      indices <- cursor:ending
      if (
        any(selected$faultNumber[indices] != fault) ||
        any(selected$simulationRun[indices] != run) ||
        !identical(selected$sample[indices], expected_sample_sequence)
      ) {
        fail("recording identity, run, sample order, or completeness is invalid")
      }
      cursor <- ending + 1L
    }
  }
  if (cursor != nrow(selected) + 1L) {
    fail("identity validation did not consume exactly all rows")
  }
  if (any(!is.finite(selected$xmeas_7))) {
    fail("selected xmeas_7 channel contains non-finite values")
  }

  temporary <- tempfile(
    pattern = paste0(".", basename(output), "."),
    tmpdir = dirname(output),
    fileext = ".tmp"
  )
  published <- FALSE
  on.exit({
    if (!published && file.exists(temporary)) unlink(temporary)
  }, add = TRUE)
  connection <- gzfile(temporary, open = "wt", encoding = "UTF-8", compression = 9L)
  tryCatch(
    write.table(
      selected,
      file = connection,
      sep = ",",
      row.names = FALSE,
      col.names = TRUE,
      quote = FALSE,
      na = "",
      dec = "."
    ),
    finally = close(connection)
  )
  if (!file.exists(temporary) || file.info(temporary)$size < 1) {
    fail("temporary gzip output was not created")
  }
  if (!Sys.chmod(temporary, mode = "0600")) {
    fail("could not restrict temporary output permissions")
  }
  output_link <- Sys.readlink(output)
  output_is_link <- any(!is.na(output_link) & nzchar(output_link))
  if (file.exists(output) || dir.exists(output) || output_is_link) {
    fail("output appeared before atomic publication")
  }
  if (!file.rename(temporary, output)) {
    fail("atomic output rename failed")
  }
  published <- TRUE

  cat(paste0("extracted_object=", expected_object, "\n"))
  cat(paste0("extracted_rows=", nrow(selected), "\n"))
  cat("selected_columns=faultNumber,simulationRun,sample,xmeas_7\n")
}

options(OutDec = ".", digits = 17, warn = 2)
main()
