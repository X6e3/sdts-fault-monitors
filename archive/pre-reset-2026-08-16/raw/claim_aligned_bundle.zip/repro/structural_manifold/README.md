# Structural Manifold Reproducibility Environment

This package records the clean environment validated for the separate
Structural Manifold research family. It does not turn that detector into the
DMREDA Core FSM and does not establish detector superiority.

> **The bundled smoke configuration is synthetic, dataset-free engineering
> validation. It is not PQD-16c scientific validation.**

The full PQD-16c dataset was unavailable during Stage 2. The only observed cache
contained one member named `dummy.csv`; its provenance and licensing are
unresolved, and the archive is not distributed in this package. See
`dataset-manifest.json`. Observed smoke and small-benchmark outcomes, including
false positives and operating-target deviations, are preserved without ranking
in `validation-record.json`.

## Validated environment

The recorded environment is:

```text
CPython 3.12.13
macOS 15.7.7 (build 24G720)
arm64
NumPy 2.3.2 using Apple Accelerate
SciPy 1.16.1
Matplotlib 3.10.5
Kaggle 1.7.4.5
uv 0.11.29
```

`requirements.txt` contains direct dependencies. `requirements.lock` is the
complete installed-distribution freeze from the validated environment. The lock
is platform-specific; other platforms require separate validation and must not
reuse the expected byte hashes as proof of parity.

## Create a clean environment

Run from the repository root. This creates a temporary environment outside the
repository and does not use `deprecated/env/`:

```bash
DMREDA_REPRO_ROOT=$(mktemp -d)
uv venv --python 3.12.13 "$DMREDA_REPRO_ROOT/venv"
uv pip sync \
  --python "$DMREDA_REPRO_ROOT/venv/bin/python" \
  repro/structural_manifold/requirements.lock
```

For an offline installation, all required artifacts must already exist in the
uv cache. `--offline` fails instead of accessing the network when an artifact is
missing:

```bash
uv pip sync --offline \
  --python "$DMREDA_REPRO_ROOT/venv/bin/python" \
  repro/structural_manifold/requirements.lock
```

## Strictly offline, dataset-free smoke

The smoke script does not authenticate, download, read a dataset archive, write
an output file, or generate a plot. It produces a JSON record on standard output
and requires exact shapes, hashes, package versions, Python version, OS, and
architecture:

```bash
PYTHONDONTWRITEBYTECODE=1 \
  "$DMREDA_REPRO_ROOT/venv/bin/python" -B \
  repro/structural_manifold/smoke.py
```

The smoke covers deterministic synthetic AR(1) generation and the ten-column
Structural Manifold feature extraction path. A pass demonstrates only the
properties encoded by `config-smoke.json`.

## Import and compatibility-path checks

These commands require no dataset and must not access the network:

```bash
PYTHONDONTWRITEBYTECODE=1 \
  "$DMREDA_REPRO_ROOT/venv/bin/python" -B \
  -m gold_line.structural_manifold.pqd16c_benchmark --help

PYTHONDONTWRITEBYTECODE=1 \
  "$DMREDA_REPRO_ROOT/venv/bin/python" -B \
  -m gold_line.benchmarks.dmreda_pqd16c_streaming_benchmark --help

PYTHONDONTWRITEBYTECODE=1 \
  "$DMREDA_REPRO_ROOT/venv/bin/python" -B \
  dmreda_pqd16c_streaming_benchmark.py --help
```

The wrappers must resolve to the canonical Structural Manifold implementation;
they are not Core FSM benchmarks.

## Internal dummy-archive small benchmark only

The dummy archive is intentionally absent from the public reproducibility
package. If an authorized internal audit supplies it, verify it before any
benchmark command:

```bash
DMREDA_SMOKE_ARCHIVE=results/pqd16c_cache/pqd16c.zip
test -f "$DMREDA_SMOKE_ARCHIVE"
printf '%s  %s\n' \
  002e1ddb8bf71d7772daf450f6710c6df7c6ab1fd385a3ef6ada784f65c16a4a \
  "$DMREDA_SMOKE_ARCHIVE" | shasum -a 256 -c -
```

Only after that preflight may the strict-offline, bounded small benchmark be
invoked:

```bash
DMREDA_SMOKE_OUTPUT=$(mktemp -d)
PYTHONDONTWRITEBYTECODE=1 \
  "$DMREDA_REPRO_ROOT/venv/bin/python" -B \
  -m gold_line.structural_manifold.pqd16c_benchmark \
  --small-benchmark \
  --offline \
  --dataset-archive "$DMREDA_SMOKE_ARCHIVE" \
  --runs 4 \
  --output-dir "$DMREDA_SMOKE_OUTPUT"
```

`--offline` fails closed if neither the explicit archive nor the canonical cache
exists; it never falls back to Kaggle. External network denial remains useful
defense in depth. Output from this command is only local engineering evidence
because the cached member is `dummy.csv` and its relationship to PQD-16c is
unresolved.

## Scientific dataset evaluation remains blocked

A PQD-16c evaluation must not begin until all of the following are recorded:

- authoritative dataset source and version;
- archive and selected-member SHA-256 hashes;
- waveform channel and sampling-rate contract;
- dataset license, citation, and redistribution decision;
- disjoint calibration/evaluation partitions;
- frozen configuration and configuration hash;
- complete runtime manifest and output schema version.

No cached filename, successful smoke command, or passing import test satisfies
those conditions.
