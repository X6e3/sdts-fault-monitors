#!/usr/bin/env python3
"""Deterministic, dataset-free Structural Manifold feature smoke check.

This validates only the pinned environment and the encoded feature-path fixture.
It is not scientific validation and does not evaluate detector performance.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np


PACKAGE_DIR = Path(__file__).resolve().parent
REPOSITORY_ROOT = PACKAGE_DIR.parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from gold_line.structural_manifold.pqd16c_benchmark import (  # noqa: E402
    STRUCTURAL_BASE_RHO,
    STRUCTURAL_SIGMA,
    augmented_features,
    structural_noise_stream,
)


def _array_sha256(array: np.ndarray, dtype: str) -> str:
    canonical = np.asarray(array, dtype=dtype, order="C")
    return hashlib.sha256(canonical.tobytes(order="C")).hexdigest()


def _runtime_record() -> dict[str, Any]:
    return {
        "python_implementation": platform.python_implementation(),
        "python_version": platform.python_version(),
        "operating_system": platform.system(),
        "macos_version": platform.mac_ver()[0],
        "architecture": platform.machine(),
        "packages": {
            name: importlib.metadata.version(name)
            for name in ("numpy", "scipy", "matplotlib", "kaggle")
        },
    }


def _compare(expected: Any, observed: Any, field: str, failures: list[str]) -> None:
    if expected != observed:
        failures.append(f"{field}: expected {expected!r}, observed {observed!r}")


def run_smoke(config_path: Path) -> dict[str, Any]:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if config.get("validation_level") != "synthetic_smoke":
        raise ValueError("smoke configuration must declare validation_level=synthetic_smoke")
    if config.get("scientific_validation") is not False:
        raise ValueError("smoke configuration must explicitly reject scientific validation")
    if config.get("dataset_required") is not False:
        raise ValueError("dataset-free smoke configuration unexpectedly requires a dataset")

    generator = config["generator"]
    feature_config = config["feature_extraction"]
    expected = config["expected"]
    failures: list[str] = []

    _compare(generator["rho"], STRUCTURAL_BASE_RHO, "generator.rho", failures)
    _compare(generator["sigma"], STRUCTURAL_SIGMA, "generator.sigma", failures)

    rng = np.random.default_rng(int(generator["seed"]))
    signal = structural_noise_stream(rng, int(generator["length"]))
    indices, features = augmented_features(signal, int(feature_config["window"]))

    observed = {
        "signal_shape": list(signal.shape),
        "indices_shape": list(indices.shape),
        "features_shape": list(features.shape),
        "signal_sha256_float64_le": _array_sha256(signal, "<f8"),
        "indices_sha256_int64_le": _array_sha256(indices, "<i8"),
        "features_sha256_float64_le": _array_sha256(features, "<f8"),
        "all_features_finite": bool(np.all(np.isfinite(features))),
    }

    for field, expected_value in expected.items():
        _compare(expected_value, observed[field], f"expected.{field}", failures)

    runtime = _runtime_record()
    for field, expected_value in config["validated_runtime"].items():
        _compare(expected_value, runtime[field], f"validated_runtime.{field}", failures)

    result = {
        "config_id": config["config_id"],
        "validation_level": "synthetic_smoke",
        "scientific_validation": False,
        "status": "pass" if not failures else "fail",
        "runtime": runtime,
        "observed": observed,
        "failures": failures,
    }
    if failures:
        raise RuntimeError(json.dumps(result, indent=2, sort_keys=True))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PACKAGE_DIR / "config-smoke.json",
        help="path to the deterministic smoke configuration",
    )
    args = parser.parse_args()
    print(json.dumps(run_smoke(args.config), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
