# DMREDA Repo Audit: Gold Line

> Historical audit copy retained for provenance. See
> `../docs/CANONICAL_DMREDA.md` for the current Core FSM versus Structural
> Manifold separation and corrected evaluation contract.

Static audit only. No network access. No benchmark results were recomputed for this report.

Scanned inventory:
- 43 source/doc files under the workspace root.
- 39 candidate detector/benchmark/evaluation artifacts were scored.
- 4 support files were left unscored because they do not define detector claims directly: `signal_gen.py`, `Framework_v0_design.md`, `__init__.py`, `utils.py`.

## Executive Summary

- The repo's true Gold Line today is a stack, not a single script: the deployable detector core is [`compute_dmreda_reference()` in `dmreda_reference_clean.py`](../dmreda_reference_clean.py), and the strongest evidence-grade benchmark harness is [`dmreda_pqd16c_streaming_benchmark.py`](../dmreda_pqd16c_streaming_benchmark.py).
- The clean reference is the clearest statement of the intended architecture: causal trailing baseline, bounded regime FSM, pending/confirm logic, refractory, and analyzable state traces.
- The strongest benchmark-grade calibration in the repo is full-length noise-only ARL matching in `dmreda_pqd16c_streaming_benchmark.py`; most other benchmark scripts still leak by calibrating on the same event traces they evaluate.
- `validation_sweep.py` and `benchmark_reference.py` are scientifically useful and close to Gold, but both still rely on pooled pre-onset data from the evaluation trials instead of a dedicated noise-only bank.
- `dmreda_delay_benchmark_v2.py` is good for latency characterization of the clean reference, but it is not yet a fair claim script because RMS calibration is not noise-bank/ARL based.
- `dmreda_reference.py` remains structurally sound, but the clean version supersedes it for any serious benchmark claim.
- `dmreda_core_test.c` is not a benchmark, but it is the strongest portability artifact in the repo: fixed buffers, no malloc, deterministic loops, and embedded-style feature extraction.
- The repo is scientifically strongest when it stays close to the cleaned DMREDA core and benchmark-grade when it uses event-level ARL calibration.
- The main remaining Gold Line gap is standardization, not invention: one shared noise-only calibration bank and one shared benchmark gate contract should replace ad hoc thresholding across scripts.

## Ranked Gold Line Files

### 1. `dmreda_pqd16c_streaming_benchmark.py`

Status: Gold Line benchmark-grade, partial portability gap  
Score: 23/25
- Causality: 5
- Calibration fairness: 5
- Event-level evaluation: 5
- Reproducibility: 5
- Portability alignment: 3

Purpose:
- Research-grade streaming benchmark harness for DMREDA-style sequential detection against fair scalar baselines on long synthetic streams.
- This is the only repo script that currently enforces full-length noise-only ARL matching, shared persistence gating, reproducibility hashes, and sample-domain reporting in one place.

Key evidence anchors:
- Causal trailing RMS and persistence gate: `trailing_rms()`, `persistent_mask()`, `gate_score_series()` at `dmreda_pqd16c_streaming_benchmark.py:430-451` and `:619-631`.
- Fair ARL calibration for scalar baselines: `calibrate_threshold()` at `dmreda_pqd16c_streaming_benchmark.py:657-683`.
- Hard ARL assertions and drift sanity: `build_scalar_detector_model()` at `dmreda_pqd16c_streaming_benchmark.py:686-715`.
- Robust sequential centering and ARL search for DMREDA feature manifold: `build_dmreda_model()` at `dmreda_pqd16c_streaming_benchmark.py:1129-1196`.
- RMS sequential baseline with the same ARL procedure: `build_rms_model()` at `dmreda_pqd16c_streaming_benchmark.py:1199-1237`.
- Reproducibility anchors: `file_sha256()`, `config_hash()` at `dmreda_pqd16c_streaming_benchmark.py:221-229`, detector metadata emitted at `:1428-1545`.

Why it's Gold:
- It is the only benchmark in the repo that calibrates detector thresholds on noise-only full-length streams and verifies ARL explicitly.
- It uses a shared persistence contract for all scalar detectors, instead of letting each baseline choose its own alarm semantics.
- It captures reproducibility state directly in outputs, including hashes and detector parameter blocks.
- It reports delay, miss, FP, and exclusive-detection comparisons in sample domain.

Main gap to become perfect:
- Runtime path still includes covariance inversion and augmented feature whitening inside the claimed DMREDA-style manifold detector.
- Scenario generation uses heavy signal processing for fairness stress cases; acceptable for benchmarking, not portable runtime.
- A frozen-whitening or diagonal-whitening plan is still missing from the script itself.

Hard flags:
- `HEAVY_RUNTIME` for the manifold detector runtime path (`mahalanobis_series()` and `np.linalg.pinv` in `build_dmreda_model()`).

---

### 2. `dmreda_reference_clean.py`

Status: Gold Line detector core  
Score: 20/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 4
- Portability alignment: 5

Purpose:
- Cleaned research-grade reference implementation of the intended DMREDA core.
- Provides the causal detector logic that should be treated as the canonical algorithmic reference.

Key evidence anchors:
- Warm-up definition: `compute_warmup_samples()` at `dmreda_reference_clean.py:300-304`.
- Core detector: `compute_dmreda_reference()` at `dmreda_reference_clean.py:307-569`.
- Causal trailing median + prefix-sum trailing energy: `mu[t]` and `e_prefix` update at `dmreda_reference_clean.py:410-415`.
- Pending / confirm / refractory logic: `dmreda_reference_clean.py:433-488`.
- Regime-tick bounded adaptation: `dmreda_reference_clean.py:490-518`.
- Self-tests: `_self_test()` at `dmreda_reference_clean.py:572-616`.

Why it's Gold:
- Causal signal path only: trailing median, trailing energy, EMA baseline, finite-lag growth, fixed regime tick.
- Finite-state behavior is explicit and inspectable through `state`, `pending`, `confirmed`, `event_times`, `m_eff`, and `confirm_len_eff`.
- Input validation is strong enough for a reference implementation.
- The self-test block catches basic regressions without external frameworks.

Main gap to become perfect:
- No built-in noise-only calibration helper. Threshold/profile calibration still lives outside the core.
- No embedded fixed-point mirror or cycle-count reference alongside the Python reference.

Hard flags:
- None.

---

### 3. `validation_sweep.py`

Status: Partial Gold Line benchmark  
Score: 20/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 5
- Reproducibility: 4
- Portability alignment: 4

Purpose:
- Constrained characterization sweep over `W1`, threshold scalings, and trigger mode, using the causal DMREDA reference and a structurally matched RMS event detector.
- Good for operating-region mapping, not yet final claim-grade calibration.

Key evidence anchors:
- Explicit constrained sweep grid: `make_eval_config_grid()` at `validation_sweep.py:81-111`.
- Shared warm-up rule and event-level evaluation: `evaluate_event_times()` at `validation_sweep.py:130-142`.
- Structurally matched RMS event wrapper: `rms_event_detector_causal()` usage at `validation_sweep.py:173-181` and `:204-212`.
- DMREDA mode routing and warm-up filtering: `evaluate_dmreda_config()` at `validation_sweep.py:226-251`.
- Best-configuration selection under RMS FA constraint: `validation_sweep.py:368-423`.

Why it's Gold:
- It correctly wraps RMS as an event detector instead of a bare threshold comparator.
- It measures latency and false alarms at event level.
- The sweep space is explicitly bounded and deterministic.
- It respects warm-up blindness for both DMREDA and RMS outputs.

Main gap to become perfect:
- RMS threshold calibration is still built from pooled pre-onset regions of the same evaluation trials (`validation_sweep.py:159-193`).
- DMREDA evaluation uses the same trial set for characterization and threshold selection; there is no separate noise-only calibration bank.

Hard flags:
- `LEAKAGE` because threshold selection uses pooled pre-onset data from the same evaluated trials.

---

### 4. `dmreda_reference.py`

Status: Gold Line detector core, superseded by clean reference  
Score: 19/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 3
- Portability alignment: 5

Purpose:
- Original causal DMREDA reference implementation with regime profiles, transitions, and native confirmation logic.
- Still scientifically defensible as the original algorithmic reference, but now superseded by the cleaned file.

Key evidence anchors:
- Profiles and transitions: `DEFAULT_PROFILES` / `DEFAULT_TRANSITIONS` at `dmreda_reference.py:63-138`.
- Warm-up rule: `compute_warmup_samples()` at `dmreda_reference.py:186-190`.
- Core detector: `compute_dmreda_reference()` at `dmreda_reference.py:193-419`.
- Event confirmation and refractory: `dmreda_reference.py:304-360`.

Why it's Gold:
- Core state machine is already finite and causal.
- Confirmation logic is explicit and event-based.
- The algorithm matches the intended v0.5-style architecture closely enough to defend implementation claims.

Main gap to become perfect:
- The clean reference now has better validation, shape checks, debug hooks, and self-tests; this file should no longer be the benchmark import target.
- No repo-standard calibration helper is bundled with it.

Hard flags:
- None.

---

### 5. `benchmark_reference.py`

Status: Partial Gold Line benchmark  
Score: 18/25
- Causality: 5
- Calibration fairness: 2
- Event-level evaluation: 4
- Reproducibility: 3
- Portability alignment: 4

Purpose:
- First serious causal benchmark harness that compares DMREDA reference output with causal RMS using event times rather than sample-wise ROC only.
- Important bridge script between playground thresholding and benchmark-grade event evaluation.

Key evidence anchors:
- Shared threshold-crossing to event conversion: `threshold_crossing_events()` at `benchmark_reference.py:17-44`.
- Event evaluation: `evaluate_events()` at `benchmark_reference.py:47-61`.
- Threshold search targeting FA rate: `calibrate_threshold_to_fa_rate()` at `benchmark_reference.py:88-133`.
- Matched RMS evaluation against DMREDA event FA: `evaluate_condition()` at `benchmark_reference.py:202-266`.

Why it's Gold:
- It reports detection and false alarms as event-level outcomes.
- It uses causal RMS, not centered RMS.
- It explicitly attempts FA matching between DMREDA and RMS instead of comparing arbitrary thresholds.

Main gap to become perfect:
- Thresholds come from pooled pre-onset regions of the evaluated event trials, not a dedicated noise-only bank.
- Event gate is simpler than the native DMREDA confirmation logic and should be replaced by a shared benchmark gate helper.

Hard flags:
- `LEAKAGE` because calibration is done on `score[warmup:meta.start]` from the same evaluated trials.

---

### 6. `dmreda_delay_benchmark_v2.py`

Status: Partial Gold Line benchmark  
Score: 17/25
- Causality: 5
- Calibration fairness: 1
- Event-level evaluation: 3
- Reproducibility: 5
- Portability alignment: 3

Purpose:
- Deterministic Monte Carlo delay benchmark for the clean DMREDA reference, with strict and effective delay definitions.
- Useful for latency accounting, not yet a fair detector-comparison harness.

Key evidence anchors:
- Deterministic config and seed: `np.random.seed(42)` and `rng_master` at `dmreda_delay_benchmark_v2.py:239-266`.
- Clean reference usage: `compute_dmreda_reference()` at `dmreda_delay_benchmark_v2.py:173`.
- Delay metric definitions: `effective_onset()` and `run_single()` at `dmreda_delay_benchmark_v2.py:107-113` and `:150-192`.
- JSON/reporting path: `RESULT_PATH` and payload build at `dmreda_delay_benchmark_v2.py:49` and `:242-280`.

Why it's Gold:
- It is deterministic and sample-domain.
- It measures latency using the cleaned reference, not the non-causal legacy score.
- It distinguishes strict delay from effective delay, which is a useful reporting discipline.

Main gap to become perfect:
- RMS path is optional and not calibrated by noise-only ARL.
- `rms_detect()` uses same-run pre-onset mean/std (`dmreda_delay_benchmark_v2.py:128-144`), which is acceptable for a quick baseline but not a Gold fairness claim.
- Event-level FA is reduced to run-level flags rather than a shared calibrated alarm contract.

Hard flags:
- `LEAKAGE` in the optional RMS baseline because thresholding uses same-run pre-onset statistics.
- `CLAIM_RISK` because the file title says "fair, deterministic" while calibration fairness is not benchmark-grade.

---

### 7. `dmreda_core_test.c`

Status: Gold Line support artifact, not a claim benchmark  
Score: 15/25
- Causality: 5
- Calibration fairness: 0
- Event-level evaluation: 0
- Reproducibility: 5
- Portability alignment: 5

Purpose:
- Embedded-style C99 feature extraction and centroid-distance sanity check.
- Best current evidence that the repo can express bounded, deterministic signal features without Python-only conveniences.

Key evidence anchors:
- Fixed sizes and no malloc: `NUM_SAMPLES`, `FEATURE_WINDOW`, static buffers at `dmreda_core_test.c:4-98`.
- Deterministic RNG and Box-Muller: `set_seed()`, `gaussian_box_muller()` at `dmreda_core_test.c:116-150`.
- Embedded-style window feature extraction: `compute_window_features()` at `dmreda_core_test.c:270-329`.
- Static processing loop: `for (i = FEATURE_WINDOW - 1; i < NUM_SAMPLES; ++i)` in `accumulate_and_store_features()` at `dmreda_core_test.c:332-340`.

Why it's Gold:
- This is the strongest portability artifact in the repo.
- All buffers are fixed-size globals and loops are deterministic.
- The low-frequency ratio uses an IIR low-pass proxy, which is closer to embedded reality than the FFT versions in Python.

Main gap to become perfect:
- It is not a detector yet. No event logic, no persistence, no refractory, no FP calibration.
- It should eventually mirror a reduced Gold Line benchmark or detector core in C, not only feature geometry.

Hard flags:
- None.

## Repo-Wide Gold Protocol

### Shared calibration protocol

- Build a dedicated noise-only calibration bank per operating configuration.
- Match calibration streams to runtime conditions:
  - same stream length distribution
  - same noise color model
  - same warm-up rule
  - same persistence and refractory semantics
- Warm-up rule:
  - `warmup_samples = max(W1_max, W2_max) + confirm_max`
  - detector state updates still run during warm-up
  - no candidate, pending, confirm accumulation, or FP counting before warm-up
- Scalar channels:
  - use robust location/scale (`median`, `MAD`) for centering
  - for sequential accumulation, verify near-zero drift under H0 numerically before ARL search
- Whitened multivariate channels:
  - estimate `μ_noise`, `Σ_noise` on the pooled noise bank only
  - regularize once
  - if portability is required, freeze whitening offline or reduce to diagonal scaling
- Threshold selection:
  - calibrate to target ARL in samples, not to per-trace quantiles
  - record achieved ARL and fail if outside tolerance
- Report:
  - event FP rate and/or ARL
  - miss rate
  - strict delay distribution
  - effective delay distribution if used

### Shared event gate contract

- Benchmark-level alarm contract for all non-native scalar detectors:
  - candidate if `score > h`
  - confirm only after `P` consecutive positive detector updates
  - refractory `R` blocks new alarms after confirmation
  - only confirmed alarms count
  - only alarms after warm-up count
- Native DMREDA exception:
  - keep the existing two-stage `pending -> confirmed` area/persistence logic from `compute_dmreda_reference()`
  - benchmarks must compare only `event_times` from that confirmed path
- Minimal standard parameters:
  - one repo-default `P`
  - one repo-default `R`
  - explicit warm-up exclusion rule
  - same alarm semantics across all baselines

## Unscored Support Files

- `signal_gen.py`: useful deterministic synthetic generator; not a detector or benchmark claim file.
- `Framework_v0_design.md`: valuable design document; not executable evidence.
- `__init__.py`: package marker only.
- `utils.py`: currently empty; no scientific role visible.
