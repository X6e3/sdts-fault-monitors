# DMREDA Research Workspace

The repository contains two different algorithmic families. They share research
history, but they are not interchangeable implementations.

## Canonical families

1. **DMREDA Core FSM** — the canonical causal, bounded-state detector:
   `gold_line/core/dmreda_reference_clean.py`
2. **Structural Manifold Detector** — a heavier sliding-feature,
   covariance/Mahalanobis, sequential-CUSUM research detector:
   `gold_line/structural_manifold/`

The first is the DMREDA canonical core. The second must not be reported as a C
port or benchmark of that core.

Start with:

- `docs/CANONICAL_DMREDA.md` — ownership, data flow, compatibility paths, and commands
- `docs/INPUT_SCALING_CONTRACT.md` — required external scaling/calibration contract
- `gold_line/README.md` — claim boundaries
- `playground/README.md` — exploratory code
- `deprecated/README.md` — preserved historical code

## Fast validation

From the repository root, with a Python runtime that provides NumPy:

```bash
python3 -m unittest discover -s tests -v
```

The test suite compiles the fixed-state C99 mirror with strict warnings and
checks both implementations against the same immutable golden fixtures. It
also compares sample-by-sample traces over 100 fixed randomized seeds. Float
traces use a declared absolute tolerance; state, pending, confirmation, event
authority, and event indices must match exactly.

Additional deliberate validation commands are documented in
`docs/CANONICAL_DMREDA.md`: golden-fixture regeneration is never automatic,
long/high-amplitude parity stress is opt-in, and the host memory report
separates persistent state from stack, caller buffers, and binary sections.

Structural Manifold clean-environment and strict-offline validation is recorded
under `repro/structural_manifold/`. Its synthetic and dummy-cache smoke runs are
engineering checks, not PQD-16c scientific validation.

Root-level legacy entry points remain as compatibility wrappers. New work must
import the tiered packages directly.
