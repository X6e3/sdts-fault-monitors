# A Negative Validation and State-Reduction Study of a Deterministic Streaming Detector

## Draft status

- **[DIRECT EVIDENCE]** This is a negative/inconclusive paper draft, not a submission-ready claim of novelty or superiority.
- **[UNKNOWN]** Publication requires fresh normal data, and any performance paper also requires a subsequently authorized untouched fault evaluation.

## Abstract

We audit a causal streaming detector composed of rolling-median residuals, finite-window residual energy, exponentially weighted normalization, lagged-growth scoring, finite-duration confirmation, refractory suppression, and a slow regime state machine. **[DIRECT EVIDENCE]** In an immutable validation at a 960-sample mission horizon, the detector produced authority on 42 of 500 independent normal simulation trajectories (8.4%), exceeding a frozen maximum of 25 (5%); the fault holdout was therefore not opened. Post-hoc replay shows that a growth-only opening mode affects the same 42 trajectories and that every first false authority confirms in the initial regime before a regime transition. **[DIRECT EVIDENCE]** Development-only A–L ablations select a smaller six-consecutive-threshold rule under a frozen simplicity/noninferiority criterion, while Page-style CUSUM and EWMA comparators are stronger on the available fault-development bank. The comparator result is confounded because fault onset precedes the authority warm-up boundary. We construct a sufficient authority-state representation and explicit history collisions showing when pending age, excess area, qualifying count, snapshotted contract, and refractory state are necessary. We also provide bounded Python and C99 implementations with exact per-sample parity on 1,039,792 enumerated samples. **[DIRECT EVIDENCE]** No genuinely untouched normal bank remains after finalization; the reduced candidate is therefore inconclusive and the locked fault holdout remains sealed. **[STRONG INFERENCE]** The strongest present contribution is reproducible negative-result analysis and deterministic state/implementation reduction, not evidence for a new detector family.

## 1. Introduction

Sequential detectors are often made more complex by adding robust preprocessing, multiple score channels, persistence gates, adaptive modes, and refractory logic. Complexity can be justified only if each state represents a necessary invariant or improves an operating trade-off under independent evaluation.

The audited repository describes its canonical Core using project-specific terminology. We instead reduce it to standard mechanisms and ask four falsifiable questions:

1. Does the frozen detector satisfy its independent normal operating-risk gate?
2. Which state transitions cause the observed negative result?
3. Can the decision semantics be represented with less authority state?
4. Does a simpler architecture retain development behavior under a frozen selection rule?

**[DIRECT EVIDENCE]** The primary result is negative: the independent normal gate fails. We preserve that result and treat all subsequent analysis of the spent bank as forensic rather than confirmatory.

## 2. Historical detector

For scaled scalar input `x_t`, the historical representation computes a trailing median `mu_t`, absolute residual `e_t`, rolling residual sum `E_t`, exponentially weighted baseline `B_t`, and bounded normalized deviation

`D_t = clamp((E_t - max(B_t,e_floor))/max(B_t,e_floor), -5, 5)`.

A finite-lag difference of `D` is exponentially smoothed into `G`. A slow residual statistic drives a three-state hysteretic controller. A candidate opens when D or G crosses an opening threshold, then accumulates positive D excess and a count of D threshold exceedances under an opening-time snapshotted contract. It confirms when both area and count thresholds are met before timeout; confirmation starts refractory dead time.

- **[DIRECT EVIDENCE]** The source of truth is `../gold_line/core/dmreda_reference_clean.py` at commit `7fb1fe26...`; TEP parameters are in `../stage3/tep/configuration.py`.
- **[DIRECT EVIDENCE]** Event authority is disabled through sample 91 while representation updates continuously.
- **[STRONG INFERENCE]** This is a handcrafted nonlinear sequential score followed by a deterministic FSM. It is neither a learned anomaly model nor a likelihood-ratio test.

## 3. Immutable validation

The frozen Stage 3.3 protocol uses independent FaultFreeTesting trajectories with H=960. The first authority owns each trajectory; a no-authority run is right-censored at H. The admission maximum is 25 authorities among 500 trajectories.

- **[DIRECT EVIDENCE]** Observed authority count is 42/500, Wilson 95% interval `[0.06274,0.11160]`; total events are 45.
- **[DIRECT EVIDENCE]** Restricted mean time to authority is 920.824 with H substituted for censored runs; this is not uncensored ARL.
- **[DIRECT EVIDENCE]** The admission seal denies Bank D and the progress ledger records FaultyTesting unopened.

The empirical horizon curve is:

| H | trajectories with authority | risk |
|---:|---:|---:|
| 120 | 3 | 0.006 |
| 160 | 5 | 0.010 |
| 240 | 10 | 0.020 |
| 480 | 22 | 0.044 |
| 720 | 31 | 0.062 |
| 960 | 42 | 0.084 |

**[DIRECT EVIDENCE]** The mission risk is horizon-dependent. Reporting a short-horizon value as if it characterized H=960 would be incorrect.

## 4. Failure forensics

We replay the frozen normal extract under D-or-G, D-only, and G-only opening without changing thresholds or representation.

- **[DIRECT EVIDENCE]** D-or-G and G-only affect identical trajectory membership (42/500); three first indices differ by +1 under G-only.
- **[DIRECT EVIDENCE]** D-only affects 32/500 trajectories.
- **[DIRECT EVIDENCE]** First-opening branches among the 42 trajectories are G-only 27, both D and G 12, and D-only 3.
- **[DIRECT EVIDENCE]** All 42 open in state 0 and confirm before a first regime transition.
- **[DIRECT EVIDENCE]** Pending duration has range 7–17 and median 11. Confirmation area is 4.500769–5.045358 against threshold 4.5; qualifying count is 7–16 against minimum 6.

**[STRONG INFERENCE]** Normal excursions cross the lagged-growth opening threshold and then persist in positive normalized residual energy long enough to satisfy both confirmation gates. Candidate confirmation delays those excursions but does not reject them. The slow regime FSM is not causal in these first failures.

## 5. Minimal authority state

Given representation/profile histories, a sufficient authority state is `(ell,A,C,Q,R)`, where `ell` is pending age, `A` positive excess area, `C` qualifying count, `Q` the snapshotted opening contract, and `R` refractory remainder.

- **[DIRECT EVIDENCE]** `pending_active` is equivalent to `ell>0`, and `pending_start=t-ell+1`; they need not be stored independently.
- **[DIRECT EVIDENCE]** Explicit collision histories show that removing C, ell, or Q can merge states that produce different decisions under a common suffix.
- **[DIRECT EVIDENCE]** R is required only to preserve multi-event semantics after a confirmation.
- **[STRONG INFERENCE]** The project-level candidate abstraction is semantically meaningful only through these sufficient numeric/contract states, not through its names or extra booleans.

## 6. Development ablations

We freeze a development-only protocol over spent TEP banks, with H=500, a complete κ grid, deterministic scalar-threshold enumeration, clustered bootstrap, and a simplicity/noninferiority selection rule. Twelve variants isolate opening channels, regime transitions, adaptive representation, area, count, run rules, hysteresis, Page-style CUSUM, and EWMA.

- **[DIRECT EVIDENCE]** Full A yields normal-development risk 24/300 and fault detection 108/400 with restricted delay 389.0025.
- **[DIRECT EVIDENCE]** Reduced H yields 20/300 and 113/400 with restricted delay 389.0525 and is the first eligible architecture in the frozen simplicity order.
- **[DIRECT EVIDENCE]** Count-only G is inferior to A under the frozen margins.
- **[DIRECT EVIDENCE]** CUSUM J yields 13/300 and 188/400; EWMA K yields 15/300 and 208/400.
- **[DIRECT EVIDENCE]** Fault onset is 20 and authority warm-up is 92.

**[STRONG INFERENCE]** The A-versus-H result supports engineering simplification. The J/K result undermines unrestricted added-value claims but cannot establish steady-state superiority because 72 changed samples update detector states before authority begins.

## 7. Bounded implementation

The selected H candidate retains a seven-sample median, 16-sample residual sum, 1/32 EWMA baseline, normalized D threshold 0.8, six-sample run rule, warm-up 92, and refractory 80.

- **[DIRECT EVIDENCE]** Python and C99 share configuration hash `4463e0e5...`.
- **[DIRECT EVIDENCE]** Exact exposed-state/output parity holds for 930,000 samples from permitted TEP extracts, 1,488 golden samples, and 108,304 deterministic randomized samples.
- **[DIRECT EVIDENCE]** The arm64 C ABI uses 232 bytes persistent state; the measured object is 2,345 bytes.
- **[DIRECT EVIDENCE]** A numerical-cancellation regression clamps a mathematically nonnegative drained running sum to zero in both implementations.
- **[UNKNOWN]** MCU WCET, energy, jitter, float32/fixed-point equivalence, and checkpoint persistence are unmeasured.

## 8. Relationship to established methods

Page CUSUM, Roberts EWMA, SPRT, finite-horizon change detection, window-limited sequential methods, robust median identifiers, and control-chart run rules precede this implementation. The historical score is not exactly a likelihood-ratio CUSUM or SPRT, but its components map to robust preprocessing, leaky integration, threshold accumulation, run rules, hysteresis, and dead time.

- **[STRONG INFERENCE]** The full detector is a known-component composition rather than demonstrated new sequential theory.
- **[UNKNOWN]** Exact prior-art identity or novelty requires a systematic review beyond the bounded primary-source positioning in `LITERATURE_POSITIONING.md`.

## 9. Threats to validity

- **[DIRECT EVIDENCE]** Historical κ=2.5 selection lineage is unavailable.
- **[DIRECT EVIDENCE]** The selected H threshold and architecture are post-hoc development choices.
- **[DIRECT EVIDENCE]** Existing normal banks are spent; no fresh gate was run.
- **[DIRECT EVIDENCE]** FaultyTesting was not opened, so no final fault estimate exists.
- **[DIRECT EVIDENCE]** Startup confounding weakens fault-development comparator interpretation.
- **[UNKNOWN]** Cross-domain robustness and physical-sensor behavior are unknown.

## 10. Conclusion

**[DIRECT EVIDENCE]** The historical detector fails its frozen normal gate. **[DIRECT EVIDENCE]** A smaller bounded candidate can reproduce the selected development semantics and Python/C implementations agree exactly on extensive replay, but the candidate has no untouched normal or fault validation. **[STRONG INFERENCE]** Current evidence favors the explanation that the historical system is an overcomplicated known-family sequential detector with strong engineering controls. The appropriate final category is **D. INCONCLUSIVE — FRESH DATA REQUIRED**.

## Primary references

1. Wald, A. and Wolfowitz, J. (1948), [Optimum Character of the Sequential Probability Ratio Test](https://projecteuclid.org/journals/annals-of-mathematical-statistics/volume-19/issue-3/Optimum-Character-of-the-Sequential-Probability-Ratio-Test/10.1214/aoms/1177730197.full).
2. Page, E. S. (1954), [Continuous Inspection Schemes](https://academic.oup.com/biomet/article-abstract/41/1-2/100/456627).
3. Roberts, S. W. (1959), [Control Chart Tests Based on Geometric Moving Averages](https://doi.org/10.1080/00401706.1959.10489860).
4. Lorden, G. (1971), [Procedures for reacting to a change in distribution](https://authors.library.caltech.edu/records/n9ryc-0sr08).
5. Moustakides, G. V. (1986), [Optimal Stopping Times for Detecting Changes in Distributions](https://projecteuclid.org/journals/annals-of-statistics/volume-14/issue-4/Optimal-Stopping-Times-for-Detecting-Changes-in-Distributions/10.1214/aos/1176350164.full).
6. Xie, L., Moustakides, G. V., and Xie, Y. (2023), [Window-Limited CUSUM for Sequential Change Detection](https://arxiv.org/abs/2206.06777).
