# Final Algorithm Contract

## Scope

- **[DIRECT EVIDENCE]** This document defines the frozen finalization engineering candidate, development variant H. It does not redefine the historical Stage 3.3 algorithm or erase its 42/500 negative result.
- **[DIRECT EVIDENCE]** Canonical implementations are `core/dmreda_minimal_streaming.py` and `core/dmreda_minimal_streaming.c`/`.h` with configuration SHA-256 `4463e0e5252741b51ba85c22ce78b4e8ccd92bf111a0fd2452c8c7128c6acf9c`.
- **[DIRECT EVIDENCE]** Input is one finite, already-affine-scaled binary64-compatible scalar sample. The TEP mapping used in development was `(raw - 2705.0) / 7.561259999999865`, fitted historically on FaultFreeTraining runs 1–100.

## Mathematical update

For zero-based sample index `t` and input `x_t`:

1. **[DIRECT EVIDENCE]** `mu_t = median(x_{max(0,t-6)}, ..., x_t)` using the conventional average of the two center values while fewer than seven samples and the prefix length is even.
2. **[DIRECT EVIDENCE]** `e_t = |x_t - mu_t|`.
3. **[DIRECT EVIDENCE]** `E_t = sum_{i=max(0,t-15)}^t e_i`. The implementation uses a 16-entry ring and clamps a negative post-update floating-point cancellation residue to zero because the mathematical sum is non-negative.
4. **[DIRECT EVIDENCE]** `B_0 = E_0`; for `t>0`, `B_t = (1/32) E_t + (31/32) B_{t-1}`.
5. **[DIRECT EVIDENCE]** `S_t = max(B_t, 0.02)` and `D_t = clamp((E_t-S_t)/S_t, -5, 5)`.
6. **[DIRECT EVIDENCE]** Authority is disabled for `t<92`, but representation state updates normally.
7. **[DIRECT EVIDENCE]** Outside refractory, let `q_t = q_{t-1}+1` when `D_t>0.8`, otherwise `q_t=0`. A confirmation occurs when `q_t>=6`; then `q_t=0` and refractory is set to 80.
8. **[DIRECT EVIDENCE]** Refractory decrements before the current sample's authority test. The sample that reduces the counter to zero is eligible.

## Minimal pseudocode

```text
validate x_t before mutation
update 7-sample x ring; compute median
e_t = abs(x_t - median)
update 16-sample e ring and nonnegative running sum E_t
B_t = E_t if t == 0 else E_t/32 + 31*B_{t-1}/32
D_t = clamp((E_t - max(B_t, .02)) / max(B_t, .02), -5, 5)

if refractory > 0: refractory -= 1
if t < 92 or refractory > 0: q = 0
else if D_t > .8:
    q += 1
    if q == 6:
        emit confirmation
        q = 0
        refractory = 80
else: q = 0
```

## State and complexity

- **[DIRECT EVIDENCE]** Persistent semantic state is: 7 input samples, input ring count/position, 16 residual samples, residual ring count/position, residual running sum, EWMA baseline, sample index, consecutive counter, and refractory counter.
- **[DIRECT EVIDENCE]** State memory is constant with stream length. The measured arm64 C ABI is 232 bytes for state and 240 bytes for a checkpoint.
- **[DIRECT EVIDENCE]** The C median uses insertion sort over at most seven values; per-sample time and memory are bounded, but no MCU WCET is established.
- **[DIRECT EVIDENCE]** Invalid input and invalid checkpoints fail before state commit. C calculates into a local `next` state and commits only after validation.

## Removed historical mechanisms

- **[DIRECT EVIDENCE]** No lagged growth `G`, candidate-open flag, candidate excess area, candidate count snapshot, adaptive lag, adaptive confirmation duration, or regime FSM remains.
- **[STRONG INFERENCE]** The current decision layer is a run rule with refractory suppression, not a distinct candidate/pending detector.
- **[UNKNOWN]** It is not known whether removal improves untouched-data performance.

## Exactness boundary

- **[DIRECT EVIDENCE]** `evidence/streaming_parity_report.json` establishes exact Python/C equality for exposed binary64 outputs on the enumerated replays.
- **[UNKNOWN]** Exact equality is not claimed for other compilers, `-ffast-math`, non-IEC floating point, extended precision, fixed point, or a target whose median/overflow behavior differs.
- **[UNKNOWN]** Statistical validity is not implied by implementation parity.
