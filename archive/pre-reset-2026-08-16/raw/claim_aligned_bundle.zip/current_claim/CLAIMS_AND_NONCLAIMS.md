# Claims and Nonclaims

## Supported statements

- **[DIRECT EVIDENCE]** The historical Stage 3.3 implementation is causal under its fixed affine-input contract.
- **[DIRECT EVIDENCE]** Its immutable H=960 normal gate failed at 42/500 authorities, above the maximum 25/500.
- **[DIRECT EVIDENCE]** The failure is horizon-dependent: observed risk rises from 0.006 at H=120 to 0.084 at H=960.
- **[DIRECT EVIDENCE]** The historical D-or-G and G-only modes affect the same 42 normal trajectories on the spent validation bank, with three one-sample first-index differences.
- **[DIRECT EVIDENCE]** Historical authority bookkeeping can be represented without separate `pending_active` or `pending_start` fields as `(ell, A, C, open_contract)` plus a refractory counter for multi-event semantics.
- **[DIRECT EVIDENCE]** Development variant H was the first eligible architecture in the frozen simplicity order under the frozen development noninferiority rule.
- **[DIRECT EVIDENCE]** The final Python and C candidate implementations are configuration-bound, fixed-state, and exactly equal on all samples enumerated in `evidence/streaming_parity_report.json`.
- **[DIRECT EVIDENCE]** The final candidate has not passed an untouched normal gate and FaultyTesting was not opened during finalization.
- **[STRONG INFERENCE]** The repository contains strong reproducibility and research-integrity engineering despite weak evidence for a distinct detector family.

## Prohibited statements

- **[DIRECT EVIDENCE]** Do not claim that the immutable negative was repaired, rescued, or superseded.
- **[DIRECT EVIDENCE]** Do not claim classical uncensored ARL from `H`-substituted no-alarm run lengths. They are censored finite-horizon restricted times.
- **[DIRECT EVIDENCE]** Do not claim H's development normal risk (20/300) is independent validation; the architecture and threshold were selected using spent development data.
- **[DIRECT EVIDENCE]** Do not claim FaultyTesting performance, because it was not opened in finalization.
- **[DIRECT EVIDENCE]** Do not claim CUSUM/EWMA superiority in steady-state quickest detection from this fault-development bank; onset precedes warm-up.
- **[DIRECT EVIDENCE]** Do not claim MCU readiness from an arm64 macOS object measurement.
- **[UNKNOWN]** Do not claim novelty, patentability, or a new statistical detector family without a systematic external literature review.
- **[UNKNOWN]** Do not claim product readiness, safety integrity, or field false-alarm rates without hardware and physical-process validation.

## Permitted final description

**[STRONG INFERENCE]** "A causal, deterministic, bounded-state sequential detector engineering candidate that applies robust rolling residual-energy normalization and a persistent threshold rule. Its historical full architecture failed an independent finite-horizon normal gate; the reduced candidate remains unvalidated pending fresh normal and fault data."

## Final category

**D. INCONCLUSIVE — FRESH DATA REQUIRED**
