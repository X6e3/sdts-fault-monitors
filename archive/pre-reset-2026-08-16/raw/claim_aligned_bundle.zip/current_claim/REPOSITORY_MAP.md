# Repository Map and Ownership

## Active claim surface

`current_claim/` is the only finalization claim surface.

- `core/`: reduced variant H Python and C99 implementations.
- `evidence/historical_negative_forensics.json`: deterministic post-hoc replay of the immutable normal failure.
- `evidence/streaming_parity_report.json`: exact Python/C replay and host resource measurements.
- `evidence/locked_gate_status.json`: frozen candidate identity, required fresh bank, and stop decision.
- `tools/`: deterministic forensic and parity reproducers that reject FaultyTesting.
- report files: claims, algorithm, state, protocol, results, baselines, literature, implementation, limitations, paper, provenance, lineage, self-falsification, and this map.
- `SHA256SUMS`: portable hashes relative to `current_claim/`; the manifest excludes itself to avoid recursive hashing.

- **[DIRECT EVIDENCE]** No claim-grade result is permitted solely because it appears under this directory; every result retains its explicit evidence classification.

## Immutable historical evidence

`frozen_history/` is the authoritative Stage 3.3 forensic archive.

- `source/`: verified Git bundle for commit `7fb1fe26...`.
- `protocol/`: frozen H=960 protocol and Bank D denial seal.
- `results/`: 42/500 normal summary, trajectory rows, scalar reference calibration/admission, and manifests.
- `environment/`: source hashes, raw-data hashes, test report, and progress ledger.
- `golden/`: historical golden fixture.
- `reports/`: historical stop/resume/session records.

- **[DIRECT EVIDENCE]** `frozen_history/SHA256SUMS` binds the archive. No historical file was rewritten during finalization.

## Historical canonical implementation

- `gold_line/core/dmreda_reference_clean.py`: canonical full Core state machine.
- `stage3/tep/configuration.py`: TEP domain scaling and historical κ/profile configuration.
- `stage3/tep/`: admission, extraction, runner, checkpoint, seal, and analysis machinery.
- `gold_line/evaluation/` and `gold_line/benchmarks/`: finite-horizon accounting and scalar baseline infrastructure.
- `tests/stage3/` and root `tests/test_*.py`: contracts and regression evidence.

- **[DIRECT EVIDENCE]** These paths remain necessary to reproduce and falsify the historical result; they are not the final reduced algorithm.

## Development-only finalization

`experimental/finalization/` contains:

- frozen spent-data protocol;
- A–L ablation runner;
- authority-state reduction model and witnesses;
- deterministic candidate, trajectory, summary, and manifest outputs.

- **[DIRECT EVIDENCE]** These artifacts are explicitly non-claim-grade and must not be moved into a validation namespace.

## Separate algorithm family

- `gold_line/structural_manifold/` and `repro/structural_manifold/` implement a heavier sliding-feature/covariance/Mahalanobis/CUSUM research path.
- **[DIRECT EVIDENCE]** It is not the canonical Core, not the final candidate, and not evidence for Core performance.

## Legacy and exploratory surface

- `.dmreda_run_backups/`: approximately 43 MB of synthetic/exploratory results and plots, including broad parameter sweeps unrelated to TEP κ lineage.
- `playground/`: exploratory and diagnostic-only code.
- `deprecated/`: explicitly deprecated implementations.
- `dmreda/`, root wrappers, and root result files: compatibility/historical entry points.
- `docs/`, `repro/`, and older reports: important provenance, but mixed claim generations.

- **[STRONG INFERENCE]** These paths should be archived outside the active import/claim surface in a future repository split. They were preserved in this pass to avoid destroying provenance.

## Package authority

- **[DIRECT EVIDENCE]** The commit-bound Git bundle is authoritative for Stage 3.3.
- **[DIRECT EVIDENCE]** External `dmreda-stage3-current-20260805.tar.gz` differs in campaign source/test bytes and is an ad-hoc snapshot. It must be retained only as quarantined recovery material.
- **[DIRECT EVIDENCE]** Current finalization verification uses relative paths and `cd current_claim && shasum -a 256 -c SHA256SUMS`; no user-specific absolute path is claim-bearing.

## Recommended future repository surgery

1. **[STRONG INFERENCE]** Freeze `frozen_history/` as a tagged, read-only historical release.
2. **[STRONG INFERENCE]** Make `current_claim/core/` a small standalone library only after the fresh-normal decision.
3. **[STRONG INFERENCE]** Move Structural Manifold to a separate repository or top-level product with independent naming/versioning.
4. **[STRONG INFERENCE]** Export `.dmreda_run_backups/`, playground, deprecated code, and ad-hoc packages into a content-addressed research archive.
5. **[STRONG INFERENCE]** Keep only one supported CLI/import path and one versioned checkpoint/wire contract.
6. **[UNKNOWN]** Do not delete any historical material until external backup hashes and retention requirements are approved.

## Verification entry points

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
cd current_claim
shasum -a 256 -c SHA256SUMS
```

- **[DIRECT EVIDENCE]** The final full-suite run before packaging passed 240 tests.
