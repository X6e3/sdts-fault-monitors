# Literature Positioning

## Scope and claim boundary

- **[DIRECT EVIDENCE]** This is a bounded primary-source comparison, not a systematic review, patent search, or novelty opinion.
- **[UNKNOWN]** Novelty is not established. No use of the word "novel" is authorized by this document.
- **[STRONG INFERENCE]** The current detector is most defensibly positioned as a known-component engineering composition: robust rolling preprocessing, leaky normalization, persistent thresholding, and refractory state.

## Primary reference families

1. **Sequential probability-ratio testing.** Wald and Wolfowitz's 1948 paper proves an optimum-character result for SPRT under simple-hypothesis assumptions: [Project Euclid, DOI 10.1214/aoms/1177730197](https://projecteuclid.org/journals/annals-of-mathematical-statistics/volume-19/issue-3/Optimum-Character-of-the-Sequential-Probability-Ratio-Test/10.1214/aoms/1177730197.full).
2. **Page/CUSUM.** Page's 1954 continuous inspection scheme is the foundational cumulative sequential-control reference: [Oxford Academic, DOI 10.1093/biomet/41.1-2.100](https://academic.oup.com/biomet/article-abstract/41/1-2/100/456627).
3. **EWMA control charts.** Roberts's 1959 geometric moving-average tests establish exponentially decaying historical weighting: [Technometrics, DOI 10.1080/00401706.1959.10489860](https://doi.org/10.1080/00401706.1959.10489860) and the [publisher archive PDF](https://www.stat.cmu.edu/technometrics/59-69/VOL-01-03/v0103239.pdf).
4. **Quickest-change criteria.** Lorden formulates an optimal-stopping change problem and asymptotically optimal rules: [CaltechAUTHORS, 1971](https://authors.library.caltech.edu/records/n9ryc-0sr08). Moustakides establishes CUSUM optimality for a classical distribution-change formulation: [Project Euclid, DOI 10.1214/aos/1176350164](https://projecteuclid.org/journals/annals-of-statistics/volume-14/issue-4/Optimal-Stopping-Times-for-Detecting-Changes-in-Distributions/10.1214/aos/1176350164.full).
5. **Window-limited sequential detection.** Sliding-window estimation combined with CUSUM and recursive updates is explicit in Xie, Moustakides, and Xie: [arXiv:2206.06777](https://arxiv.org/abs/2206.06777).
6. **Finite-horizon false-alarm probability.** A 1994 nonparametric sequential changepoint paper explicitly assumes a finite horizon and controls a probability of false alarm: [Stochastic Processes and their Applications, DOI 10.1016/0304-4149(94)90051-5](https://www.sciencedirect.com/science/article/pii/0304414994900515).
7. **Run rules.** Multi-sample control-chart signaling rules were codified in the Western Electric handbook: [Western Electric, 1956, Google Books](https://books.google.com/books/about/Statistical_Quality_Control_Handbook.html?id=yx1pqn_aMLkC).
8. **Robust median/outlier identification.** Median-centered robust identification predates this repository; Davies and Gather formalize a Hampel-derived outlier identifier: [JASA, DOI 10.1080/01621459.1993.10476339](https://doi.org/10.1080/01621459.1993.10476339).

## Mechanism comparison

| Repository mechanism | Closest established concept | Relationship | Current classification |
|---|---|---|---|
| Fixed affine scalar input | calibrated measurement normalization | ordinary external calibration; causal only when frozen before evaluation | **[STRONG INFERENCE] KNOWN** |
| Trailing median and absolute residual | robust median/Hampel-style residual | exact window/energy composition differs, but robust median centering is established | **[STRONG INFERENCE] KNOWN COMPONENT** |
| Rolling residual sum | moving-window statistic | fixed-window sequential summaries are established | **[STRONG INFERENCE] KNOWN** |
| EWMA energy baseline | Roberts geometric moving average / leaky integrator | same first-order exponential recursion applied to residual energy | **[DIRECT EVIDENCE] KNOWN** |
| `D=(E-B)/B` with floor/clamp | normalized residual score | handcrafted score, not a likelihood ratio | **[STRONG INFERENCE] KNOWN COMBINATION** |
| Historical `G` | finite difference plus EWMA | high-pass/leaky derivative construction | **[STRONG INFERENCE] KNOWN COMBINATION** |
| Positive excess area within candidate | finite-horizon CUSUM-like accumulation | resembles CUSUM accumulation but has episodic open/timeout and no likelihood model | **[STRONG INFERENCE] CUSUM-LIKE, NOT CLASSICAL CUSUM** |
| Qualifying count / six consecutive exceedances | run rule | directly within established multi-sample signaling practice | **[STRONG INFERENCE] KNOWN** |
| Regime thresholds and refractory | hysteresis/dead-time FSM | ordinary deterministic control state | **[STRONG INFERENCE] KNOWN** |
| `P_infinity(tau<=H)` | finite-horizon false-alarm probability | appropriate finite-mission estimand; not ARL | **[STRONG INFERENCE] KNOWN METHODOLOGY** |
| Hash-bound replay/checkpoint/seals | reproducible engineering controls | implementation/research-integrity contribution rather than detection theory | **[STRONG INFERENCE] ENGINEERING CONTRIBUTION** |
| Authority-state collision witnesses | sufficient-state software/mathematical analysis | useful exact-semantics evidence; literature novelty not searched exhaustively | **[UNKNOWN] NOVELTY UNESTABLISHED** |

## CUSUM, EWMA, SPRT, hysteresis, leaky-integrator, and FSM reduction

- **[DIRECT EVIDENCE]** The historical Core is not SPRT: no pre/post distributions or log-likelihood ratio appear in canonical source.
- **[DIRECT EVIDENCE]** It is not classical Page CUSUM: its score is a normalized robust-energy deviation; positive excess is accumulated only during a threshold-opened candidate and is cleared on timeout/confirmation.
- **[DIRECT EVIDENCE]** It contains two EWMA/leaky-integrator recursions: energy baseline and smoothed lagged growth, plus a slower tick-updated activity term.
- **[DIRECT EVIDENCE]** It contains explicit hysteresis and an FSM: up/down thresholds with hold counters, candidate timeout, strict confirmation gates, and refractory dead time.
- **[STRONG INFERENCE]** The full construction therefore belongs inside the broad sequential-threshold/control-chart family, not outside it.
- **[DIRECT EVIDENCE]** The reduced final candidate is a run rule applied to a robust EWMA-normalized rolling score, followed by refractory dead time.

## Strongest novelty challenge

- **[STRONG INFERENCE]** Every detector ingredient has a clear known-family analogue, and the repository supplies no theorem or untouched cross-domain result showing a new operating regime unavailable to those families.
- **[STRONG INFERENCE]** The development evidence instead shows that standard CUSUM/EWMA scores can outperform the repository's more elaborate score on the available bank, albeit under a confounded startup contract.
- **[UNKNOWN]** The exact combined transfer function and decision automaton may not appear verbatim in the cited papers. Exact absence from the literature cannot be inferred from a bounded search.

## Publishable positioning, if future evidence succeeds

- **[STRONG INFERENCE]** A defensible paper would emphasize negative-result preservation, horizon-aware risk, state reduction, and deterministic embedded parity—not claim a fundamentally new sequential detector.
- **[UNKNOWN]** A distinct algorithmic contribution would require an exhaustive review, a precise mathematical problem where the construction differs from established robust CUSUM/EWMA/run-rule methods, and preregistered untouched experiments showing why that difference matters.
