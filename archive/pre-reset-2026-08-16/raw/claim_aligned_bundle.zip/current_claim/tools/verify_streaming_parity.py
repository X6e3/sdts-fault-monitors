#!/usr/bin/env python3
"""Compile the minimal C99 core and replay allowed Python/C parity banks."""

from __future__ import annotations

import argparse
import csv
import ctypes
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
from typing import Iterable

import numpy as np


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from current_claim.core.dmreda_minimal_streaming import (
    CONFIGURATION_SHA256,
    MinimalStreamingDetector,
)
from stage3.tep.configuration import apply_tep_affine_scale
from tests.golden_support import generate_signal, load_golden_set


C_SOURCE = REPOSITORY_ROOT / "current_claim/core/dmreda_minimal_streaming.c"
C_HEADER = REPOSITORY_ROOT / "current_claim/core/dmreda_minimal_streaming.h"
PYTHON_SOURCE = REPOSITORY_ROOT / "current_claim/core/dmreda_minimal_streaming.py"
EXPECTED_HASHES = {
    "normal_training": "f48e6735bc80d0ab0ab4b7aad4957a7203ed346ea1556ef7e1f37693fc686b4d",
    "fault_training": "c8c6990730c23be501260235417d2c8347653cf11faae056ac09e39b6288261d",
    "normal_testing": "9b7283e83fb4e31dec218df29aaedd934cfa7a32a4f678f6bb9bc85b68d68e7e",
}


class CState(ctypes.Structure):
    _fields_ = [
        ("x_ring", ctypes.c_double * 7),
        ("e_ring", ctypes.c_double * 16),
        ("e_sum", ctypes.c_double),
        ("e_baseline", ctypes.c_double),
        ("sample_index", ctypes.c_uint64),
        ("x_count", ctypes.c_uint32),
        ("x_position", ctypes.c_uint32),
        ("e_count", ctypes.c_uint32),
        ("e_position", ctypes.c_uint32),
        ("consecutive_count", ctypes.c_uint32),
        ("refractory_remaining", ctypes.c_uint32),
    ]


class COutput(ctypes.Structure):
    _fields_ = [
        ("sample_index", ctypes.c_uint64),
        ("median", ctypes.c_double),
        ("residual", ctypes.c_double),
        ("residual_sum", ctypes.c_double),
        ("energy_baseline", ctypes.c_double),
        ("normalized_deviation", ctypes.c_double),
        ("authority_enabled", ctypes.c_uint32),
        ("consecutive_count", ctypes.c_uint32),
        ("refractory_remaining", ctypes.c_uint32),
        ("confirmed", ctypes.c_uint32),
    ]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def configure_library(path: Path):
    library = ctypes.CDLL(str(path))
    library.dmreda_minimal_reset.argtypes = [ctypes.POINTER(CState)]
    library.dmreda_minimal_reset.restype = None
    library.dmreda_minimal_step.argtypes = [
        ctypes.POINTER(CState),
        ctypes.c_double,
        ctypes.POINTER(COutput),
    ]
    library.dmreda_minimal_step.restype = ctypes.c_int
    library.dmreda_minimal_state_size.argtypes = []
    library.dmreda_minimal_state_size.restype = ctypes.c_uint64
    library.dmreda_minimal_checkpoint_size.argtypes = []
    library.dmreda_minimal_checkpoint_size.restype = ctypes.c_uint64
    library.dmreda_minimal_configuration_sha256.argtypes = []
    library.dmreda_minimal_configuration_sha256.restype = ctypes.c_char_p
    return library


def assert_row_equal(python_row, c_row: COutput) -> None:
    pairs = (
        (python_row.sample_index, c_row.sample_index, "sample_index"),
        (python_row.median, c_row.median, "median"),
        (python_row.residual, c_row.residual, "residual"),
        (python_row.residual_sum, c_row.residual_sum, "residual_sum"),
        (python_row.energy_baseline, c_row.energy_baseline, "energy_baseline"),
        (
            python_row.normalized_deviation,
            c_row.normalized_deviation,
            "normalized_deviation",
        ),
        (int(python_row.authority_enabled), c_row.authority_enabled, "authority_enabled"),
        (python_row.consecutive_count, c_row.consecutive_count, "consecutive_count"),
        (
            python_row.refractory_remaining,
            c_row.refractory_remaining,
            "refractory_remaining",
        ),
        (int(python_row.confirmed), c_row.confirmed, "confirmed"),
    )
    for expected, observed, field in pairs:
        if expected != observed:
            raise AssertionError(
                f"Python/C mismatch at sample {python_row.sample_index}, "
                f"field {field}: {expected!r} != {observed!r}"
            )


def replay_signal(library, signal: Iterable[float]) -> tuple[int, int]:
    python_detector = MinimalStreamingDetector()
    c_state = CState()
    library.dmreda_minimal_reset(ctypes.byref(c_state))
    sample_count = 0
    event_count = 0
    for sample in signal:
        numeric = float(sample)
        python_row = python_detector.step(numeric)
        c_row = COutput()
        status = library.dmreda_minimal_step(
            ctypes.byref(c_state), numeric, ctypes.byref(c_row)
        )
        if status != 0:
            raise AssertionError(f"C step failed with status {status}")
        assert_row_equal(python_row, c_row)
        sample_count += 1
        event_count += int(python_row.confirmed)
    return sample_count, event_count


def load_extract(path: Path) -> list[np.ndarray]:
    grouped: dict[tuple[int, int], list[tuple[int, float]]] = {}
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            key = (int(row["faultNumber"]), int(row["simulationRun"]))
            grouped.setdefault(key, []).append(
                (int(row["sample"]), float(row["xmeas_7"]))
            )
    signals: list[np.ndarray] = []
    for key, pairs in sorted(grouped.items()):
        pairs.sort()
        indices = [pair[0] for pair in pairs]
        if indices != list(range(indices[0], indices[0] + len(indices))):
            raise RuntimeError(f"non-contiguous samples in trajectory {key}")
        raw = np.array([pair[1] for pair in pairs], dtype=np.float64)
        signals.append(apply_tep_affine_scale(raw))
    return signals


def parse_stack_usage(path: Path) -> dict[str, int]:
    result: dict[str, int] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        location, bytes_text, qualifier = line.rsplit("\t", 2)
        function = location.rsplit(":", 1)[-1]
        if qualifier != "static":
            raise RuntimeError(f"unexpected stack-usage qualifier: {qualifier}")
        result[function] = int(bytes_text)
    return result


def write_json_atomic(path: Path, payload: object) -> None:
    encoded = json.dumps(
        payload,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    ) + "\n"
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(encoded, encoding="utf-8")
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--normal-training", required=True, type=Path)
    parser.add_argument("--fault-training", required=True, type=Path)
    parser.add_argument("--normal-testing", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()
    paths = {
        "normal_training": arguments.normal_training,
        "fault_training": arguments.fault_training,
        "normal_testing": arguments.normal_testing,
    }
    for role, path in paths.items():
        normalized = str(path).lower().replace("_", "").replace("-", "")
        if "faultytesting" in normalized:
            raise RuntimeError("FaultyTesting access is forbidden")
        observed_hash = sha256_file(path)
        if observed_hash != EXPECTED_HASHES[role]:
            raise RuntimeError(
                f"{role} hash mismatch: {observed_hash} != {EXPECTED_HASHES[role]}"
            )

    with tempfile.TemporaryDirectory() as directory:
        build = Path(directory)
        dynamic_library = build / "libdmreda_minimal.dylib"
        object_path = build / "dmreda_minimal_streaming.o"
        common_flags = [
            "clang",
            "-std=c99",
            "-pedantic-errors",
            "-Wall",
            "-Wextra",
            "-Werror",
        ]
        subprocess.run(
            [
                *common_flags,
                "-O2",
                "-fPIC",
                "-shared",
                str(C_SOURCE),
                "-o",
                str(dynamic_library),
                "-lm",
            ],
            check=True,
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [
                *common_flags,
                "-Os",
                "-ffunction-sections",
                "-fdata-sections",
                "-fstack-usage",
                "-c",
                str(C_SOURCE),
                "-o",
                str(object_path),
            ],
            check=True,
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
        )
        library = configure_library(dynamic_library)
        if library.dmreda_minimal_configuration_sha256().decode() != CONFIGURATION_SHA256:
            raise AssertionError("C/Python configuration hash mismatch")

        parity_banks: dict[str, object] = {}
        for role, path in paths.items():
            signals = load_extract(path)
            row_count = 0
            event_count = 0
            for signal in signals:
                rows, events = replay_signal(library, signal)
                row_count += rows
                event_count += events
            parity_banks[role] = {
                "extract_sha256": EXPECTED_HASHES[role],
                "trajectory_count": len(signals),
                "sample_count": row_count,
                "python_c_exact_row_count": row_count,
                "total_confirmed_events": event_count,
            }

        golden = load_golden_set()
        golden_samples = 0
        for fixture in golden["fixtures"]:
            signal = generate_signal(fixture["input"]["generator_definition"])
            rows, _ = replay_signal(library, signal)
            golden_samples += rows

        rng = np.random.default_rng(20260814)
        randomized_samples = 0
        for _ in range(100):
            length = int(rng.integers(64, 2049))
            signal = rng.normal(0.0, float(rng.uniform(0.01, 5.0)), length)
            rows, _ = replay_signal(library, signal)
            randomized_samples += rows

        size_output = subprocess.run(
            ["/usr/bin/size", str(object_path)],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.splitlines()
        size_fields = size_output[0].split()
        size_values = size_output[1].split()
        parsed_size = dict(zip(size_fields, size_values))
        size_record = {
            field: int(value)
            for field, value in parsed_size.items()
            if field not in {"dec", "hex"}
        }
        size_record["total_decimal"] = int(parsed_size["dec"])
        size_record["total_hex"] = parsed_size["hex"]
        stack_usage = parse_stack_usage(object_path.with_suffix(".su"))
        compiler = subprocess.run(
            ["clang", "--version"],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.splitlines()

    payload = {
        "schema": "dmreda.finalization.streaming-parity-report.v1",
        "claim_grade": False,
        "configuration_sha256": CONFIGURATION_SHA256,
        "faulty_testing_opened": False,
        "parity_definition": "exact equality for every exposed integer, boolean, and float64 output field at every replayed sample",
        "banks": parity_banks,
        "golden": {
            "fixture_count": len(golden["fixtures"]),
            "sample_count": golden_samples,
            "python_c_exact_row_count": golden_samples,
        },
        "randomized": {
            "seed": 20260814,
            "trajectory_count": 100,
            "sample_count": randomized_samples,
            "python_c_exact_row_count": randomized_samples,
        },
        "embedded_host_measurement": {
            "target": platform.machine() + "-" + platform.system().lower(),
            "compiler": compiler,
            "compile_mode": "Apple clang -std=c99 -pedantic-errors -Wall -Wextra -Werror -Os",
            "state_bytes": ctypes.sizeof(CState),
            "checkpoint_bytes": int(library.dmreda_minimal_checkpoint_size()),
            "object_sections_bytes": size_record,
            "static_stack_usage_bytes_by_function": stack_usage,
            "hardware_cycle_energy_jitter_measurement": "UNAVAILABLE_NO_MCU_HARDWARE",
        },
        "source_sha256": {
            "dmreda_minimal_streaming.c": sha256_file(C_SOURCE),
            "dmreda_minimal_streaming.h": sha256_file(C_HEADER),
            "dmreda_minimal_streaming.py": sha256_file(PYTHON_SOURCE),
            "verify_streaming_parity.py": sha256_file(Path(__file__)),
        },
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json_atomic(arguments.output, payload)
    print(json.dumps({"output": str(arguments.output), "status": "exact_parity"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
