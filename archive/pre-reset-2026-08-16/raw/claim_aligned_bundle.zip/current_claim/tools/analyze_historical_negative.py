#!/usr/bin/env python3
"""Reconstruct the immutable Stage 3.3 normal failure mechanism.

This post-hoc forensic analysis accepts only the hash-bound FaultFreeTesting
extract.  It is not a claim-grade validation run and it never accepts a path
whose normalized name contains ``FaultyTesting``.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys

import numpy as np


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from current_claim.tools.verify_streaming_parity import load_extract
from gold_line.core.dmreda_reference_clean import compute_dmreda_reference
from stage3.tep.configuration import build_effective_profiles, build_tep_core_kwargs


EXPECTED_EXTRACT_SHA256 = (
    "9b7283e83fb4e31dec218df29aaedd934cfa7a32a4f678f6bb9bc85b68d68e7e"
)
FROZEN_ROWS = (
    REPOSITORY_ROOT / "frozen_history/results/dmreda_normal_trajectory_results.jsonl"
)
FROZEN_SUMMARY = REPOSITORY_ROOT / "frozen_history/results/dmreda_normal_summary.json"
EXPECTED_ROWS_SHA256 = (
    "dd0e3e6a78e840915258a68533280aa2c2ef1b19861aebe0b32560ada5cf0608"
)
EXPECTED_SUMMARY_SHA256 = (
    "48c82c94eb61ea618d0d0ad2ffc44c09db9c083e8c006d9ff5efa0d1d230d018"
)
HORIZONS = (120, 160, 240, 480, 720, 960)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json_atomic(path: Path, payload: object) -> None:
    encoded = json.dumps(
        payload,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    ) + "\n"
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(encoded, encoding="utf-8")
    os.replace(temporary, path)


def channel_summary(first: list[int | None], events: list[list[int]]) -> dict[str, object]:
    observed = [value for value in first if value is not None]
    return {
        "trajectory_count": len(first),
        "trajectory_with_authority_count": len(observed),
        "total_confirmed_event_count": sum(len(value) for value in events),
        "first_authority_index": {
            "minimum": min(observed) if observed else None,
            "median": statistics.median(observed) if observed else None,
            "maximum": max(observed) if observed else None,
        },
        "horizon_curve": [
            {
                "H": horizon,
                "authority_count": sum(
                    value is not None and value < horizon for value in first
                ),
                "risk": sum(
                    value is not None and value < horizon for value in first
                )
                / len(first),
                "survival": 1.0
                - sum(value is not None and value < horizon for value in first)
                / len(first),
            }
            for horizon in HORIZONS
        ],
        "restricted_mean_time_to_authority_H960": sum(
            960 if value is None else value for value in first
        )
        / len(first),
        "classical_uncensored_ARL_claimed": False,
    }


def compare_first_authority(
    left: list[int | None], right: list[int | None]
) -> dict[str, object]:
    differing = [
        {"simulationRun": index, "left": left_value, "right": right_value}
        for index, (left_value, right_value) in enumerate(zip(left, right), start=1)
        if left_value != right_value
    ]
    deltas = [
        int(row["right"]) - int(row["left"])
        for row in differing
        if row["left"] is not None and row["right"] is not None
    ]
    return {
        "authority_membership_equal": [value is not None for value in left]
        == [value is not None for value in right],
        "first_authority_indices_exactly_equal": not differing,
        "differing_first_authority_count": len(differing),
        "maximum_absolute_index_delta_when_both_authorize": (
            max((abs(value) for value in deltas), default=0)
        ),
        "differences": differing,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--normal-testing", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()

    normalized = str(arguments.normal_testing).lower().replace("_", "").replace("-", "")
    if "faultytesting" in normalized:
        raise RuntimeError("FaultyTesting access is forbidden")
    observed_hash = sha256_file(arguments.normal_testing)
    if observed_hash != EXPECTED_EXTRACT_SHA256:
        raise RuntimeError(
            f"normal-testing extract hash mismatch: {observed_hash}"
        )

    signals = load_extract(arguments.normal_testing)
    if len(signals) != 500 or any(signal.size != 960 for signal in signals):
        raise RuntimeError("expected exactly 500 trajectories of length 960")

    kwargs = build_tep_core_kwargs()
    profiles = build_effective_profiles()
    channel_first: dict[str, list[int | None]] = {
        "D_OR_G": [],
        "D_ONLY": [],
        "G_ONLY": [],
    }
    channel_events: dict[str, list[list[int]]] = {
        "D_OR_G": [],
        "D_ONLY": [],
        "G_ONLY": [],
    }
    forensic_rows: list[dict[str, object]] = []

    for run, signal in enumerate(signals, start=1):
        results = {}
        for label, mode in (
            ("D_OR_G", "D_or_G"),
            ("D_ONLY", "D_only"),
            ("G_ONLY", "G_only"),
        ):
            result = compute_dmreda_reference(signal, **{**kwargs, "mode": mode})
            results[label] = result
            events = [int(value) for value in result.event_times]
            channel_events[label].append(events)
            channel_first[label].append(events[0] if events else None)

        result = results["D_OR_G"]
        if not result.event_times:
            continue
        confirmation = int(result.event_times[0])
        opening = confirmation
        while opening > 0 and bool(result.pending[opening - 1]):
            opening -= 1
        opening_state = int(result.state[opening - 1]) if opening > 0 else 0
        profile = profiles[opening_state]
        d_open = bool(result.d[opening] > profile.th_d)
        g_open = bool(result.g[opening] > profile.th_g)
        if d_open and g_open:
            branch = "D_AND_G"
        elif d_open:
            branch = "D_ONLY"
        elif g_open:
            branch = "G_ONLY"
        else:
            branch = "UNRESOLVED_PUBLIC_PENDING_SEGMENT"
        segment = result.d[opening : confirmation + 1]
        area = float(np.maximum(0.0, segment - profile.th_d2).sum())
        count = int(np.count_nonzero(segment > profile.th_d2))
        transitions = np.flatnonzero(result.state != 0)
        first_transition = int(transitions[0]) if transitions.size else None
        forensic_rows.append(
            {
                "simulationRun": run,
                "opening_index": opening,
                "confirmation_index": confirmation,
                "pending_segment_samples": confirmation - opening + 1,
                "opening_state": opening_state,
                "opening_branch": branch,
                "opening_d": float(result.d[opening]),
                "opening_g": float(result.g[opening]),
                "confirmation_area": area,
                "confirmation_count": count,
                "confirmation_energy_baseline_safe": float(
                    result.e_baseline_safe[confirmation]
                ),
                "first_regime_transition_index": first_transition,
                "confirmation_precedes_first_regime_transition": (
                    first_transition is None or confirmation < first_transition
                ),
            }
        )

    if sha256_file(FROZEN_ROWS) != EXPECTED_ROWS_SHA256:
        raise RuntimeError("frozen trajectory-row hash mismatch")
    if sha256_file(FROZEN_SUMMARY) != EXPECTED_SUMMARY_SHA256:
        raise RuntimeError("frozen normal-summary hash mismatch")
    frozen_rows = [
        json.loads(line)
        for line in FROZEN_ROWS.read_text(encoding="utf-8").splitlines()
    ]
    frozen_summary = json.loads(FROZEN_SUMMARY.read_text(encoding="utf-8"))
    frozen_events = [row["authoritative_event_indices"] for row in frozen_rows]
    if channel_events["D_OR_G"] != frozen_events:
        raise RuntimeError("D_OR_G replay differs from immutable trajectory rows")
    if (
        frozen_summary["primary_dmreda"]["false_authority_count"] != 42
        or frozen_summary["primary_dmreda"]["total_authoritative_event_count"] != 45
        or frozen_summary["status"] != "failed"
    ):
        raise RuntimeError("immutable normal summary no longer states the frozen failure")

    branches = {
        name: sum(row["opening_branch"] == name for row in forensic_rows)
        for name in (
            "D_ONLY",
            "G_ONLY",
            "D_AND_G",
            "UNRESOLVED_PUBLIC_PENDING_SEGMENT",
        )
    }
    durations = [int(row["pending_segment_samples"]) for row in forensic_rows]
    areas = [float(row["confirmation_area"]) for row in forensic_rows]
    counts = [int(row["confirmation_count"]) for row in forensic_rows]
    baselines = [
        float(row["confirmation_energy_baseline_safe"]) for row in forensic_rows
    ]
    payload = {
        "schema": "dmreda.finalization.historical-negative-forensics.v1",
        "evidence_scope": "POST_HOC_FORENSIC_REANALYSIS_OF_SPENT_VALIDATION",
        "claim_grade": False,
        "historical_result_unchanged": "42/500 at H=960; frozen maximum 25; denied",
        "historical_binding": {
            "immutable_trajectory_rows_sha256": EXPECTED_ROWS_SHA256,
            "immutable_summary_sha256": EXPECTED_SUMMARY_SHA256,
            "D_OR_G_replay_exact_event_indices_equal": True,
            "immutable_summary_status": "failed",
        },
        "faulty_testing_opened": False,
        "input": {
            "logical_name": "FaultFreeTesting xmeas_7 extract",
            "sha256": EXPECTED_EXTRACT_SHA256,
            "trajectory_count": 500,
            "samples_per_trajectory": 960,
        },
        "channels": {
            label: channel_summary(channel_first[label], channel_events[label])
            for label in ("D_OR_G", "D_ONLY", "G_ONLY")
        },
        "first_confirmation_mechanism": {
            "trajectory_count": len(forensic_rows),
            "opening_branch_counts": branches,
            "pending_segment_samples": {
                "minimum": min(durations),
                "median": statistics.median(durations),
                "maximum": max(durations),
            },
            "confirmation_area": {
                "threshold_in_state_0": profiles[0].th_a,
                "minimum": min(areas),
                "median": statistics.median(areas),
                "maximum": max(areas),
            },
            "confirmation_count": {
                "minimum_required_in_state_0": profiles[0].n_min,
                "minimum": min(counts),
                "median": statistics.median(counts),
                "maximum": max(counts),
            },
            "confirmation_energy_baseline_safe": {
                "minimum": min(baselines),
                "median": statistics.median(baselines),
                "maximum": max(baselines),
            },
            "confirmation_precedes_first_regime_transition_count": sum(
                bool(row["confirmation_precedes_first_regime_transition"])
                for row in forensic_rows
            ),
            "opening_in_state_0_count": sum(
                row["opening_state"] == 0 for row in forensic_rows
            ),
            "rows": forensic_rows,
        },
        "cross_mode_first_authority_comparison": {
            "D_OR_G_vs_G_ONLY": compare_first_authority(
                channel_first["D_OR_G"], channel_first["G_ONLY"]
            ),
            "D_OR_G_vs_D_ONLY": compare_first_authority(
                channel_first["D_OR_G"], channel_first["D_ONLY"]
            ),
        },
        "source_sha256": {
            "analyze_historical_negative.py": sha256_file(Path(__file__)),
            "dmreda_reference_clean.py": sha256_file(
                REPOSITORY_ROOT / "gold_line/core/dmreda_reference_clean.py"
            ),
            "configuration.py": sha256_file(
                REPOSITORY_ROOT / "stage3/tep/configuration.py"
            ),
        },
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json_atomic(arguments.output, payload)
    print(json.dumps({"output": str(arguments.output), "status": "complete"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
