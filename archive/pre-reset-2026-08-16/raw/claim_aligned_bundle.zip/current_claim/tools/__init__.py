"""Verification tools for the frozen current claim path."""

