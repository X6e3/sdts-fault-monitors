# A–L Development Ablation Results

## Evidence scope

- **[DIRECT EVIDENCE]** Results come from `../experimental/finalization/results/development_v2/ablation_summary.json`, SHA-256 `d78f770741133dd181d76f690558de2319ec8560c06ed2b94776bdd1e2583898`.
- **[DIRECT EVIDENCE]** Candidate grid and trajectory artifacts are bound by `../experimental/finalization/results/development_v2/manifest.json`.
- **[DIRECT EVIDENCE]** All results are development-only. They cannot validate performance or erase the immutable Stage 3.3 negative.

## Compact results

**[DIRECT EVIDENCE]** `normal cal` is authorities/200 used for threshold selection; `normal dev` is authorities/300; `fault det` is detections/400; RMD is restricted mean delay with misses assigned H=500.

| Variant | Selected parameter | normal cal | normal dev | fault det | RMD | detected median |
|---|---:|---:|---:|---:|---:|---:|
| A | κ=2.30 | 10 | 24 (0.0800) | 108 (0.2700) | 389.0025 | 111.5 |
| B | κ=2.25 | 10 | 24 (0.0800) | 109 (0.2725) | 388.2225 | 111.0 |
| C | κ=2.25 | 10 | 24 (0.0800) | 108 (0.2700) | 391.2975 | 115.5 |
| D | κ=2.30 | 10 | 24 (0.0800) | 112 (0.2800) | 388.1150 | 112.0 |
| E | κ=2.35 | 9 | 17 (0.0567) | 108 (0.2700) | 391.2100 | 112.0 |
| F | κ=2.30 | 11 | 24 (0.0800) | 109 (0.2725) | 388.1100 | 112.0 |
| G | κ=3.35 | 11 | 19 (0.0633) | 87 (0.2175) | 408.1825 | 118.0 |
| H | κ=4.00 | 10 | 20 (0.0667) | 113 (0.2825) | 389.0525 | 112.0 |
| I | κ=2.40 | 9 | 16 (0.0533) | 112 (0.2800) | 387.6375 | 113.5 |
| J | threshold=86.56156249 | 10 | 13 (0.0433) | 188 (0.4700) | 306.1400 | 91.0 |
| K | threshold=1.96222605 | 10 | 15 (0.0500) | 208 (0.5200) | 298.9325 | 94.0 |
| L | κ=3.00 | 10 | 21 (0.0700) | 102 (0.2550) | 398.9300 | 109.0 |

## Ablation definitions

- **[DIRECT EVIDENCE]** A is the full historical representation and D-or-G candidate/area/count/regime machinery.
- **[DIRECT EVIDENCE]** B and C isolate D-only and G-only opening.
- **[DIRECT EVIDENCE]** D removes regime transitions; E freezes the entire state-0 representation; F freezes confirmation duration while retaining regime representation.
- **[DIRECT EVIDENCE]** G keeps only candidate qualifying count; I keeps only rolling positive excess area; H replaces candidates with six consecutive D exceedances; L is a high/low hysteretic single-crossing detector.
- **[DIRECT EVIDENCE]** J and K are Page-style CUSUM and Roberts-style absolute EWMA scalar baselines with the common external persistence/refractory gate.

## Frozen architecture selection

- **[DIRECT EVIDENCE]** Simplicity order was `L,H,I,G,E,D,F,B,C,A`.
- **[DIRECT EVIDENCE]** Eligibility required normal-development point risk `<=0.075`, cluster-bootstrap detection-probability delta lower bound versus A `>=-0.05`, and restricted-delay delta upper bound `<=+10` samples.
- **[DIRECT EVIDENCE]** L failed only the delay condition: its 95% upper delta bound was `16.1275625` samples.
- **[DIRECT EVIDENCE]** H passed all three: normal risk 0.0667; detection delta 0.0125 with 95% interval approximately `[0,0.025]`; restricted-delay delta 0.05 with 95% interval `[-4.2076,4.2751]`.
- **[DIRECT EVIDENCE]** H was therefore selected before considering I or later variants.
- **[STRONG INFERENCE]** Selection supports simplification of the engineering candidate, not superiority or even equivalence in the population.

## Mechanism findings

- **[DIRECT EVIDENCE]** Removing regime transitions (D) did not degrade development results versus A; fixing the state-0 representation (E) retained the same fault detection count with lower observed normal risk.
- **[DIRECT EVIDENCE]** Removing area and keeping count alone (G) materially degraded detection: paired detection delta `-0.0525`, bootstrap interval `[-0.0800,-0.0225]`, and restricted-delay delta `+19.18`.
- **[DIRECT EVIDENCE]** The simple consecutive rule H was noninferior by the frozen development rule and detected 5 more fault trajectories than A.
- **[STRONG INFERENCE]** Historical adaptive states were not demonstrated to add value on this development bank; candidate area carried more apparent value than qualifying count alone.
- **[UNKNOWN]** Whether these findings generalize beyond the spent TEP partitions is unknown.

## Critical interpretation limit

- **[DIRECT EVIDENCE]** Fault onset at 20 precedes authority warm-up at 92.
- **[STRONG INFERENCE]** J/K's large apparent advantage is partly a startup-state effect, not clean evidence about steady-state quickest detection. H/A also face this confound differently because their rolling median and EWMA baseline adapt to the already changed signal.
- **[DIRECT EVIDENCE]** No variant in this table has claim-grade validation.
