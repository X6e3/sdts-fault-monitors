# Limitations

## Scientific validity

- **[DIRECT EVIDENCE]** The historical claim-grade normal test is negative: 42/500 at H=960.
- **[DIRECT EVIDENCE]** The reduced candidate was selected and tuned on spent development data.
- **[DIRECT EVIDENCE]** No untouched post-freeze normal bank exists, so the locked normal gate was not executed.
- **[DIRECT EVIDENCE]** FaultyTesting was not opened; candidate fault generalization is unknown.
- **[DIRECT EVIDENCE]** Fault-development onset precedes warm-up, confounding startup behavior with detection delay and preventing observation of pre-onset false authority.
- **[UNKNOWN]** Sensitivity to noise family, autocorrelation, heavy tails, drift, missing samples, channel choice, and process operating regime is not established.

## Causality and metrics

- **[DIRECT EVIDENCE]** Source computations are causal under fixed external scaling.
- **[DIRECT EVIDENCE]** Historical scaling was fitted on designated normal training values; fitting on an evaluated full trace is prohibited.
- **[DIRECT EVIDENCE]** Finite-horizon no-alarm substitution is explicitly censored restricted time, not uncensored ARL.
- **[UNKNOWN]** Field false-authority probability for missions longer or shorter than the tested H cannot be inferred by simple rescaling.

## Parameter and provenance lineage

- **[UNKNOWN]** Historical κ=2.5 selection rationale is unrecoverable from available Git history and artifacts.
- **[DIRECT EVIDENCE]** The original recorded uv environment is not preserved as executable bytes; dependency artifacts lack wheel/sdist hashes.
- **[DIRECT EVIDENCE]** HAI values are unavailable and SKAB values are not present in this checkout; metadata cannot substitute for experiments.
- **[UNKNOWN]** FaultyTesting's human access history before machine logging is unknown.

## Algorithmic distinctiveness

- **[DIRECT EVIDENCE]** Components reduce to known robust filtering, leaky integration, threshold accumulation, run rules, hysteresis, and refractory FSM patterns.
- **[DIRECT EVIDENCE]** Development CUSUM/EWMA baselines outperform the DMREDA-derived candidates on the available fault bank, subject to startup confounding.
- **[UNKNOWN]** Novelty is not established; the literature pass is positioning, not an exhaustive prior-art search.
- **[UNKNOWN]** No theorem establishes global minimality, optimality, robustness class, or false-alarm bound.

## Implementation and productization

- **[DIRECT EVIDENCE]** Python/C parity is exact only for tested binary64 histories and the measured host toolchain.
- **[DIRECT EVIDENCE]** No MCU timing, energy, jitter, thermal, compiler-diversity, or fault-injection result exists.
- **[UNKNOWN]** Float32/fixed-point behavior, physical scaling drift, sensor failure, data loss, and persistent-state corruption are uncharacterized.
- **[UNKNOWN]** Safety integrity, security boundary, remote update, telemetry, and lifecycle requirements are outside this repository.

## Classification consequence

**[DIRECT EVIDENCE]** These limitations force **D. INCONCLUSIVE — FRESH DATA REQUIRED**. They cannot be repaired by documentation, further post-hoc analysis of spent banks, or opening FaultyTesting before a new normal gate.
