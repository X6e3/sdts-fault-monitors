# Validation Protocol V3

## Status

- **[DIRECT EVIDENCE]** Development protocol: frozen and executed.
- **[DIRECT EVIDENCE]** Fresh-normal locked gate: not executed because qualifying data are unavailable.
- **[DIRECT EVIDENCE]** Fault holdout: prohibited and unopened in finalization.
- **[DIRECT EVIDENCE]** Current classification: **D. INCONCLUSIVE — FRESH DATA REQUIRED**.

## Estimand and event ownership

- **[DIRECT EVIDENCE]** Mission horizon is `H=500` samples for the finalization candidate.
- **[DIRECT EVIDENCE]** Normal operating risk is `P_infinity(tau <= 500)`, estimated as the fraction of independent normal trajectories with at least one confirmed authority at indices 0–499.
- **[DIRECT EVIDENCE]** The complete trace is owned by its first authority. For a fault trajectory, a first authority before onset is a false authority and cannot be redeemed by a later post-onset event.
- **[DIRECT EVIDENCE]** No-authority trajectories are right-censored at H. Assigning H produces a finite-horizon restricted time; it must never be called classical uncensored ARL.
- **[DIRECT EVIDENCE]** Report risk at preregistered horizons, survival `1-P(tau<=h)`, censoring, detected-only delay, and restricted delay with misses assigned H. Do not report detected-only delay without detection probability.

## Completed development protocol

- **[DIRECT EVIDENCE]** The exact frozen contract is `../experimental/finalization/protocol_v3_development.json` with SHA-256 `a66edbd87df4521f81272fd9943352569c61a023618af14ecdde93814d3ed9f1`.
- **[DIRECT EVIDENCE]** Normal calibration: FaultFreeTraining runs 1–200, 200 trajectories.
- **[DIRECT EVIDENCE]** Normal development evaluation: FaultFreeTraining runs 201–500, 300 trajectories.
- **[DIRECT EVIDENCE]** Fault development evaluation: FaultyTraining fault numbers 1–20 and runs 301–320, 400 trajectories clustered by simulation run.
- **[DIRECT EVIDENCE]** Threshold calibration's primary objective was closeness to 10/200 normal authorities. Restricted-time sum and higher threshold were deterministic tie-breaks.
- **[DIRECT EVIDENCE]** A–I/L used a κ grid from 0.5 through 16.0 in 0.05 increments. J/K enumerated every data-derived scalar threshold where the 20-sample persistence decision could change.
- **[DIRECT EVIDENCE]** Architecture selection used a frozen simplicity order and cluster-bootstrap noninferiority margins versus A; variant H was the first eligible candidate.
- **[DIRECT EVIDENCE]** These results are `DEVELOPMENT_NON_CLAIM_GRADE` because all value-bearing inputs were already spent or used in finalization.

## Known development confound

- **[DIRECT EVIDENCE]** Fault onset is index 20 and authority warm-up is 92. Therefore pre-onset authority is structurally unobservable and minimum authoritative delay is 72.
- **[STRONG INFERENCE]** This design permits scalar accumulators to absorb 72 changed samples before authority becomes visible. It also permits the robust adaptive representation to absorb the change into its baseline. Comparisons therefore mix startup adaptation with change detection.
- **[DIRECT EVIDENCE]** A future claim-grade protocol must split startup faults from steady-state faults. In the steady-state arm, onset must follow warm-up by a frozen pre-change dwell sufficient for every detector's declared state.

## Required fresh-normal gate

The bank must be acquired after the candidate freeze and before any value access:

- **[DIRECT EVIDENCE]** 1,000 independently seeded normal `xmeas_7` trajectories, exactly 500 samples each.
- **[DIRECT EVIDENCE]** One independent process trajectory is the statistical unit; overlapping windows or multiple channels from one trajectory are not independent units.
- **[DIRECT EVIDENCE]** Freeze simulator/physical-process version, configuration, per-trajectory seed or recording ID, raw package SHA-256, deterministic extraction source and hash, all inclusions, and all human/programmatic accesses before opening values.
- **[DIRECT EVIDENCE]** Apply the already frozen affine map exactly once. Any new fit requires a separate calibration bank and a new pre-access protocol.
- **[DIRECT EVIDENCE]** No exclusion, replacement, extension, early stopping, or threshold adjustment based on observed values is allowed.

Admission requires both:

1. `authority_count / 1000 <= 0.05`;
2. the one-sided exact-binomial 95% upper confidence bound for `P_infinity(tau<=500)` is `<=0.05`.

- **[DIRECT EVIDENCE]** For n=1000 these rules admit at most 38 authorities. Under `Binomial(1000,0.05)`, `P(X<=38)=0.04334819060690801` while `P(X<=39)=0.05981487905190082`.
- **[DIRECT EVIDENCE]** This integer boundary is tested in `../tests/test_minimal_streaming_final.py`.

## Fault holdout gate

- **[DIRECT EVIDENCE]** FaultyTesting SHA-256 is `c2f1aabc77498efda4d5f9ad81ecc829e2fcd98752b84cf5b2a06558cabacc36`.
- **[DIRECT EVIDENCE]** It remains sealed unless and until the fresh-normal gate passes without any source/configuration/hash discrepancy.
- **[DIRECT EVIDENCE]** If normal fails, stop and report D. Do not inspect FaultyTesting, retune, change H, alter warm-up, or substitute another risk metric.
- **[DIRECT EVIDENCE]** If normal passes, record a one-time, hash-bound open event before evaluating the frozen candidate and frozen baselines.
- **[UNKNOWN]** Human access before recorded machine controls is not provable; this must remain a disclosed limitation even if the machine seal opens.

## Decision categories after new data

- **[DIRECT EVIDENCE]** A future result may only move out of D if all source, provenance, normal-risk, and fault-holdout prerequisites pass.
- **[UNKNOWN]** Statistical power and the exact publishable fault-effect estimand must be frozen against the acquired bank structure before values are opened; the current repository cannot manufacture those details without the new acquisition design.
