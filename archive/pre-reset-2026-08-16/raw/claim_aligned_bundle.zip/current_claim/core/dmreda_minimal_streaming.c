#include "dmreda_minimal_streaming.h"

#include <float.h>
#include <math.h>
#include <stddef.h>
#include <string.h>

#define DMREDA_MINIMAL_BETA (1.0 / 32.0)
#define DMREDA_MINIMAL_ENERGY_FLOOR 0.02
#define DMREDA_MINIMAL_D_LOW (-5.0)
#define DMREDA_MINIMAL_D_HIGH 5.0
#define DMREDA_MINIMAL_D_THRESHOLD 0.8
#define DMREDA_MINIMAL_MAX_ABS_INPUT (DBL_MAX / 64.0)

static int dmreda_minimal_state_valid(const dmreda_minimal_state_t *state) {
    uint32_t index;
    uint32_t expected_x_count;
    uint32_t expected_e_count;

    if (state == NULL) {
        return 0;
    }
    expected_x_count = state->sample_index < DMREDA_MINIMAL_MEDIAN_WIDTH
        ? (uint32_t)state->sample_index
        : DMREDA_MINIMAL_MEDIAN_WIDTH;
    expected_e_count = state->sample_index < DMREDA_MINIMAL_ENERGY_WIDTH
        ? (uint32_t)state->sample_index
        : DMREDA_MINIMAL_ENERGY_WIDTH;
    if (state->x_count != expected_x_count || state->e_count != expected_e_count) {
        return 0;
    }
    if (state->x_position != state->sample_index % DMREDA_MINIMAL_MEDIAN_WIDTH) {
        return 0;
    }
    if (state->e_position != state->sample_index % DMREDA_MINIMAL_ENERGY_WIDTH) {
        return 0;
    }
    if (state->consecutive_count >= DMREDA_MINIMAL_CONSECUTIVE_SAMPLES) {
        return 0;
    }
    if (state->refractory_remaining > DMREDA_MINIMAL_REFRACTORY_SAMPLES) {
        return 0;
    }
    if (!isfinite(state->e_sum) || !isfinite(state->e_baseline)) {
        return 0;
    }
    if (state->e_sum < 0.0 || state->e_baseline < 0.0) {
        return 0;
    }
    for (index = 0u; index < DMREDA_MINIMAL_MEDIAN_WIDTH; ++index) {
        if (!isfinite(state->x_ring[index])) {
            return 0;
        }
    }
    for (index = 0u; index < DMREDA_MINIMAL_ENERGY_WIDTH; ++index) {
        if (!isfinite(state->e_ring[index]) || state->e_ring[index] < 0.0) {
            return 0;
        }
    }
    return 1;
}

static void dmreda_minimal_sort(double *values, uint32_t count) {
    uint32_t index;
    for (index = 1u; index < count; ++index) {
        double selected = values[index];
        uint32_t position = index;
        while (position > 0u && values[position - 1u] > selected) {
            values[position] = values[position - 1u];
            --position;
        }
        values[position] = selected;
    }
}

static double dmreda_minimal_median(const dmreda_minimal_state_t *state) {
    double ordered[DMREDA_MINIMAL_MEDIAN_WIDTH];
    uint32_t index;
    uint32_t middle;
    for (index = 0u; index < state->x_count; ++index) {
        ordered[index] = state->x_ring[index];
    }
    dmreda_minimal_sort(ordered, state->x_count);
    middle = state->x_count / 2u;
    if ((state->x_count % 2u) != 0u) {
        return ordered[middle];
    }
    return 0.5 * (ordered[middle - 1u] + ordered[middle]);
}

static double dmreda_minimal_bounded_ratio(double numerator, double denominator) {
    if (numerator > DMREDA_MINIMAL_D_HIGH * denominator) {
        return DMREDA_MINIMAL_D_HIGH;
    }
    if (numerator < DMREDA_MINIMAL_D_LOW * denominator) {
        return DMREDA_MINIMAL_D_LOW;
    }
    return numerator / denominator;
}

void dmreda_minimal_reset(dmreda_minimal_state_t *state) {
    if (state != NULL) {
        memset(state, 0, sizeof(*state));
    }
}

dmreda_minimal_status_t dmreda_minimal_step(
    dmreda_minimal_state_t *state,
    double scaled_sample,
    dmreda_minimal_output_t *output
) {
    dmreda_minimal_state_t next;
    dmreda_minimal_output_t next_output;
    double median;
    double residual;
    double baseline_safe;
    double d_value;
    uint64_t index;

    if (state == NULL || output == NULL) {
        return DMREDA_MINIMAL_ERROR_NULL;
    }
    if (!dmreda_minimal_state_valid(state)) {
        return DMREDA_MINIMAL_ERROR_STATE;
    }
    if (!isfinite(scaled_sample) || fabs(scaled_sample) > DMREDA_MINIMAL_MAX_ABS_INPUT) {
        return DMREDA_MINIMAL_ERROR_INPUT_DOMAIN;
    }

    next = *state;
    memset(&next_output, 0, sizeof(next_output));
    index = next.sample_index;
    next.x_ring[next.x_position] = scaled_sample;
    next.x_position = (next.x_position + 1u) % DMREDA_MINIMAL_MEDIAN_WIDTH;
    if (next.x_count < DMREDA_MINIMAL_MEDIAN_WIDTH) {
        ++next.x_count;
    }
    median = dmreda_minimal_median(&next);
    residual = fabs(scaled_sample - median);
    if (!isfinite(residual)) {
        return DMREDA_MINIMAL_ERROR_INPUT_DOMAIN;
    }

    if (next.e_count < DMREDA_MINIMAL_ENERGY_WIDTH) {
        next.e_sum += residual;
        ++next.e_count;
    } else {
        next.e_sum -= next.e_ring[next.e_position];
        next.e_sum += residual;
    }
    if (next.e_sum < 0.0) {
        /* The exact residual sum is non-negative; remove cancellation drift. */
        next.e_sum = 0.0;
    }
    next.e_ring[next.e_position] = residual;
    next.e_position = (next.e_position + 1u) % DMREDA_MINIMAL_ENERGY_WIDTH;
    if (!isfinite(next.e_sum) || next.e_sum < 0.0) {
        return DMREDA_MINIMAL_ERROR_INPUT_DOMAIN;
    }

    if (index == 0u) {
        next.e_baseline = next.e_sum;
    } else {
        next.e_baseline = DMREDA_MINIMAL_BETA * next.e_sum
            + (1.0 - DMREDA_MINIMAL_BETA) * next.e_baseline;
    }
    if (!isfinite(next.e_baseline) || next.e_baseline < 0.0) {
        return DMREDA_MINIMAL_ERROR_INPUT_DOMAIN;
    }
    baseline_safe = next.e_baseline > DMREDA_MINIMAL_ENERGY_FLOOR
        ? next.e_baseline
        : DMREDA_MINIMAL_ENERGY_FLOOR;
    d_value = dmreda_minimal_bounded_ratio(
        next.e_sum - baseline_safe,
        baseline_safe
    );

    if (next.refractory_remaining > 0u) {
        --next.refractory_remaining;
    }
    next_output.authority_enabled = index >= DMREDA_MINIMAL_WARMUP_SAMPLES;
    if (next_output.authority_enabled == 0u || next.refractory_remaining > 0u) {
        next.consecutive_count = 0u;
    } else if (d_value > DMREDA_MINIMAL_D_THRESHOLD) {
        ++next.consecutive_count;
        if (next.consecutive_count >= DMREDA_MINIMAL_CONSECUTIVE_SAMPLES) {
            next_output.confirmed = 1u;
            next.consecutive_count = 0u;
            next.refractory_remaining = DMREDA_MINIMAL_REFRACTORY_SAMPLES;
        }
    } else {
        next.consecutive_count = 0u;
    }

    next.sample_index = index + 1u;
    next_output.sample_index = index;
    next_output.median = median;
    next_output.residual = residual;
    next_output.residual_sum = next.e_sum;
    next_output.energy_baseline = next.e_baseline;
    next_output.normalized_deviation = d_value;
    next_output.consecutive_count = next.consecutive_count;
    next_output.refractory_remaining = next.refractory_remaining;
    if (!dmreda_minimal_state_valid(&next)) {
        return DMREDA_MINIMAL_ERROR_STATE;
    }
    *state = next;
    *output = next_output;
    return DMREDA_MINIMAL_OK;
}

dmreda_minimal_status_t dmreda_minimal_export_checkpoint(
    const dmreda_minimal_state_t *state,
    dmreda_minimal_checkpoint_t *checkpoint
) {
    if (state == NULL || checkpoint == NULL) {
        return DMREDA_MINIMAL_ERROR_NULL;
    }
    if (!dmreda_minimal_state_valid(state)) {
        return DMREDA_MINIMAL_ERROR_STATE;
    }
    checkpoint->magic = DMREDA_MINIMAL_CHECKPOINT_MAGIC;
    checkpoint->version = DMREDA_MINIMAL_CHECKPOINT_VERSION;
    checkpoint->state = *state;
    return DMREDA_MINIMAL_OK;
}

dmreda_minimal_status_t dmreda_minimal_import_checkpoint(
    dmreda_minimal_state_t *state,
    const dmreda_minimal_checkpoint_t *checkpoint
) {
    if (state == NULL || checkpoint == NULL) {
        return DMREDA_MINIMAL_ERROR_NULL;
    }
    if (checkpoint->magic != DMREDA_MINIMAL_CHECKPOINT_MAGIC
        || checkpoint->version != DMREDA_MINIMAL_CHECKPOINT_VERSION) {
        return DMREDA_MINIMAL_ERROR_CHECKPOINT;
    }
    if (!dmreda_minimal_state_valid(&checkpoint->state)) {
        return DMREDA_MINIMAL_ERROR_CHECKPOINT;
    }
    *state = checkpoint->state;
    return DMREDA_MINIMAL_OK;
}

uint64_t dmreda_minimal_state_size(void) {
    return (uint64_t)sizeof(dmreda_minimal_state_t);
}

uint64_t dmreda_minimal_checkpoint_size(void) {
    return (uint64_t)sizeof(dmreda_minimal_checkpoint_t);
}

const char *dmreda_minimal_configuration_sha256(void) {
    return DMREDA_MINIMAL_CONFIGURATION_SHA256;
}
