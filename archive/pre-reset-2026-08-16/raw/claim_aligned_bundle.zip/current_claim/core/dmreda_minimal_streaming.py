"""O(1)-with-stream-length Python reference for finalization variant H.

The input is one finite, already-affine-scaled float64-compatible sample at a
time.  No trace-length output arrays are retained.  This is an engineering
candidate selected on spent DEVELOPMENT data, not a validated scientific
detector.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import sys
from typing import Mapping


CONFIGURATION = {
    "schema": "dmreda.finalization.minimal-core.v1",
    "selection": {
        "development_variant": "H",
        "development_result": "experimental/finalization/results/development_v2/ablation_summary.json",
        "claim_grade": False,
    },
    "input": {
        "domain": "finite already-affine-scaled scalar",
        "maximum_absolute_value": "DBL_MAX/64",
        "invalid_sample_policy": "raise ValueError before state mutation",
    },
    "representation": {
        "trailing_median_width": 7,
        "absolute_residual": True,
        "residual_sum_width": 16,
        "residual_sum_roundoff_policy": "clamp a negative post-update running sum to zero",
        "energy_baseline_beta": 0.03125,
        "energy_floor": 0.02,
        "normalized_deviation_bounds": [-5.0, 5.0],
    },
    "authority": {
        "warmup_samples": 92,
        "threshold_comparison": "D > 0.8",
        "consecutive_samples": 6,
        "refractory_samples": 80,
        "refractory_boundary": "decrement before test; current sample is eligible when counter reaches zero",
        "first_sample_index": 0,
    },
    "removed": [
        "lagged growth G",
        "candidate opening",
        "candidate area",
        "candidate snapshot contract",
        "adaptive lag",
        "adaptive confirmation length",
        "regime FSM",
    ],
}


def _canonical_sha256(payload: object) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


CONFIGURATION_SHA256 = _canonical_sha256(CONFIGURATION)
CHECKPOINT_SCHEMA = "dmreda.finalization.minimal-core.checkpoint.v1"
MEDIAN_WIDTH = 7
ENERGY_WIDTH = 16
BETA = 1.0 / 32.0
ENERGY_FLOOR = 0.02
D_LOW = -5.0
D_HIGH = 5.0
WARMUP_SAMPLES = 92
D_THRESHOLD = 0.8
CONSECUTIVE_SAMPLES = 6
REFRACTORY_SAMPLES = 80
MAX_ABS_INPUT = sys.float_info.max / 64.0


@dataclass(frozen=True)
class StepOutput:
    sample_index: int
    median: float
    residual: float
    residual_sum: float
    energy_baseline: float
    normalized_deviation: float
    authority_enabled: bool
    consecutive_count: int
    refractory_remaining: int
    confirmed: bool


class MinimalStreamingDetector:
    """Fixed-size state machine; memory does not grow with stream length."""

    __slots__ = (
        "_x_ring",
        "_x_count",
        "_x_position",
        "_e_ring",
        "_e_count",
        "_e_position",
        "_e_sum",
        "_e_baseline",
        "_sample_index",
        "_consecutive_count",
        "_refractory_remaining",
    )

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._x_ring = [0.0] * MEDIAN_WIDTH
        self._x_count = 0
        self._x_position = 0
        self._e_ring = [0.0] * ENERGY_WIDTH
        self._e_count = 0
        self._e_position = 0
        self._e_sum = 0.0
        self._e_baseline = 0.0
        self._sample_index = 0
        self._consecutive_count = 0
        self._refractory_remaining = 0

    @property
    def sample_index(self) -> int:
        return self._sample_index

    @property
    def configuration_sha256(self) -> str:
        return CONFIGURATION_SHA256

    def _validate_sample(self, sample: float) -> float:
        if isinstance(sample, bool):
            raise ValueError("sample must be a finite real number")
        try:
            numeric = float(sample)
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError("sample must be a finite real number") from error
        if not math.isfinite(numeric) or abs(numeric) > MAX_ABS_INPUT:
            raise ValueError(
                "sample must be finite and abs(sample) must not exceed DBL_MAX/64"
            )
        return numeric

    @staticmethod
    def _bounded_ratio(numerator: float, denominator: float) -> float:
        if numerator > D_HIGH * denominator:
            return D_HIGH
        if numerator < D_LOW * denominator:
            return D_LOW
        return numerator / denominator

    def step(self, sample: float) -> StepOutput:
        value = self._validate_sample(sample)
        index = self._sample_index

        self._x_ring[self._x_position] = value
        self._x_position = (self._x_position + 1) % MEDIAN_WIDTH
        if self._x_count < MEDIAN_WIDTH:
            self._x_count += 1
        ordered = sorted(self._x_ring[: self._x_count])
        middle = self._x_count // 2
        if self._x_count % 2:
            median = ordered[middle]
        else:
            median = 0.5 * (ordered[middle - 1] + ordered[middle])
        residual = abs(value - median)

        if self._e_count < ENERGY_WIDTH:
            self._e_sum += residual
            self._e_count += 1
        else:
            self._e_sum -= self._e_ring[self._e_position]
            self._e_sum += residual
        if self._e_sum < 0.0:
            # The mathematical sum is non-negative.  Subtractive cancellation
            # can leave a small negative residue when a nonzero window drains.
            self._e_sum = 0.0
        self._e_ring[self._e_position] = residual
        self._e_position = (self._e_position + 1) % ENERGY_WIDTH

        if index == 0:
            self._e_baseline = self._e_sum
        else:
            self._e_baseline = BETA * self._e_sum + (1.0 - BETA) * self._e_baseline
        baseline_safe = max(self._e_baseline, ENERGY_FLOOR)
        d_value = self._bounded_ratio(
            self._e_sum - baseline_safe,
            baseline_safe,
        )

        if self._refractory_remaining > 0:
            self._refractory_remaining -= 1
        authority_enabled = index >= WARMUP_SAMPLES
        confirmed = False
        if not authority_enabled or self._refractory_remaining > 0:
            self._consecutive_count = 0
        elif d_value > D_THRESHOLD:
            self._consecutive_count += 1
            if self._consecutive_count >= CONSECUTIVE_SAMPLES:
                confirmed = True
                self._consecutive_count = 0
                self._refractory_remaining = REFRACTORY_SAMPLES
        else:
            self._consecutive_count = 0

        self._sample_index += 1
        return StepOutput(
            sample_index=index,
            median=median,
            residual=residual,
            residual_sum=self._e_sum,
            energy_baseline=self._e_baseline,
            normalized_deviation=d_value,
            authority_enabled=authority_enabled,
            consecutive_count=self._consecutive_count,
            refractory_remaining=self._refractory_remaining,
            confirmed=confirmed,
        )

    def checkpoint(self) -> dict[str, object]:
        """Return a JSON-round-trippable, configuration-bound checkpoint."""

        return {
            "schema": CHECKPOINT_SCHEMA,
            "configuration_sha256": CONFIGURATION_SHA256,
            "state": {
                "x_ring": list(self._x_ring),
                "x_count": self._x_count,
                "x_position": self._x_position,
                "e_ring": list(self._e_ring),
                "e_count": self._e_count,
                "e_position": self._e_position,
                "e_sum": self._e_sum,
                "e_baseline": self._e_baseline,
                "sample_index": self._sample_index,
                "consecutive_count": self._consecutive_count,
                "refractory_remaining": self._refractory_remaining,
            },
        }

    @classmethod
    def from_checkpoint(
        cls, checkpoint: Mapping[str, object]
    ) -> "MinimalStreamingDetector":
        if checkpoint.get("schema") != CHECKPOINT_SCHEMA:
            raise ValueError("unsupported checkpoint schema")
        if checkpoint.get("configuration_sha256") != CONFIGURATION_SHA256:
            raise ValueError("checkpoint configuration hash mismatch")
        raw_state = checkpoint.get("state")
        if not isinstance(raw_state, Mapping):
            raise ValueError("checkpoint state must be a mapping")
        detector = cls()
        try:
            x_ring = [float(value) for value in raw_state["x_ring"]]
            e_ring = [float(value) for value in raw_state["e_ring"]]
            x_count = int(raw_state["x_count"])
            x_position = int(raw_state["x_position"])
            e_count = int(raw_state["e_count"])
            e_position = int(raw_state["e_position"])
            e_sum = float(raw_state["e_sum"])
            e_baseline = float(raw_state["e_baseline"])
            sample_index = int(raw_state["sample_index"])
            consecutive_count = int(raw_state["consecutive_count"])
            refractory_remaining = int(raw_state["refractory_remaining"])
        except (KeyError, TypeError, ValueError, OverflowError) as error:
            raise ValueError("malformed checkpoint state") from error
        if len(x_ring) != MEDIAN_WIDTH or len(e_ring) != ENERGY_WIDTH:
            raise ValueError("checkpoint ring length mismatch")
        if not all(math.isfinite(value) for value in [*x_ring, *e_ring, e_sum, e_baseline]):
            raise ValueError("checkpoint contains non-finite numeric state")
        if any(value < 0.0 for value in e_ring) or e_sum < 0.0 or e_baseline < 0.0:
            raise ValueError("checkpoint contains negative energy state")
        if sample_index < 0:
            raise ValueError("checkpoint sample_index must be non-negative")
        if x_count != min(sample_index, MEDIAN_WIDTH):
            raise ValueError("checkpoint x_count disagrees with sample_index")
        if e_count != min(sample_index, ENERGY_WIDTH):
            raise ValueError("checkpoint e_count disagrees with sample_index")
        if x_position != sample_index % MEDIAN_WIDTH:
            raise ValueError("checkpoint x_position disagrees with sample_index")
        if e_position != sample_index % ENERGY_WIDTH:
            raise ValueError("checkpoint e_position disagrees with sample_index")
        if not 0 <= consecutive_count < CONSECUTIVE_SAMPLES:
            raise ValueError("checkpoint consecutive_count is outside its range")
        if not 0 <= refractory_remaining <= REFRACTORY_SAMPLES:
            raise ValueError("checkpoint refractory_remaining is outside its range")
        detector._x_ring = x_ring
        detector._x_count = x_count
        detector._x_position = x_position
        detector._e_ring = e_ring
        detector._e_count = e_count
        detector._e_position = e_position
        detector._e_sum = e_sum
        detector._e_baseline = e_baseline
        detector._sample_index = sample_index
        detector._consecutive_count = consecutive_count
        detector._refractory_remaining = refractory_remaining
        return detector
