#ifndef DMREDA_MINIMAL_STREAMING_H
#define DMREDA_MINIMAL_STREAMING_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DMREDA_MINIMAL_MEDIAN_WIDTH 7u
#define DMREDA_MINIMAL_ENERGY_WIDTH 16u
#define DMREDA_MINIMAL_WARMUP_SAMPLES 92u
#define DMREDA_MINIMAL_CONSECUTIVE_SAMPLES 6u
#define DMREDA_MINIMAL_REFRACTORY_SAMPLES 80u
#define DMREDA_MINIMAL_CHECKPOINT_MAGIC UINT32_C(0x444d5233)
#define DMREDA_MINIMAL_CHECKPOINT_VERSION UINT32_C(1)
#define DMREDA_MINIMAL_CONFIGURATION_SHA256 \
    "4463e0e5252741b51ba85c22ce78b4e8ccd92bf111a0fd2452c8c7128c6acf9c"

typedef enum dmreda_minimal_status {
    DMREDA_MINIMAL_OK = 0,
    DMREDA_MINIMAL_ERROR_NULL = -1,
    DMREDA_MINIMAL_ERROR_INPUT_DOMAIN = -2,
    DMREDA_MINIMAL_ERROR_STATE = -3,
    DMREDA_MINIMAL_ERROR_CHECKPOINT = -4
} dmreda_minimal_status_t;

typedef struct dmreda_minimal_state {
    double x_ring[DMREDA_MINIMAL_MEDIAN_WIDTH];
    double e_ring[DMREDA_MINIMAL_ENERGY_WIDTH];
    double e_sum;
    double e_baseline;
    uint64_t sample_index;
    uint32_t x_count;
    uint32_t x_position;
    uint32_t e_count;
    uint32_t e_position;
    uint32_t consecutive_count;
    uint32_t refractory_remaining;
} dmreda_minimal_state_t;

typedef struct dmreda_minimal_output {
    uint64_t sample_index;
    double median;
    double residual;
    double residual_sum;
    double energy_baseline;
    double normalized_deviation;
    uint32_t authority_enabled;
    uint32_t consecutive_count;
    uint32_t refractory_remaining;
    uint32_t confirmed;
} dmreda_minimal_output_t;

typedef struct dmreda_minimal_checkpoint {
    uint32_t magic;
    uint32_t version;
    dmreda_minimal_state_t state;
} dmreda_minimal_checkpoint_t;

void dmreda_minimal_reset(dmreda_minimal_state_t *state);

dmreda_minimal_status_t dmreda_minimal_step(
    dmreda_minimal_state_t *state,
    double scaled_sample,
    dmreda_minimal_output_t *output
);

dmreda_minimal_status_t dmreda_minimal_export_checkpoint(
    const dmreda_minimal_state_t *state,
    dmreda_minimal_checkpoint_t *checkpoint
);

dmreda_minimal_status_t dmreda_minimal_import_checkpoint(
    dmreda_minimal_state_t *state,
    const dmreda_minimal_checkpoint_t *checkpoint
);

uint64_t dmreda_minimal_state_size(void);
uint64_t dmreda_minimal_checkpoint_size(void);
const char *dmreda_minimal_configuration_sha256(void);

#ifdef __cplusplus
}
#endif

#endif
