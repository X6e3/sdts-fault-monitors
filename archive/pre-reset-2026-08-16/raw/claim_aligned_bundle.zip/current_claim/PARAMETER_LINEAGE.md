# Parameter Lineage Audit

## Historical κ=2.5

- **[DIRECT EVIDENCE]** `TEP_KAPPA = 2.5` first appears in reachable history in commit `7b891a5b7c37f72aeeed6a5f6c05c37cb4c9edf9` (`stage3: add immutable domain profile configuration`, 2026-08-05 12:45:49 +0300).
- **[DIRECT EVIDENCE]** The parent commit has no `stage3/tep/configuration.py`; the introducing commit adds the number directly and provides no linked threshold-selection result.
- **[DIRECT EVIDENCE]** `git log --all -S'TEP_KAPPA'` returns only the introducing commit.
- **[DIRECT EVIDENCE]** The later frozen protocol declares FaultFreeTraining runs 101–200 as `kappa_selection_spent`, but a declaration of role is not evidence of the missing selection execution.
- **[UNKNOWN]** The tested grid, objective, competing κ values, result table, seed, and operator decision that produced 2.5 are unavailable.

## Recovery attempts

- **[DIRECT EVIDENCE]** Reachable authoritative history through `7fb1fe26...` contains 58 commits and no tags.
- **[DIRECT EVIDENCE]** Git object audit found nine unreachable blobs: `9b313a...`, `9bc386...`, `a7fb56...`, `a5acfd...`, `c81ca3...`, `d9c401...`, `9bc515...`, `b86d0a...`, and `e32d91...`.
- **[DIRECT EVIDENCE]** Searching their payloads for `TEP_KAPPA`, `kappa`, `2.5`, FaultFreeTraining identities, and threshold-selection terms produced no recovery evidence.
- **[DIRECT EVIDENCE]** `.dmreda_run_backups/.../dmreda_equal_fa_recalibrated_sweep.json` contains 2.5 inside a broad synthetic `dmreda_scale_grid`, but its disturbances/noise experiments are not TEP, do not bind runs 101–200, and select different scales by scenario.
- **[STRONG INFERENCE]** That backup sweep is prior exploratory context, not provenance for Stage 3.3 κ=2.5.

## Finalization parameters

- **[DIRECT EVIDENCE]** The finalization κ grid and architecture rule were frozen in `../experimental/finalization/protocol_v3_development.json` before the development execution.
- **[DIRECT EVIDENCE]** Variant H selected κ=4.0, which yields `D>0.8` because the state-0 `th_d2` base is 0.2. Candidate index 70 in the 311-point grid is recorded in the development summary.
- **[DIRECT EVIDENCE]** H's configuration and source were frozen before the attempted locked-gate phase; the gate did not execute because fresh normal data were absent.
- **[DIRECT EVIDENCE]** H=500 was chosen because available development trajectories have 500 samples. It is a new mission contract, not a reinterpretation of H=960.
- **[STRONG INFERENCE]** Finalization parameter lineage is reproducible but still post-hoc development tuning; its transparency does not convert it to independent evidence.

## Consequence

- **[DIRECT EVIDENCE]** Historical κ lineage must be reported as unrecoverable, never reconstructed from protocol prose.
- **[UNKNOWN]** Whether κ=2.5 was honestly selected on runs 101–200, chosen heuristically, or inherited from another experiment cannot be determined.
- **[DIRECT EVIDENCE]** The immutable negative is valid as the behavior of the frozen κ=2.5 configuration regardless of why the number was selected.
