# Data Provenance and Holdout Audit

## TEP banks

| Raw object | Raw SHA-256 | Extract SHA-256 | Actual role | Value-access conclusion |
|---|---|---|---|---|
| FaultFreeTraining | `12d1055b852763fac09ef36bd7c9612a800c8bf7b6f75f344d12119206f9e940` | `f48e6735bc80d0ab0ab4b7aad4957a7203ed346ea1556ef7e1f37693fc686b4d` | scaling, historical calibration, finalization development | **[DIRECT EVIDENCE] SPENT DEVELOPMENT** |
| FaultyTraining | `058df8bd90c5f575f44d2f6085bdd3bc3662e3e9cc25a50e34af42be3748952b` | `c8c6990730c23be501260235417d2c8347653cf11faae056ac09e39b6288261d` | finalization fault development | **[DIRECT EVIDENCE] SPENT DEVELOPMENT** |
| FaultFreeTesting | `4f45afafa469793eeb7203fb9ed10ed0b1724c73c9c95537f15a0889ade0ebd4` | `9b7283e83fb4e31dec218df29aaedd934cfa7a32a4f678f6bb9bc85b68d68e7e` | immutable Stage 3.3 validation, post-hoc forensics/parity | **[DIRECT EVIDENCE] SPENT VALIDATION** |
| FaultyTesting | `c2f1aabc77498efda4d5f9ad81ecc829e2fcd98752b84cf5b2a06558cabacc36` | unavailable because unopened | locked fault holdout | **[DIRECT EVIDENCE] NOT OPENED IN FINALIZATION** |

- **[DIRECT EVIDENCE]** Raw identities and the historical machine access scope are recorded in `../frozen_history/environment/raw_integrity_stage3_3.json`.
- **[DIRECT EVIDENCE]** The historical progress ledger states FaultFreeTesting opened for the independent normal gate, the gate stopped at 42 authorities, Bank D was denied, and FaultyTesting remained unopened.
- **[DIRECT EVIDENCE]** Finalization parity reused spent banks only for implementation equivalence; it explicitly reports `claim_grade=false`.
- **[UNKNOWN]** The raw-integrity machine record cannot establish that no human had inspected FaultyTesting values outside the recorded workflow. Human access history remains unknown.

## Contamination and leakage audit

- **[DIRECT EVIDENCE]** Historical affine parameters use FaultFreeTraining runs 1–100 and are applied once to each trajectory; evaluated-trace fitting is prohibited and tested.
- **[UNKNOWN]** κ=2.5's selection data and rationale are not recoverable, so the exact historical tuning boundary cannot be verified.
- **[DIRECT EVIDENCE]** FaultFreeTesting influenced diagnosis through the 42/500 negative and later post-hoc mechanism analysis. It cannot be reused as fresh validation for H.
- **[DIRECT EVIDENCE]** FaultFreeTraining and FaultyTraining explicitly influenced finalization architecture/threshold choice. Their A–L results are development evidence only.
- **[DIRECT EVIDENCE]** Fault onset 20 is earlier than warm-up 92, causing a causal evaluation weakness rather than future-sample leakage: changed samples legitimately update detector state before authority is allowed, but the experiment cannot distinguish startup adaptation from steady-state detection.
- **[STRONG INFERENCE]** No direct future leakage is present in canonical per-sample transforms; the larger threats are holdout reuse, incomplete parameter lineage, post-hoc architecture selection, and benchmark-startup bias.

## Other datasets

- **[DIRECT EVIDENCE]** The Stage 3 dataset authority audit rejected the local PQD-16c mirror for scientific execution: original source/citation and rights chain were incomplete, acquisition identities/onsets were absent, and normal rows collapsed to one unique waveform.
- **[DIRECT EVIDENCE]** SKAB metadata identifies one local recording that had already been used in prior studies; the raw file is not present in this checkout, and it cannot populate independent normal/calibration/fault banks.
- **[DIRECT EVIDENCE]** HAI was not acquired and was not admitted; repository metadata notes only four independent disturbed acquisition files and ambiguous physical-onset authority.
- **[DIRECT EVIDENCE]** NASA IMS local data was a derived full-trace-normalized scalar with algorithmic onset and no raw archive identity; it was rejected.
- **[UNKNOWN]** No performance conclusion about PQD-16c, SKAB, HAI, or NASA IMS can be made from repository metadata.

## Required new provenance

- **[DIRECT EVIDENCE]** `evidence/locked_gate_status.json` preregisters 1,000 new independent normal trajectories and their required hashes/identities/access declarations.
- **[STRONG INFERENCE]** A new simulator campaign is preferable to repartitioning any existing TEP file because all existing value-bearing normal partitions influenced this project.
- **[UNKNOWN]** If physical data replace simulation, recording independence, sensor calibration, timestamp domain, operating regime, and maintenance/fault intervention provenance require a new protocol.
