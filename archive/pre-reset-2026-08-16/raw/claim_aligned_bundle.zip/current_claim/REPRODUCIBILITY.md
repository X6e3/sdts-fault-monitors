# Reproducibility Record

## Source identities

- **[DIRECT EVIDENCE]** Authoritative historical commit: `7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc`.
- **[DIRECT EVIDENCE]** Historical Git bundle: `../frozen_history/source/dmreda-stage3-source-7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc.bundle`, SHA-256 `9138e31d17ee4788fdd2e41a46069c4b3cccae5811c2e9b0c85668a48f2f7cb6`.
- **[DIRECT EVIDENCE]** Finalization branch: `research/dmreda-finalization-v3`.
- **[DIRECT EVIDENCE]** Final candidate configuration SHA-256: `4463e0e5252741b51ba85c22ce78b4e8ccd92bf111a0fd2452c8c7128c6acf9c`.
- **[DIRECT EVIDENCE]** Portable finalization hashes are listed in `SHA256SUMS`; verification is run from this directory.

## Environment

- **[DIRECT EVIDENCE]** Recorded Stage 3 environment is specified by `../repro/stage3/environment.json` and `../repro/stage3/requirements.lock`: CPython 3.12.13, NumPy 2.3.2, SciPy 1.16.1, macOS 15.7.7 arm64, Apple clang 17.
- **[DIRECT EVIDENCE]** That environment location was external to Git and is not available as an immutable executable environment in this checkout; wheel/sdist hashes were not captured.
- **[DIRECT EVIDENCE]** Finalization development results were reproduced with CPython 3.12.13 and NumPy 2.3.5 on macOS 15.7.7 arm64. The available runtime has no SciPy; the selected finalization paths do not require it.
- **[DIRECT EVIDENCE]** Homebrew Python 3.14.6 has no NumPy and was not used.

## Verification commands

From repository root:

```bash
PYTHONDONTWRITEBYTECODE=1 /path/to/python3 -m unittest discover -s tests -v
```

- **[DIRECT EVIDENCE]** Final run on 2026-08-14: 240 tests, 6.174 seconds, `OK`.

From `current_claim/`:

```bash
shasum -a 256 -c SHA256SUMS
```

Reproduce historical negative forensics without modifying tracked files:

```bash
python3 current_claim/tools/analyze_historical_negative.py \
  --normal-testing "$FAULT_FREE_TESTING_EXTRACT" \
  --output "$TEMP_DIR/historical_negative_forensics.json"
cmp "$TEMP_DIR/historical_negative_forensics.json" \
  current_claim/evidence/historical_negative_forensics.json
```

Reproduce exact Python/C parity without opening FaultyTesting:

```bash
python3 current_claim/tools/verify_streaming_parity.py \
  --normal-training "$FAULT_FREE_TRAINING_EXTRACT" \
  --fault-training "$FAULTY_TRAINING_EXTRACT" \
  --normal-testing "$FAULT_FREE_TESTING_EXTRACT" \
  --output "$TEMP_DIR/streaming_parity_report.json"
cmp "$TEMP_DIR/streaming_parity_report.json" \
  current_claim/evidence/streaming_parity_report.json
```

- **[DIRECT EVIDENCE]** Both tools hash-check every extract before value use and reject any path normalized as FaultyTesting.
- **[DIRECT EVIDENCE]** Prior reruns were byte-identical to the tracked forensic, parity, and development-result artifacts.

## Bound artifacts

- **[DIRECT EVIDENCE]** Historical trajectory rows SHA-256: `dd0e3e6a78e840915258a68533280aa2c2ef1b19861aebe0b32560ada5cf0608`.
- **[DIRECT EVIDENCE]** Historical normal summary SHA-256: `48c82c94eb61ea618d0d0ad2ffc44c09db9c083e8c006d9ff5efa0d1d230d018`.
- **[DIRECT EVIDENCE]** Development protocol SHA-256: `a66edbd87df4521f81272fd9943352569c61a023618af14ecdde93814d3ed9f1`.
- **[DIRECT EVIDENCE]** Development summary SHA-256: `d78f770741133dd181d76f690558de2319ec8560c06ed2b94776bdd1e2583898`.
- **[DIRECT EVIDENCE]** Streaming parity report SHA-256: `8251e2ff1bb1ef4b694c32f69ef70453b5df38583a3e6f4cf3cac67f5b3d18fd`.

## Historical package discrepancy

- **[DIRECT EVIDENCE]** External ad-hoc tarball SHA-256 is `16f1d9378201ccaadc4eca94e869f1c11153807a83b44dc5382e1f2d777444dd`.
- **[DIRECT EVIDENCE]** Commit/tar hashes differ for `stage3/tep/campaign.py`: `111e898f...` versus `cdb58046...`; and `tests/stage3/test_tep_campaign.py`: `faf4db5e...` versus `36e299c4...`.
- **[DIRECT EVIDENCE]** `stage3/tep/runner.py` matches at `19b9400b...`.
- **[STRONG INFERENCE]** The tarball is an unversioned working snapshot and must not override the commit-bound Git bundle.

## Reproducibility limits

- **[DIRECT EVIDENCE]** Raw RData is external and is represented here by hashes and extraction manifests, not redistributed values.
- **[DIRECT EVIDENCE]** No container/VM image or artifact-signed toolchain is supplied.
- **[DIRECT EVIDENCE]** Exact parity covers the enumerated binary64 replays, not all real histories or platforms.
- **[UNKNOWN]** Bit-identical reproduction on another OS/compiler/NumPy build is not established.
- **[UNKNOWN]** Scientific reproducibility of the final candidate awaits new data that do not yet exist.
