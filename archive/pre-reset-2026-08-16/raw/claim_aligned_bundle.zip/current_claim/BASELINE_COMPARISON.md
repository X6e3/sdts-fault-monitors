# Baseline Comparison

## Comparator contract

- **[DIRECT EVIDENCE]** All finalization comparators receive the same fixed affine scalar input and the same H=500 trajectory identities.
- **[DIRECT EVIDENCE]** J is a two-sided Page-style CUSUM score centered at zero with allowance 0.5, followed by a 20-sample persistence gate and 80-sample refractory.
- **[DIRECT EVIDENCE]** K is an absolute Roberts-style EWMA mean-shift score centered at zero with scale 1 and alpha `2/33`, followed by the same persistence/refractory gate.
- **[DIRECT EVIDENCE]** Only the scalar threshold was calibrated on FaultFreeTraining runs 1–200. Exact change-point threshold grids were constructed from all normal-calibration persistence-window minima.
- **[DIRECT EVIDENCE]** J/K intentionally do not use the median-residual-energy representation. The comparison asks whether that representation and historical arbitration add value over standard scalar sequential scores.

## Matched development operating point

| Detector | calibration authorities/200 | threshold | normal dev authorities/300 | fault detections/400 | restricted delay |
|---|---:|---:|---:|---:|---:|
| A full Core | 10 | κ=2.30 | 24 | 108 | 389.0025 |
| H reduced candidate | 10 | κ=4.00 (`D>0.8`) | 20 | 113 | 389.0525 |
| J Page-style CUSUM | 10 | 86.56156249 | 13 | 188 | 306.1400 |
| K absolute EWMA | 10 | 1.96222605 | 15 | 208 | 298.9325 |

- **[DIRECT EVIDENCE]** Relative to A, J's paired detection delta is +0.20 with cluster-bootstrap 95% interval `[0.14,0.2426]`; its restricted-delay delta is -82.8625 samples with interval `[-99.7003,-59.1543]`.
- **[DIRECT EVIDENCE]** Relative to A, K's paired detection delta is +0.25 with interval `[0.18,0.31]`; its restricted-delay delta is -90.07 samples with interval `[-108.0628,-64.7594]`.
- **[STRONG INFERENCE]** On this development bank, known scalar accumulators are materially stronger than the full and reduced DMREDA-derived detectors at approximately matched calibration risk.

## Why this is not a steady-state superiority result

- **[DIRECT EVIDENCE]** Faults begin at index 20; authority is disabled until index 92.
- **[STRONG INFERENCE]** CUSUM/EWMA can accumulate the post-change mean signal during those 72 samples and cross their thresholds soon after authority is enabled. The robust median-residual-energy path instead treats much of the persistent shift as a new local baseline.
- **[DIRECT EVIDENCE]** No pre-onset false authority can be observed in this fault bank because onset precedes warm-up.
- **[STRONG INFERENCE]** The table falsifies an unrestricted claim that DMREDA-derived complexity is generally necessary or dominant. It does not establish universal CUSUM/EWMA superiority.
- **[UNKNOWN]** A fair steady-state comparison requires frozen onset after a pre-change dwell, matched computation/latency constraints, and untouched trajectories.

## Historical H=960 comparator context

- **[DIRECT EVIDENCE]** On immutable FaultFreeTesting, full D-or-G risk was 42/500 (0.084), CUSUM 27/500 (0.054), EWMA 37/500 (0.074), and RMS 44/500 (0.088). These are normal-risk observations only; FaultyTesting stayed sealed.
- **[DIRECT EVIDENCE]** Historical CUSUM was excluded from admitted references because its achieved risk was not matched under that frozen protocol. Therefore no historical fault-performance ordering exists.
- **[STRONG INFERENCE]** Both historical and finalization evidence weaken claims that the full Core provides uniquely controlled normal authority.
