# DMREDA Final Technical Report

## Evidence vocabulary

- **[DIRECT EVIDENCE]** means the statement is directly established by a tracked source file, immutable result, hash, or executed test.
- **[STRONG INFERENCE]** means the statement is the best mechanism-level interpretation of repository evidence, but is not a theorem or untouched-data result.
- **[UNKNOWN]** means the repository cannot establish the statement; external literature, unavailable provenance, hardware, or new data is required.

## Final decision

**D. INCONCLUSIVE — FRESH DATA REQUIRED**

- **[DIRECT EVIDENCE]** The immutable Stage 3.3 normal gate failed: 42 of 500 independent FaultFreeTesting trajectories produced at least one authority by `H=960`, versus the frozen maximum of 25. The frozen result remains `status="failed"` in `../frozen_history/results/dmreda_normal_summary.json`; its source commit is `7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc`.
- **[DIRECT EVIDENCE]** The finalization candidate is development variant H, selected only on spent development data. `evidence/locked_gate_status.json` records `BLOCKED_FRESH_NORMAL_REQUIRED`, `phase_8_executed=false`, `phase_9_permitted=false`, and `FaultyTesting` unopened in this pass.
- **[DIRECT EVIDENCE]** No genuinely untouched normal bank exists after architecture, scalar parameters, implementation, and mission horizon were frozen. Therefore no present repository result can validate the candidate's normal operating risk.
- **[UNKNOWN]** Detection performance on a genuinely untouched fault holdout is unknown because the required fresh-normal gate did not run and FaultyTesting was not opened.

## What this project actually is

- **[DIRECT EVIDENCE]** The historical canonical algorithm is a causal deterministic sequential decision machine over a nonlinear scalar representation. Its canonical implementation is `../gold_line/core/dmreda_reference_clean.py`; the TEP specialization is `../stage3/tep/configuration.py`.
- **[DIRECT EVIDENCE]** Its representation is: trailing median, absolute residual, trailing residual sum, exponentially weighted baseline, normalized/clamped deviation `D`, lagged difference `G_raw`, exponentially smoothed `G`, a slow activity statistic, and a three-state hysteretic regime controller. Its decision layer is a finite-duration candidate gate with excess-area and qualifying-count conditions followed by refractory suppression.
- **[STRONG INFERENCE]** It is best classified as a handcrafted sequential detector plus deterministic finite-state arbitration, not as a learned anomaly detector and not as a likelihood-ratio procedure. The repository around it is a research framework because it contains protocol freezes, bank seals, deterministic replay, baselines, checkpointing, provenance controls, and reports; those framework properties do not make the detector itself a new statistical family.
- **[DIRECT EVIDENCE]** The Structural Manifold code under `../gold_line/structural_manifold/` is a separate covariance/Mahalanobis/CUSUM research family. It is not the canonical Core and is excluded from the current claim.

## Canonical algorithm ownership

Historical Stage 3.3 identity:

1. **[DIRECT EVIDENCE]** `../gold_line/core/dmreda_reference_clean.py` defines every historical representation update, authority transition, regime transition, warm-up rule, and refractory boundary.
2. **[DIRECT EVIDENCE]** `../stage3/tep/configuration.py` defines the TEP affine transform, `TEP_KAPPA=2.5`, the four multiplied threshold fields, warm-up 92, initial state 0, regime tick 50, and `D_or_G` opening mode.
3. **[DIRECT EVIDENCE]** `../frozen_history/protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json` binds the dataset roles, horizon 960, first-event ownership, source hashes, and stop rules.
4. **[DIRECT EVIDENCE]** `../frozen_history/results/dmreda_normal_trajectory_results.jsonl` and `../frozen_history/results/dmreda_normal_summary.json` define the immutable negative result.

Finalization candidate identity:

1. **[DIRECT EVIDENCE]** `core/dmreda_minimal_streaming.py` is the readable streaming reference.
2. **[DIRECT EVIDENCE]** `core/dmreda_minimal_streaming.c` and `.h` are the bounded C99 implementation and ABI.
3. **[DIRECT EVIDENCE]** Their canonical configuration SHA-256 is `4463e0e5252741b51ba85c22ce78b4e8ccd92bf111a0fd2452c8c7128c6acf9c`.
4. **[DIRECT EVIDENCE]** `evidence/streaming_parity_report.json` binds source hashes and exact per-sample Python/C replay evidence.

## Documentation and implementation mismatches

- **[DIRECT EVIDENCE]** Historical prose calls the Core a "research-grade reference" and uses bespoke abstraction names. The implementation is a deterministic threshold-and-FSM detector; no repository theorem, independent benchmark, or literature review establishes a distinct statistical class.
- **[DIRECT EVIDENCE]** The frozen Stage 3.3 admission seal contains two denial reasons, including `normal_summary_and_admission_disagree`, even though the normal summary and admission both deny the gate. The maintained seal implementation now has a regression test showing that coherent primary failure is not a disagreement; the frozen artifact was not rewritten.
- **[DIRECT EVIDENCE]** The historical ad-hoc tarball `dmreda-stage3-current-20260805.tar.gz` is not byte-identical to commit `7fb1fe26...`: `stage3/tep/campaign.py` and its campaign test differ. The verified Git bundle in `../frozen_history/source/` is the authoritative historical source.
- **[UNKNOWN]** The original rationale or selection experiment for historical `TEP_KAPPA=2.5` is unavailable. Reachable history introduces the number directly; no reachable selection grid or result binds it to runs 101–200.

## Technical strengths

- **[DIRECT EVIDENCE]** First-event accounting is correct: an authority before onset remains a false authority and cannot earn later detection credit. Tests cover this invariant across benchmark, Stage 3, and finalization paths.
- **[DIRECT EVIDENCE]** Warm-up gates authority while representation state continues to update, avoiding a discontinuous cold-start representation at sample 92.
- **[DIRECT EVIDENCE]** The repository has strict JSON, source/configuration hashes, immutable result handling, external raw-data paths, deterministic checkpoint/resume logic, serial/parallel replay checks, and fail-closed bank seals.
- **[DIRECT EVIDENCE]** The final C implementation is C99, heap-free, fixed-state, validates input before state mutation, and has configuration-bound checkpoint import/export.
- **[DIRECT EVIDENCE]** The final replay report establishes exact equality for 930,000 extracted-bank samples, 1,488 golden samples, and 108,304 deterministic randomized samples.
- **[STRONG INFERENCE]** These are serious engineering and research-integrity strengths. They support reproducibility and falsifiability, not detection novelty or external validity.

## Overengineering and removable complexity

- **[DIRECT EVIDENCE]** In the failed normal gate, all 42 first confirmations opened in regime state 0 and confirmed before any first regime transition. The regime FSM therefore did not prevent the observed first false authorities.
- **[DIRECT EVIDENCE]** G-only replay affected the same 42 trajectories as historical D-or-G replay, with only three first indices shifted by one sample. D-only affected 32 trajectories. The G opening path dominates membership in this specific failure.
- **[DIRECT EVIDENCE]** Development variant H removes G, candidate opening, candidate area, snapshotted contracts, adaptive lag, adaptive confirmation length, and the regime FSM while meeting the frozen development noninferiority rule versus full variant A.
- **[STRONG INFERENCE]** For the observed TEP use case, the historical three-regime controller and dual-stage candidate abstraction carry much more implementation surface than demonstrated decision value.
- **[UNKNOWN]** Those states may matter on other signal families or longer missions; the repository has no untouched evidence establishing either usefulness or uselessness outside the audited banks.

## Methodology audit

- **[DIRECT EVIDENCE]** The historical FaultFreeTesting bank became spent validation when it produced the 42/500 result. Post-hoc mode forensics on it are diagnostic only.
- **[DIRECT EVIDENCE]** Finalization used FaultFreeTraining runs 1–200 for parameter calibration, 201–500 for development evaluation, and FaultyTraining faults 1–20/runs 301–320 for development fault evaluation. All are explicitly marked non-claim-grade.
- **[DIRECT EVIDENCE]** Fault onset is index 20 but authority warm-up ends at index 92. Thus the first observable authoritative delay is 72 samples and pre-onset authority cannot be observed on that bank.
- **[STRONG INFERENCE]** CUSUM/EWMA can accumulate post-change evidence during warm-up and fire shortly after authority becomes enabled, while the median-residual-energy representation adapts toward the post-change signal. This creates a startup-contract bias and makes the observed baseline advantage uninformative about steady-state change detection.
- **[DIRECT EVIDENCE]** Candidate selection and all A–L comparisons are post-hoc development evidence. The selected H architecture, threshold, and H=500 mission now require a new independent normal bank before any fault holdout access.
- **[UNKNOWN]** External validity across noise families, process regimes, channels, physical sensors, and MCU numeric formats remains unmeasured.

## Failure mechanism of the immutable negative

- **[DIRECT EVIDENCE]** D-or-G produced 42 affected trajectories and 45 events. The finite-horizon risks were 0.006 at H=120, 0.010 at 160, 0.020 at 240, 0.044 at 480, 0.062 at 720, and 0.084 at 960.
- **[DIRECT EVIDENCE]** Among the 42 first confirmations, opening branches were G-only 27, D-and-G 12, and D-only 3. Pending spans were 7–17 samples (median 11). Confirmation area was 4.500769–5.045358 against a strict `>4.5` threshold; qualifying count was 7–16 against a minimum of 6.
- **[STRONG INFERENCE]** The dominant mechanism is ordinary normal variation creating a G threshold crossing, followed by enough sustained positive D excess to satisfy the area/count gate. The candidate gate delays the authority; it does not reject these normal excursions.
- **[DIRECT EVIDENCE]** Because every first false authority confirmed in state 0 before a regime change, the slow regime logic cannot explain or rescue the negative result.

## Reduction to known structures

- **[DIRECT EVIDENCE]** The historical baseline recursion is an EWMA/leaky integrator over a rolling robust residual-energy statistic. G is a finite difference followed by another EWMA. The authority layer combines a threshold trigger, finite-window accumulated excess, a run count, timeout, hysteretic mode changes, and refractory suppression.
- **[STRONG INFERENCE]** This is reducible to familiar sequential-control components: robust preprocessing + EWMA normalization + CUSUM-like positive excess accumulation + run rule + hysteresis/refractory FSM. It is not mathematically identical to classical Page CUSUM or SPRT because its score is not a log-likelihood ratio and its positive excess is bounded inside a candidate episode rather than recursively reset at zero forever.
- **[DIRECT EVIDENCE]** The final candidate is even smaller: robust rolling preprocessing followed by a six-consecutive-sample threshold run rule and refractory counter.
- **[UNKNOWN]** Whether the exact composition has prior-art identity under another name requires a broader systematic literature review than this pass.

## What to freeze, archive, remove, and redesign

- **[DIRECT EVIDENCE] Freeze:** immutable Stage 3.3 artifacts, source bundle, failure result, first-event accounting, dataset/seal contracts, finalization protocol, deterministic result hashes, and Python/C parity fixtures.
- **[STRONG INFERENCE] Freeze as engineering candidate only:** variant H source and configuration. Do not freeze a performance claim.
- **[STRONG INFERENCE] Archive from active claim surface:** `.dmreda_run_backups/`, `playground/`, `deprecated/`, Structural Manifold outputs, root compatibility wrappers, and ad-hoc tar packages. They retain provenance but should not be imported by current-claim code.
- **[STRONG INFERENCE] Remove in a future breaking version if fresh evidence does not reverse this assessment:** historical regime adaptation, G opening, adaptive lag/confirmation, and area/count candidate machinery.
- **[STRONG INFERENCE] Redesign validation:** create a post-freeze normal bank, then a steady-state fault protocol with onset after warm-up and a separate startup-fault protocol. Match risk on the actual mission horizon and report both detection probability and censored delay.
- **[UNKNOWN]** Production redesign also requires target-specific timing, overflow, floating-point policy, sensor scaling, and fault-containment requirements.

## Maturity classification

- **[STRONG INFERENCE]** Overall: **advanced prototype**.
- **[DIRECT EVIDENCE]** It exceeds a hobby prototype in deterministic implementation, tests, protocol discipline, negative-result preservation, and reproducibility controls.
- **[DIRECT EVIDENCE]** It is not publishable performance research in the present state because the selected candidate has no untouched normal gate or fault evaluation, historical κ lineage is incomplete, and development baseline comparisons have startup contamination.
- **[DIRECT EVIDENCE]** It is not productizable yet because MCU timing/energy/jitter, fixed-point behavior, target compiler/ABI, physical-sensor calibration drift, and field failure modes are absent.
- **[UNKNOWN]** Novelty is not established. A systematic literature comparison and new experiments are mandatory before using that word.

## Self-falsification

- **[STRONG INFERENCE] Strongest destructive argument:** the project is an overcomplicated known sequential detector. Its components are standard; G-only reproduces the failed normal membership; first false authorities happen before adaptive states matter; a much smaller run-rule candidate survives the project's own development noninferiority rule; and CUSUM/EWMA baselines are materially stronger on the only available fault-development bank.
- **[STRONG INFERENCE] Strongest counterargument:** the causal robust representation can be useful under non-Gaussian contamination and scale drift, the historical candidate contract has genuinely history-dependent semantics, and the repository's bounded deterministic implementation/provenance work is stronger than typical prototypes.
- **[STRONG INFERENCE] Current balance:** the destructive side has better evidence for algorithmic distinctiveness. The counterargument is plausible engineering motivation, but it lacks untouched cross-domain results and a novelty comparison.

## Evidence unavailable in this pass

- **[DIRECT EVIDENCE]** Reachable history through the authoritative baseline contains 58 commits and no tags; nine unreachable blobs were inspected for κ/TEP selection terms and did not supply the missing lineage.
- **[DIRECT EVIDENCE]** The recorded 2026-08-03 Python environment is specified in `../repro/stage3/`, but that external uv environment itself is not in Git. The available reproduction runtime has NumPy 2.3.5 rather than 2.3.2 and has no SciPy.
- **[DIRECT EVIDENCE]** No MCU hardware was available; cycle count, energy, jitter, WCET, and hardware fault behavior are unavailable.
- **[DIRECT EVIDENCE]** HAI raw data was not acquired and SKAB raw data is not present in this checkout. Repository metadata is not a substitute for their values.
- **[UNKNOWN]** Human access history for FaultyTesting before machine logging began cannot be proven; only the machine record says values were not deserialized.
