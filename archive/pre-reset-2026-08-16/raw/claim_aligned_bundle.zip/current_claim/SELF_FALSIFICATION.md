# Self-Falsification: Is DMREDA Merely an Overcomplicated Known Detector?

## Strongest destructive case

1. **[DIRECT EVIDENCE]** The historical detector is assembled from trailing median residuals, rolling sums, EWMAs, normalized thresholds, a finite-difference score, accumulated positive excess, a run count, timeout, hysteresis, and refractory dead time. None of those mechanism classes is unfamiliar in sequential control.
2. **[DIRECT EVIDENCE]** The immutable normal validation failed at 42/500 by H=960. Its false-authority risk grows with horizon rather than remaining at the nominal 5% mission target.
3. **[DIRECT EVIDENCE]** G-only produces authority on exactly the same 42 normal trajectories as D-or-G; only three first indices shift by one sample. The supposed dual-channel opening adds almost no membership information in this failure.
4. **[DIRECT EVIDENCE]** All 42 first false authorities open and confirm in state 0 before the first regime transition. The three-state adaptive regime abstraction does not participate in preventing the observed failure.
5. **[DIRECT EVIDENCE]** A simple six-consecutive-D rule removes most authority machinery and is the first candidate to pass the repository's own frozen development noninferiority/simplicity rule.
6. **[DIRECT EVIDENCE]** Known Page-style CUSUM and absolute EWMA baselines detect 188/400 and 208/400 development faults versus 108/400 for full A, with lower observed normal-development risk.
7. **[UNKNOWN]** No systematic literature result or untouched-data experiment establishes a unique problem that requires the full historical machinery.

**[STRONG INFERENCE]** The most economical explanation is that the historical algorithm is an overparameterized robust sequential threshold detector whose custom names obscure ordinary components.

## Strongest counterargument

1. **[DIRECT EVIDENCE]** The score is not exactly Page CUSUM, Roberts EWMA, or SPRT. It uses a causal rolling median, L1 residual energy, adaptive normalization, strict episodic confirmation, and snapshotted opening contracts.
2. **[DIRECT EVIDENCE]** Explicit state-collision histories prove that historical candidate age, area, count, and open-time contract can change decisions under a common suffix. The candidate state is semantically real even if its named booleans are redundant.
3. **[DIRECT EVIDENCE]** Fixed-window robust preprocessing can reject isolated raw amplitude behavior that a scalar mean-shift accumulator treats differently; canonical code is bounded and causal.
4. **[DIRECT EVIDENCE]** The repository has unusually strong negative-result preservation, first-event accounting, seal/checkpoint integrity, and exact Python/C replay evidence.
5. **[STRONG INFERENCE]** The full construction could provide useful robustness on non-Gaussian impulses, scale drift, or structural transient domains not represented by the audited startup-shift bank.

**[STRONG INFERENCE]** The best counterclaim is not "new detector family"; it is "a carefully engineered robust front end and deterministic arbitration contract whose value may appear under the right contamination model."

## Which side has better evidence?

- **[STRONG INFERENCE]** The destructive side currently wins on algorithmic distinctiveness and demonstrated need.
- **[DIRECT EVIDENCE]** It has an independent negative normal result, ablations eliminating complex states without development loss, a near-equivalent G-only failure membership, and stronger known baselines on available development faults.
- **[DIRECT EVIDENCE]** The counterargument has implementation-quality and semantic-state evidence, but no untouched cross-domain operating result.
- **[UNKNOWN]** Fresh, preregistered normal and steady-state fault campaigns could change this balance. Until then, novelty and added-value claims are unsupported.
