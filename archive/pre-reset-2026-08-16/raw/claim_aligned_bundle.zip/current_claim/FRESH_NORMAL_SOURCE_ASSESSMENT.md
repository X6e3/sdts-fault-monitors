# Fresh-normal source assessment: locked Phase 2 stop

Assessment time: `2026-08-14T14:31:37Z`

## Decision

**[DIRECT EVIDENCE] Phase 2 stopped. Freshness was not established.** No new
normal values were generated or read, the locked detector was not applied to a
new bank, and `FaultyTesting` was not opened. The retained classification is:

**D. INCONCLUSIVE — FRESH DATA REQUIRED**

This is not a locked-normal PASS or FAIL. The gate was not executed, so `K`,
`p_hat`, and the one-sided exact-binomial upper bound do not exist.

## Phase 1 freeze evidence

| Check | Observed result |
|---|---|
| Branch | `research/dmreda-finalization-v3` |
| Pre-pass HEAD | `8c375fb8d83a8dc292b2f7b761c07fed50df83a5` |
| Candidate configuration SHA-256 | `4463e0e5252741b51ba85c22ce78b4e8ccd92bf111a0fd2452c8c7128c6acf9c` |
| `current_claim/SHA256SUMS` before this assessment | 27/27 entries verified |
| Full test suite before source assessment | 240 tests, `OK` |
| Python/C parity evidence | Claim-grade false; exact agreement on 250,000 normal-training, 200,000 faulty-training, and 480,000 spent normal-testing samples, plus 1,488 golden and 108,304 randomized replay samples |
| Worktree before source assessment | Clean |

**[DIRECT EVIDENCE]** The required protocol, algorithm, claims, provenance,
reproducibility, and finalization handoff documents were reread before source
inventory. No detector source or parameter was changed. The detector remains
frozen at the configuration hash above.

## Source inventory performed without value access

### Rieth V1 release

**[DIRECT EVIDENCE]** Repository provenance records bind the Rieth V1 release to
four RData banks. `FaultFreeTraining` is spent development data,
`FaultFreeTesting` is spent validation data, and both faulty banks have the
roles recorded in `DATA_PROVENANCE_AUDIT.md`. The release inventory and the
repository contain no exact Rieth V1 simulator, generation wrapper, RNG seed
list, or source-to-release build record. The release exposes
`simulationRun=1..500` identities but not the corresponding RNG states.

No RData or CSV payload was deserialized during this assessment.

### MIT/Braatz predecessor archive

The only locally available process simulator candidate was inspected as source
text only:

| Object | SHA-256 |
|---|---|
| `TE_process.zip` | `3ae9d9578cd0883ed81ee3c2b911f85e57e367016e08bd5f1bde963694e4c111` |
| `TE_process/temain_mod.f.txt` | `31b83c17f8d52332d6f6fe46d9da3ee7131de2d018bb83945453350bf635c8b6` |
| `TE_process/teprob.f.txt` | `409975e070780a3b197d37125dddeca64e46c11d8c99028528a56a1f238d45e3` |
| `TE_process/readme.txt` | `db068740d80b6f4883d9ef1e1e526b41accd9ac7421b1b11bb2a147bb171d7ee` |

**[DIRECT EVIDENCE]** A streaming SHA-256 check of the official MIT URL on the
assessment date produced the same `TE_process.zip` hash as the local archive.
This establishes archive identity, not identity with the Rieth V1 generator.

Source inspection established all of the following:

- `temain_mod.f.txt` uses one-second fixed integration and records output every
  180 seconds.
- Its distributed main program sets all disturbance flags to zero and then
  enables `IDV(12)=1` after `SSPTS = 3600 * 8`; as distributed, it is not a
  500-sample fault-free campaign generator.
- Its instructions require changing scalar `G` in `teprob.f.txt` for each run.
- `teprob.f.txt` initializes `G=4651207995.D0` and advances it as
  `G = DMOD(G * 9228907.D0, 4294967296.D0)`.
- The source comments enumerate seeds for the old single training/testing
  files. They do not enumerate the RNG states used for Rieth V1's 500-run
  partitions.

No `.dat` member of this archive was read.

### Other sources

**[DIRECT EVIDENCE]** A name-based inventory of the DMREDA working directories
and relevant Codex workspaces found no other TEP simulator/generator source.
No mounted acquisition volume, frozen physical acquisition campaign, MATLAB,
Octave, or installed TEP-specific R package was available. Generic NumPy test
fixtures and the repository's detector-oriented synthetic signal utilities are
not TEP process generators and were not admitted as fresh evidence.

## Why the predecessor simulator was not admitted to this gate

**[DIRECT EVIDENCE]** The task requires the new seed identities to be disjoint
from every development/spent seed. The actual Rieth V1 RNG states are
unavailable. Therefore numerical RNG-stream disjointness cannot be checked or
proved.

**[STRONG INFERENCE]** Giving a new wrapper a new file hash or qualifying its
seed names with a new namespace would provide new provenance labels, but it
would not prove that its underlying LCG streams do not collide with or replay a
spent Rieth trajectory. Treating those labels as proof of statistical
independence would manufacture freshness.

**[STRONG INFERENCE]** The predecessor source could support a separately
preregistered cross-simulator transfer experiment after its fault-free wrapper,
compiler behavior, sampling/extraction order, and seed partition are validated.
The repository evidence does not establish that such an experiment is the same
target population as the locked Rieth-domain normal admission gate.

**[UNKNOWN]** Whether Rieth V1 used this exact source revision, its RNG, its
fixed-step/output ordering, or any of its commented seeds is not recoverable
from the available release evidence.

Because the required disjointness and source-to-population authority are
unavailable, the provenance is ambiguous. The non-negotiable stop rule applies.

## Exact evidence required to resume

One of the following must exist before another locked attempt:

1. **Exact Rieth-lineage simulation authority:** the simulator and 500-run
   generation wrapper used for Rieth V1, immutable source/version hashes, the
   complete RNG identities for every spent development/validation trajectory,
   and a preregistered list of 1,000 RNG identities proven disjoint from them.
   The normal-only configuration, initial condition, integration method,
   controller, 180-second sampling order, `xmeas_7` extraction, and 500-sample
   trajectory boundary must be frozen before any new value is generated.
2. **A separately authoritative independent simulator:** an already validated
   process model and normal operating regime with explicit RNG algorithm,
   versioned stream/key semantics, source/configuration hashes, and a
   non-overlap proof against every previously used stream. Its relationship to
   the detector's intended deployment population and the frozen affine input
   contract must be justified before value access; it cannot be selected after
   observing detector behavior.
3. **Post-freeze physical/process acquisition:** 1,000 independent normal
   recordings of exactly 500 samples under a frozen protocol that binds sensor
   identity/calibration, sample rate, operating regime, initial/reset state,
   recording identities, timing, exclusions, extraction, environment, and raw
   hashes. No recording may have been inspected or used during development.

After one source satisfies these conditions, the source, protocol, complete
seed/identity manifest, environment, and extraction procedure must be committed
before generation or value access. The same frozen candidate then receives one
locked gate attempt. No alternate bank or replacement seed is permitted after
that attempt begins.

## Sealed non-results

- Fresh source established: `false`
- New normal bank generated: `false`
- Locked normal gate executed: `false`
- `K/1000`: unavailable
- Exact one-sided binomial upper bound: unavailable
- Admission: not evaluated
- `FaultyTesting` opened: `false`
- Locked fault evaluation executed: `false`
- Final classification: `D. INCONCLUSIVE — FRESH DATA REQUIRED`

## Post-assessment verification

- `git diff --check`: passed
- Updated `current_claim/SHA256SUMS`: 29/29 entries verified
- Full repository suite: 240 tests in 6.267 seconds, `OK`
- Detector source/configuration files changed: none
