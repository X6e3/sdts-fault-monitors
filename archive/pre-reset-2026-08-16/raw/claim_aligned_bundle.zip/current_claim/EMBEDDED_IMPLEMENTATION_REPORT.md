# Embedded Implementation Report

## Established implementation properties

- **[DIRECT EVIDENCE]** `core/dmreda_minimal_streaming.c` compiles under Apple clang 17 with `-std=c99 -pedantic-errors -Wall -Wextra -Werror`.
- **[DIRECT EVIDENCE]** No heap allocation, recursion, OS call, thread, or variable-size persistent buffer is used.
- **[DIRECT EVIDENCE]** Persistent state is 232 bytes and checkpoint state is 240 bytes on the measured arm64 Darwin ABI.
- **[DIRECT EVIDENCE]** The `-Os` object measurement is 2,345 bytes total (`0x929`): 2,089 bytes `__TEXT` and 256 other bytes.
- **[DIRECT EVIDENCE]** Compiler-reported static stack use is 432 bytes for `dmreda_minimal_step`, 32 bytes for checkpoint export/import, and zero for the small query/reset helpers on this host build.
- **[DIRECT EVIDENCE]** Configuration is exposed by a fixed SHA-256 string and Python/C agree on it at runtime.

## Timing and storage bounds

- **[DIRECT EVIDENCE]** Rolling buffers have fixed widths 7 and 16. Median computation performs bounded insertion sort over at most seven binary64 values.
- **[STRONG INFERENCE]** Host source has a constant per-sample upper operation count independent of stream length.
- **[UNKNOWN]** No target-cycle WCET, interrupt latency, cache effect, bus contention, jitter, or energy measurement exists. Host static stack output is not an MCU stack proof.

## Numeric and API behavior

- **[DIRECT EVIDENCE]** Input must be finite with absolute value no greater than `DBL_MAX/64`; invalid input returns before state mutation.
- **[DIRECT EVIDENCE]** Residual running-sum cancellation is clamped to zero in both languages. The regression history `[0,.15,.3]+[.3]*40` establishes the drained-window boundary.
- **[DIRECT EVIDENCE]** Normalized deviation is bounded without forming an overflowing raw ratio when it is outside `[-5,5]`.
- **[DIRECT EVIDENCE]** C step computes a full local next-state copy and commits only after all state/output checks pass.
- **[DIRECT EVIDENCE]** Checkpoints are magic/version bound in C and schema/configuration-hash bound in Python.
- **[UNKNOWN]** Checkpoint structs are not a portable serialized wire format; padding, endianness, ABI, integrity code, and atomic nonvolatile persistence are unspecified.

## MCU readiness gaps

- **[UNKNOWN]** Target MCU, FPU mode, compiler flags, flush-to-zero behavior, double precision cost, alignment, DMA/cache ownership, sampling deadline, watchdog budget, and reset persistence are unspecified.
- **[UNKNOWN]** Fixed-point or float32 equivalence has not been analyzed; threshold behavior near strict inequalities may change.
- **[UNKNOWN]** There is no sensor front-end, timestamp contract, missed-sample policy, saturation policy, or corrupt-checkpoint recovery protocol.
- **[STRONG INFERENCE]** This is a bounded C reference suitable for target-port feasibility work, not production firmware.

## Required next embedded pass

1. **[UNKNOWN]** Freeze target, sample rate, deadline, compiler, floating-point mode, and maximum physical input.
2. **[UNKNOWN]** Define a byte-level checkpoint format with endianness, CRC/MAC as appropriate, monotonic sequence, and atomic storage ownership.
3. **[UNKNOWN]** Measure WCET/jitter/energy under realistic interrupt and memory contention.
4. **[UNKNOWN]** Replay golden and boundary vectors on target and compare event indices and intermediate states.
5. **[UNKNOWN]** Fault-inject NaN/Inf, sample loss, timestamp discontinuity, brownout, torn checkpoint, and ring-index corruption.
