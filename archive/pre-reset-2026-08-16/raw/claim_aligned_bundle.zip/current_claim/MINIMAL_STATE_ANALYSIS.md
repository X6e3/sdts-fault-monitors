# Minimal State Analysis

## Historical authority semantics

- **[DIRECT EVIDENCE]** For a supplied feature history `(D_t,G_t)`, regime/profile history, and warm-up enable signal, `../experimental/finalization/minimal_state_model.py` reproduces the historical public `pending` and `confirmed` traces in the tested modes.
- **[DIRECT EVIDENCE]** A sufficient authority state is `(ell, A, C, Q, R)`: pending age `ell`, positive excess area `A`, qualifying count `C`, snapshotted open contract `Q=(L,theta_D2,theta_A,N_min,refractory)`, and refractory remainder `R`.
- **[DIRECT EVIDENCE]** `ell=0` means inactive; `ell>0` means pending. Therefore `pending_active` is derived as `ell>0`, and at current index `t`, `pending_start=t-ell+1`. Separate stored fields for these values carry no additional information.
- **[DIRECT EVIDENCE]** For single-first-authority evaluation, `R` is irrelevant after confirmation because evaluation stops. For complete multi-event semantics it is required.
- **[STRONG INFERENCE]** This is an implementation-state reduction and a tested bisimulation over the supplied representation traces, not a proof of globally minimal state over all numeric encodings.

## Concrete histories forcing additional state

### Qualifying count cannot be removed

- **[DIRECT EVIDENCE]** Use contract `L=4`, `theta_D2=1`, `theta_A=1`, `N_min=3`. Histories `[1.6,0.5]` and `[1.3,1.3]` collide at `ell=2, A=0.6` but have `C=1` and `C=2`. Under common next sample `D=1.5`, the second confirms with `C=3`; the first remains pending with `C=2`.
- **[STRONG INFERENCE]** Any exact representation that retains only age and area merges states with different future decisions.

### Pending age cannot be removed

- **[DIRECT EVIDENCE]** Use `L=3`, `theta_D2=1`, `theta_A=1`, `N_min=2`. States `(ell=2,A=.2,C=1)` and `(ell=1,A=.2,C=1)` receive common suffix `[.5,2.0]`. The older state times out before the final sample and merely reopens; the younger state confirms.
- **[STRONG INFERENCE]** Area and count alone cannot preserve timeout semantics.

### Snapshotted open contract cannot be replaced by current profile

- **[DIRECT EVIDENCE]** Two reachable prefixes can collide at `ell=5,A=1.7,C=5` while carrying state-0 contract `(20,.20,1.8,6)` or state-1 contract `(28,.28,2.6,8)`. With common next `D=.5`, the first confirms and the second does not.
- **[STRONG INFERENCE]** If profile/regime changes during a candidate, exact historical semantics require the contract captured at opening or an equivalent sufficient encoding.

### Refractory cannot be removed for repeated events

- **[DIRECT EVIDENCE]** Inactive states with identical `(ell=0,A=0,C=0)` but `R=0` and `R=2` respond differently to a common threshold-exceeding next sample: only `R=0` may open.

## Current finalization candidate

- **[DIRECT EVIDENCE]** Variant H has no historical candidate episode. Its authority state is only consecutive count `q in {0,...,5}` plus refractory remainder `R in {0,...,80}` and the warm-up/sample index.
- **[DIRECT EVIDENCE]** Its representation still requires rolling input/residual rings and EWMA state; authority-state minimality must not be confused with full streaming-state minimality.
- **[STRONG INFERENCE]** The explicit historical candidate abstraction did carry information because area, count, age, and opening-time contract can force different suffix behavior. The separate boolean/name-level abstraction did not: its semantics reduce to numeric sufficient state.
- **[UNKNOWN]** A bit-minimal automaton after quantizing all numeric state is not established.
