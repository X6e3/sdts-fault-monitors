# Classical Reduction Checks

## Conclusion

DMREDA is a composition of known signal-processing and sequential-decision
primitives plus an explicit representation/authority contract. Its individual
recurrences are not new on repository evidence. The historical authority is
not exactly Page CUSUM, EWMA, SPRT, or a consecutive run rule. H, however, is
well described as a robust residual front end followed by an EWMA-normalized
six-run rule and dead time.

## Primitive-by-primitive reduction

| DMREDA element | Standard reduction | Exactness / difference |
|---|---|---|
| trailing median | causal finite-window rank filter | exact |
| `e=|x-median|` | unsigned robust residual magnitude | exact; loses sign |
| `E=sum trailing e` | finite moving L1 sum | exact; not squared energy |
| `B=beta E+(1-beta)B_prev` | EWMA / first-order leaky integrator | exact |
| `D=clip((E-Bsafe)/Bsafe)` | clipped relative residual of current mass to EWMA context | exact; not standardized likelihood |
| `G` | EWMA of a finite-lag difference of `D` | exact |
| candidate `A` | finite-episode sum of positive excess | CUSUM-like accumulation, but not Page's max/reset recursion |
| candidate `C` | within-residence exceedance count | not necessarily consecutive |
| `ell`/timeout | timed residence guard | deterministic bounded counter |
| confirmation/refractory | hysteretic/debounce event gate with dead time | exact behavioral description |
| regime controller | ticked hysteretic gain/window scheduling FSM | exact behavioral description |
| H authority | six consecutive `D>0.8`, then 80-sample dead time | exact run-rule description |

For fixed lag `m` and zero initial conditions, the growth filter has transfer
relation:

```text
G(z) = lambda * (1-z^-m) / (1-(1-lambda)z^-1) * D(z)
```

It is therefore a conventional FIR difference followed by a first-order IIR
smoother.

## Page CUSUM

Page's cumulative scheme uses a recursively reset statistic, commonly written
`W_t=max(0,W_(t-1)+s_t-k)`, and signals when `W_t` crosses a boundary. The
historical candidate area accumulates `max(0,D-theta_D2)` only inside an
episode opened by a separate fast trigger; it also requires a qualifying count,
times out, snapshots its contract, and enters refractory. It is structurally
CUSUM-like but not algebraically Page CUSUM. Primary source:
[Page (1954)](https://doi.org/10.1093/biomet/41.1-2.100).

## EWMA

`B`, `r`, `a_slow`, and the smoothing stage of `G` are first-order exponentially
weighted recurrences. Renaming them does not create a new primitive. Primary
source: [Roberts (1959)](https://doi.org/10.1080/00401706.1959.10489860).

## SPRT

No Core coordinate is a log-likelihood ratio; no pair of probabilistic
hypotheses is specified; and no Wald error-bound interpretation follows from
the thresholds. The architecture is therefore not an SPRT. Primary source:
[Wald and Wolfowitz (1948)](https://doi.org/10.1214/aoms/1177730197).

## Run rules and hysteresis

H is exactly a fixed-length consecutive run rule over `D`, followed by dead
time. The historical Core count is weaker/different: qualifying samples may be
separated by nonqualifying samples while the candidate remains resident.
Classical run-rule context includes the
[Western Electric handbook](https://books.google.com/books?id=yx1pqn_aMLkC)
and [Nelson (1984)](https://doi.org/10.1080/00224065.1984.11978921).

## Timed/hybrid monitor interpretation

The finite discrete control, clocks/counters, guards, and reset ordering fit a
timed-monitor interpretation; the real-valued area makes the mathematical
authority a bounded-register/hybrid automaton rather than a small pure FSM.
Relevant foundations include
[Alur and Dill's timed automata](https://doi.org/10.1016/0304-3975(94)90010-8),
[LOLA bounded online monitors](https://theory.stanford.edu/~sipma/papers/time05.html),
and [TeSSLa](https://arxiv.org/abs/1808.10717).

## Strongest destructive reduction argument

The strongest case that DMREDA is an overcomplicated known sequential detector
is mechanical: median residual + moving L1 sum + several EWMAs + thresholded
episode accumulation + counters + hysteresis/dead time. No learned model,
likelihood derivation, new estimator, or detector-superiority result has been
established. H makes the reduction especially stark.

## Strongest counterargument

The claim-bearing object is not only its alarm statistic. The repository
defines and tests a directional separation between temporal representation and
external authority, and exact collision witnesses show that current magnitude,
current `D/G`, and smaller candidate aggregates are not enough to preserve the
specified future semantics. The exact-multiset campaign shows that `B/D/G`
preserves order that current `e/E` discards. This is a legitimate structural
object even if every primitive is known.

## Evidence balance

The reduction argument is stronger against **algorithmic novelty** and detector
superiority. The counterargument is stronger against the claim that the entire
project is merely one scalar detector: the tested representation and authority
semantics contain demonstrable state distinctions. Current evidence therefore
supports a known-combination structural/methodological contribution, not a new
sequential-detection principle.
