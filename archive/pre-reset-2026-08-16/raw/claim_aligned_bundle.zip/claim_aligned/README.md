# Claim-Aligned Validation

This directory contains the independent structural/semantic validation pass
branched from finalization checkpoint
`5b43516c7e63c015f7774b790c461b349f5b1d90`.

Historical, finalization, and sealed real-data artifacts outside this directory
are inputs and are not rewritten. `results/` is reserved for outputs generated
only after the protocol, seed manifest, generator, initial claim matrix, and
architecture model are committed.

FaultyTesting is out of scope and remains sealed.
