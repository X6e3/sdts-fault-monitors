# Literature Positioning V2

## Search boundary

This is a focused mechanism-level comparison against primary sources, performed
after reconstructing and testing the architecture. It is not a systematic
review, patent search, citation-network review, or proof of novelty. Absence of
an exact match in this focused set cannot establish novelty.

## Mechanism comparison

### Sequential statistics

Page's cumulative sum is a recursively reset evidence statistic for change
detection. DMREDA's candidate area resembles positive score accumulation, but
it is opened by a separate guard, has finite residence, also requires a count,
snapshots a contract, and enters refractory. It is a known-primitives variant,
not an exact Page recursion. Source:
[Page, “Continuous Inspection Schemes,” 1954](https://doi.org/10.1093/biomet/41.1-2.100).

Roberts' geometric moving average is the relevant prior primitive for `B`,
`r`, `a_slow`, and the smoother within `G`. Those coordinates are EWMAs/leaky
integrators under different inputs and time constants. Source:
[Roberts, “Control Chart Tests Based on Geometric Moving Averages,” 1959](https://doi.org/10.1080/00401706.1959.10489860).

Wald's sequential probability ratio framework requires specified likelihoods
or likelihood-ratio increments and interpretable decision boundaries. DMREDA
has neither; calling it SPRT would be false. Source:
[Wald and Wolfowitz, 1948](https://doi.org/10.1214/aoms/1177730197).

Run rules are established control-chart machinery. H is exactly a six-sample
consecutive run rule over normalized evidence plus dead time. The historical
candidate count is not consecutive, but threshold/exceedance count logic is
still not novel by naming. Sources:
[Western Electric, 1956](https://books.google.com/books?id=yx1pqn_aMLkC) and
[Nelson, 1984](https://doi.org/10.1080/00224065.1984.11978921).

### Temporal representation

The general proposition that temporal ordering carries information not present
in marginal magnitude statistics is established outside DMREDA. Ordinal-pattern
methods explicitly encode ordering, while scattering representations separate
structure across scales and orders. DMREDA's result is therefore evidence that
its particular low-cost recurrence preserves some order, not discovery of the
general principle. Sources:
[Bandt and Pompe, 2002](https://doi.org/10.1103/PhysRevLett.88.174102) and
[Mallat, 2012](https://arxiv.org/abs/1101.2286).

Robust causal residualization with running medians, finite-window accumulation,
EWMA normalization, lag differences, and hysteresis are individually standard
signal-processing/control ideas. This pass found no primary source showing the
exact same parameterized composition and opening-contract semantics, but the
search is not broad enough to turn that absence into novelty.

### Transient, nuisance, and diagnostic change

Sequential-change literature distinguishes persistent, transient/intermittent,
and nuisance changes and treats diagnosis as different from simple alarm
generation. These bodies of work are closer controls for future claims than
generic detector leaderboards. Sources include the change-detection monograph
by [Basseville and Nikiforov](https://web.mit.edu/fustflum/documents/papers/basseville.pdf),
[Lau and Tay on nuisance changes](https://arxiv.org/abs/1902.03460),
[Tartakovsky et al. on transient signals](https://arxiv.org/abs/2102.01310),
[Sokolov et al. on intermittent signals](https://arxiv.org/abs/2210.17342),
and [Nikiforov on sequential diagnosis](https://doi.org/10.1080/07474946.2016.1206354).

DMREDA has not yet shown that its representation is sufficient for diagnosis,
nuisance rejection, or transient-change optimality.

### Automata and bounded online monitoring

Timed automata formalize finite control plus clock guards and resets; runtime
monitoring work formalizes causal stream monitors with bounded-memory
conditions. DMREDA's representation/authority split and explicit collision
precedence fit naturally in that vocabulary. This is a useful semantic
formulation, not evidence that bounded online monitoring itself is new.
Sources:

- [Alur and Dill, timed automata](https://doi.org/10.1016/0304-3975(94)90010-8);
- [Maler and Nickovic, metric temporal logic monitoring](https://doi.org/10.1016/j.entcs.2004.01.029);
- [D'Angelo et al., LOLA](https://theory.stanford.edu/~sipma/papers/time05.html);
- [Convent et al., TeSSLa](https://arxiv.org/abs/1808.10717);
- [Reinbacher et al., runtime verification for embedded systems](https://doi.org/10.1007/s10703-013-0199-z).

## Claim classification

| Claim/mechanism | Literature status | Repository evidence | Classification |
|---|---|---|---|
| causal trailing median residual | long-known robust causal filtering idea | implemented and tested | KNOWN |
| finite moving L1 residual mass | standard finite-window statistic | implemented; historically mislabeled energy | KNOWN |
| EWMA baseline/activity/growth smoothing | classical geometric moving average | exact recurrence reduction | KNOWN |
| finite-lag difference followed by EWMA | standard FIR/IIR composition | exact transfer relation | KNOWN |
| threshold/run/dead-time H authority | established run-rule/debounce construction | exact H semantics | KNOWN |
| episodic excess area + count + timeout | combination of accumulation and timed gates | exact authority tests | KNOWN COMBINATION |
| opening-time contract snapshot | deterministic transaction/configuration semantics | collision establishes aggregate necessity | ENGINEERING CONTRIBUTION |
| representation independent of authority | common monitor-architecture principle | source/test invariant | DISTINCT SEMANTIC FORMULATION within this project |
| exact bounded authority quotient `(ell,A,C,Q,R)` | bounded-register monitor model | bounded equivalence + collisions | ENGINEERING / METHODOLOGICAL CONTRIBUTION |
| matched-order `D/G` separation | scoped empirical property of this recurrence | preregistered held-out campaign | POTENTIALLY DISTINCT EMPIRICAL RESULT; not novelty proof |
| globally minimal state | not established | bounded search only | NOVELTY NOT ESTABLISHED |
| detector superiority/optimality | classical fields have mature guarantees/benchmarks | no fresh positive evidence | NOVELTY NOT ESTABLISHED |
| full architecture novelty | exact prior-art landscape not exhaustively searched | no systematic/patent review | NOVELTY NOT ESTABLISHED |

## Research position

The defensible contribution is not a new EWMA, CUSUM, run rule, or proof of
sequential optimality. It is an engineering-validated structural formulation:
a robust causal representation recurrence, explicit bounded temporal state,
and a separately specified authority monitor with collision-tested state
necessity and boundary semantics. The matched-order experiment supplies scoped
scientific support that the representation retains information current
magnitude summaries discard.

That can support a methodological paper if framed around formal contracts,
counterexamples, and reproducible structural experiments. It does not support
an algorithmic novelty or best-detector claim.

## What novelty work remains

Before using “novel,” conduct a systematic database and patent search with
forward/backward citation chaining around robust sequential residual monitors,
finite-memory transient detectors, episode accumulators, timed runtime
monitors, and diagnosis representations. State a precise contribution theorem
or experimentally falsifiable distinction, then compare against the closest
compositions—not only scalar CUSUM/EWMA baselines.
