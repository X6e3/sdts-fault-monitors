# A Bounded Causal Temporal Representation with Separate Event Authority:
# Claim-Aligned Evaluation of DMREDA

## Paper status

Candidate methodological manuscript, not submission-ready. It intentionally
does not claim novelty, detector superiority, real-process generalization, or
global state minimality. Those claims remain unsupported.

## Abstract

Streaming event systems often conflate signal representation with the policy
that emits an alarm. We study a deterministic scalar-stream architecture that
first maps a causal robust residual into finite-window and leaky temporal
evidence, then converts that evidence into bounded event authority through a
separate timed register automaton. The representation combines a trailing
median, absolute residual, finite-window L1 mass, an exponentially weighted
context, normalized deviation, and a smoothed finite-lag difference. The
authority layer maintains candidate age, accumulated positive excess,
qualifying count, an opening-time contract, and refractory state.

We evaluate structural rather than detector-superiority claims. In a
preregistered post-residual campaign, six temporal families per seed had the
same residual multiset, duration, peak, RMS, squared energy, current residual,
and final residual window. Current residual and current window mass were at
six-class chance, while normalized deviation achieved 0.543 held-out accuracy
and deviation plus lagged growth achieved 0.755. Exact common-suffix witnesses
show that current median, current rolling sum, current `(D,G)`, and reduced
candidate aggregates cannot reproduce all future semantics. A reduced
authority model matched 1,176 bounded-exhaustive transitions. Adversarial tests
also expose sign blindness, loss of persistent level after median adaptation,
context dependence, and non-monotonic benefit of richer readouts.

The result supports a scoped structural/methodological claim: known streaming
primitives can be composed into an explicitly bounded representation and
authority contract that preserves some temporal-order information beyond
matched current magnitude. It does not establish a new sequential statistic,
detector superiority, or real-process efficacy.

## 1. Research question

The central question is not whether the architecture beats CUSUM or EWMA on a
single benchmark. It is whether temporal evidence and external authority can be
specified as separate causal transitions, whether their state is bounded, and
which stored distinctions are required to preserve the intended behavior.

We test five propositions:

1. prefix-equivalent inputs yield prefix-equivalent representation and
   authority;
2. a fixed-size recurrence realizes the claimed stream behavior;
3. temporal order can survive when current magnitude statistics collide;
4. event authority can be described by a bounded, deterministic transition
   with explicit precedence;
5. proposed state reductions must survive a common-future equivalence test.

## 2. Related mechanisms

The component mechanisms are established. Exponential smoothing follows the
geometric moving-average lineage of
[Roberts (1959)](https://doi.org/10.1080/00401706.1959.10489860). Positive
episode accumulation is related to, but not algebraically identical with,
[Page CUSUM](https://doi.org/10.1093/biomet/41.1-2.100). The system is not an
SPRT because it does not form a likelihood ratio or inherit Wald error
guarantees ([Wald and Wolfowitz, 1948](https://doi.org/10.1214/aoms/1177730197)).
Consecutive exceedance logic, as used in the reduced H detector, belongs to the
run-rule/control-chart tradition
([Nelson, 1984](https://doi.org/10.1080/00224065.1984.11978921)).

The general value of temporal order is also known from representations such as
ordinal patterns
([Bandt and Pompe, 2002](https://doi.org/10.1103/PhysRevLett.88.174102)) and
multiscale scattering
([Mallat, 2012](https://arxiv.org/abs/1101.2286)). Bounded online monitor and
timed-automaton theory provide the appropriate semantic vocabulary
([Alur and Dill, 1994](https://doi.org/10.1016/0304-3975(94)90010-8);
[LOLA](https://theory.stanford.edu/~sipma/papers/time05.html);
[TeSSLa](https://arxiv.org/abs/1808.10717)). Our focused comparison does not
establish that the composition is absent from prior art.

## 3. Architecture

For a scaled scalar sample `x_t`, define a trailing median `mu_t`, unsigned
residual `e_t=|x_t-mu_t|`, finite-window L1 mass `E_t`, and EWMA context `B_t`.
The normalized deviation is

```text
D_t = clip((E_t-max(B_t,floor))/max(B_t,floor), -5, 5).
```

For selected lag `m`, growth is

```text
G_t = lambda(D_t-D_(t-m)) + (1-lambda)G_(t-1).
```

Additional leaky activity and hysteretic regime state may select future window,
lag, and authority contracts. The representation is computed independently of
authority state.

The authority state is `(ell,A,C,Q_open,R)`: candidate age, positive excess
area, qualifying count, opening-time contract, and refractory remainder.
Confirmation requires strict area and inclusive count conditions before the
inclusive timeout test. A timeout can re-arm on the same sample. Confirmation
is a one-sample impulse.

## 4. Methods

### 4.1 Pre-registration

Generator equations, seed ranges, matching constraints, readout locations,
metrics, and falsification cases were committed before result generation. We
used 128 training and 128 disjoint test seeds with PCG64, and 2,000 paired
seed-block bootstrap replicates.

### 4.2 Matched residual-order families

Six 96-sample residual sequences were permutations of one shared multiset:
coherent ramp, incoherent order, pulse, plateau, alternating extremes, and
blockwise migration. A shared final 16-sample tail forced current residual and
current residual-window mass to collide. Peak, total L1 mass, RMS, squared
energy, duration, and sorted residuals were also matched.

We compared current residual (`R0`), current residual mass (`R1`), normalized
deviation (`R2`), deviation plus growth (`R3`), and a broader fixed-profile
vector (`R4`). Nearest-centroid held-out accuracy, Fisher trace ratio,
collisions, confusion matrices, and paired bootstrap uncertainty were reported.

### 4.3 State collision tests

For a proposed reduced state, we sought two histories mapping to the same
reduced state and appended a common future suffix. Differing future relevant
outputs refute equivalence. We also compared a literal authority transition
with a reduced transition over reachable states to depth 8 and a frozen
24-symbol alphabet.

### 4.4 Adversarial cases

We included sign reflection, persistent steps, baseline migration, unmatched
raw equal-RMS shapes, near-threshold authority histories, timeout/confirmation
coincidence, same-sample re-arm, and refractory boundaries.

## 5. Results

All 256 matched seed blocks satisfied the residual contract. At the frozen
readout, `R0` and `R1` were at chance 0.1667. `R2` achieved 0.5430 (95% paired
bootstrap interval 0.5039–0.5807), `R3` achieved 0.7552 (0.7344–0.7747), and
`R4` achieved 0.7930 (0.7786–0.8073). The `R3-R2` accuracy change was 0.2122
(0.1823–0.2435).

The representation was not complete: ramp and slow migration were strongly
confused. The raw campaign did not isolate temporal order because residual
magnitudes were unmatched, and the sign, persistent-level, and context tests
exposed important invariances and sensitivities.

Exact witnesses established the insufficiency of current median, rolling sum,
and `(D,G)` without expiration history. Authority witnesses separately
established the need for age, area, count, aggregate opening contract, and
refractory under the declared semantics. The reduced authority transition
matched 1,176 tested transitions with no mismatch.

The reduced H implementation preserved the fixed front end through `D` within
`7.33e-14` on 192 raw traces, but 152 event-index sequences differed and H has
no `G` or episodic candidate representation. It is not structurally equivalent.

## 6. Embedded realization

Fixed C subsets have compile-time rings and no heap. The H implementation
compiled under strict C99 and matched Python exactly on 1,039,792 exposed
sample rows. On arm64 Darwin its state was 232 bytes and statically reported
step stack was 432 bytes. These are host results; full adaptive C parity and
target WCET/jitter are unavailable.

Checkpoint validation does not currently verify residual-ring/sum consistency.
An inconsistent accepted checkpoint can cause a mathematical sum of -100 to be
silently clamped to zero. This is an engineering limitation, not a change to
the historical experimental result.

## 7. Real-data boundary

The historical normal admission failed: 42/500 trajectories produced authority
by horizon 960 against a limit of 25. No provenance-clean fresh Rieth-lineage
normal source was available for the later locked gate, and FaultyTesting
remained sealed. Detector superiority and real-process generalization are
therefore unknown positive claims.

## 8. Discussion

The positive result is narrower and more defensible than a generic detector
claim. The architecture provides an observable temporal representation and a
separate event contract; its state distinctions can be attacked directly with
collisions. This makes implementation and review more auditable.

The negative interpretation is equally important. Every primitive is familiar,
and the architecture's complexity is not justified merely by its name. Regime
adaptation has not shown independent value, the representation discards sign
and persistent level, and no optimality or external-validity result exists.
Consequently, the current contribution is structural/methodological and
engineering-oriented.

## 9. Limitations and next work

The primary matched experiment operates at the residual layer; a stronger test
must generate raw histories whose post-median residual statistics are also
matched. The state quotient requires symbolic or machine-checked all-suffix
analysis. A systematic prior-art and patent review is needed before novelty
language. A full adaptive no-heap C implementation and MCU timing measurements
are absent. Any detector claim requires a new provenance-clean normal gate
before fault evaluation.

## 10. Conclusion

The evidence supports a research-backed bounded structural representation and
authority architecture. It does not support a new sequential-detection
algorithm, detector superiority, real-process generalization, or novelty. The
appropriate present classification is R3, with R4 contingent on stronger
formal equivalence, end-to-end matched-order replication, and systematic
closest-prior-art positioning.
