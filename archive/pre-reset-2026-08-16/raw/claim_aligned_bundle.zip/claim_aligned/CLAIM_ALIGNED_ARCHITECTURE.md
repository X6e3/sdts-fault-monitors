# Claim-Aligned Architecture

Status: final claim-aligned model. The three-object decomposition was frozen
before the result; the assessment below incorporates the sealed campaign.

## Three objects, not one

DMREDA must be evaluated as three coupled but distinct objects:

```text
input/calibration contract
        |
        v
representation recurrence R  ---->  claim-bearing evidence Z_t
        |                                  |
        |                                  v
        +--------------------------> authority automaton Q
                                           |
                                           v
                              bounded external event impulse
```

Detector performance is a fourth, application-level object. It cannot validate
the meaning or necessity of representation coordinates.

## Representation map

For one already-scaled scalar sample `x_t`, fixed-width trailing sets, and
profile `p_t`:

```text
mu_t = median(x[t-w1+1:t])
e_t  = abs(x_t - mu_t)
E_t  = sum(e[t-w2+1:t])
B_t  = beta E_t + (1-beta) B_(t-1)
D_t  = clip((E_t - max(B_t, floor)) / max(B_t, floor), -5, 5)
G*_t = D_t - D_(t-m)
G_t  = lambda G*_t + (1-lambda) G_(t-1)
r_t  = rho e_t + (1-rho) r_(t-1)
```

`E` is L1 residual mass, not squared energy. `D` is a bounded, adaptive,
dimensionless deviation ratio. `G` is a leaky finite-lag difference, not a
likelihood ratio. `r`, `a=clip(abs(G)/g_ref)`, and tick-updated `a_slow` drive a
hysteretic regime machine that changes the future window/lag/confirmation
contract.

The raw-to-residual map and the residual-to-`D/G` recurrence will be tested
separately. This prevents a temporal distinction created by the trailing median
from being misattributed to `G`, and prevents an exactly matched residual
experiment from being misreported as a full raw-signal result.

## Authority automaton

Given exogenous `D_t`, `G_t`, the current profile, and the authority-enabled
guard, a sufficient historical authority state is provisionally:

```text
U_t = (ell_t, A_t, C_t, Q_open_t, R_t)
```

- `ell=0` means no candidate; otherwise it is candidate age.
- `A` is accumulated positive excess above the snapshotted secondary
  threshold.
- `C` counts qualifying samples; it is not a consecutive-run count.
- `Q_open=(L, theta_D2, theta_A, N_min, refractory)` is frozen when the
  candidate opens.
- `R` is refractory remainder.

The public `pending[t]` flag means the candidate was active at some point
during sample `t`; it is not necessarily the end-of-sample state. Confirmation
is a one-sample external authority impulse. Candidate confirmation uses strict
area inequality and inclusive timeout ordering. Timeout is processed before a
new opening test, so a timed-out candidate may re-arm on the same sample.

## Full bounded recurrence state

A bounded streaming implementation of the adaptive historical Core requires at
least the following sufficient state classes:

- ordered trailing input window sufficient for exact median expiration;
- ordered trailing residual window and its running L1 sum;
- EWMA baseline `B` and residual activity `r`;
- lag history of `D` and growth EWMA `G`;
- slow activity, regime state, tick phase, and up/down hold counters;
- warm-up phase or sample index;
- authority state `(ell,A,C,Q_open,R)`.

Current `mu`, `e`, `D`, `a`, selected lag, and selected confirmation length can
be recomputed from this state and the current sample/profile; that observation
does not establish a globally minimal encoding. Exact trailing median and
trailing-sum expiration cannot in general be recovered from only their current
scalar outputs.

## H boundary

H retains only the fixed state-0 path through `D` and replaces the authority
automaton with a consecutive-run counter and refractory. Consequently:

- H may preserve a useful subset of the representation;
- H cannot be called representation-equivalent if an admissible pair has equal
  current `D` but different claim-bearing `G` or regime evidence;
- detector noninferiority cannot merge states that differ under an admissible
  future suffix.

## Claim scopes

- Causality and determinism are semantic properties of the frozen transition.
- Bounded state and structural bounded compute are implementation/formal
  properties, not measured WCET.
- Temporal separability is an experimental property of a declared signal
  family and readout contract.
- State necessity is a behavioral-equivalence property: two states may merge
  only if every admissible future suffix produces equivalent relevant outputs.
- Detector false-authority/detection performance is an application property.
- Novelty is a literature property and is not inferred from any internal name.

## Evidence after falsification

The preregistered exact-residual-multiset campaign confirms that this
decomposition is empirically meaningful within a declared domain. Current
`e/E` collided, `D` preserved some order through the historical EWMA context,
and `D+G` preserved more at the frozen readout. Authority semantics were then
tested independently using exact input histories and boundary cases.

The architecture also has hard limits:

- absolute residualization is direction-blind;
- the median adapts to a sustained level step, so late absolute level is lost;
- normalized evidence depends strongly on preceding baseline context;
- `D+G` does not uniquely identify waveform family;
- regime adaptation has not shown independent representational benefit;
- H preserves the front end through `D`, but not the historical representation
  or authority quotient.

Accordingly, the supported object is a bounded structural
representation/authority architecture, not a universal anomaly detector and
not an established new sequential-detection statistic.
