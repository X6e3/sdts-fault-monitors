# Temporal Order Experiments

## Tested proposition

The narrow proposition was:

```text
same residual magnitudes and same current magnitude evidence
does not imply
same history-dependent representation state.
```

It was not “DMREDA classifies all waveform types” and not “DMREDA is a better
detector.”

## Direct order control

For each frozen seed, six event histories were permutations of one identical
96-value residual multiset. They also shared the final 16 values. Thus at the
event-end sample they had the same current `e`, essentially the same current
rolling `E`, the same peak, RMS, squared energy, sum, duration, and complete
residual histogram. Only the ordering of the first 80 event residuals differed.

**[DIRECTLY ESTABLISHED]** All 256 seed blocks passed those checks before any
classification metric was interpreted. The first seed's sorted event hash was
the same for every class:
`955cea50319cbe75fe7f9f430d6eea2d06b8d5d44f03c64b74c82363462ff47d`.

## Mechanism

At the readout, `E_t` sees only the common final 16 values, but

```text
B_t = beta E_t + (1-beta) B_(t-1)
D_t = clip((E_t-max(B_t,floor))/max(B_t,floor))
```

retains a leaky summary of older `E` values. `G_t` additionally retains a
finite-lag difference history and an EWMA state. The measured ranking therefore
has a concrete mechanism: current local magnitude collides, while earlier
ordering changes `B`, then `D`, and then `G`.

## Result

- `e` and `E`: chance accuracy, 0.1667.
- `D`: 0.5430, 95% paired seed-block bootstrap interval
  `[0.5039, 0.5807]`.
- `D+G`: 0.7552, interval `[0.7344, 0.7747]`.
- broader fixed evidence: 0.7930, interval `[0.7786, 0.8073]`.

The `D+G` improvement over `D` was 0.2122, with interval
`[0.1823, 0.2435]`. This is the strongest experimental evidence that a temporal
coordinate omitted by H preserves additional information under the frozen
family.

## Exact feature-history witness

For lag `m=4` and `lambda=1/8`, the two `D` histories

```text
H1 = [-1.0, 0.0, 0.0, 0.0, 0.2]
H2 = [ 0.2, 0.0, 0.0, 0.0, 0.2]
```

have the same current `D=0.2`, which is below the state-0 D-opening threshold
`0.35`. Their current smoothed growth values are `G=0.15` and `G=0.0`; only the
first exceeds `th_G=0.10`. Therefore a D-only representation cannot reproduce
the historical D-or-G opening semantics on the declared feature-history domain.

**Scope:** this is an exact recurrence-level witness. A preregistered exhaustive
search of all `4^9 = 262,144` raw histories over
`{0, 0.04, 0.08, 0.12}` found no exact raw-reachable witness with common
current raw sample and bit-identical current `D`. That negative bounded search
is not an impossibility proof; raw reachability remains **[UNKNOWN]**.

## State versus output

Even `(D_t,G_t)` is not sufficient recurrence state. Before the lag becomes
active, these histories collide at current `(D,G)=(0.2,0)`:

```text
K1 = [0.0, 0.0, 0.0, 0.2]
K2 = [1.0, 0.0, 0.0, 0.2]
```

Appending the common next `D=0.2` yields `G=0.025` and `G=-0.1`. The lag ring,
or a behaviorally equivalent encoding of its expiration information, is
necessary to continue the recurrence exactly. This witness is covered by
`test_lag_history_is_needed_beyond_current_D_and_G`.

## Destructive interpretation

The experiment also rules out stronger readings:

- It does not show that `D/G` uniquely identifies temporal form; ramp and slow
  migration remain heavily confused.
- It does not show that more temporal state always helps; in the raw campaign,
  `D+G` was worse than `D` at the late readout.
- It does not show direction. `x` and `-x` yield identical absolute-residual
  Core evidence.
- It does not show context invariance. Adaptive baseline motion materially
  changes the response to an identical injection.
- It does not show detector utility or real-process generalization.

## Status

**[EXPERIMENTALLY SUPPORTED]** Temporal order is preserved beyond matched
instantaneous/finite-window magnitude by `B/D`, and `G` contributes additional
scoped discrimination.

**[UNKNOWN]** Global necessity of `G` for all raw-signal semantics, task-level
sufficiency, and novelty.
