# Claim-Aligned Result Seals

`CLAIM_ALIGNED_RESULTS.json` is the first complete result produced from
preregistration amendment commit `60d266d`. It is preserved byte-for-byte.

- file SHA-256: `1053b748b814f319c4ad6eca2542d0d0ed6dbd282cfa7f756e2def447e3dc01f`
- canonical JSON SHA-256: `9a6b51cf4487c8d559d1d4b5f5def5127dd2ccc41aa426dd8c730c5d10469e2f`
- embedded pre-self-hash payload: `f12137dc287204bc633915f9c52a5c831c863c68efa8c733388c05488f1ef7e1`

A first `--verify-existing` attempt reported inequality because Python tuples in
the fresh in-memory payload become JSON arrays/lists after loading the saved
file. A separate canonical-JSON comparison immediately established equality
and reproduced canonical SHA-256 `9a6b51cf...`. No experiment field differed.
The first result is committed before the verifier-only repair so this chronology
cannot be rewritten.

`CLAIM_ALIGNED_RESULTS_V2.json` is the authoritative, verifier-bound result
after Amendment 002.

- file SHA-256: `1a1303cf622f8721d714a2e90694a696cce1d4478eacaece7fec5cdf7917091a`
- canonical JSON SHA-256: `ae1ad350bd0ace1e55e6020f6645d170f02a7c47adae2468170ecf01c3cc5556`
- embedded pre-self-hash payload: `29275f1130f5191599e8c525186009e94496fd21307f386969db3d79a30ce651`
- experiment subtree SHA-256: `115636658345e32ed9067a6724ef688f472d36ef6e63b16ad7faa5b9fe71351d`

The corrected `--verify-existing` path completed successfully and reproduced
canonical SHA-256 `ae1ad350...`. The complete experiment subtree is equal to V1
and has the same subtree hash; only binding/protocol chronology changed.
