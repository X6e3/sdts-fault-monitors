# History Collision Witnesses

## Standard used

A coordinate is called necessary only when two valid states collapse under a
proposed reduction and one common future suffix produces different relevant
future behavior. Dataset similarity is not enough. Unless stated otherwise,
authority witnesses operate on the historical authority transition with
exogenous `D/G` values; they do not claim raw-signal reachability.

## Representation recurrence witnesses

### Current trailing sum is insufficient

For a width-two rolling sum:

```text
history 1 = [1,0]   current sum = 1
history 2 = [0,1]   current sum = 1
common next = 0     next sums = 0 and 1
```

The expiring residual must be retained, directly or equivalently.

### Current median is insufficient

For a width-three trailing median:

```text
history 1 = [0,1,2]      current median = 1
history 2 = [1,1,100]    current median = 1
common next = 50         next medians = 2 and 50
```

The current median scalar cannot encode exact future window expiration.

### Current `(D,G)` is insufficient recurrence state

With `m=4`, `lambda=1/8`:

```text
history 1 = [0,0,0,0.2]  current (D,G) = (0.2,0)
history 2 = [1,0,0,0.2]  current (D,G) = (0.2,0)
common next D = 0.2       next G = 0.025 and -0.1
```

The D-lag expiration state is necessary. The exact calculation is a passing
unit test.

### `D` alone cannot encode historical D-or-G opening

```text
history 1 = [-1,0,0,0,0.2]   current D=0.2, G=0.15
history 2 = [0.2,0,0,0,0.2]  current D=0.2, G=0.0
```

At state-0 thresholds `th_D=0.35`, `th_G=0.10`, only history 1 opens through
`G`. This is exact in feature space. Raw reachability is not established; a
bounded `4^9` raw search found no witness.

## Authority-state witnesses

Let the sufficient candidate state be
`(ell, area, count, opening_contract, refractory)`.

### Observation only is insufficient

Two candidates receive common `(D,G)=(1.5,0)` under
`L=4, D2=1, A*=1, C*=3`. They share `ell=2, area=0.6` but have counts 1 and 2.
Only the second reaches count 3 and confirms. Current observation does not
encode candidate history.

### Area alone is insufficient: count is necessary

The same witness gives:

```text
state 1: ell=2, area=0.6, count=1
state 2: ell=2, area=0.6, count=2
common next D=1.5
outputs: not confirmed, confirmed
```

Thus `(ell,area)` cannot replace `(ell,area,count)`.

### Age and count alone are insufficient: area is necessary

Under `L=4, D2=1, A*=1, C*=2`, histories `[1.1,1.1]` and `[1.4,1.4]`
produce pending states:

```text
state 1: ell=2, count=2, area=0.2
state 2: ell=2, count=2, area=0.8
common next D=1.3
outputs: not confirmed, confirmed
```

This exact witness is exercised by
`test_candidate_area_is_necessary_given_age_and_count`.

### Area and count are insufficient: age is necessary

Under `L=3, D2=1, A*=1, C*=2`:

```text
state 1: ell=2, area=0.2, count=1
state 2: ell=1, area=0.2, count=1
common suffix D=[0.5,2.0]
outputs on final sample: reopen/no confirmation, confirmation
```

The older candidate times out before it can use the last sample; the younger
candidate remains resident and confirms.

### `(age,area,count)` is insufficient: opening contract is necessary

Two candidates collide at `(ell,area,count)=(5,1.7,5)` but retain different
opening-time contracts:

```text
Q0 = (L=20,D2=0.20,A*=1.8,C*=6,R=80)
Q1 = (L=28,D2=0.28,A*=2.6,C*=8,R=100)
common next D=0.5
outputs: confirmed, not confirmed
```

This proves the aggregate snapshotted contract is necessary while profiles can
change. It does not prove each contract field separately minimal.

### Candidate state plus contract is insufficient for multi-event behavior

Inactive states with identical `(ell,area,count,contract)=(0,0,0,None)` and
refractory values 0 and 2 receive the same D-threshold-exceeding sample. Only
the zero-refractory state opens. Refractory is additional state.

## What can be removed

- `pending_start` is not necessary when the current sample index and `ell` are
  available: `pending_start = t-ell+1`.
- An explicit persistent `pending` Boolean is redundant with `ell>0`.
- The public `pending[t]` output is a transition observation (“active at some
  point during this sample”), not end-of-sample persistent state.
- Candidate fields are zero/absent when `ell=0`; their inactive values carry no
  semantics.

The reduced model matched the literal source-shaped authority model over all
1,176 transitions reachable to depth 8 on the frozen finite alphabet, across
D-only, G-only, and D-or-G modes. This is
**[EXPERIMENTALLY SUPPORTED] tested equivalence**, not an all-real-input proof.

## Confidence boundary

- **[DIRECTLY ESTABLISHED]** Each explicit arithmetic collision above and its
  differing common-suffix output.
- **[EXPERIMENTALLY SUPPORTED]** Reduced-versus-literal equivalence on the
  declared bounded exhaustive domain.
- **[UNKNOWN]** Global behavioral minimality, bit-minimal encoding, raw
  reachability of the feature-level D/G witness, and necessity of each opening
  contract field individually.
