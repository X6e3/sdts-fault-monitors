# DMREDA Claim-Aligned Technical Report

## Executive verdict

DMREDA's recoverable primary object is a causal bounded temporal
representation followed by a separately specified bounded event-authority
monitor. It is not established as a superior anomaly detector and it is not an
established novel sequential statistic.

The claim-aligned pass found real, scoped structural content:

- exactly magnitude-matched residual histories that current `e/E` cannot
  distinguish are separable in `D` and more separable in `D+G`;
- exact common-suffix collisions establish why ordered window expiration,
  lag history, and candidate age/area/count/opening-contract/refractory state
  cannot all be removed;
- representation state is updated independently of authority state;
- the authority transition has deterministic, bounded, testable precedence.

It also found hard negative results:

- all primitives reduce to known filters, accumulators, counters, hysteresis,
  and run/dead-time logic;
- the representation loses sign and sustained absolute level and is strongly
  context-dependent;
- H preserves only the fixed front end through `D`, not the historical
  structural representation or authority semantics;
- the historical 42/500 normal-authority gate failure stands;
- no fresh real-data source, detector-superiority evidence, full adaptive C
  implementation, WCET measurement, global minimality proof, or novelty proof
  exists;
- H checkpoint validation permits a large ring/sum inconsistency to be hidden
  by the unconditional negative clamp.

Overall classification: **R3. RESEARCH-SUPPORTED STRUCTURAL REPRESENTATION /
AUTHORITY ARCHITECTURE**. This is a structural/methodological and engineering
contribution, not yet a publishable algorithmic result.

## 1. Provenance and immutable history

The historical canonical commit is
`7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc`. The finalization starting point is
`5b43516c7e63c015f7774b790c461b349f5b1d90`. This work was performed on the
isolated branch `research/dmreda-claim-aligned-validation`.

The reachable repository contains 58 commits and no tags before the canonical
point, but history prior to the imported snapshot is unavailable. Standalone
historical Layer-A/Layer-B result files named by the protocol are unavailable,
although the corresponding code/tests exist. The exact historical `kappa=2.5`
selection record and immutable original Python/package bytes are unavailable.
Documentation was not used to fill those gaps.

The Stage 3.3 negative remains immutable: 42 of 500 historical normal
trajectories produced at least one authority by horizon 960 against a frozen
maximum of 25. There were 45 total events and 458 censored trajectories. This
claim-aligned campaign did not access FaultyTesting and did not run a new
locked normal gate because no defensible fresh Rieth-lineage source exists.

## 2. Recovered executable architecture

The full historical reference path is:

```text
affine input contract
-> causal trailing median
-> absolute residual e
-> finite-window L1 residual mass E
-> EWMA context B
-> clipped relative deviation D
-> lagged difference + EWMA growth G
-> residual activity and hysteretic regime scheduler
-> episodic candidate (age, area, count, opening contract)
-> confirmation impulse
-> refractory
```

Historical documents call `E`/`e1` energy, but source computes a sum of
absolute residuals. The batch Python function allocates trace arrays and is
`O(T)` memory. Its recurrence admits a fixed-window/register `O(1)` streaming
realization.

The historical fixed C mirror is profile 0 only. H is a later fixed detector:

```text
median -> e -> E -> B -> D -> six consecutive D>0.8 -> refractory 80
```

It contains no `G`, regime evidence, candidate area/timeout, nonconsecutive
count, or opening-time contract.

## 3. Claim-aligned methodology

Before values were emitted, the campaign froze generator equations, parameter
ranges, matching constraints, seeds, readouts, metrics, uncertainty method,
and falsification criteria. The authoritative result is
`results/CLAIM_ALIGNED_RESULTS_V2.json`, SHA-256
`1a1303cf622f8721d714a2e90694a696cce1d4478eacaece7fec5cdf7917091a`.

The run used 128 train seeds `100000..100127`, 128 disjoint test seeds
`200000..200127`, PCG64, CPython 3.12.13, NumPy 2.3.5, and 2,000 paired
seed-block bootstrap replicates. Two pre-result/verifier-only amendments are
preserved in Git; neither changed data or metrics.

The primary experiment starts after median residualization so it can match the
exact statistic presented to `E/B/D/G`. A separate raw equal-RMS campaign was
kept as descriptive falsification because peak and post-median residual
histograms were not matched.

## 4. Representation result

For each of 256 seeds, six 96-sample histories shared the exact same residual
multiset and final 16-sample tail. Duration, peak, sum, RMS, squared energy,
current `e`, and current `E` were matched within the frozen contract.

| Representation | Held-out accuracy | 95% paired seed-block interval | Fisher ratio |
|---|---:|---:|---:|
| current `e` | 0.1667 | [0.1667, 0.1667] | 0 |
| current `E` | 0.1667 | [0.1667, 0.1667] | approximately 0 |
| current `D` | 0.5430 | [0.5039, 0.5807] | 17.56 |
| `(D,G)` | 0.7552 | [0.7344, 0.7747] | 26.99 |
| `(D,G,r,a)` | 0.7930 | [0.7786, 0.8073] | 32.18 |

The paired `D+G` minus `D` change was 0.2122, interval
`[0.1823,0.2435]`. This supports a scoped statement: leaky context and lagged
growth preserve temporal ordering discarded by current residual magnitude and
current residual mass.

It does not establish completeness: coherent ramp and slow migration remained
heavily confused. Nor does `a` add information, because it is a deterministic
function of `G`; the experiment does not isolate the separate effect of `r`.

## 5. Adversarial limits

Exact sign reflection leaves every tested absolute-residual Core field equal;
direction is lost. A persistent unit step is absorbed by the median, after
which residual mass vanishes and `D=-1`; the Core represents transition rather
than sustained absolute level. An identical injection after different contexts
produced peak `(D,G)` of `(5,2.4829)` versus `(2.0447,0.7129)`, so normalized
evidence is not event-invariant.

In the confounded raw campaign, richer representations were not monotonically
better. `D+G` improved on `D` at offset 47 but was significantly worse at
offset 95. This refutes a phase-independent “more state is always better”
reading.

## 6. Exact state-necessity witnesses

The following common-suffix pairs are arithmetic witnesses, not aggregate
benchmarks:

- rolling sum: `[1,0]` and `[0,1]` both sum to 1; append 0 and next sums are 0
  and 1;
- median: `[0,1,2]` and `[1,1,100]` both have median 1; append 50 and next
  medians are 2 and 50;
- lag state: D histories `[0,0,0,0.2]` and `[1,0,0,0.2]` share current
  `(D,G)=(0.2,0)`; append D=0.2 and next G values are 0.025 and -0.1;
- D-only representation: `[-1,0,0,0,0.2]` and
  `[0.2,0,0,0,0.2]` share current D=0.2 but have G=0.15 and 0; only the first
  opens under the historical G threshold. This witness is exact in feature
  space; raw reachability remains unknown;
- count: same age 2 and area 0.6, counts 1/2; common D=1.5 yields no-confirm/
  confirm;
- area: same age 2 and count 2, areas 0.2/0.8; common D=1.3 yields no-confirm/
  confirm;
- age: same area 0.2 and count 1, ages 2/1; common suffix `[0.5,2]` diverges
  through timeout;
- opening contract: same `(age,area,count)=(5,1.7,5)` under profile-0/profile-1
  contracts; common D=0.5 confirms only the first;
- refractory: identical inactive candidate coordinates, refractory 0/2;
  common high D opens only the first.

These establish necessity of information classes for the declared semantics,
not globally minimal bit encodings.

## 7. Smallest state justified now

The smallest currently justified authority tuple is:

```text
(ell, A, C, Q_open, R)
```

given exogenous `D/G`, current configuration/mode, and authority enable. The
literal and reduced models matched all 1,176 reachable transitions checked to
depth 8 across a 24-symbol alphabet and three modes. `pending_start` and a
persistent pending Boolean are redundant.

The representation requires ordered trailing input/residual windows, an
expiration-capable D-lag history, `B`, `G`, `r`, `a_slow`, regime/tick/hold
state, selected parameters, and warm-up phase. Exact current scalar outputs
cannot replace the ordered windows. This is a sufficient bounded-register
model; global minimality is unknown.

## 8. Representation versus authority

All seven preregistered semantic cases passed: isolated evidence without
authority, sustained confirmation, insufficient-persistence timeout,
refractory retrigger bounds, recovery, confirmation winning at the timeout
boundary, and timeout followed by same-sample re-arm.

Representation fields are computed before and independently of candidate and
refractory state. Warm-up and opening mode change authority but leave
representation unchanged in the tested contract. Thus the directional split
`representation -> authority` is directly established.

## 9. H reassessment

On 192 raw traces, H and the fixed historical front end matched `mu/e/E/B/D`
within `7.33e-14` maximum error. This is a strong subset result. It is not full
equivalence: H cannot expose `G` or the historical authority registers, and 152
of 192 event-index sequences differed (314 historical events versus 224 H
events).

Therefore H is outcome C: a useful detector-oriented ablation that preserves
part of the representation, not canonical DMREDA as recovered from the
historical claim boundary.

## 10. Classical reduction and novelty

The median, moving L1 sum, EWMA states, finite-lag difference, threshold
accumulator, count, timeout, hysteresis, run rule, and refractory are known
primitives. The historical area is CUSUM-like but not Page's recursive CUSUM;
the Core is not an SPRT because it has no likelihood ratio or hypothesis/error
contract. H is an exact run-rule/dead-time detector.

The defensible distinction is semantic and methodological: representation is
made an explicit observable object, authority is a separately specified
bounded monitor, and state-necessity claims are tested by behavioral collisions.
A focused literature review found relevant prior frameworks for every broad
idea. Novelty is not established without a systematic closest-prior-art and
patent review plus a precise contribution theorem.

## 11. Embedded audit

The H parity report was regenerated from hash-allowlisted, non-FaultyTesting
extracts and was byte-identical to the tracked report. It covers 1,039,792 exact
rows. H compiles strict C99, uses no heap, has fixed 7/16 rings, and measured
232-byte state, 240-byte checkpoint, 2,345-byte object sections, and 432-byte
step stack on arm64 Darwin. These are host measurements, not MCU WCET.

The residual-sum clamp is incomplete. Natural cancellation reached only
`-2.7756e-17`, but a validator-accepted inconsistent checkpoint can produce
`-100`, silently clamped to zero. Historical code was preserved; a future
revision should validate ring/sum consistency and clamp only within a derived
roundoff tolerance.

## 12. Layered final status

| Layer | Status |
|---|---|
| representation | experimentally supported in the exact matched residual-order domain |
| temporal state | exact necessity witnesses; full minimum unknown |
| authority semantics | directly established for implemented transition and boundaries |
| embedded engineering | strong for fixed subsets; full adaptive C/WCET absent; checkpoint invariant flaw |
| detector performance | historical normal gate failed; superiority unknown |
| real-data generalization | unknown; no fresh admissible source |
| novelty | not established; known combination with a defensible semantic formulation |

## 13. Classification and next discriminator

Final classification: **R3. RESEARCH-SUPPORTED STRUCTURAL REPRESENTATION /
AUTHORITY ARCHITECTURE**.

R4 would require more than additional favorable synthetic accuracy. The next
classification-changing package should contain:

1. a symbolic or machine-checked equivalence/minimality result for a precisely
   declared observation contract, including all strict boundaries and profile
   changes;
2. a preregistered raw-signal generator whose pairs are simultaneously matched
   after the actual median/residual front end, with adversarial held-out families
   and independent replication;
3. systematic closest-prior-art/patent comparison identifying what theorem or
   semantic contract is genuinely new;
4. a full adaptive no-heap C implementation with parity and target WCET/jitter;
5. separately, for any efficacy claim, a provenance-clean fresh normal gate
   followed only on pass by sealed fault evaluation at matched horizon/risk.

The first three could support R4 as a methodological/structural result. R5
would additionally require an algorithmic contribution not reducible to this
known composition and independently supported performance or theory.

## 14. Final verification record

On 2026-08-14, using CPython 3.12.13 and NumPy 2.3.5 on macOS 15.7.7 arm64:

- historical/full repository suite: `Ran 240 tests in 8.555s`, `OK`;
- claim-aligned contract suite: `Ran 8 tests in 0.048s`, `OK`;
- `current_claim/SHA256SUMS`: all 28 entries `OK` when invoked from
  `current_claim/`;
- `frozen_history/SHA256SUMS`: all 19 entries `OK` when invoked from
  `frozen_history/`;
- H external parity replay: 1,039,792 exact rows; regenerated report
  byte-identical at SHA-256 `8251e2...18fd`;
- `git diff --check`: no whitespace error;
- generated Python bytecode directories: none left in the worktree;
- FaultyTesting accessed: false.

An earlier manifest invocation from repository root failed because both
manifests intentionally contain paths relative to their own directories. It
was rerun from the correct directories as above; the failed invocation is not
evidence of an artifact mismatch.
