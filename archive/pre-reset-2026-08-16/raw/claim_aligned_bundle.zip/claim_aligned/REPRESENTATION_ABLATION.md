# Representation Ablation

## Evaluation rule

Components are retained or rejected here according to information and semantic
role, not fault hit rate. RAM figures are direct logical storage for a simple
binary64 streaming realization at canonical maximum window sizes; they exclude
alignment, configuration tables, outputs, and temporary stack.

| Component | Standard concept and encoded information | What removal loses / collision | Matched-order evidence | Logical state and fixed work | Role / disposition |
|---|---|---|---|---|---|
| trailing median `mu` | causal rank filter / local location estimate | current median alone cannot predict expiration; `[0,1,2]` and `[1,1,100]` diverge after common 50 | not isolated because campaign starts after median | up to 11 doubles = 88 B; bounded selection/sort | representation front end; useful robustness primitive, particular window necessity unknown |
| absolute residual `e` | unsigned local deviation | removes direction; `x` and `-x` collide exactly | chance 0.1667; all six classes collide | derived scalar; no persistent byte needed after insertion | magnitude primitive; insufficient alone; sign blindness is real information loss |
| rolling residual mass `E` | finite-window L1 accumulation, not squared energy | removes local persistence/mass; scalar needs residual ring to expire exactly | chance 0.1667 at matched final window | up to 32 doubles = 256 B, sum and indices; O(1) update | representation primitive; state necessary for exact window semantics |
| adaptive baseline `B` | EWMA/leaky integrator of `E` | removing it makes equal-current-E histories indistinguishable | `D`, which combines `E/B`, reaches 0.5430 while E stays at chance | one double = 8 B; fixed multiply/add | primary temporal-context carrier; experimentally supported, context-sensitive |
| normalized deviation `D` | clipped relative deviation of current mass from leaky context | without it, no dimensionless contextual contrast; clipping merges extremes | 0.5430, CI [0.5039,0.5807] | derived scalar; fixed arithmetic | representationally supported; not a likelihood ratio and not context invariant |
| lagged growth `G` | EWMA of finite-lag D difference | D-only feature collision changes G-opening; D-lag ring needed for continuation | `D+G` 0.7552; delta vs D CI [0.1823,0.2435] | up to 8 D doubles = 64 B plus G/index; fixed update | representationally useful in matched family; raw-global necessity unknown |
| residual activity `r` | slow EWMA of `e` | removes a separate time constant used by regime transitions | only joint R4 tested in matched campaign; not isolated | one double = 8 B | plausible representation/regime input; individual necessity unproved |
| `a=clip(|G|/g_ref)` | derived nonlinear magnitude of growth | no information beyond G under fixed profile; may alter classifier geometry | included in R4 but cannot support independent information claim | no persistent state | redundant as state; useful derived output only |
| `a_slow` | tick-updated leaky activity | removal changes adaptive lag/confirmation schedule | raw primary accuracy only 0.4622 alone; raw magnitudes unmatched | one double = 8 B | adaptive-control state; empirical value not established |
| regime state and hysteresis | discrete gain/window scheduling controller | removal freezes profile and future recurrence parameters | regime state alone at chance 0.1667 in raw end readout | enum, tick phase, two bounded counters | authority/representation adaptation; semantically active, representational benefit unproved |
| candidate persistence age `ell` | timed residence | without it, timeout histories collide | exact common-suffix confirmation collision | one bounded integer | authority-only; necessary within historical semantics |
| candidate excess area `A` | finite-episode positive score accumulation | same age/count can confirm differently | exact `[1.1,1.1]` vs `[1.4,1.4]` witness | one bounded real register | authority-only; necessary within historical semantics |
| candidate count `C` | number of D exceedances during candidate | area does not encode number of qualifying samples | exact same age/area collision | one bounded integer | authority-only; necessary; not a consecutive run rule |
| opening contract | snapshot of timeout/threshold/count/refractory policy | profile change would retroactively alter an open candidate | exact aggregate-contract collision | five bounded config values while pending | authority-only; aggregate snapshot necessary; individual fields not minimized |
| noncanonical signed area | signed finite-window mean/RMS | restores direction lost by absolute residual | sign mirror gives `+0.9951` vs `-0.9951`; raw late accuracy 0.9167 | finite signed ring or sum | potentially useful extension, but not canonical and not validated |

## End-to-end raw component results are descriptive only

At the late raw readout, individual accuracies were high for `r` (0.9974), `B`
(0.9935), and `E` (0.9635), while `G` was 0.7734 and regime state was chance.
These numbers do not rank intrinsic temporal information because the raw
families had unmatched peaks and post-median residual histograms. They show
behavior under those shapes, not controlled information gain.

## Strongest positive ablation conclusion

**[EXPERIMENTALLY SUPPORTED]** `B/D` preserves order discarded by current
`e/E`, and `G` adds substantial held-out separation under the exact residual
matching contract. A detector-only reduction that keeps `D` but deletes `G`
therefore preserves only part of the demonstrated representation.

## Strongest negative ablation conclusion

The broader adaptive machinery is not yet justified as a representational
necessity. `a` is derived, regime state showed no separability in the raw late
readout, `a_slow` was weak alone, and no exact collision establishes that the
three-regime scheduler is required for the matched temporal distinctions. It
is semantically active code, but its scientific benefit remains
**[UNKNOWN]**.
