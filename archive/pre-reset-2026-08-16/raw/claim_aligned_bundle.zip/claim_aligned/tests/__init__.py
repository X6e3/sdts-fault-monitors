"""Tests for frozen claim-aligned contracts."""
