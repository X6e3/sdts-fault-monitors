from __future__ import annotations

import json
from pathlib import Path
import unittest

import numpy as np

from claim_aligned.tools.experiment_support import (
    EVENT_END,
    RESIDUAL_CLASSES,
    _fixed_raw_last_d_g,
    bounded_exhaustive_authority_equivalence,
    fixed_residual_representation,
    generate_residual_order_family,
    run_authority_semantics,
    run_numeric_invariant_audit,
    run_sign_blindness_case,
    verify_residual_matching,
)
from claim_aligned.tools.run_claim_aligned_experiments import (
    PROTOCOL_PATH,
    SEED_PATH,
    validate_frozen_inputs,
)
from experimental.finalization.minimal_state_model import (
    MinimalAuthorityState,
    OpenContract,
    step_authority,
)
from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    RegimeTransition,
    compute_dmreda_reference,
)


class ClaimAlignedContractTests(unittest.TestCase):
    def test_protocol_seed_and_source_hashes_are_bound(self) -> None:
        protocol = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
        seeds = json.loads(SEED_PATH.read_text(encoding="utf-8"))
        train, test = validate_frozen_inputs(protocol, seeds)
        self.assertEqual(len(train), 128)
        self.assertEqual(len(test), 128)
        self.assertFalse(set(train) & set(test))

    def test_exact_residual_multiset_contract(self) -> None:
        family = generate_residual_order_family(100000)
        self.assertEqual(set(family), set(RESIDUAL_CLASSES))
        matching = verify_residual_matching(family)
        self.assertTrue(matching["all_passed"])
        traces = {
            name: fixed_residual_representation(values) for name, values in family.items()
        }
        self.assertEqual(
            len({round(float(trace["E"][EVENT_END]), 12) for trace in traces.values()}),
            1,
        )

    def test_fast_raw_recurrence_matches_canonical_final_D_G(self) -> None:
        histories = (
            [0.0, 0.04, 0.08, 0.12, 0.08, 0.04, 0.0, 0.12, 0.04],
            [0.12, 0.0, 0.12, 0.0, 0.08, 0.04, 0.08, 0.0, 0.04],
        )
        for history in histories:
            fast = _fixed_raw_last_d_g(history)
            reference = compute_dmreda_reference(
                np.asarray(history),
                profiles={0: DEFAULT_PROFILES[0]},
                transitions={0: RegimeTransition()},
                regime_tick=len(history) + 1,
                warmup_samples=0,
                mode="D_or_G",
            )
            self.assertAlmostEqual(fast[0], float(reference.d[-1]), places=15)
            self.assertAlmostEqual(fast[1], float(reference.g[-1]), places=15)

    def test_authority_semantics_and_bounded_equivalence(self) -> None:
        result = run_authority_semantics()
        self.assertTrue(result["all_checks_pass"])
        self.assertTrue(
            result["bounded_exhaustive_equivalence"]["all_equivalent_within_bound"]
        )

    def test_sign_mirror_is_a_destructive_collision(self) -> None:
        result = run_sign_blindness_case()
        self.assertTrue(result["all_claim_bearing_core_fields_equal"])
        self.assertGreater(result["positive_signed_area"], 0.0)
        self.assertLess(result["negative_signed_area"], 0.0)

    def test_large_negative_clamp_can_hide_checkpoint_inconsistency(self) -> None:
        result = run_numeric_invariant_audit()
        case = result["large_inconsistency_case"]
        self.assertTrue(case["checkpoint_accepted"])
        self.assertTrue(case["large_negative_silently_clamped"])

    def test_candidate_area_is_necessary_given_age_and_count(self) -> None:
        contract = OpenContract(4, 1.0, 1.0, 2, 0)
        states = []
        for history in ([1.1, 1.1], [1.4, 1.4]):
            state = MinimalAuthorityState()
            for d_value in history:
                output = step_authority(
                    state,
                    d_value=d_value,
                    g_value=0.0,
                    th_d=1.0,
                    th_g=10.0,
                    current_contract=contract,
                    mode="d_only",
                    authority_enabled=True,
                )
                self.assertFalse(output.confirmed)
            states.append(state)

        self.assertEqual(states[0].ell, states[1].ell)
        self.assertEqual(states[0].count, states[1].count)
        self.assertNotEqual(states[0].area, states[1].area)
        outputs = [
            step_authority(
                state,
                d_value=1.3,
                g_value=0.0,
                th_d=10.0,
                th_g=10.0,
                current_contract=contract,
                mode="d_only",
                authority_enabled=True,
            )
            for state in states
        ]
        self.assertEqual([output.confirmed for output in outputs], [False, True])

    def test_lag_history_is_needed_beyond_current_D_and_G(self) -> None:
        def growth(history: list[float], *, lag: int = 4, lam: float = 0.125) -> list[float]:
            result = []
            for index, value in enumerate(history):
                raw = value - history[index - lag] if index >= lag else 0.0
                result.append(raw if index == 0 else lam * raw + (1.0 - lam) * result[-1])
            return result

        history_1 = [0.0, 0.0, 0.0, 0.2]
        history_2 = [1.0, 0.0, 0.0, 0.2]
        self.assertEqual(history_1[-1], history_2[-1])
        self.assertEqual(growth(history_1)[-1], growth(history_2)[-1])
        next_1 = growth([*history_1, 0.2])[-1]
        next_2 = growth([*history_2, 0.2])[-1]
        self.assertEqual(next_1, 0.025)
        self.assertEqual(next_2, -0.1)


if __name__ == "__main__":
    unittest.main()
