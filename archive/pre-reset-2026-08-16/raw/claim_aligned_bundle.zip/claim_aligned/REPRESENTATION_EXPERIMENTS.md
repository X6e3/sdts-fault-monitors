# Representation Experiments

## Result in one sentence

**[EXPERIMENTALLY SUPPORTED]** In the preregistered post-median campaign,
histories with the same residual multiset, duration, peak, RMS, squared energy,
sum, current residual, and final 16-sample residual window were indistinguishable
from current `e` or `E`, but distinguishable from the history-dependent `D` and
`D+G` representations. This establishes a scoped temporal-order property of the
`E/B/D/G` recurrence; it does not establish end-to-end raw-signal invariance,
fault-detection value, or novelty.

## Frozen experiment boundary

The generator, seeds, metrics, and falsification rules were committed at
`d49808e` before result values were generated. Two amendments are preserved:

- `AMENDMENT_001` corrected a feature-table alias after a `KeyError`, before any
  metric or result file was emitted. It did not change values or generators.
- `AMENDMENT_002` corrected tuple-versus-JSON-list comparison in the
  `--verify-existing` path after the first result was sealed. It did not change
  generated values or metrics.

The authoritative reproducible result is
`results/CLAIM_ALIGNED_RESULTS_V2.json`, file SHA-256
`1a1303cf622f8721d714a2e90694a696cce1d4478eacaece7fec5cdf7917091a`.
Its canonical result SHA-256 is
`ae1ad350bd0ace1e55e6020f6645d170f02a7c47adae2468170ecf01c3cc5556`.
The run used CPython 3.12.13, NumPy 2.3.5, PCG64, 128 frozen train seeds,
128 disjoint test seeds, and 2,000 paired seed-block bootstrap replicates.

## Campaign 1: exactly matched residual order

This campaign starts after the trailing-median operation. For each of 256 seed
blocks, the same 96 residual magnitudes were arranged as six temporal families:
coherent ramp, incoherent order, central pulse, plateau/step, alternating
extremes, and blockwise slow migration. The 16-sample event tail was identical.

Every seed block passed all frozen matching conditions:

- bit-identical sorted event residuals;
- identical duration and peak;
- residual sum, squared energy, and RMS within `1e-12`;
- bit-identical final 16 residuals and current residual;
- current 16-sample residual mass `E` within `1e-12`.

This is the claim-bearing magnitude-versus-order experiment because amplitude,
histogram, duration, current `e`, and current `E` were controlled before the
representation comparison.

### Held-out result at the event-end readout

| Space | Coordinates | Test accuracy | Paired 95% bootstrap interval | Fisher trace ratio | Interpretation |
|---|---|---:|---:|---:|---|
| `R0` | current `e` | 0.1667 | [0.1667, 0.1667] | 0.00 | chance; exact collision |
| `R1` | current `E` | 0.1667 | [0.1667, 0.1667] | approximately 0 | chance; numerical-order dust only |
| `R2` | current `D` | 0.5430 | [0.5039, 0.5807] | 17.56 | EWMA context retains order information |
| `R3` | `D,G` | 0.7552 | [0.7344, 0.7747] | 26.99 | growth adds useful separation in this family |
| `R4` | `D,G,r,a` | 0.7930 | [0.7786, 0.8073] | 32.18 | broader evidence is most separable here |

Chance is `1/6 = 0.1667`. The paired accuracy change from `D` to `D+G` was
0.2122 with a 95% bootstrap interval of `[0.1823, 0.2435]`. The change from
`D` to `R4` was 0.2500 with interval `[0.2148, 0.2852]`.

**Important qualification:** `a=clip(|G|/g_ref)` is a deterministic transform
of `G`, so its inclusion can change nearest-centroid geometry without adding a
new state variable or new information. The only additional recurrence in the
fixed-profile `R4` vector is residual activity `r`. The experiment does not
isolate `r` from the redundant nonlinear `a` coordinate. Therefore it supports
the joint `R4` space, not a separate necessity claim for `a` or `r`.

### Collision result

- `R0`: all six classes collided in all 256 seed blocks.
- `R1`: all six classes collided within 12-decimal tolerance in 253/256 blocks;
  the other three blocks had only two encodings caused by floating subtraction
  order around `1e-14`. Train scaling classified this coordinate as constant.
- `R2`, `R3`, and `R4`: six distinct readout vectors in every seed block.

The confusion matrices prevent a stronger interpretation. Even with `D+G`,
coherent ramp and slow migration were frequently confused (71/128 ramps were
called slow migration; 52/128 slow migrations were called ramps). The
representation preserves some temporal organization; it is not a unique or
complete structural code.

## Campaign 2: end-to-end raw shapes

The second campaign exercised the historical Core from raw synthetic samples.
All six 96-sample injections had equal RMS `0.5`, squared energy `24`, and
duration. Peak, mean, and post-median residual histograms were deliberately not
matched and were reported.

For the first seed, peak magnitudes ranged from `0.5` for the step to `1.3808`
for incoherent noise. Across seeds, mean sorted-residual RMSE relative to the
ramp was approximately `0.4633` for noise, `0.4977` for oscillation, `0.08495`
for step, `0.04556` for pulse, and `0.02076` for slow migration.

Consequently, the raw campaign is a falsification/behavior study, not direct
evidence for information beyond magnitude. At event offsets 15, 47, and 95,
held-out accuracies were:

| Space | offset 15 | offset 47 | offset 95 |
|---|---:|---:|---:|
| current `e` | 0.9050 | 0.8672 | 0.8776 |
| current `E` | 0.8255 | 0.9688 | 0.9635 |
| current `D` | 0.8503 | 0.8177 | 0.8945 |
| `D,G` | 0.7852 | 0.8893 | 0.8607 |
| broader adaptive Core | 0.7083 | 0.9323 | 0.8789 |
| `D,G` plus noncanonical signed area | 0.8021 | 0.9232 | 0.9167 |

Richer spaces were not monotonically better. `D+G` improved over `D` at offset
47 (paired 95% delta interval `[0.0482, 0.0964]`) but was worse at offset 95
(`[-0.0482, -0.0195]`). This is direct evidence that readout phase matters and
refutes any blanket claim that adding `G` always improves separability.

## What is established

- **[EXPERIMENTALLY SUPPORTED]** `B/D` retains temporal ordering information
  after current residual magnitude and current residual mass have collided.
- **[EXPERIMENTALLY SUPPORTED]** `G` adds discriminative information to `D` for
  the exact-multiset family at the frozen event-end readout.
- **[EXPERIMENTALLY SUPPORTED]** The broader fixed evidence vector retains more
  separability than `D` alone for that family.
- **[REFUTED]** The absolute-residual Core encodes disturbance sign: exact sign
  reflection leaves every tested claim-bearing Core field unchanged.
- **[REFUTED]** A persistent level step remains represented indefinitely: the
  trailing median adapts, residual goes to zero, and `D` returns to `-1`.
- **[REFUTED]** `D/G` are event-only invariants: the identical injection reached
  peak `D=5.0, G=2.4829` after a stationary context but only
  `D=2.0447, G=0.7129` after a migrating context.

## What remains unknown

- Whether the matched residual histories are reachable from raw signals under
  the exact trailing-median map.
- Whether these distinctions correspond to real process regimes or useful
  fault classes.
- Whether `G`, `r`, or regime adaptation improves an application objective at
  controlled risk.
- Whether another simpler causal representation preserves the same distinctions.
- Whether the exact composition is novel; that requires broader literature and
  prior-art search than this experiment.
