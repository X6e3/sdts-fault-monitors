# Formal State Model

## Scope and observation contract

This model describes the historical Core in
`gold_line/core/dmreda_reference_clean.py`. It separates the causal
representation recurrence from the event-authority recurrence. It is a
constructive sufficient-state model, not a proof of globally minimal state.

Let `c` be immutable configuration and let one transition consume one finite,
valid binary64 input `x_t`:

```text
S^R_(t+1), Z_t = R_c(S^R_t, x_t)
S^Q_(t+1), Y_t = Q_c(S^Q_t, Z_t, q_t)
S_(t+1) = (S^R_(t+1), S^Q_(t+1))
```

`q_t` contains the authority-enabled guard and current opening mode. `Z_t`
contains representation evidence. `Y_t` contains the public pending trace and
the one-sample confirmed/authority impulse. The source gives no feedback path
from `S^Q` to `S^R`.

## Representation transition

A sufficient state before sample `t` is:

```text
S^R_t = (
  X_ring, X_count, X_position,
  e_ring, e_count, e_position, E,
  B, r,
  D_ring, D_count, D_position, G,
  a_slow,
  regime, tick_phase, up_hold, down_hold,
  selected_m, selected_L,
  warmup_phase
)
```

For the profile selected at the beginning of the transition:

```text
mu_t = median(trailing X ring after inserting x_t)
e_t  = |x_t - mu_t|
E_t  = E_(t-1) - expired_e + e_t
B_t  = beta E_t + (1-beta) B_(t-1)
b_t  = max(B_t, floor)
D_t  = clip((E_t-b_t)/b_t, -5, 5)
u_t  = D_t - D_(t-m)
G_t  = lambda u_t + (1-lambda) G_(t-1)
r_t  = rho e_t + (1-rho) r_(t-1)
a_t  = clip(|G_t|/g_ref, 0, 1)
```

On a regime tick, the hysteretic hold counters may change `regime`; `a_slow`
is updated and the future lag and confirmation length are selected. The profile
table, affine transform, thresholds, and maximum window dimensions are
configuration, not mutable history.

`E` is an L1 residual sum, despite the historical “energy” name. `G` is a
leaky finite-lag difference, not a likelihood statistic. `a` is derived from
`G` and does not require persistent storage.

## Authority transition

Given `Z_t=(D_t,G_t,profile_t,...)`, a sufficient authority state is:

```text
S^Q_t = (ell, A, C, Q_open, R)
Q_open = (L, theta_D2, theta_A, N_min, refractory_length)
```

`ell=0` denotes no candidate. Otherwise `ell` is candidate age including the
opening sample, `A` is accumulated positive excess, `C` counts—not
necessarily consecutive—samples above `theta_D2`, and `Q_open` is the contract
snapshotted at opening. `R` is remaining refractory.

The transition precedence is:

```text
R <- max(R-1, 0)
if enabled and ell>0:
    pending_output <- true
    ell <- ell+1
    A <- A + max(0, D-theta_D2)
    C <- C + [D>theta_D2]
    if A>theta_A and C>=N_min:
        confirmed <- true; clear candidate; R <- refractory_length
    else if ell>=L:
        clear candidate

trigger <- mode_guard(D,G)
if enabled and ell==0 and not confirmed and R==0 and trigger:
    open with current contract; consume current sample immediately
```

Confirmation therefore wins over timeout at the inclusive boundary. A timeout
can be followed by same-sample re-arm. `pending_output` is a transition
observation, not the final Boolean `ell>0`.

## Causality and determinism

**[DIRECTLY ESTABLISHED]** Every source read is from the current sample, fixed
configuration, or retained prefix state. A suffix alteration cannot alter an
already-computed field. Prefix fixtures and repeated/checkpointed executions
pass within the claimed input contract.

**[DIRECTLY ESTABLISHED]** For valid finite binary64 state/input and a fixed
configuration, the source transition has one ordered branch outcome. Worker
count changes the scheduling of independent trajectories, not their internal
transition order.

These statements do not cover data races introduced by an external caller,
fast-math reassociation, corrupted checkpoints, or a different numeric model.

## Bounded state and compute

For the canonical table, `max(w1)=11`, `max(w2)=32`, and `max(m)=8`.
All rings and counters therefore have configuration-fixed bounds independent of
stream duration `T`. Candidate area is bounded by
`L * max(0,D_max-theta_D2)` because `D` is clipped. Warm-up can use a saturating
phase counter. Hence a streaming realization has `Memory(T)=O(1)`.

All source-level loops can be given fixed profile bounds: insertion-sort median
is bounded by the maximum median window, ring updates are constant work, and
the regime/authority update has a fixed branch count. This establishes a
structural per-sample bound, not measured WCET. Cache, compiler, interrupt,
memory-system, and target timing measurements are unavailable.

The historical NumPy batch function allocates arrays proportional to `T`; its
implementation memory is therefore `O(T)` even though the recurrence has an
`O(1)` streaming realization.

## Behavioral reduction evidence

The literal source-shaped authority state and `(ell,A,C,Q_open,R)` model were
compared over the reachable state pairs to depth 8, a 24-symbol alphabet, and
all three opening modes. All 1,176 transitions matched.

Exact common-suffix witnesses establish that removing `ell`, `A`, `C`, the
aggregate opening contract, or `R` changes behavior. Conversely,
`pending_start=t-ell+1` and a persistent pending Boolean are redundant. The
result is a tested quotient over the declared bounded domain, not an all-real
bisimulation or bit-minimal encoding.

## Automaton classification

At the mathematical-real level, the authority object is a deterministic
bounded-register timed/hybrid automaton: its control is finite but `A` is a
real register. Under the actual binary64 and bounded-integer implementation,
the number of bit states is finite, though astronomically large. Calling it a
plain small finite-state machine would hide the real-valued accumulator and
opening contract.

## Status

- **[DIRECTLY ESTABLISHED]** source-level causality, deterministic precedence,
  representation-to-authority direction, and the displayed collision
  witnesses;
- **[EXPERIMENTALLY SUPPORTED]** reduced authority equivalence within the
  frozen finite search;
- **[STRONG INFERENCE]** an exact full-Core streaming implementation can have
  state and per-step work independent of `T`;
- **[UNKNOWN]** global state minimality, symbolic all-suffix equivalence,
  numeric safety outside the validated domain, and target WCET/jitter.
