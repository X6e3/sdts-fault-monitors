# Minimal State Reassessment

## Conclusion

The smallest state currently justified is a **sufficient bounded-register
model**, not a globally minimal state proof. The historical batch Python arrays
can be reduced to fixed windows, scalar recurrences, bounded counters, and an
episodic authority register. The explicit candidate start index and persistent
pending Boolean are removable. The trailing windows, D-lag expiration data,
candidate age, area, count, opening contract, and refractory state cannot be
collapsed to their current scalar outputs without changing demonstrated future
behavior.

## Sufficient representation state

For the full adaptive historical recurrence, one sufficient state before the
next sample is:

```text
S_R = (
  X_ring, X_count, X_position,
  e_ring, e_count, e_position, E,
  B, r,
  D_ring, D_count, D_position, G,
  a_slow,
  regime, tick_phase, up_hold, down_hold,
  selected_m, selected_confirmation_length,
  warmup_phase
)
```

The static profile table and affine parameters are configuration, not mutable
stream state. `mu`, current `e`, current `D`, `G_raw`, and `a` can be computed
during the transition and need not persist after their consumers run.

For the canonical three profiles, logical maxima are `w1=11`, `w2=32`, and
`m=8`. A direct binary64 implementation therefore needs at least 88 bytes of
input samples, 256 bytes of residual samples, and 64 bytes of D history, before
indices, scalar recurrences, authority state, profile storage, alignment, and
temporary median workspace. This is a component accounting, not an ABI size
claim.

The existing fixed-profile C mirror uses larger compile-time maxima
`15/64/16`, embeds configuration in the state, and occupies 984 bytes on the
recorded arm64 ABI. It implements only profile 0 with adaptation disabled.

## Sufficient authority state

Given exogenous `(D_t,G_t)`, current profile/configuration, opening mode, and
authority-enabled guard:

```text
S_Q = (ell, A, C, Q_open, R)

Q_open = (L, theta_D2, theta_A, N_min, refractory_length)
```

- `ell=0` means inactive; `ell>0` is candidate age including its opening sample.
- `A` is accumulated positive excess.
- `C` is qualifying-sample count, not necessarily consecutive.
- `Q_open` is snapshotted when the candidate opens.
- `R` is refractory remainder.

`pending_start` is recoverable as `t-ell+1`, and persistent `pending_active` is
recoverable as `ell>0`. The external `pending` output cannot be identified with
end-of-sample `ell>0` because confirmation or timeout can clear the state after
the output was asserted during the same transition.

## Coordinate disposition

| Coordinate/class | Current disposition | Evidence |
|---|---|---|
| trailing input history | necessary for exact median continuation | equal current medians, different common-next medians |
| trailing residual expiration history | necessary for exact rolling mass | equal current sums, different common-next sums |
| current `B` | sufficient scalar for its own EWMA recurrence | recurrence equation; no earlier E history needed once `B` is retained |
| D-lag history | necessary for exact `G` continuation | equal current `(D,G)`, different common-next `G` |
| current `G` | sufficient scalar for its leaky recurrence given lag input | recurrence equation |
| `r` | sufficient scalar for its EWMA recurrence | recurrence equation |
| `a` | derived; no persistent state needed | `clip(abs(G)/g_ref)` |
| `a_slow` | retained by adaptive semantics | tick-updated EWMA; necessity versus an alternative encoding unproved |
| regime/tick/hold state | retained by adaptive semantics | changes future profiles; global coordinate minimality unproved |
| `ell` | authority-necessary | timeout collision |
| `A` | authority-necessary | same age/count, different confirmation |
| `C` | authority-necessary | same age/area, different confirmation |
| aggregate `Q_open` | authority-necessary under adaptive profiles | same age/area/count, different confirmation |
| `R` | necessary for multiple events | inactive collision, different re-open behavior |
| `pending_start` | redundant | computed from `t` and `ell` |
| persistent pending Boolean | redundant | `ell>0` |

## Boundedness

State **dimension** is independent of total stream duration. Candidate age and
count are bounded by the snapshotted confirmation length. Since `D` is clipped,
candidate area is also bounded for fixed configuration by
`L * max(0, D_max-theta_D2)`. Refractory and hold counters have fixed profile
bounds. Warm-up needs only a saturating phase counter, not an unbounded sample
index.

This does not mean every mathematical numeric value is magnitude-bounded. The
historical Python Core accepts arbitrary finite binary64 input and can overflow
intermediate residual mass for extreme values. Bounded state means a fixed
number of storage locations, not an automatically safe numeric domain.

## Equivalence evidence

The reduced authority state was compared with a literal source-shaped model on
a frozen alphabet of 24 input/configuration combinations, to depth 8, in three
opening modes. All 1,176 checked transitions matched both outputs and reduced
next state. This supports removal of implementation-only fields over that
domain.

It is not a bisimulation proof over all real `D/G` values. A global proof would
need a symbolic transition relation with strict-boundary cases, all admissible
profile changes, warm-up, and an explicitly defined observation equivalence.

## Final confidence

- **[DIRECTLY ESTABLISHED]** The displayed state is sufficient by constructive
  recurrence; specific coordinates have exact collision witnesses.
- **[EXPERIMENTALLY SUPPORTED]** The reduced authority model matches the literal
  model within the declared bounded exhaustive domain.
- **[STRONG INFERENCE]** Full adaptive recurrence can be implemented in O(1)
  memory and fixed per-sample work using the displayed windows and registers.
- **[UNKNOWN]** Globally minimal real-register state, minimal bit encoding,
  full adaptive C realization, and a formal all-suffix equivalence proof.
