# Embedded Claim Audit

## Scope split

There are three different implementation objects:

1. `gold_line/core/dmreda_reference_clean.py`: full adaptive historical batch
   reference;
2. `gold_line/core/dmreda_streaming_fixed.c/.h`: fixed profile-0 streaming
   subset;
3. `current_claim/core/dmreda_minimal_streaming.c/.h/.py`: H, a different
   fixed detector-oriented subset.

Parity for a subset cannot be promoted to parity for the full adaptive Core.

## H Python/C replay

The parity verifier was rerun on 2026-08-14 against three external extracts
whose SHA-256 values matched the frozen allowlist before value access:

| Bank | Trajectories | Samples | Exact rows | Extract SHA-256 |
|---|---:|---:|---:|---|
| normal training | 500 | 250,000 | 250,000 | `f48e6735...686b4d` |
| fault training | 400 | 200,000 | 200,000 | `c8c69907...8261d` |
| normal testing | 500 | 480,000 | 480,000 | `9b7283e8...68e7e` |
| golden fixtures | 8 fixtures | 1,488 | 1,488 | bound fixture set |
| random seed 20260814 | 100 | 108,304 | 108,304 | generated |

Total exact exposed rows: `1,039,792`. The regenerated report was byte-identical
to `current_claim/evidence/streaming_parity_report.json`; both SHA-256 values
were `8251e2ff1bb1ef4b694c32f69ef70453b5df38583a3e6f4cf3cac67f5b3d18fd`.
FaultyTesting was not accessed.

**[DIRECTLY ESTABLISHED]** H Python/C exposed binary64 fields and discrete
outputs match exactly over this enumerated replay. **[UNKNOWN]** This does not
prove all-input, cross-compiler, fixed-point, or full-Core parity.

## Strict C99 and resource structure

H compiled with Apple clang 17 using
`-std=c99 -pedantic-errors -Wall -Wextra -Werror`. Source inspection finds no
heap allocation. Ring bounds are compile-time constants 7 and 16. On the
recorded arm64 Darwin ABI:

- persistent state: 232 bytes;
- checkpoint: 240 bytes;
- object sections: 2,345 bytes;
- statically reported `dmreda_minimal_step` stack: 432 bytes.

The historical fixed subset uses maxima 15/64/16 and measured 984 bytes of
state in the prior host test. The full adaptive Core has no C implementation,
no measured state ABI, and no target hardware cycle/energy/jitter result.

All loops have compile-time/profile-fixed bounds. This supports structural
bounded compute. It is not WCET: compiler output, cache/bus behavior,
interrupts, target memory placement, and execution-time distributions were not
measured.

## Transactional input/reset behavior

H's C step copies persistent state into `next`, validates the input, computes
the transition, validates the next state, and only then commits `*state=next`.
Nonfinite or oversized inputs therefore return an error without committing a
partial transition. Reset zeroes the declared state. Checkpoint magic/version,
counts, positions, bounds, and finite/nonnegative scalar fields are validated.

These are sound engineering choices within the validated contract. Raw struct
checkpoint serialization remains ABI/endian/layout-specific unless an external
portable encoding contract is added.

## Residual-sum numerical invariant

The H source unconditionally executes:

```c
if (next.e_sum < 0.0) next.e_sum = 0.0;
```

The known natural drain history produced a minimum pre-clamp recomputed sum of
`-2.7755575615628914e-17`. That is consistent with floating-point cancellation,
so a small negative tolerance clamp is defensible.

However, checkpoint validation accepts a state with outgoing ring value `100`
and stored sum `0`. The next subtraction mathematically yields `-100`, which is
silently clamped to zero. Thus the current check can hide a large ring/sum
invariant violation.

**[DIRECTLY ESTABLISHED]** The checkpoint validator does not enforce ring/sum
consistency, and the unconditional clamp masks the constructed large error.
No historical source or result was changed in this pass.

A defensible future contract would validate ring/count/sum consistency within
an explicitly derived tolerance and apply:

```text
-epsilon <= E < 0  -> clamp to zero
E < -epsilon       -> invariant error; do not commit state
```

The value of `epsilon` must be derived from the operation/error bound and input
domain, not chosen merely to pass the example.

## Embedded claim statuses

| Claim | Status |
|---|---|
| H strict C99 compile on recorded host | [DIRECTLY ESTABLISHED] |
| H no heap and fixed rings | [DIRECTLY ESTABLISHED] |
| H exact Python/C parity on enumerated replay | [DIRECTLY ESTABLISHED] |
| H transactional invalid-input/reset behavior | [DIRECTLY ESTABLISHED] within tests/source contract |
| full adaptive Core bounded streaming realization | [STRONG INFERENCE] constructively specified |
| full adaptive Core C parity | [UNKNOWN] no implementation |
| portable checkpoint bytes | [UNKNOWN] / not claimed by raw struct |
| target WCET, cycles, energy, jitter | [UNKNOWN] no MCU measurement |
| checkpoint numeric invariant complete | [REFUTED] |
