# Original Claim Recovery

Status: final recovery record. The pre-experiment reconstruction below was
committed before the claim-aligned synthetic campaign; the concluding audit
note was added only after the sealed result.

## Recovered claim boundary

The strongest recoverable historical statement is not a generic superiority
claim. At commit `7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc`,
`stage3/tep/protocol.py` defines the primary scientific identity as
`causal_deterministic_bounded_state_temporal_evidence_representation_and_arbitration_core`.
It separates three layers:

1. representation validation;
2. arbitration and external event-authority validation;
3. one TEP `xmeas_7` assurance-channel application.

The same source explicitly prohibits `universal_detector_superiority` and
prohibits defining DMREDA by CUSUM, EWMA, or RMS. This is direct historical
source evidence, not a claim reconstructed from the present task.

`gold_line/support/Framework_v0_design.md` supplies a broader, earlier design
direction: temporal growth, structural bias, bounded multi-axis decision
geometry, and a separation between the signal core and application policy. It
also contains aspirational novelty and publication language. That language is
historical intent only; it is not evidence that separability, usefulness, or
novelty was established.

## Executable objects recovered

### Historical Core

The executable research object is
`gold_line/core/dmreda_reference_clean.py`, SHA-256
`f0a6d72132f8e5ecfadc5d0b9f4f2374b6d417e49f94246c9764bfb21505a4ae`.
It implements this causal path:

```text
fixed external affine scale
-> trailing median mu
-> absolute residual e
-> trailing L1 residual mass E
-> EWMA baseline B
-> normalized deviation D
-> lagged, EWMA-smoothed growth G
-> residual-activity/regime state
-> candidate age + excess area + qualifying count
-> strict confirmation
-> refractory event authority
```

The source variable `e1` is a sum of absolute residuals. It is not a sum of
squares. Historical documents that call it “energy” are terminologically
imprecise. This matters: equal raw RMS or equal squared energy does not by
itself match the statistic consumed by `D`.

The Python function is a full-trace reference and allocates arrays proportional
to trace length. Its recurrence is bounded-state, but that particular batch
implementation is not bounded-memory.

### Fixed C subset

`gold_line/core/dmreda_streaming_fixed.c` and `.h`, SHA-256
`a23919d72229a5c4330e8bdc8b2684ab4899ae48115188a1553bbf842990e25b`
and `b400c5b693ba804069f229d0fa8bc3c4b371fb9a6dfe2f6a3c8347cccb47ac53`,
implement a bounded no-heap state-0 subset. They do not implement the full
adaptive three-regime Python state machine.

### Structural Manifold family

`gold_line/structural_manifold/` is a separate covariance/Mahalanobis/CUSUM
family. It is not the Core and cannot be used to establish Core representation
claims.

### H

The later H implementation is
`current_claim/core/dmreda_minimal_streaming.py`, SHA-256
`e2122ff66c8cdfe3c34eb97340123f6b32a0f7de6948a3507f3f4c58c37f6d9e`.
Its development protocol explicitly optimized a detector-oriented
noninferiority/simplicity rule on spent TEP development data. H retains the
fixed state-0 `mu/e/E/B/D` path and replaces the historical authority system by
six consecutive `D > 0.8` samples plus refractory. It removes `G`, residual
activity/regime state, candidate area, candidate age/timeout, qualifying count
as a non-consecutive statistic, and the opening-time contract. Therefore H is
not presumed equivalent to the historical representation.

## Evidence preserved from finalization

- The Stage 3.3 normal result remains `42/500` trajectories with authority by
  horizon 960 against a maximum of 25. The bound artifact is
  `frozen_history/results/dmreda_normal_summary.json`, SHA-256
  `48c82c94eb61ea618d0d0ad2ffc44c09db9c083e8c006d9ff5efa0d1d230d018`.
- That detector-level gate failed. It is not altered by this pass.
- The finalization development ablation was explicitly non-claim-grade and its
  H selection is reproducible for that objective.
- No defensible fresh Rieth-lineage normal source was established. FaultyTesting
  remains unopened in this pass.
- The exact lineage of historical TEP `kappa=2.5` is unavailable. Protocol prose
  says which bank was spent, but no selection grid/result survives.

## Evidence that is unavailable

- Repository history before the imported snapshot commit `145277854...` is not
  present. The reachable history to `7fb1fe26...` contains 58 commits and no
  tags; it is not the complete development history.
- The historical Layer-A and Layer-B result files named by hashes in the frozen
  protocol are not present as standalone files in this checkout. Their runners
  and tests are present and reproducible.
- The original executable CPython/NumPy environment is described but not
  preserved as immutable bytes; wheel/sdist hashes are absent.
- Raw experiment/acquisition values needed for new real-process generalization
  are not available under a fresh, independent provenance contract.
- No external literature search has yet been performed at this preregistration
  point. Novelty is unknown.

## Recovered research questions

The defensible questions are:

1. Is the prefix-to-state map causal and deterministic?
2. Can the recurrence and authority semantics be implemented with state and
   work independent of stream duration?
3. Which current-state coordinates distinguish temporally reordered histories
   when simple magnitude statistics are exactly matched?
4. Which authority coordinates are behaviorally necessary under a common
   future suffix?
5. Is representation state independent of whether external authority is
   enabled or which authority-opening mode is selected?
6. Which parts of H preserve the historical representation, and which parts
   merely preserve a useful detector path?

Detector superiority, real-process generalization, and novelty remain separate
questions.

## Post-campaign recovery conclusion

The executable and experimental evidence supports the historical protocol's
three-layer reading. The exact residual-order campaign established a scoped
representation property; authority collision tests established that several
temporal registers carry future-behavior semantics; and source/tests established
directional representation-to-authority separation. None of these findings
requires detector superiority.

The earlier finalization remains valid where it said the 42/500 Stage 3.3 gate
failed, provenance did not permit a fresh locked normal run, H has strong
fixed-profile engineering evidence, and detector/real-world/novelty claims were
not established. Its scope error was treating H's detector-oriented selection
as if it could identify or reduce the original structural research object.

Final recovered claim boundary:

```text
primary: causal bounded temporal representation + explicit bounded authority
secondary: detector behavior for a declared application and horizon
unestablished: detector superiority, real-process generalization, novelty
```
