# Preregistration Amendment 002

## Trigger

The first complete result was written and sealed in commit `99ca7bd`. A
deterministic `--verify-existing` rerun then raised a false mismatch. The first
recursive difference was:

```text
$.experiment.history_collisions.age_area_count.contracts[0]
TYPE list tuple
```

JSON serializes both Python tuples and lists as arrays. Direct Python object
equality therefore compared a freshly generated tuple with a loaded JSON list.
A diagnostic canonical-JSON comparison reported exact equality and the same
canonical SHA-256 `9a6b51cf4487c8d559d1d4b5f5def5127dd2ccc41aa426dd8c730c5d10469e2f`
for both runs.

## Amendment

`--verify-existing` now compares canonical JSON bytes rather than Python
container types. No generator, seed, equation, matching constraint, feature,
classifier, bootstrap, authority model, falsification case, metric, or result
value changes.

The original result remains immutable. A separately named V2 result will bind
the verifier-only source change and will be checked through the corrected path.
