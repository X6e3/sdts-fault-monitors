# Preregistration Amendment 001

## Trigger

The first execution attempt from preregistration commit `d49808e` terminated
before writing `CLAIM_ALIGNED_RESULTS.json`. The traceback was:

```text
KeyError: 'R0_e'
```

`_bootstrap_accuracy()` assumed every feature table used the representation
space name `R0_e`. The individual-component ablation table uses the already
frozen semantically corresponding names `residual_e` and `normalized_D`.

## Value-access boundary

- No result artifact was created.
- No metric, class result, matching statistic, or favorable/unfavorable value
  was printed to the terminal.
- The generator completed some calculations in process memory before the
  exception; those values were not exposed to the operator.

## Amendment

Only the generic bootstrap reference-name selection is changed:

- normal representation tables: `R0_e` and `R2_D`;
- individual-component ablation: `residual_e` and `normalized_D`.

Seeds, RNG, generator equations, class definitions, matching constraints,
readouts, classifier, bootstrap seed/replicate count, authority cases,
falsification cases, and claim rules are unchanged.

The amended source hash is bound into the protocol before re-execution. This is
an analysis implementation repair, not a result-conditioned generator or metric
change.
