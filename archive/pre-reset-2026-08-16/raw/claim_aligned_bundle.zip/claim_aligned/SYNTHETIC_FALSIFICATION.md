# Synthetic Falsification

## Frozen campaign

The equations, parameter ranges, seed identities, matching rules, readout
times, metrics, and falsification criteria were committed before claim-bearing
values were generated. The authoritative bindings are:

- protocol file SHA-256
  `bfb8aa186ca26049d6ab1726d318a30c2f33175a9cb579c1a3ba7ba51fc8e40c`;
- protocol payload SHA-256
  `6ff0d0b63d03f872ba33bb42fd1ca9769995b4c130722a641f9688b820c690ac`;
- seed manifest SHA-256
  `f06d59799e9e8d6c908895e494beb40a16ed712fc69f5c30401d795421bae24d`;
- result file SHA-256
  `1a1303cf622f8721d714a2e90694a696cce1d4478eacaece7fec5cdf7917091a`;
- canonical result payload SHA-256
  `ae1ad350bd0ace1e55e6020f6645d170f02a7c47adae2468170ecf01c3cc5556`.

The two amendments are separately committed and did not change generators,
seeds, metrics, or values. The run used 128 training seeds, 128 disjoint test
seeds, PCG64, CPython 3.12.13, NumPy 2.3.5, and 2,000 paired seed-block
bootstrap replicates.

## Supportive test: exact residual-order matching

Six 96-sample residual histories per seed used exactly one shared residual
multiset and a common final 16-sample tail. Duration, peak, sum, RMS, squared
energy, current residual, current 16-sample L1 mass, and sorted residual values
were matched. All 256 seed blocks passed before classification.

Current `e` and current `E` remained at six-class chance (`0.1667`). Current
`D` reached `0.5430`; `(D,G)` reached `0.7552`; and `(D,G,r,a)` reached
`0.7930`. The paired `D+G` minus `D` test-accuracy change was `0.2122`, with
95% seed-block bootstrap interval `[0.1823,0.2435]`.

**[EXPERIMENTALLY SUPPORTED]** The recurrence preserves some ordering
information beyond the matched current magnitude evidence. The experiment is
post-median; raw reachability of every residual history is not established.

## Destructive test: incomplete structural code

The `D+G` confusion matrix heavily confused coherent ramp and blockwise slow
migration. The richer vector is therefore neither injective nor a complete
label-independent description of temporal organization. “Preserves some
distinction” survives; “uniquely identifies temporal structure” is
**[REFUTED]**.

## Destructive test: raw magnitude mismatch

The raw equal-RMS campaign matched duration, RMS `0.5`, and squared energy
`24`, but not peak, mean, or post-median residual histogram. Raw class
accuracies as high as `0.9974` cannot be attributed solely to temporal order.
This prevents favorable but confounded raw results from validating C6/C7.

Readout phase also changes conclusions: `D+G` exceeded `D` at offset 47, but
was worse at offset 95 with paired delta interval
`[-0.0482,-0.0195]`. A global “G always improves representation” claim is
**[REFUTED]**.

## Destructive test: sign reflection

For the paired raw signals `x` and `-x`, every tested absolute-residual Core
field (`e,E,B,D,G,r,a,a_slow,regime,pending,confirmed`) was identical. The
median changed sign and the noncanonical signed-area feature changed from
`+0.995122` to `-0.995122`.

**[REFUTED]** The canonical absolute-residual representation preserves
disturbance direction.

## Destructive test: persistent level step

After a unit step at sample 192, the residual was `1` and `D=5`. By sample 195
the trailing median had moved to `1`, making the instantaneous residual zero.
At sample 223, `E=0` and `D=-1`.

**[REFUTED]** The Core maintains a sustained absolute level representation.
It represents the transition relative to its causal local baseline.

## Destructive test: normalization context

The same injected event produced peak `(D,G)=(5,2.4829)` after stationary
context and only `(2.0447,0.7129)` after migrating context; pre-event baseline
`B` was `0` versus `1.0905`.

**[REFUTED]** `D/G` are invariant properties of an event independent of its
preceding context. Context sensitivity is the mechanism by which history is
retained, but it is also a nuisance/failure mode.

## Boundary and collision adversaries

- timeout/confirmation coincidence confirms because confirmation is evaluated
  first;
- timeout can re-arm on the same sample;
- refractory=3 under continuously high evidence produces events at 0, 3, 6;
- current `(D,G)` collision can diverge on a common future because lag-expiry
  history differs;
- current candidate aggregates collide when age, area, count, opening contract,
  or refractory is omitted.

These cases support deterministic semantics while exposing the exact policy;
they do not assert the policy is optimal for a physical application.

## Falsification ledger

| Proposition | Result | Status |
|---|---|---|
| order survives matched current magnitude | held-out separation in `D`, larger in `D+G` | [EXPERIMENTALLY SUPPORTED] |
| richer representation uniquely encodes shape | ramp/migration collisions remain | [REFUTED] |
| G always improves separation | late raw readout is worse | [REFUTED] |
| representation preserves direction | exact sign-mirror collision | [REFUTED] |
| persistent step stays represented | median adaptation erases residual | [REFUTED] |
| normalized evidence is context invariant | identical injection changes materially | [REFUTED] |
| historical authority has deterministic boundary semantics | all preregistered cases pass | [DIRECTLY ESTABLISHED] |
| synthetic distinctions generalize to TEP/process faults | no fresh real-data experiment | [UNKNOWN] |

## Interpretation limit

Synthetic construction is appropriate for causal-state and collision claims
because exact histories can falsify them. It cannot establish fault prevalence,
operating-risk calibration, physical meaning, or real-process generalization.
