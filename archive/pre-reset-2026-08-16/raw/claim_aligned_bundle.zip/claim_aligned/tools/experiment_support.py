"""Frozen support code for the DMREDA claim-aligned campaign.

The module deliberately separates two experimental layers:

* ``residual_order`` starts after the trailing-median operation.  Every class
  for a seed receives exactly the same residual multiset and common final
  window.  It isolates ordering information in E/B/D/G.
* ``raw_shape`` runs the unmodified historical Core from scalar input.  Its
  injected event families have equal duration and squared energy, but the
  median is allowed to create different residual distributions.  Those
  differences are reported rather than hidden.

No function searches parameters or changes a generator in response to a
result.  Seeds, equations, readout indices, feature spaces, and inference rules
are bound by the adjacent protocol JSON.
"""

from __future__ import annotations

from dataclasses import dataclass
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np

from current_claim.core.dmreda_minimal_streaming import MinimalStreamingDetector
from experimental.finalization.minimal_state_model import (
    MinimalAuthorityState,
    OpenContract,
    step_authority,
)
from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    DMREDAProfile,
    RegimeTransition,
    compute_dmreda_reference,
)


SCHEMA = "dmreda.claim-aligned.experiment.v1"
LENGTH = 512
ONSET = 192
EVENT_LENGTH = 96
EVENT_END = ONSET + EVENT_LENGTH - 1
READOUT_OFFSETS = (15, 47, 95)
RESIDUAL_CLASSES = (
    "coherent_ramp",
    "incoherent_noise",
    "transient_pulse",
    "sustained_step",
    "oscillatory_excursion",
    "slow_bias_migration",
)
RAW_CLASSES = RESIDUAL_CLASSES
BOOTSTRAP_REPLICATES = 2000
BOOTSTRAP_SEED = 2026081403
MATCH_ATOL = 1e-12
CONSTANT_FEATURE_TOLERANCE = 1e-10


def canonical_json_bytes(payload: object) -> bytes:
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")


def canonical_sha256(payload: object) -> str:
    return hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_sha256(values: np.ndarray) -> str:
    array = np.asarray(values, dtype="<f8")
    return hashlib.sha256(array.tobytes(order="C")).hexdigest()


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def fixed_residual_representation(
    residuals: Sequence[float],
    profile: DMREDAProfile = DEFAULT_PROFILES[0],
) -> dict[str, np.ndarray]:
    """Run the fixed state-0 post-median E/B/D/G/r recurrence.

    This is a diagnostic recurrence, not a replacement Core implementation.
    Input values are non-negative exogenous residuals.
    """

    e = np.asarray(residuals, dtype=np.float64)
    if e.ndim != 1 or e.size == 0 or not np.all(np.isfinite(e)):
        raise ValueError("residuals must be a finite non-empty 1-D sequence")
    if np.any(e < 0.0):
        raise ValueError("residuals must be non-negative")

    n = e.size
    mass = np.zeros(n, dtype=np.float64)
    baseline = np.zeros(n, dtype=np.float64)
    d_value = np.zeros(n, dtype=np.float64)
    g_raw = np.zeros(n, dtype=np.float64)
    growth = np.zeros(n, dtype=np.float64)
    activity = np.zeros(n, dtype=np.float64)
    aggressiveness = np.zeros(n, dtype=np.float64)
    ring = np.zeros(profile.w2, dtype=np.float64)
    ring_count = 0
    ring_pos = 0
    running = 0.0
    for index, value in enumerate(e.tolist()):
        if ring_count < profile.w2:
            ring_count += 1
        else:
            running -= float(ring[ring_pos])
        ring[ring_pos] = value
        running += value
        ring_pos = (ring_pos + 1) % profile.w2
        mass[index] = running
        if index == 0:
            baseline[index] = running
            activity[index] = value
        else:
            baseline[index] = (
                profile.beta * running
                + (1.0 - profile.beta) * baseline[index - 1]
            )
            activity[index] = (
                profile.rho * value
                + (1.0 - profile.rho) * activity[index - 1]
            )
        safe = max(float(baseline[index]), profile.e_floor)
        d_value[index] = _clamp((running - safe) / safe, -5.0, 5.0)
        g_raw[index] = (
            d_value[index] - d_value[index - profile.m_base]
            if index >= profile.m_base
            else 0.0
        )
        growth[index] = (
            g_raw[index]
            if index == 0
            else profile.lam * g_raw[index]
            + (1.0 - profile.lam) * growth[index - 1]
        )
        aggressiveness[index] = _clamp(
            abs(float(growth[index])) / profile.g_ref,
            0.0,
            1.0,
        )
    return {
        "e": e,
        "E": mass,
        "B": baseline,
        "D": d_value,
        "G_raw": g_raw,
        "G": growth,
        "r": activity,
        "a": aggressiveness,
    }


def _center_cluster(values: np.ndarray) -> np.ndarray:
    result = np.empty_like(values)
    center = (values.size - 1) / 2.0
    positions = sorted(range(values.size), key=lambda i: (abs(i - center), i))
    descending = np.sort(values)[::-1]
    for position, value in zip(positions, descending, strict=True):
        result[position] = value
    return result


def _alternating_extremes(values: np.ndarray) -> np.ndarray:
    ordered = np.sort(values)
    result: list[float] = []
    low = 0
    high = ordered.size - 1
    while low <= high:
        result.append(float(ordered[high]))
        high -= 1
        if low <= high:
            result.append(float(ordered[low]))
            low += 1
    return np.asarray(result, dtype=np.float64)


def _step_block(values: np.ndarray) -> np.ndarray:
    ordered = np.sort(values)
    low = ordered[:40]
    middle = ordered[40:48]
    high = ordered[48:]
    return np.concatenate([low[:20], middle, high, low[20:]])


def _blockwise_migration(values: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    ordered = np.sort(values)
    blocks = np.array_split(ordered, 8)
    return np.concatenate([rng.permutation(block) for block in blocks])


def generate_residual_order_family(seed: int) -> dict[str, np.ndarray]:
    """Generate six exact-shared-multiset residual histories for one seed."""

    rng = np.random.default_rng(seed)
    prefix = rng.uniform(0.15, 0.25, ONSET)
    low = rng.uniform(0.15, 0.25, 40)
    middle = rng.uniform(0.35, 0.65, 8)
    high = rng.uniform(0.75, 0.85, 32)
    body = np.concatenate([low, middle, high])
    tail = rng.uniform(0.15, 0.25, 16)
    suffix = rng.uniform(0.15, 0.25, LENGTH - ONSET - EVENT_LENGTH)

    orders = {
        "coherent_ramp": np.sort(body),
        "incoherent_noise": rng.permutation(body),
        "transient_pulse": _center_cluster(body),
        "sustained_step": _step_block(body),
        "oscillatory_excursion": _alternating_extremes(body),
        "slow_bias_migration": _blockwise_migration(body, rng),
    }
    return {
        name: np.concatenate([prefix, order, tail, suffix]).astype(np.float64)
        for name, order in orders.items()
    }


def _raw_prototypes(seed: int) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    u = np.linspace(0.0, 1.0, EVENT_LENGTH, endpoint=True)
    pulse_axis = np.linspace(-3.0, 3.0, EVENT_LENGTH, endpoint=True)
    prototypes = {
        "coherent_ramp": u,
        "incoherent_noise": rng.normal(0.0, 1.0, EVENT_LENGTH),
        "transient_pulse": np.exp(-0.5 * pulse_axis**2),
        "sustained_step": np.ones(EVENT_LENGTH, dtype=np.float64),
        "oscillatory_excursion": np.sin(2.0 * np.pi * 6.0 * u),
        "slow_bias_migration": u**2,
    }
    target_rms = 0.5
    normalized: dict[str, np.ndarray] = {}
    for name, values in prototypes.items():
        rms = float(np.sqrt(np.mean(values**2)))
        if rms <= 0.0:
            raise AssertionError("raw prototype has zero RMS")
        normalized[name] = np.asarray(values * (target_rms / rms), dtype=np.float64)
    return normalized


def generate_raw_shape_family(seed: int) -> dict[str, np.ndarray]:
    """Generate equal-duration, equal-squared-energy raw signal families."""

    rng = np.random.default_rng(seed ^ 0x5A17)
    prefix = rng.normal(0.0, 0.03, ONSET)
    suffix = rng.normal(0.0, 0.03, LENGTH - ONSET - EVENT_LENGTH)
    return {
        name: np.concatenate([prefix, event, suffix]).astype(np.float64)
        for name, event in _raw_prototypes(seed).items()
    }


def _signed_area(signal: np.ndarray, index: int, width: int = 16) -> float:
    start = max(0, index - width + 1)
    segment = signal[start : index + 1]
    rms = float(np.sqrt(np.mean(segment**2)))
    return float(np.mean(segment) / max(rms, 1e-12))


def _fixed_core(signal: np.ndarray):
    profile = DEFAULT_PROFILES[0]
    return compute_dmreda_reference(
        signal,
        profiles={0: profile},
        transitions={0: RegimeTransition()},
        regime_tick=LENGTH + 1,
        initial_state=0,
        warmup_samples=0,
        mode="D_or_G",
    )


def _adaptive_core(signal: np.ndarray):
    return compute_dmreda_reference(signal, warmup_samples=0, mode="D_or_G")


def _space_vectors_from_residual(
    trace: Mapping[str, np.ndarray],
    index: int,
) -> dict[str, list[float]]:
    return {
        "R0_e": [float(trace["e"][index])],
        "R1_E": [float(trace["E"][index])],
        "R2_D": [float(trace["D"][index])],
        "R3_D_G": [float(trace["D"][index]), float(trace["G"][index])],
        "R4_core_evidence": [
            float(trace["D"][index]),
            float(trace["G"][index]),
            float(trace["r"][index]),
            float(trace["a"][index]),
        ],
    }


def _space_vectors_from_core(result, signal: np.ndarray, index: int) -> dict[str, list[float]]:
    return {
        "R0_e": [float(result.e[index])],
        "R1_E": [float(result.e1[index])],
        "R2_D": [float(result.d[index])],
        "R3_D_G": [float(result.d[index]), float(result.g[index])],
        "R4_core_evidence": [
            float(result.d[index]),
            float(result.g[index]),
            float(result.r[index]),
            float(result.a_slow[index]),
            float(result.state[index]),
            float(result.m_eff[index]),
            float(result.confirm_len_eff[index]),
        ],
        "R5_noncanonical_signed_area": [
            float(result.d[index]),
            float(result.g[index]),
            _signed_area(signal, index),
        ],
    }


def verify_residual_matching(family: Mapping[str, np.ndarray]) -> dict[str, object]:
    reference = family[RESIDUAL_CLASSES[0]][ONSET : ONSET + EVENT_LENGTH]
    reference_sorted = np.sort(reference)
    rows: dict[str, object] = {}
    all_passed = True
    reference_trace = fixed_residual_representation(family[RESIDUAL_CLASSES[0]])
    for name in RESIDUAL_CLASSES:
        event = family[name][ONSET : ONSET + EVENT_LENGTH]
        trace = fixed_residual_representation(family[name])
        checks = {
            "duration_equal": event.size == reference.size,
            "sorted_residuals_bit_equal": np.array_equal(np.sort(event), reference_sorted),
            "sum_within_tolerance": math.isclose(
                float(np.sum(event)),
                float(np.sum(reference)),
                rel_tol=0.0,
                abs_tol=MATCH_ATOL,
            ),
            "squared_energy_within_tolerance": math.isclose(
                float(np.sum(event**2)),
                float(np.sum(reference**2)),
                rel_tol=0.0,
                abs_tol=MATCH_ATOL,
            ),
            "rms_within_tolerance": math.isclose(
                float(np.sqrt(np.mean(event**2))),
                float(np.sqrt(np.mean(reference**2))),
                rel_tol=0.0,
                abs_tol=MATCH_ATOL,
            ),
            "peak_equal": float(np.max(event)) == float(np.max(reference)),
            "common_final_16_bit_equal": np.array_equal(event[-16:], reference[-16:]),
            "current_e_bit_equal": float(trace["e"][EVENT_END])
            == float(reference_trace["e"][EVENT_END]),
            "current_E_within_tolerance": math.isclose(
                float(trace["E"][EVENT_END]),
                float(reference_trace["E"][EVENT_END]),
                rel_tol=0.0,
                abs_tol=MATCH_ATOL,
            ),
        }
        all_passed = all_passed and all(checks.values())
        rows[name] = {
            "checks": checks,
            "event_sha256": array_sha256(event),
            "sorted_event_sha256": array_sha256(np.sort(event)),
            "sum": float(np.sum(event)),
            "squared_energy": float(np.sum(event**2)),
            "rms": float(np.sqrt(np.mean(event**2))),
            "peak": float(np.max(event)),
            "readout_e": float(trace["e"][EVENT_END]),
            "readout_E": float(trace["E"][EVENT_END]),
        }
    return {"all_passed": all_passed, "rows": rows}


def verify_raw_matching(family: Mapping[str, np.ndarray]) -> dict[str, object]:
    rows: dict[str, object] = {}
    energies: list[float] = []
    for name in RAW_CLASSES:
        event = family[name][ONSET : ONSET + EVENT_LENGTH]
        energy = float(np.sum(event**2))
        energies.append(energy)
        rows[name] = {
            "duration": int(event.size),
            "squared_energy": energy,
            "rms": float(np.sqrt(np.mean(event**2))),
            "peak_absolute": float(np.max(np.abs(event))),
            "mean": float(np.mean(event)),
            "event_sha256": array_sha256(event),
        }
    return {
        "all_duration_equal": len({row["duration"] for row in rows.values()}) == 1,
        "all_energy_within_tolerance": max(energies) - min(energies) <= MATCH_ATOL,
        "all_rms_within_tolerance": max(row["rms"] for row in rows.values())
        - min(row["rms"] for row in rows.values())
        <= MATCH_ATOL,
        "peak_was_not_matched": len(
            {round(float(row["peak_absolute"]), 12) for row in rows.values()}
        )
        > 1,
        "rows": rows,
    }


def _fit_nearest_centroid(
    train_rows: Sequence[Mapping[str, object]],
    test_rows: Sequence[Mapping[str, object]],
    space: str,
    classes: Sequence[str],
) -> dict[str, object]:
    train_x = np.asarray([row["spaces"][space] for row in train_rows], dtype=np.float64)
    test_x = np.asarray([row["spaces"][space] for row in test_rows], dtype=np.float64)
    train_y = np.asarray([str(row["class"]) for row in train_rows])
    test_y = np.asarray([str(row["class"]) for row in test_rows])
    mean = np.mean(train_x, axis=0)
    scale = np.std(train_x, axis=0)
    variable = scale > CONSTANT_FEATURE_TOLERANCE
    scale = np.where(variable, scale, 1.0)
    train_z = (train_x - mean) / scale
    test_z = (test_x - mean) / scale
    train_z[:, ~variable] = 0.0
    test_z[:, ~variable] = 0.0
    centroids = {
        name: np.mean(train_z[train_y == name], axis=0) for name in classes
    }
    distances = np.stack(
        [np.sum((test_z - centroids[name]) ** 2, axis=1) for name in classes],
        axis=1,
    )
    predictions = np.asarray([classes[index] for index in np.argmin(distances, axis=1)])
    correct = predictions == test_y
    per_class = {
        name: float(np.mean(correct[test_y == name])) for name in classes
    }
    confusion = {
        actual: {
            predicted: int(np.count_nonzero((test_y == actual) & (predictions == predicted)))
            for predicted in classes
        }
        for actual in classes
    }

    within_values = []
    for name in classes:
        members = train_z[train_y == name]
        within_values.extend(np.sum((members - centroids[name]) ** 2, axis=1).tolist())
    centroid_values = np.stack([centroids[name] for name in classes])
    global_centroid = np.mean(centroid_values, axis=0)
    between = float(np.mean(np.sum((centroid_values - global_centroid) ** 2, axis=1)))
    within = float(np.mean(within_values))
    return {
        "space": space,
        "dimension": int(train_x.shape[1]),
        "accuracy": float(np.mean(correct)),
        "macro_accuracy": float(np.mean(list(per_class.values()))),
        "per_class_accuracy": per_class,
        "confusion": confusion,
        "within_class_squared_distance": within,
        "between_centroid_squared_distance": between,
        "fisher_trace_ratio": between / max(within, 1e-15),
        "test_predictions": predictions.tolist(),
        "test_truth": test_y.tolist(),
        "test_seeds": [int(row["seed"]) for row in test_rows],
    }


def _bootstrap_accuracy(
    fitted: Mapping[str, Mapping[str, object]],
    test_seeds: Sequence[int],
    *,
    magnitude_reference_space: str,
    d_reference_space: str,
) -> dict[str, object]:
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    seeds = np.asarray(test_seeds, dtype=np.int64)
    spaces = sorted(fitted)
    correctness: dict[str, dict[int, list[bool]]] = {}
    for space in spaces:
        entry = fitted[space]
        by_seed: dict[int, list[bool]] = {int(seed): [] for seed in seeds}
        for seed, prediction, truth in zip(
            entry["test_seeds"],
            entry["test_predictions"],
            entry["test_truth"],
            strict=True,
        ):
            by_seed[int(seed)].append(prediction == truth)
        correctness[space] = by_seed

    samples = {space: [] for space in spaces}
    deltas_r0 = {space: [] for space in spaces}
    deltas_r2 = {space: [] for space in spaces}
    for _ in range(BOOTSTRAP_REPLICATES):
        selected = rng.choice(seeds, size=seeds.size, replace=True)
        values: dict[str, float] = {}
        for space in spaces:
            flags = [flag for seed in selected for flag in correctness[space][int(seed)]]
            values[space] = float(np.mean(flags))
            samples[space].append(values[space])
        for space in spaces:
            deltas_r0[space].append(
                values[space] - values[magnitude_reference_space]
            )
            deltas_r2[space].append(values[space] - values[d_reference_space])

    def interval(values: Sequence[float]) -> list[float]:
        return [
            float(np.quantile(values, 0.025)),
            float(np.quantile(values, 0.975)),
        ]

    return {
        space: {
            "accuracy_95_percentile_interval": interval(samples[space]),
            "delta_vs_R0_95_percentile_interval": interval(deltas_r0[space]),
            "delta_vs_R2_95_percentile_interval": interval(deltas_r2[space]),
        }
        for space in spaces
    }


def classify_spaces(
    rows: Sequence[Mapping[str, object]],
    train_seeds: Sequence[int],
    test_seeds: Sequence[int],
    classes: Sequence[str],
) -> dict[str, object]:
    train_set = set(train_seeds)
    test_set = set(test_seeds)
    train_rows = [row for row in rows if int(row["seed"]) in train_set]
    test_rows = [row for row in rows if int(row["seed"]) in test_set]
    spaces = sorted(train_rows[0]["spaces"])
    magnitude_reference_space = (
        "R0_e" if "R0_e" in spaces else "residual_e"
    )
    d_reference_space = (
        "R2_D" if "R2_D" in spaces else "normalized_D"
    )
    if magnitude_reference_space not in spaces or d_reference_space not in spaces:
        raise ValueError("feature spaces lack declared magnitude/D references")
    fitted = {
        space: _fit_nearest_centroid(train_rows, test_rows, space, classes)
        for space in spaces
    }
    bootstrap = _bootstrap_accuracy(
        fitted,
        test_seeds,
        magnitude_reference_space=magnitude_reference_space,
        d_reference_space=d_reference_space,
    )
    for entry in fitted.values():
        entry.pop("test_predictions")
        entry.pop("test_truth")
        entry.pop("test_seeds")
    return {
        "classifier": "nearest centroid after train-only z scaling",
        "chance_accuracy": 1.0 / len(classes),
        "train_seed_count": len(train_seeds),
        "test_seed_count": len(test_seeds),
        "spaces": fitted,
        "paired_seed_bootstrap": {
            "replicates": BOOTSTRAP_REPLICATES,
            "seed": BOOTSTRAP_SEED,
            "resampling_unit": "seed block containing all classes",
            "intervals": bootstrap,
            "magnitude_reference_space": magnitude_reference_space,
            "D_reference_space": d_reference_space,
        },
    }


def _collision_summary(rows: Sequence[Mapping[str, object]]) -> dict[str, object]:
    by_seed: dict[int, list[Mapping[str, object]]] = {}
    for row in rows:
        by_seed.setdefault(int(row["seed"]), []).append(row)
    spaces = sorted(rows[0]["spaces"])
    summary: dict[str, object] = {}
    for space in spaces:
        unique_counts = []
        for seed_rows in by_seed.values():
            encodings = {
                tuple(round(float(value), 12) for value in row["spaces"][space])
                for row in seed_rows
            }
            unique_counts.append(len(encodings))
        summary[space] = {
            "seed_blocks": len(unique_counts),
            "all_classes_collide_seed_count": int(np.count_nonzero(np.asarray(unique_counts) == 1)),
            "mean_unique_states_among_six_classes": float(np.mean(unique_counts)),
            "minimum_unique_states": int(min(unique_counts)),
            "maximum_unique_states": int(max(unique_counts)),
        }
    return summary


def run_residual_order_campaign(
    train_seeds: Sequence[int],
    test_seeds: Sequence[int],
) -> dict[str, object]:
    rows: list[dict[str, object]] = []
    matching_rows: list[dict[str, object]] = []
    for seed in [*train_seeds, *test_seeds]:
        family = generate_residual_order_family(int(seed))
        matching = verify_residual_matching(family)
        matching_rows.append({"seed": int(seed), **matching})
        for name in RESIDUAL_CLASSES:
            trace = fixed_residual_representation(family[name])
            rows.append(
                {
                    "seed": int(seed),
                    "class": name,
                    "readout_index": EVENT_END,
                    "spaces": _space_vectors_from_residual(trace, EVENT_END),
                }
            )
    return {
        "layer": "post_median_residual_recurrence",
        "interpretation_limit": (
            "establishes ordering behavior of E/B/D/G given exogenous residuals; "
            "does not establish that the raw median produces those residual histories"
        ),
        "classes": list(RESIDUAL_CLASSES),
        "matching": {
            "all_seed_blocks_pass": all(row["all_passed"] for row in matching_rows),
            "seed_block_count": len(matching_rows),
            "first_seed_detail": matching_rows[0],
        },
        "readout_index": EVENT_END,
        "collision_summary": _collision_summary(rows),
        "separability": classify_spaces(rows, train_seeds, test_seeds, RESIDUAL_CLASSES),
        "row_count": len(rows),
        "rows_sha256": canonical_sha256(rows),
    }


def _individual_component_rows(
    seed: int,
    name: str,
    signal: np.ndarray,
    fixed,
    adaptive,
    index: int,
) -> dict[str, object]:
    return {
        "seed": int(seed),
        "class": name,
        "readout_index": index,
        "spaces": _space_vectors_from_core(adaptive, signal, index),
        "components": {
            "raw_magnitude": [float(abs(signal[index]))],
            "median": [float(adaptive.mu[index])],
            "residual_e": [float(adaptive.e[index])],
            "residual_mass_E": [float(adaptive.e1[index])],
            "baseline_B": [float(adaptive.e_baseline[index])],
            "normalized_D": [float(adaptive.d[index])],
            "growth_G": [float(adaptive.g[index])],
            "activity_r": [float(adaptive.r[index])],
            "slow_activity": [float(adaptive.a_slow[index])],
            "regime_state": [float(adaptive.state[index])],
            "fixed_D": [float(fixed.d[index])],
            "fixed_G": [float(fixed.g[index])],
            "noncanonical_signed_area": [_signed_area(signal, index)],
        },
    }


def run_raw_shape_campaign(
    train_seeds: Sequence[int],
    test_seeds: Sequence[int],
) -> dict[str, object]:
    primary_rows: list[dict[str, object]] = []
    per_readout: dict[str, list[dict[str, object]]] = {
        str(offset): [] for offset in READOUT_OFFSETS
    }
    matching_rows: list[dict[str, object]] = []
    residual_histogram_distances: dict[str, list[float]] = {
        name: [] for name in RAW_CLASSES
    }
    for seed in [*train_seeds, *test_seeds]:
        family = generate_raw_shape_family(int(seed))
        matching_rows.append({"seed": int(seed), **verify_raw_matching(family)})
        reference_sorted_residual = None
        for name in RAW_CLASSES:
            signal = family[name]
            fixed = _fixed_core(signal)
            adaptive = _adaptive_core(signal)
            event_residual = np.sort(adaptive.e[ONSET : ONSET + EVENT_LENGTH])
            if reference_sorted_residual is None:
                reference_sorted_residual = event_residual
            residual_histogram_distances[name].append(
                float(np.sqrt(np.mean((event_residual - reference_sorted_residual) ** 2)))
            )
            for offset in READOUT_OFFSETS:
                index = ONSET + offset
                row = _individual_component_rows(
                    int(seed), name, signal, fixed, adaptive, index
                )
                per_readout[str(offset)].append(row)
                if offset == READOUT_OFFSETS[-1]:
                    primary_rows.append(row)

    separability_by_readout = {
        offset: classify_spaces(rows, train_seeds, test_seeds, RAW_CLASSES)
        for offset, rows in per_readout.items()
    }
    component_rows = [
        {
            "seed": row["seed"],
            "class": row["class"],
            "spaces": row["components"],
        }
        for row in primary_rows
    ]
    return {
        "layer": "end_to_end_raw_signal_core",
        "classes": list(RAW_CLASSES),
        "matching": {
            "all_seed_blocks_duration_energy_rms_pass": all(
                row["all_duration_equal"]
                and row["all_energy_within_tolerance"]
                and row["all_rms_within_tolerance"]
                for row in matching_rows
            ),
            "peak_intentionally_not_matched": all(
                row["peak_was_not_matched"] for row in matching_rows
            ),
            "seed_block_count": len(matching_rows),
            "first_seed_detail": matching_rows[0],
        },
        "residual_histogram_rmse_vs_coherent_ramp": {
            name: {
                "mean": float(np.mean(values)),
                "maximum": float(np.max(values)),
            }
            for name, values in residual_histogram_distances.items()
        },
        "readout_offsets": list(READOUT_OFFSETS),
        "primary_readout_offset": READOUT_OFFSETS[-1],
        "separability_by_readout": separability_by_readout,
        "component_ablation_at_primary_readout": classify_spaces(
            component_rows,
            train_seeds,
            test_seeds,
            RAW_CLASSES,
        ),
        "primary_collision_summary": _collision_summary(primary_rows),
        "row_count": sum(len(rows) for rows in per_readout.values()),
        "rows_sha256": canonical_sha256(per_readout),
    }


def run_sign_blindness_case() -> dict[str, object]:
    signal = np.zeros(256, dtype=np.float64)
    signal[96:160] = np.linspace(0.0, 1.0, 64)
    positive = _adaptive_core(signal)
    negative = _adaptive_core(-signal)
    fields = (
        "e",
        "e1",
        "e_baseline",
        "d",
        "g_raw",
        "g",
        "r",
        "a",
        "a_slow",
        "state",
        "m_eff",
        "confirm_len_eff",
        "pending",
        "confirmed",
    )
    equality = {
        field: bool(np.array_equal(getattr(positive, field), getattr(negative, field)))
        for field in fields
    }
    return {
        "case": "sign_mirror",
        "raw_signals_differ": not np.array_equal(signal, -signal),
        "median_sign_reverses": bool(np.array_equal(positive.mu, -negative.mu)),
        "field_equality": equality,
        "all_claim_bearing_core_fields_equal": all(equality.values()),
        "positive_signed_area": _signed_area(signal, 150),
        "negative_signed_area": _signed_area(-signal, 150),
        "interpretation": (
            "absolute-residual Core is direction-blind under exact sign reflection; "
            "the historically proposed signed-area extension is not direction-blind"
        ),
    }


def run_step_adaptation_case() -> dict[str, object]:
    signal = np.zeros(512, dtype=np.float64)
    signal[192:] = 1.0
    result = _adaptive_core(signal)
    checkpoints = (192, 195, 199, 223, 287, 511)
    return {
        "case": "persistent_step_adaptation",
        "checkpoints": {
            str(index): {
                "median": float(result.mu[index]),
                "residual": float(result.e[index]),
                "E": float(result.e1[index]),
                "D": float(result.d[index]),
                "G": float(result.g[index]),
            }
            for index in checkpoints
        },
        "late_residual_is_zero": float(result.e[-1]) == 0.0,
        "late_D": float(result.d[-1]),
        "interpretation": (
            "the trailing median adapts to a persistent level step; the Core represents "
            "the transition, not indefinite absolute level offset"
        ),
    }


def run_baseline_contamination_case() -> dict[str, object]:
    stationary = np.zeros(512, dtype=np.float64)
    migrating = np.zeros(512, dtype=np.float64)
    migrating[:256] = 0.25 * np.sin(np.linspace(0.0, 12.0 * np.pi, 256))
    event = np.zeros(512, dtype=np.float64)
    event[256:272] = 1.0
    stationary += event
    migrating += event
    first = _adaptive_core(stationary)
    second = _adaptive_core(migrating)
    window = slice(256, 288)
    return {
        "case": "normalization_context_dependence",
        "same_injected_event": True,
        "stationary": {
            "pre_event_B": float(first.e_baseline[255]),
            "peak_D": float(np.max(first.d[window])),
            "peak_G": float(np.max(first.g[window])),
        },
        "migrating": {
            "pre_event_B": float(second.e_baseline[255]),
            "peak_D": float(np.max(second.d[window])),
            "peak_G": float(np.max(second.g[window])),
        },
        "interpretation": (
            "D/G are contextual normalized evidence, not event-only invariants; "
            "baseline motion can suppress or reshape identical injected events"
        ),
    }


def _authority_trace(
    d_values: Sequence[float],
    *,
    contract: OpenContract,
    th_d: float = 0.35,
    th_g: float = 0.10,
    g_values: Sequence[float] | None = None,
    mode: str = "d_only",
    enabled_values: Sequence[bool] | None = None,
) -> dict[str, object]:
    g_values = [0.0] * len(d_values) if g_values is None else list(g_values)
    enabled_values = (
        [True] * len(d_values) if enabled_values is None else list(enabled_values)
    )
    if not (len(d_values) == len(g_values) == len(enabled_values)):
        raise ValueError("authority input lengths differ")
    state = MinimalAuthorityState()
    rows: list[dict[str, object]] = []
    for index, (d_value, g_value, enabled) in enumerate(
        zip(d_values, g_values, enabled_values, strict=True)
    ):
        output = step_authority(
            state,
            d_value=float(d_value),
            g_value=float(g_value),
            th_d=th_d,
            th_g=th_g,
            current_contract=contract,
            mode=mode,
            authority_enabled=bool(enabled),
        )
        rows.append(
            {
                "index": index,
                "D": float(d_value),
                "G": float(g_value),
                "enabled": bool(enabled),
                "pending_output": output.pending,
                "confirmed": output.confirmed,
                "ell_end": state.ell,
                "area_end": state.area,
                "count_end": state.count,
                "refractory_end": state.refractory_remaining,
            }
        )
    return {
        "rows": rows,
        "event_indices": [row["index"] for row in rows if row["confirmed"]],
        "pending_indices": [row["index"] for row in rows if row["pending_output"]],
        "end_state": {
            "ell": state.ell,
            "area": state.area,
            "count": state.count,
            "refractory_remaining": state.refractory_remaining,
        },
    }


@dataclass
class LiteralAuthorityState:
    pending_start: int = -1
    elapsed: int = 0
    area: float = 0.0
    count: int = 0
    contract: OpenContract | None = None
    refractory: int = 0
    index: int = 0


def _literal_step(
    state: LiteralAuthorityState,
    *,
    d_value: float,
    g_value: float,
    th_d: float,
    th_g: float,
    current_contract: OpenContract,
    mode: str,
    authority_enabled: bool,
) -> tuple[bool, bool]:
    if state.refractory > 0:
        state.refractory -= 1
    pending_output = False
    confirmed = False
    if authority_enabled:
        if state.pending_start >= 0:
            pending_output = True
            state.elapsed += 1
            assert state.contract is not None
            state.area += max(0.0, d_value - state.contract.th_d2)
            state.count += int(d_value > state.contract.th_d2)
            if state.area > state.contract.th_a and state.count >= state.contract.n_min:
                state.refractory = state.contract.refractory
                state.pending_start = -1
                state.elapsed = 0
                state.area = 0.0
                state.count = 0
                state.contract = None
                confirmed = True
            elif state.elapsed >= state.contract.confirm_len:
                state.pending_start = -1
                state.elapsed = 0
                state.area = 0.0
                state.count = 0
                state.contract = None
        trigger = {
            "d_only": d_value > th_d,
            "g_only": g_value > th_g,
            "d_or_g": d_value > th_d or g_value > th_g,
        }[mode]
        if (
            state.pending_start < 0
            and not confirmed
            and state.refractory == 0
            and trigger
        ):
            state.pending_start = state.index
            state.elapsed = 1
            state.area = max(0.0, d_value - current_contract.th_d2)
            state.count = int(d_value > current_contract.th_d2)
            state.contract = current_contract
            pending_output = True
            if state.area > current_contract.th_a and state.count >= current_contract.n_min:
                state.refractory = current_contract.refractory
                state.pending_start = -1
                state.elapsed = 0
                state.area = 0.0
                state.count = 0
                state.contract = None
                confirmed = True
    state.index += 1
    return pending_output, confirmed


def _contract_key(contract: OpenContract | None) -> tuple[object, ...] | None:
    if contract is None:
        return None
    return (
        contract.confirm_len,
        contract.th_d2.hex(),
        contract.th_a.hex(),
        contract.n_min,
        contract.refractory,
    )


def _minimal_key(state: MinimalAuthorityState) -> tuple[object, ...]:
    return (
        state.ell,
        state.area.hex(),
        state.count,
        _contract_key(state.open_contract),
        state.refractory_remaining,
    )


def _literal_reduced_key(state: LiteralAuthorityState) -> tuple[object, ...]:
    return (
        state.elapsed if state.pending_start >= 0 else 0,
        state.area.hex(),
        state.count,
        _contract_key(state.contract),
        state.refractory,
    )


def bounded_exhaustive_authority_equivalence(depth: int = 8) -> dict[str, object]:
    contracts = (
        OpenContract(3, 0.2, 0.9, 2, 2),
        OpenContract(4, 0.4, 1.4, 3, 3),
    )
    inputs = tuple(
        itertools.product(
            (-0.5, 0.3, 1.2),
            (-0.2, 0.2),
            range(len(contracts)),
            (False, True),
        )
    )
    mode_results: dict[str, object] = {}
    total_transitions = 0
    for mode in ("d_only", "g_only", "d_or_g"):
        frontier = [(MinimalAuthorityState(), LiteralAuthorityState())]
        visited: set[tuple[object, ...]] = set()
        mismatches: list[dict[str, object]] = []
        transitions = 0
        for _ in range(depth):
            next_frontier: dict[
                tuple[tuple[object, ...], tuple[object, ...]],
                tuple[MinimalAuthorityState, LiteralAuthorityState],
            ] = {}
            for minimal, literal in frontier:
                pair_key = (_minimal_key(minimal), _literal_reduced_key(literal))
                if pair_key in visited:
                    continue
                visited.add(pair_key)
                for d_value, g_value, contract_index, enabled in inputs:
                    m_next = copy.deepcopy(minimal)
                    l_next = copy.deepcopy(literal)
                    contract = contracts[int(contract_index)]
                    m_output = step_authority(
                        m_next,
                        d_value=float(d_value),
                        g_value=float(g_value),
                        th_d=0.5,
                        th_g=0.1,
                        current_contract=contract,
                        mode=mode,
                        authority_enabled=bool(enabled),
                    )
                    l_output = _literal_step(
                        l_next,
                        d_value=float(d_value),
                        g_value=float(g_value),
                        th_d=0.5,
                        th_g=0.1,
                        current_contract=contract,
                        mode=mode,
                        authority_enabled=bool(enabled),
                    )
                    transitions += 1
                    if (
                        (m_output.pending, m_output.confirmed) != l_output
                        or _minimal_key(m_next) != _literal_reduced_key(l_next)
                    ):
                        mismatches.append(
                            {
                                "input": [d_value, g_value, contract_index, enabled],
                                "minimal_output": [m_output.pending, m_output.confirmed],
                                "literal_output": list(l_output),
                            }
                        )
                        break
                    next_key = (_minimal_key(m_next), _literal_reduced_key(l_next))
                    next_frontier.setdefault(next_key, (m_next, l_next))
                if mismatches:
                    break
            frontier = list(next_frontier.values())
            if mismatches:
                break
        total_transitions += transitions
        mode_results[mode] = {
            "visited_state_pairs": len(visited),
            "transitions_checked": transitions,
            "mismatch_count": len(mismatches),
            "first_mismatch": mismatches[0] if mismatches else None,
        }
    return {
        "depth": depth,
        "input_alphabet_size": len(inputs),
        "modes": mode_results,
        "total_transitions_checked": total_transitions,
        "all_equivalent_within_bound": all(
            row["mismatch_count"] == 0 for row in mode_results.values()
        ),
        "limitation": (
            "bounded exhaustive equivalence over the declared finite alphabet and depth; "
            "not a proof for all real-valued inputs or global state minimality"
        ),
    }


def run_authority_semantics() -> dict[str, object]:
    ordinary = OpenContract(4, 0.2, 1.8, 3, 3)
    quick = OpenContract(4, 0.0, 0.0, 1, 3)
    inclusive = OpenContract(3, 0.2, 1.8, 3, 3)
    timeout = OpenContract(2, 99.0, 999.0, 2, 3)
    cases = {
        "isolated_high_evidence": _authority_trace(
            [2.0, 0.0, 0.0, 0.0, 0.0], contract=ordinary
        ),
        "sustained_coherent_evidence": _authority_trace(
            [1.0, 1.0, 1.0, 0.0], contract=ordinary
        ),
        "insufficient_persistence_timeout": _authority_trace(
            [1.0, 0.0, 0.0, 0.0, 0.0], contract=ordinary
        ),
        "refractory_bounded_retrigger": _authority_trace(
            [1.0] * 8, contract=quick
        ),
        "recovery_after_evidence_collapse": _authority_trace(
            [1.0, 0.0, 0.0, 0.0, 0.0, 0.0], contract=quick
        ),
        "confirmation_wins_at_inclusive_boundary": _authority_trace(
            [1.0, 1.0, 1.0], contract=inclusive
        ),
        "timeout_then_same_sample_rearm": _authority_trace(
            [1.0, 1.0, 0.0], contract=timeout
        ),
    }
    checks = {
        "isolated_evidence_no_authority": cases["isolated_high_evidence"]["event_indices"] == [],
        "sustained_evidence_confirms": cases["sustained_coherent_evidence"]["event_indices"] == [2],
        "insufficient_times_out": cases["insufficient_persistence_timeout"]["event_indices"] == [],
        "refractory_events_at_0_3_6": cases["refractory_bounded_retrigger"]["event_indices"] == [0, 3, 6],
        "recovery_has_no_reopen": cases["recovery_after_evidence_collapse"]["event_indices"] == [0],
        "inclusive_boundary_confirms": cases["confirmation_wins_at_inclusive_boundary"]["event_indices"] == [2],
        "same_sample_timeout_rearm_visible": cases["timeout_then_same_sample_rearm"]["pending_indices"] == [0, 1, 2],
    }
    return {
        "cases": cases,
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "bounded_exhaustive_equivalence": bounded_exhaustive_authority_equivalence(),
    }


def _growth_from_d_history(history: Sequence[float], m: int = 4, lam: float = 0.125) -> list[float]:
    values = list(map(float, history))
    growth: list[float] = []
    for index, value in enumerate(values):
        raw = value - values[index - m] if index >= m else 0.0
        growth.append(raw if index == 0 else lam * raw + (1.0 - lam) * growth[-1])
    return growth


def _fixed_raw_last_d_g(history: Sequence[float]) -> tuple[float, float]:
    """Return final fixed-profile D/G with the canonical batch addition order."""

    profile = DEFAULT_PROFILES[0]
    x = [float(value) for value in history]
    residuals: list[float] = []
    masses: list[float] = []
    baseline: list[float] = []
    d_values: list[float] = []
    g_values: list[float] = []
    for index, value in enumerate(x):
        window = sorted(x[max(0, index - profile.w1 + 1) : index + 1])
        middle = len(window) // 2
        median = (
            window[middle]
            if len(window) % 2
            else 0.5 * (window[middle - 1] + window[middle])
        )
        residuals.append(abs(value - median))
        mass = float(sum(residuals[max(0, index - profile.w2 + 1) : index + 1]))
        masses.append(mass)
        if index == 0:
            baseline.append(mass)
        else:
            baseline.append(
                profile.beta * mass + (1.0 - profile.beta) * baseline[-1]
            )
        safe = max(baseline[-1], profile.e_floor)
        d_values.append(_clamp((mass - safe) / safe, -5.0, 5.0))
        raw = (
            d_values[-1] - d_values[index - profile.m_base]
            if index >= profile.m_base
            else 0.0
        )
        g_values.append(
            raw
            if index == 0
            else profile.lam * raw + (1.0 - profile.lam) * g_values[-1]
        )
    return d_values[-1], g_values[-1]


def bounded_raw_d_g_collision_search() -> dict[str, object]:
    alphabet = (0.0, 0.04, 0.08, 0.12)
    length = 9
    groups: dict[tuple[str, str], tuple[tuple[float, ...], float]] = {}
    checked = 0
    witness = None
    for history in itertools.product(alphabet, repeat=length):
        d_now, g_now = _fixed_raw_last_d_g(history)
        checked += 1
        key = (float(history[-1]).hex(), d_now.hex())
        previous = groups.get(key)
        if previous is not None:
            previous_history, previous_g = previous
            if (previous_g > DEFAULT_PROFILES[0].th_g) != (
                g_now > DEFAULT_PROFILES[0].th_g
            ) and d_now <= DEFAULT_PROFILES[0].th_d:
                validated = []
                for candidate in (previous_history, history):
                    result = compute_dmreda_reference(
                        np.asarray(candidate, dtype=np.float64),
                        profiles={0: DEFAULT_PROFILES[0]},
                        transitions={0: RegimeTransition()},
                        regime_tick=length + 1,
                        warmup_samples=0,
                        mode="D_or_G",
                    )
                    validated.append((float(result.d[-1]), float(result.g[-1])))
                if (
                    validated[0][0].hex() != validated[1][0].hex()
                    or (validated[0][1] > DEFAULT_PROFILES[0].th_g)
                    == (validated[1][1] > DEFAULT_PROFILES[0].th_g)
                ):
                    continue
                witness = {
                    "history_1": list(previous_history),
                    "history_2": list(history),
                    "common_current_x": float(history[-1]),
                    "common_current_D": validated[0][0],
                    "G_1": validated[0][1],
                    "G_2": validated[1][1],
                    "D_trigger": validated[0][0] > DEFAULT_PROFILES[0].th_d,
                    "G_trigger_1": validated[0][1] > DEFAULT_PROFILES[0].th_g,
                    "G_trigger_2": validated[1][1] > DEFAULT_PROFILES[0].th_g,
                    "validated_by_canonical_source": True,
                }
                break
        else:
            groups[key] = (tuple(history), g_now)
    return {
        "alphabet": list(alphabet),
        "history_length": length,
        "histories_checked": checked,
        "witness_found": witness is not None,
        "witness": witness,
        "limitation": "bounded search; failure to find a witness is not an impossibility proof",
    }


def run_history_collisions() -> dict[str, object]:
    d_history_1 = [-1.0, 0.0, 0.0, 0.0, 0.2]
    d_history_2 = [0.2, 0.0, 0.0, 0.0, 0.2]
    g_history_1 = _growth_from_d_history(d_history_1)
    g_history_2 = _growth_from_d_history(d_history_2)
    count_contract = OpenContract(4, 1.0, 1.0, 3, 0)
    count_1 = MinimalAuthorityState(2, 0.6, 1, count_contract, 0)
    count_2 = MinimalAuthorityState(2, 0.6, 2, count_contract, 0)
    count_outputs = []
    for state in (count_1, count_2):
        output = step_authority(
            state,
            d_value=1.5,
            g_value=0.0,
            th_d=10.0,
            th_g=10.0,
            current_contract=count_contract,
            mode="d_or_g",
            authority_enabled=True,
        )
        count_outputs.append(output.confirmed)

    age_contract = OpenContract(3, 1.0, 1.0, 2, 0)
    age_states = (
        MinimalAuthorityState(2, 0.2, 1, age_contract, 0),
        MinimalAuthorityState(1, 0.2, 1, age_contract, 0),
    )
    age_outputs: list[bool] = []
    for state in age_states:
        step_authority(
            state,
            d_value=0.5,
            g_value=0.0,
            th_d=10.0,
            th_g=10.0,
            current_contract=age_contract,
            mode="d_or_g",
            authority_enabled=True,
        )
        age_outputs.append(
            step_authority(
                state,
                d_value=2.0,
                g_value=0.0,
                th_d=1.0,
                th_g=10.0,
                current_contract=age_contract,
                mode="d_or_g",
                authority_enabled=True,
            ).confirmed
        )

    contract_0 = OpenContract(20, 0.20, 1.8, 6, 80)
    contract_1 = OpenContract(28, 0.28, 2.6, 8, 100)
    contract_outputs = []
    for state, current in (
        (MinimalAuthorityState(5, 1.7, 5, contract_0, 0), contract_0),
        (MinimalAuthorityState(5, 1.7, 5, contract_1, 0), contract_1),
    ):
        contract_outputs.append(
            step_authority(
                state,
                d_value=0.5,
                g_value=0.0,
                th_d=10.0,
                th_g=10.0,
                current_contract=current,
                mode="d_or_g",
                authority_enabled=True,
            ).confirmed
        )

    refractory_outputs = []
    for remaining in (0, 2):
        state = MinimalAuthorityState(refractory_remaining=remaining)
        refractory_outputs.append(
            step_authority(
                state,
                d_value=1.0,
                g_value=0.0,
                th_d=0.5,
                th_g=10.0,
                current_contract=OpenContract(3, 0.2, 2.0, 2, 3),
                mode="d_only",
                authority_enabled=True,
            ).pending
        )

    return {
        "instantaneous_observation_only": {
            "collision": "same current D=1.5 and G=0 with different hidden count",
            "confirmed_outputs": count_outputs,
            "different": count_outputs[0] != count_outputs[1],
        },
        "D_only": {
            "D_history_1": d_history_1,
            "D_history_2": d_history_2,
            "current_D_both": 0.2,
            "G_history_1": g_history_1,
            "G_history_2": g_history_2,
            "current_G_1": g_history_1[-1],
            "current_G_2": g_history_2[-1],
            "G_threshold": 0.10,
            "D_below_open_threshold": 0.2 <= 0.35,
            "G_opening_differs": (g_history_1[-1] > 0.10)
            != (g_history_2[-1] > 0.10),
            "scope": "exact feature-history witness; raw reachability tested separately",
        },
        "single_area_A": {
            "collision": {"ell": 2, "area": 0.6},
            "counts": [1, 2],
            "common_next_D": 1.5,
            "confirmed_outputs": count_outputs,
        },
        "area_and_count": {
            "collision": {"area": 0.2, "count": 1},
            "ages": [2, 1],
            "common_suffix_D": [0.5, 2.0],
            "confirmed_outputs": age_outputs,
        },
        "age_area_count": {
            "collision": {"ell": 5, "area": 1.7, "count": 5},
            "contracts": [_contract_key(contract_0), _contract_key(contract_1)],
            "common_next_D": 0.5,
            "confirmed_outputs": contract_outputs,
        },
        "age_area_count_open_contract": {
            "inactive_collision": {"ell": 0, "area": 0.0, "count": 0, "contract": None},
            "refractory_values": [0, 2],
            "common_next_D": 1.0,
            "pending_outputs": refractory_outputs,
        },
        "representation_window_state": {
            "rolling_sum": {
                "histories": [[1.0, 0.0], [0.0, 1.0]],
                "current_sum_both": 1.0,
                "common_next": 0.0,
                "next_sums": [0.0, 1.0],
            },
            "trailing_median": {
                "histories": [[0.0, 1.0, 2.0], [1.0, 1.0, 100.0]],
                "current_median_both": 1.0,
                "common_next": 50.0,
                "next_medians": [2.0, 50.0],
            },
        },
        "bounded_raw_search": bounded_raw_d_g_collision_search(),
    }


def run_h_reassessment(
    test_seeds: Sequence[int],
) -> dict[str, object]:
    max_errors = {name: 0.0 for name in ("mu", "e", "E", "B", "D")}
    canonical_events = 0
    h_events = 0
    trajectory_event_disagreements = 0
    trace_count = 0
    for seed in list(test_seeds)[:32]:
        for signal in generate_raw_shape_family(int(seed)).values():
            core = compute_dmreda_reference(
                signal,
                profiles={0: DEFAULT_PROFILES[0]},
                transitions={0: RegimeTransition()},
                regime_tick=LENGTH + 1,
                warmup_samples=92,
                mode="D_or_G",
            )
            h = MinimalStreamingDetector()
            outputs = [h.step(float(value)) for value in signal]
            h_arrays = {
                "mu": np.asarray([row.median for row in outputs]),
                "e": np.asarray([row.residual for row in outputs]),
                "E": np.asarray([row.residual_sum for row in outputs]),
                "B": np.asarray([row.energy_baseline for row in outputs]),
                "D": np.asarray([row.normalized_deviation for row in outputs]),
            }
            core_arrays = {
                "mu": core.mu,
                "e": core.e,
                "E": core.e1,
                "B": core.e_baseline,
                "D": core.d,
            }
            for name in max_errors:
                max_errors[name] = max(
                    max_errors[name],
                    float(np.max(np.abs(h_arrays[name] - core_arrays[name]))),
                )
            h_indices = [index for index, row in enumerate(outputs) if row.confirmed]
            canonical_events += len(core.event_times)
            h_events += len(h_indices)
            trajectory_event_disagreements += int(h_indices != core.event_times)
            trace_count += 1
    collisions = run_history_collisions()["D_only"]
    return {
        "trace_count": trace_count,
        "fixed_front_end_max_absolute_errors": max_errors,
        "front_end_matches_within_5e_12": all(value <= 5e-12 for value in max_errors.values()),
        "canonical_total_events": canonical_events,
        "H_total_events": h_events,
        "trajectory_event_trace_disagreements": trajectory_event_disagreements,
        "exact_D_collision_with_different_G": collisions,
        "structural_equivalence_possible": False,
        "reason": (
            "H retains fixed mu/e/E/B/D but has no coordinate equivalent to G, "
            "regime evidence, or episodic authority state; an exact D collision has "
            "different G-trigger behavior"
        ),
    }


def run_numeric_invariant_audit() -> dict[str, object]:
    history = [0.0, 0.15, 0.3] + [0.3] * 40
    minimum_unclamped = 0.0
    detector = MinimalStreamingDetector()
    outputs = [detector.step(value) for value in history]
    residuals = [row.residual for row in outputs]
    running = 0.0
    ring = [0.0] * 16
    for index, residual in enumerate(residuals):
        position = index % 16
        if index >= 16:
            running -= ring[position]
        running += residual
        ring[position] = residual
        minimum_unclamped = min(minimum_unclamped, running)

    valid = MinimalStreamingDetector()
    for _ in range(16):
        valid.step(0.0)
    checkpoint = valid.checkpoint()
    state = checkpoint["state"]
    position = int(state["e_position"])
    state["e_ring"][position] = 100.0
    state["e_sum"] = 0.0
    restored = MinimalStreamingDetector.from_checkpoint(checkpoint)
    output = restored.step(0.0)
    return {
        "known_drain_history": history,
        "minimum_unclamped_recomputed_sum": minimum_unclamped,
        "implementation_final_sum": outputs[-1].residual_sum,
        "large_inconsistency_case": {
            "checkpoint_accepted": True,
            "outgoing_ring_value": 100.0,
            "stored_sum_before": 0.0,
            "mathematical_post_subtraction_before_clamp": -100.0,
            "reported_sum_after_step": output.residual_sum,
            "large_negative_silently_clamped": output.residual_sum == 0.0,
        },
        "assessment": (
            "unconditional negative clamp is adequate for the observed tiny cancellation "
            "case but can hide a large ring/sum invariant violation admitted by checkpoint validation"
        ),
        "defensible_future_contract": (
            "validate ring/sum consistency and clamp only when -epsilon <= E < 0; "
            "E < -epsilon must fail without state commit"
        ),
    }


def run_all(
    train_seeds: Sequence[int],
    test_seeds: Sequence[int],
) -> dict[str, object]:
    payload: dict[str, object] = {
        "schema": SCHEMA,
        "configuration": {
            "length": LENGTH,
            "onset": ONSET,
            "event_length": EVENT_LENGTH,
            "event_end": EVENT_END,
            "readout_offsets": list(READOUT_OFFSETS),
            "bootstrap_replicates": BOOTSTRAP_REPLICATES,
            "bootstrap_seed": BOOTSTRAP_SEED,
        },
        "residual_order": run_residual_order_campaign(train_seeds, test_seeds),
        "raw_shape": run_raw_shape_campaign(train_seeds, test_seeds),
        "adversarial": {
            "sign_blindness": run_sign_blindness_case(),
            "persistent_step_adaptation": run_step_adaptation_case(),
            "baseline_contamination": run_baseline_contamination_case(),
        },
        "authority_semantics": run_authority_semantics(),
        "history_collisions": run_history_collisions(),
        "H_reassessment": run_h_reassessment(test_seeds),
        "numeric_invariant_audit": run_numeric_invariant_audit(),
    }
    payload["payload_sha256"] = canonical_sha256(payload)
    return payload
