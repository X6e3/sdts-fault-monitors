"""Frozen tools for claim-aligned structural experiments."""
