"""Execute or verify the frozen claim-aligned DMREDA campaign."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

import numpy as np

from claim_aligned.tools.experiment_support import (
    canonical_json_bytes,
    canonical_sha256,
    file_sha256,
    run_all,
)


ROOT = Path(__file__).resolve().parents[2]
PROTOCOL_PATH = ROOT / "claim_aligned/protocol/CLAIM_ALIGNED_SYNTHETIC_PROTOCOL.json"
SEED_PATH = ROOT / "claim_aligned/protocol/CLAIM_ALIGNED_SEED_MANIFEST.json"
DEFAULT_OUTPUT = ROOT / "claim_aligned/results/CLAIM_ALIGNED_RESULTS.json"


def _load_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _git_head() -> str:
    return subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


def validate_frozen_inputs(
    protocol: dict[str, object],
    seeds: dict[str, object],
) -> tuple[list[int], list[int]]:
    if protocol.get("status") != "frozen_before_value_generation":
        raise ValueError("protocol is not frozen")
    if seeds.get("status") != "frozen_before_value_generation":
        raise ValueError("seed manifest is not frozen")
    expected_seed_hash = protocol["bindings"]["seed_manifest_sha256"]
    if file_sha256(SEED_PATH) != expected_seed_hash:
        raise ValueError("seed manifest hash mismatch")
    for relative, expected in protocol["bindings"]["source_sha256"].items():
        path = ROOT / relative
        if file_sha256(path) != expected:
            raise ValueError(f"source hash mismatch: {relative}")

    train = [int(value) for value in seeds["train_seeds"]]
    test = [int(value) for value in seeds["test_seeds"]]
    if len(train) != seeds["train_seed_count"] or len(test) != seeds["test_seed_count"]:
        raise ValueError("seed count mismatch")
    if len(set(train)) != len(train) or len(set(test)) != len(test):
        raise ValueError("duplicate seed")
    if set(train) & set(test):
        raise ValueError("train/test seed overlap")
    return train, test


def build_result() -> dict[str, object]:
    protocol = _load_json(PROTOCOL_PATH)
    seeds = _load_json(SEED_PATH)
    train, test = validate_frozen_inputs(protocol, seeds)
    experiment = run_all(train, test)
    result: dict[str, object] = {
        "schema": "dmreda.claim-aligned.result.v1",
        "status": "complete",
        "bindings": {
            "protocol_file_sha256": file_sha256(PROTOCOL_PATH),
            "protocol_payload_sha256": canonical_sha256(protocol),
            "seed_manifest_sha256": file_sha256(SEED_PATH),
            "source_sha256": dict(protocol["bindings"]["source_sha256"]),
            "historical_canonical_commit": protocol["historical_authorities"][
                "canonical_commit"
            ],
            "finalization_start_commit": protocol["historical_authorities"][
                "finalization_checkpoint"
            ],
            "execution_git_head": _git_head(),
        },
        "environment": {
            "python": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "numpy": np.__version__,
            "platform": platform.platform(),
            "machine": platform.machine(),
            "byteorder": sys.byteorder,
            "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
        },
        "experiment": experiment,
        "scope_guards": {
            "faulty_testing_accessed": False,
            "real_process_values_generated": False,
            "detector_parameter_search_performed": False,
            "generator_changed_after_values": False,
            "result_is_detector_performance_claim": False,
        },
    }
    result["result_payload_sha256"] = canonical_sha256(result)
    return result


def _write_atomic(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {path}")
    encoded = json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n"
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--verify-existing", action="store_true")
    parser.add_argument("--print-summary", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    try:
        output.relative_to((ROOT / "claim_aligned/results").resolve())
    except ValueError as error:
        raise ValueError("output must remain under claim_aligned/results") from error

    payload = build_result()
    encoded_hash = canonical_sha256(payload)
    if args.verify_existing:
        existing = _load_json(output)
        if canonical_json_bytes(existing) != canonical_json_bytes(payload):
            raise RuntimeError("existing result differs from deterministic rerun")
        action = "verified"
    else:
        _write_atomic(output, payload)
        action = "written"
    if args.print_summary:
        summary = {
            "action": action,
            "output": str(output.relative_to(ROOT)),
            "canonical_result_sha256": encoded_hash,
            "embedded_result_payload_sha256": payload["result_payload_sha256"],
            "residual_matching_passed": payload["experiment"]["residual_order"][
                "matching"
            ]["all_seed_blocks_pass"],
            "raw_matching_passed": payload["experiment"]["raw_shape"]["matching"][
                "all_seed_blocks_duration_energy_rms_pass"
            ],
            "authority_checks_passed": payload["experiment"]["authority_semantics"][
                "all_checks_pass"
            ],
            "bounded_authority_equivalence": payload["experiment"][
                "authority_semantics"
            ]["bounded_exhaustive_equivalence"]["all_equivalent_within_bound"],
        }
        print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
