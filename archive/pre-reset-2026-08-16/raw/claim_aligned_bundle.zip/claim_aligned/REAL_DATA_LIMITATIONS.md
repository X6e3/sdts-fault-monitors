# Real-Data Limitations

## Immutable historical result

The authoritative Stage 3.3 normal result remains:

```text
bank: historical FaultFreeTesting
horizon: 960 samples
independent unit: simulation trajectory
trajectories with >=1 authority: 42/500
false-authority risk: 0.084
frozen maximum: 25/500
status: FAILED
```

The artifact is `frozen_history/results/dmreda_normal_summary.json`, SHA-256
`48c82c94eb61ea618d0d0ad2ffc44c09db9c083e8c006d9ff5efa0d1d230d018`.
There were 45 total authority impulses; 458 trajectories were censored without
authority. Observed first-authority indices ranged from 102 to 954 with median
465.5. The restricted mean time to authority was 920.824 samples.

This negative is preserved without retuning, truncation, reinterpretation, or
replacement by H.

## Horizon dependence

The primary quantity is

```text
p_H = P(at least one authority in samples 0..H-1).
```

For a fixed process and detector, this cumulative incidence is nondecreasing in
`H`. It is not a horizon-free false-alarm rate and the censored restricted mean
is not a classical uncensored average run length. A result at horizon 500
cannot rescue or overwrite the frozen failure at horizon 960.

The Stage 3.3 artifact correctly records horizon, censoring assignment, and
that classical uncensored ARL is not claimed. The gate nevertheless failed on
its own declared metric.

## Provenance stop

The later locked-validation pass found no scientifically defensible fresh
Rieth-lineage normal source with established independent RNG/acquisition
provenance. Historical FaultFreeTraining, FaultFreeTesting, diagnostic banks,
and spent development partitions cannot be relabeled fresh. Reordering,
resampling, truncating, or synthesizing directly from spent empirical traces
would not create independent evidence.

Therefore the preregistered 1,000-by-500 locked normal gate was not run. There
is no `K/1000` result and no exact-binomial admission result. This is a valid
provenance stop, not missing detector tuning.

## Fault data boundary

FaultyTesting remained unopened during this claim-aligned pass. FaultyTraining
faults 1–20/runs 301–320 were previously spent in detector development and are
used here only to reproduce an existing non-claim-grade H parity report. They
cannot establish independent fault performance.

## What real data currently establish

- **[DIRECTLY ESTABLISHED]** The historical full Core failed its frozen normal
  admission gate at horizon 960.
- **[DIRECTLY ESTABLISHED]** The known real/simulated TEP partitions used in
  development are spent.
- **[DIRECTLY ESTABLISHED]** No fresh source satisfying the locked protocol was
  available in the repository/handoff evidence.
- **[UNKNOWN]** H normal admission risk on genuinely fresh trajectories.
- **[UNKNOWN]** Full-Core or H fault detection on an untouched bank after a
  clean normal admission.
- **[UNKNOWN]** Generalization to another process, sensor, operating regime,
  sampling rate, or physical acquisition.

## What would resolve the unknown

Before values are observed, freeze either an independently justified simulator
with traceable RNG/configuration lineage or a post-freeze physical acquisition
protocol. Then generate/acquire the preregistered 1,000 independent normal
trajectories of 500 samples, seal identities and hashes, and execute the frozen
normal gate once. Only a passing seal can authorize untouched fault evaluation.

This requirement concerns detector-performance/generalization claims. It does
not invalidate causal, bounded-state, collision, or automaton properties that
are established directly or by controlled histories.
