# Claim Matrix

Statuses refer only to the exact statement in each row. Documentation wording
is not evidence; sources, executable tests, sealed results, or missing-evidence
records are named explicitly.

| Claim | Exact statement | Type | Evidence | Falsification test | Result | Limitation | Status |
|---|---|---|---|---|---|---|---|
| causal operation | Equal valid input prefixes under fixed configuration produce equal claim-bearing state/output prefixes. | semantic | trailing-only source transition; prefix invariance fixtures | change only future suffix and compare every prior field | no suffix read or earlier-output mutation; tests pass | external concurrency/corrupt state outside contract | **[DIRECTLY ESTABLISHED]** |
| deterministic transition | Fixed valid `(state,input,config)` has one ordered next state/output; repeat and checkpoint/resume agree. | semantic/engineering | source precedence; repeat, worker, reset, checkpoint tests | exact replay and boundary collisions | tests pass; branch precedence reconstructed | other compilers, fast-math, data races untested | **[DIRECTLY ESTABLISHED]** within numeric contract |
| bounded mathematical state | A streaming realization uses storage independent of stream duration `T`. | structural | constructive ring/register model with maxima 11/32/8 and bounded authority registers | supply sufficient fixed state; show expiration collisions | `Memory(T)=O(1)` construction; scalar-only reductions fail | global/minimal-bit encoding unproved | **[STRONG INFERENCE]** |
| historical Python batch memory | `compute_dmreda_reference` itself uses memory independent of `T`. | implementation | source allocates full-length arrays and prefix sum | inspect allocations as `T` grows | allocation is `O(T)` | streaming recurrence exists separately | **[REFUTED]** |
| bounded compute | For fixed profiles, per-sample operation/loop count has a bound independent of `T`. | structural/engineering | fixed ring sizes, bounded insertion sort, fixed branches, no heap in C subsets | inspect all loops/allocations | structural bound exists | no MCU WCET/cycle/jitter measurement | **[STRONG INFERENCE]**; measured WCET **[UNKNOWN]** |
| training-free runtime | Runtime performs no model fitting/gradient/statistical training; it uses fixed supplied parameters plus causal adaptation. | semantic | no fit/model update path; affine/thresholds external; EWMA updates online | search mutation and parameter lineage | no learned runtime model | calibrated/tuned parameters exist; exact historical `kappa=2.5` lineage absent | **[DIRECTLY ESTABLISHED]**; “parameter-free” **[REFUTED]** |
| temporal structural representation | At least one history-dependent representation separates temporal orders that current magnitude summaries collapse. | scientific | sealed exact-residual-multiset campaign | six classes with identical residual multiset/current `e/E`; held-out readouts | `e/E` chance; D 0.5430; D+G 0.7552 | post-median family; not unique/task-valid | **[EXPERIMENTALLY SUPPORTED]** |
| magnitude-versus-order distinction | Equal duration, peak, residual sum/RMS/squared energy/histogram/current `e/E` can yield different richer state. | scientific | all 256 matched seed blocks; collision/separability report | verify matching before metric | all blocks passed; richer vectors distinct per block | raw reachability of every residual history unknown | **[EXPERIMENTALLY SUPPORTED]** at residual layer |
| necessity of representation history | Current median, sum, or `(D,G)` alone cannot continue exact recurrence for every suffix. | formal witness | median, rolling-sum, lag-expiry common-suffix pairs | merge histories, append identical next value | next medians/sums/G differ exactly | witnesses establish coordinate class, not minimal encoding | **[DIRECTLY ESTABLISHED]** |
| representation/authority separation | Authority state/mode/warm-up cannot feed back into representation trace. | invariant | source dataflow; warm-up/mode comparison tests | vary authority controls with identical raw trace | representation fields identical while authority differs | regime adaptation is representation-side and does affect it | **[DIRECTLY ESTABLISHED]** within Core |
| authority boundedness | Candidate residence/count/area and retrigger spacing are configuration-bounded; confirmation is an impulse. | automaton | source transition; seven semantic cases | sustained, timeout, refractory, recovery, collision boundaries | all cases pass; events at 0/3/6 for R=3 | does not imply one event per physical fault | **[DIRECTLY ESTABLISHED]** |
| authority state reduction | Given exogenous features/config, `(ell,A,C,Q_open,R)` preserves literal authority semantics on the tested domain. | semi-formal | 24-symbol, depth-8, three-mode exhaustive comparison | compare outputs and reduced next states | 1,176 transitions, zero mismatch | not all-real bisimulation | **[EXPERIMENTALLY SUPPORTED]** |
| authority state minimality | That tuple is globally/bitwise minimal. | formal | omission witnesses for `ell,A,C,aggregate Q,R`; removal of start/pending Boolean | all-admissible-suffix equivalence proof | several coordinates necessary; two fields redundant | individual contract fields and alternative encodings unproved | **[UNKNOWN]** globally |
| H structural equivalence | H preserves the historical representation and authority semantics. | equivalence | 192 front-end comparisons; D/G collision; event traces | common inputs and feature histories | through-D tolerance passes; 152/192 event traces differ; G absent | exact D/G feature witness raw reachability unknown | **[REFUTED]** overall; partial front-end equivalence established |
| Python/C semantic parity | H fixed subset exposes identical Python/C binary64 outputs over the declared replay. | engineering | regenerated byte-identical parity report | 1,039,792 row replay plus strict C99 compile | every exposed field exact; report SHA `8251e2...18fd` | no full adaptive C, all-input proof, or cross-platform proof | **[DIRECTLY ESTABLISHED]** for enumerated H scope |
| checkpoint numeric invariant | Accepted H checkpoints preserve ring/sum consistency and cannot hide a large negative sum. | engineering | constructed outgoing ring=100, stored sum=0 | import then one step | accepted; `-100` silently clamped to zero | historical source intentionally unchanged | **[REFUTED]** |
| detector superiority | DMREDA outperforms CUSUM/EWMA/run-rule controls at matched risk/horizon. | application performance | no fresh positive holdout; historical normal gate failed | preregistered fresh normal admission then fault study | not performed/established | FaultyTesting sealed; no fresh source | **[UNKNOWN]** |
| real-process generalization | Frozen architecture generalizes to independent process normal/fault data. | external validity | Stage 3.3: 42/500 at H=960, limit 25; provenance stop | genuinely fresh 1,000x500 normal gate then sealed faults | historical normal gate failed; new gate unavailable | known Rieth lineage spent/ambiguous | **[UNKNOWN]** positive generalization; historical gate failure directly established |
| novelty | The exact architecture/semantic contribution is absent from prior art and more than a known combination. | literature | focused primary-source comparison only | systematic review/patent search plus precise closest-work comparison | primitives are known; exact-composition novelty not shown | focused search is not exhaustive | **[UNKNOWN] / NOVELTY NOT ESTABLISHED** |

## Layer verdicts

| Layer | Verdict |
|---|---|
| representation claim | **EXPERIMENTALLY SUPPORTED**, scoped to exact matched residual-order families |
| temporal-state claim | **DIRECTLY ESTABLISHED** for explicit recurrence/authority collision witnesses; global minimality unknown |
| authority-semantics claim | **DIRECTLY ESTABLISHED** for implemented precedence and bounded cases |
| embedded-engineering claim | **DIRECTLY ESTABLISHED** for fixed subsets; full adaptive C and WCET unknown; checkpoint invariant incomplete |
| detector-performance claim | **UNKNOWN** as a positive claim; historical normal gate directly failed |
| real-data generalization | **UNKNOWN** |
| novelty | **NOT ESTABLISHED** |

## Verification baseline

Before new experiments, the complete suite reported `Ran 240 tests in 8.483s`
and `OK` at starting commit `5b43516c...`. Final verification reported 240
historical/repository tests in 8.555 seconds and 8 claim-aligned tests in 0.048
seconds, both `OK`. The current-claim and frozen-history manifests also passed
from their declared directories.
