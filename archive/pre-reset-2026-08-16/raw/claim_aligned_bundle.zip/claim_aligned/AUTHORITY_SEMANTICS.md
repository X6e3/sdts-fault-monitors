# Authority Semantics

## Object under test

External authority is not the representation. It is a deterministic bounded
register automaton consuming `D/G` evidence. A one-sample `confirmed` impulse
is the externally authoritative event; high evidence or `pending` alone is not.

## Transition ordering

For each enabled sample, the historical ordering is:

1. decrement refractory;
2. if a candidate is active, mark public `pending`, increment age, area, and
   count under its snapshotted contract;
3. test strict confirmation: `area > A*` and `count >= C*`;
4. if not confirmed, apply inclusive timeout `age >= L` and clear;
5. calculate the current fast trigger;
6. if inactive, not confirmed, refractory is zero, and trigger is true, open a
   new candidate on the same sample and accumulate that sample;
7. permit same-sample confirmation for a contract that is immediately met.

Therefore confirmation wins over timeout at the boundary, and timeout may be
followed by same-sample re-arm. The public pending output can be true even when
the candidate is inactive at the end of the transition.

## Semantic cases

All preregistered cases passed:

| Case | Input summary | Result |
|---|---|---|
| isolated high evidence | `[2,0,0,0,0]` | candidate opens; no authority; clears |
| sustained coherent evidence | `[1,1,1,0]` | authority at index 2 |
| insufficient persistence | `[1,0,0,0,0]` | no authority; timeout clears |
| refractory bounded retrigger | eight high samples, immediate contract, R=3 | events only at 0, 3, 6 |
| recovery | one immediate event followed by collapse | refractory releases; no spontaneous reopen |
| confirmation at timeout boundary | three qualifying samples with L=3 | confirmation at index 2 |
| timeout then same-sample re-arm | timeout contract and `[1,1,0]` | pending visible at 0, 1, and 2 |

This establishes the implemented invariants without using detector accuracy.

## Boundedness

For fixed configuration:

- candidate residence is at most `L` samples;
- count is at most `L`;
- with clipped `D`, area has a fixed maximum;
- confirmation is a one-sample impulse;
- refractory bounds retrigger frequency;
- candidate state is cleared on confirmation or timeout.

“Bounded authority” does not mean one event per physical fault. Sustained high
evidence can generate another event every refractory interval, as the 0/3/6
test intentionally demonstrates.

## Reduced-state validation

The source-shaped model and `(ell,A,C,Q_open,R)` model were exhaustively
compared to depth 8 over a 24-symbol frozen input alphabet. Results:

| mode | visited state pairs | transitions | mismatches |
|---|---:|---:|---:|
| D-only | 11 | 264 | 0 |
| G-only | 19 | 456 | 0 |
| D-or-G | 19 | 456 | 0 |

Total: 1,176 transitions, zero mismatch. This is bounded exhaustive evidence,
not a proof over every real-valued feature sequence.

## Representation separation

The Core source updates `mu/e/E/B/D/G/r/a` before authority and does not feed
candidate or refractory state back into those updates. Existing tests run the
same trace with warm-up 0 and 92 and obtain bit-identical representation arrays
while authority differs. Opening mode similarly changes authority only.

Thus separation is directional:

```text
representation -> authority
authority -/-> representation
```

The regime controller belongs to representation/configuration adaptation and
does influence future representation. It is not authority feedback.

## Status

- **[DIRECTLY ESTABLISHED]** Source transition precedence and all seven semantic
  cases.
- **[DIRECTLY ESTABLISHED]** Representation is invariant to authority warm-up
  in the tested Core contract.
- **[EXPERIMENTALLY SUPPORTED]** Reduced state equivalence within the declared
  finite alphabet/depth.
- **[UNKNOWN]** Global state minimality, whether same-sample timeout/re-arm is
  the desired application policy, and physical-event interpretation.
