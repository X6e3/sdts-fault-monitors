# H Variant Reassessment

## Verdict

**Outcome C:** H is a useful detector-oriented development ablation, but it is
not equivalent to DMREDA as the historical structural representation and
authority architecture. More precisely, it preserves a supported subset
through `D` and discards `G`, regime evidence, and episodic candidate semantics.

## What H preserves

H implements the fixed profile-0 front end:

```text
trailing median -> absolute residual -> 16-sample L1 residual mass
-> beta=1/32 EWMA baseline -> clipped normalized D
```

Across 192 frozen raw synthetic traces, H and the historical fixed-profile
Core matched this path with maximum absolute differences:

| field | maximum absolute difference |
|---|---:|
| median | 0 |
| residual `e` | 0 |
| residual mass `E` | `3.07e-14` |
| baseline `B` | `1.61e-14` |
| deviation `D` | `7.33e-14` |

This is **[DIRECTLY ESTABLISHED]** front-end equivalence within the tested
binary64 tolerance. Because `D` separated the matched residual-order family,
H retains some genuine temporal context rather than only instantaneous
magnitude.

## What H removes

H replaces historical D-or-G candidate authority with:

```text
six consecutive samples with D > 0.8 -> authority impulse -> refractory 80
```

It has no coordinates equivalent to:

- lagged smoothed growth `G`;
- residual-activity/regime representation;
- candidate age and timeout;
- accumulated positive excess area;
- non-consecutive qualifying count;
- opening-time snapshotted contract.

The H source itself declares these removals and marks the configuration
development-only/non-claim-grade.

## Falsification of equivalence

The exact feature histories

```text
[-1,0,0,0,0.2] and [0.2,0,0,0,0.2]
```

share current `D=0.2` but have current `G=0.15` and `0`. Under historical
state-0 D-or-G thresholds, only the first opens. No transition system observing
only current D and H's run/refractory state can reproduce that decision for
both histories without additional history.

The scope caveat is important: a bounded raw search did not recover this exact
witness through the median front end. Nevertheless, H is definitionally unable
to expose the claim-bearing G coordinate, and the matched residual-order
campaign shows that `D+G` contains substantially more separable ordering
information than D alone.

Authority traces also differ empirically. On 192 frozen raw-shape traces, the
historical fixed-profile Core produced 314 total events and H produced 224;
152/192 trajectory event-index sequences disagreed. This is not a performance
comparison and does not say which authority policy is preferable. It directly
refutes semantic equivalence.

## Relation to the previous finalization

The previous selection of H was valid for its declared objective: a frozen,
spent-data detector-development simplicity/noninferiority rule. It was not a
test of structural representation preservation. Treating that selection as a
proof that G, candidate state, or regime representation was redundant was an
objective-function artifact.

## Status by layer

- front-end through D: **[DIRECTLY ESTABLISHED] tested equivalence**;
- temporal representation through G: **[REFUTED] equivalence**;
- adaptive regime representation: **[REFUTED] inclusion**, benefit unknown;
- historical authority semantics: **[REFUTED] equivalence**;
- detector usefulness: development evidence only;
- independent normal/fault validation: **[UNKNOWN]**, because no fresh source
  passed the provenance gate and FaultyTesting remained sealed.
