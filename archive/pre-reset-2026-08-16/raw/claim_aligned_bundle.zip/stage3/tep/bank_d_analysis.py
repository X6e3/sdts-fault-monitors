"""Claim-constrained analysis of Stage 3.3 dual-boundary authority records.

This module consumes immutable per-trajectory rows.  It never reads sensor
data and never reruns an evidence channel.  All statistics retain the
recording as the independent unit, preserve first-event ownership, and keep
the two onset mappings co-equal.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Final, Mapping, Sequence

import numpy as np

from gold_line.evaluation.alarm_metrics import RunOutcome
from stage3.admission.serialization import canonical_sha256
from stage3.tep.authority_runner import validate_dual_boundary_result_row
from stage3.tep.statistics import (
    holm_adjust,
    paired_comparison,
    summarize_dual_boundary_rows,
)


PRIMARY_CHANNEL: Final[str] = "dmreda_core_d_or_g"
ONSET_INDICES: Final[tuple[int, int]] = (159, 160)


def _group_rows(
    rows: Sequence[Mapping[str, object]],
) -> dict[tuple[int, str], list[Mapping[str, object]]]:
    if not rows:
        raise ValueError("Bank D analysis requires at least one trajectory row")
    groups: dict[tuple[int, str], list[Mapping[str, object]]] = defaultdict(list)
    observed_order: list[tuple[int, int, str]] = []
    identities: set[tuple[int, int, str]] = set()
    for row in rows:
        validate_dual_boundary_result_row(row)
        identity = (
            int(row["faultNumber"]),
            int(row["simulationRun"]),
            str(row["evidence_channel_identifier"]),
        )
        if identity in identities:
            raise ValueError("Bank D rows contain a duplicate trajectory/channel identity")
        identities.add(identity)
        observed_order.append(identity)
        groups[(identity[0], identity[2])].append(row)
    if observed_order != sorted(observed_order):
        raise ValueError("Bank D rows are not in deterministic fault/run/channel order")
    for group_rows in groups.values():
        runs = [int(row["simulationRun"]) for row in group_rows]
        if runs != sorted(runs):
            raise ValueError("Bank D group run order is unstable")
    return dict(groups)


def _onset_view(summary: Mapping[str, object], onset: int) -> dict[str, object]:
    view = summary[f"onset_{onset}"]
    assert isinstance(view, Mapping)
    return dict(view)


def _macro_summary(
    per_fault: Mapping[str, Mapping[str, object]], *, onset: int
) -> dict[str, object]:
    if not per_fault:
        raise ValueError("macro summary requires fault-class summaries")
    rates: dict[str, list[float]] = {
        "false_authority": [],
        "valid_authority": [],
        "no_authority": [],
    }
    conditional_means: list[float] = []
    conditional_medians: list[float] = []
    restricted_means: list[float] = []
    for record in per_fault.values():
        view = record[f"onset_{onset}"]
        if not isinstance(view, Mapping):
            raise ValueError("per-fault onset summary is malformed")
        child_rates = view["rates"]
        if not isinstance(child_rates, Mapping):
            raise ValueError("per-fault rate summary is malformed")
        for category in rates:
            rates[category].append(float(child_rates[category]))
        delay = view["conditional_valid_authority_latency_samples"]
        restricted = view["restricted_post_onset_time_to_authority"]
        if not isinstance(delay, Mapping) or not isinstance(restricted, Mapping):
            raise ValueError("per-fault latency summary is malformed")
        if delay["mean"] is not None:
            conditional_means.append(float(delay["mean"]))
        if delay["median"] is not None:
            conditional_medians.append(float(delay["median"]))
        if restricted["mean"] is not None:
            restricted_means.append(float(restricted["mean"]))
    return {
        "fault_class_count": len(per_fault),
        "equal_fault_weight": True,
        "mean_false_authority_rate": float(np.mean(rates["false_authority"])),
        "mean_valid_authority_coverage": float(np.mean(rates["valid_authority"])),
        "mean_no_authority_rate": float(np.mean(rates["no_authority"])),
        "mean_of_fault_conditional_mean_latencies": (
            None if not conditional_means else float(np.mean(conditional_means))
        ),
        "mean_of_fault_conditional_median_latencies": (
            None if not conditional_medians else float(np.mean(conditional_medians))
        ),
        "conditional_latency_contributing_fault_class_count": len(
            conditional_means
        ),
        "mean_restricted_post_onset_time_to_authority": (
            None if not restricted_means else float(np.mean(restricted_means))
        ),
    }


def _outcome_from_row(row: Mapping[str, object], *, onset: int) -> RunOutcome:
    outcome = row[f"outcome_onset_{onset}"]
    first = row["first_authoritative_event"]
    latency = row[f"latency_onset_{onset}"]
    if outcome == "false_authority":
        return RunOutcome(int(first), True, False, False, None)
    if outcome == "valid_authority":
        return RunOutcome(int(first), False, True, False, int(latency))
    if outcome == "no_authority":
        return RunOutcome(None, False, False, True, None)
    raise ValueError("invalid Bank D row cannot enter scientific analysis")


def _aligned_outcomes(
    groups: Mapping[tuple[int, str], Sequence[Mapping[str, object]]],
    *,
    fault_number: int,
    left_channel: str,
    right_channel: str,
    onset: int,
) -> tuple[list[RunOutcome], list[RunOutcome]]:
    left = groups[(fault_number, left_channel)]
    right = groups[(fault_number, right_channel)]
    left_runs = [int(row["simulationRun"]) for row in left]
    right_runs = [int(row["simulationRun"]) for row in right]
    if left_runs != right_runs:
        raise ValueError("paired evidence channels do not share recording identities")
    return (
        [_outcome_from_row(row, onset=onset) for row in left],
        [_outcome_from_row(row, onset=onset) for row in right],
    )


def _apply_holm_families(
    pairwise: dict[str, object], *, admitted_references: Sequence[str]
) -> dict[str, object]:
    families: dict[str, object] = {}
    for onset in ONSET_INDICES:
        onset_key = f"onset_{onset}"
        onset_records = pairwise[onset_key]
        assert isinstance(onset_records, Mapping)
        for reference in sorted(admitted_references):
            for endpoint, path in (
                ("early_false_authority", ("early_false_authority_discordance", "exact_p_value")),
                ("non_fp_authority", ("non_fp_detection_discordance", "exact_p_value")),
                ("paired_latency", ("paired_valid_detection_delay", "wilcoxon", "p_value")),
            ):
                raw: dict[str, float | None] = {}
                for fault, comparisons in onset_records.items():
                    comparison = comparisons[reference]
                    value: Any = comparison
                    for key in path:
                        if value is None:
                            break
                        value = value[key]
                    raw[str(fault)] = None if value is None else float(value)
                family_id = f"{onset_key}/{reference}/{endpoint}"
                families[family_id] = {
                    "raw_p_values": raw,
                    "holm_adjusted_p_values": holm_adjust(raw),
                }
    return families


def _coequal_added_value_family(
    pairwise: Mapping[str, object], *, admitted_references: Sequence[str]
) -> dict[str, object]:
    """Control one final claim family across both onsets, faults, and references."""

    raw: dict[str, float | None] = {}
    fault_keys = sorted(pairwise["onset_159"])
    if fault_keys != sorted(pairwise["onset_160"]):
        raise ValueError("co-equal pairwise fault families differ")
    for reference in sorted(admitted_references):
        for fault in fault_keys:
            values: list[float] = []
            for onset in ONSET_INDICES:
                record = pairwise[f"onset_{onset}"][fault][reference]
                value = record["non_fp_detection_discordance"]["exact_p_value"]
                if value is None:
                    break
                values.append(float(value))
            key = f"{fault}/{reference}"
            raw[key] = max(values) if len(values) == len(ONSET_INDICES) else None
    return {
        "hypothesis_unit": "fault_class_and_admitted_reference",
        "coequal_boundary_combination": "intersection_union_max_exact_p_value",
        "family_scope": "all_admitted_references_times_twenty_fault_classes",
        "raw_intersection_union_p_values": raw,
        "holm_adjusted_p_values": holm_adjust(raw),
        "direction_and_early_false_authority_rules_applied_separately": True,
    }


def analyze_bank_d_rows(
    rows: Sequence[Mapping[str, object]],
    *,
    admitted_references: Sequence[str],
    bootstrap_replicates: int = 10_000,
    bootstrap_seed: int = 20_260_805,
    require_frozen_campaign_shape: bool = True,
) -> dict[str, object]:
    """Produce all primary summary payloads without selecting an onset."""

    references = tuple(sorted(admitted_references))
    if any(name not in {"rms", "cusum", "ewma"} for name in references) or len(
        references
    ) != len(set(references)):
        raise ValueError("admitted reference allowlist is invalid")
    groups = _group_rows(rows)
    faults = sorted({fault for fault, _ in groups})
    channels = sorted({channel for _, channel in groups})
    expected_channels = {PRIMARY_CHANNEL, *references}
    if set(channels) != expected_channels:
        raise ValueError("Bank D rows differ from the primary plus admitted allowlist")
    for fault in faults:
        for channel in channels:
            if (fault, channel) not in groups:
                raise ValueError("Bank D fault/channel matrix is incomplete")
            if require_frozen_campaign_shape and len(groups[(fault, channel)]) != 500:
                raise ValueError("Bank D fault/channel group must contain 500 trajectories")
    if require_frozen_campaign_shape and faults != list(range(1, 21)):
        raise ValueError("Bank D must contain publisher fault classes 1..20")

    per_fault_dual: dict[str, dict[str, object]] = {}
    for fault in faults:
        fault_key = f"fault_{fault:02d}"
        per_fault_dual[fault_key] = {
            channel: summarize_dual_boundary_rows(groups[(fault, channel)])
            for channel in channels
        }

    per_onset: dict[int, dict[str, object]] = {}
    global_by_onset: dict[int, dict[str, object]] = {}
    for onset in ONSET_INDICES:
        per_fault_onset = {
            fault_key: {
                channel: _onset_view(summary, onset)
                for channel, summary in channel_records.items()
            }
            for fault_key, channel_records in per_fault_dual.items()
        }
        per_onset[onset] = per_fault_onset
        channel_global: dict[str, object] = {}
        for channel in channels:
            all_channel_rows = [
                row
                for fault in faults
                for row in groups[(fault, channel)]
            ]
            micro = _onset_view(
                summarize_dual_boundary_rows(all_channel_rows), onset
            )
            fault_views = {
                fault_key: channel_records[channel]
                for fault_key, channel_records in per_fault_dual.items()
            }
            channel_global[channel] = {
                "micro_recording_level": micro,
                "macro_equal_fault_class": _macro_summary(
                    fault_views, onset=onset
                ),
            }
        global_by_onset[onset] = channel_global

    boundary_per_fault = {
        fault_key: {
            channel: {
                "trajectory_count": summary["trajectory_count"],
                "boundary_sensitivity_counts": summary[
                    "boundary_sensitivity_counts"
                ],
                "classification_flip_rate": summary["classification_flip_rate"],
                "valid_authority_under_both_count": summary[
                    "valid_authority_under_both_count"
                ],
                "false_authority_under_both_count": summary[
                    "false_authority_under_both_count"
                ],
                "no_authority_under_both_count": summary[
                    "no_authority_under_both_count"
                ],
                "exact_differences": summary["exact_differences"],
            }
            for channel, summary in channel_records.items()
        }
        for fault_key, channel_records in per_fault_dual.items()
    }
    global_dual = {
        channel: summarize_dual_boundary_rows(
            [row for fault in faults for row in groups[(fault, channel)]]
        )
        for channel in channels
    }
    changed_rows = tuple(
        row
        for row in rows
        if row["mutually_exclusive_outcome_changed"] is True
    )

    pairwise: dict[str, object] = {}
    if references:
        for onset in ONSET_INDICES:
            onset_records: dict[str, object] = {}
            for fault in faults:
                fault_key = f"fault_{fault:02d}"
                comparisons: dict[str, object] = {}
                for reference in references:
                    primary, scalar = _aligned_outcomes(
                        groups,
                        fault_number=fault,
                        left_channel=PRIMARY_CHANNEL,
                        right_channel=reference,
                        onset=onset,
                    )
                    comparisons[reference] = paired_comparison(
                        primary,
                        scalar,
                        fault=fault_key,
                        comparator=reference,
                        base_seed=bootstrap_seed,
                        bootstrap_replicates=bootstrap_replicates,
                    )
                onset_records[fault_key] = comparisons
            pairwise[f"onset_{onset}"] = onset_records
    statistical = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.bank_d_statistical_analysis",
        "independent_unit": "simulation_trajectory_or_fault_episode",
        "bootstrap_seed": bootstrap_seed,
        "bootstrap_replicates": bootstrap_replicates,
        "holm_families": (
            _apply_holm_families(pairwise, admitted_references=references)
            if references
            else {}
        ),
        "coequal_non_fp_added_value_family": (
            _coequal_added_value_family(
                pairwise, admitted_references=references
            )
            if references
            else {
                "hypothesis_unit": "fault_class_and_admitted_reference",
                "coequal_boundary_combination": (
                    "intersection_union_max_exact_p_value"
                ),
                "family_scope": (
                    "all_admitted_references_times_twenty_fault_classes"
                ),
                "raw_intersection_union_p_values": {},
                "holm_adjusted_p_values": {},
                "direction_and_early_false_authority_rules_applied_separately": True,
            }
        ),
        "no_sample_level_pseudoreplication": True,
    }

    artifact_core: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.bank_d_analysis",
        "fault_numbers": faults,
        "evidence_channels": channels,
        "admitted_reference_allowlist": list(references),
        "per_fault_summary_onset_159": per_onset[159],
        "per_fault_summary_onset_160": per_onset[160],
        "global_summary_onset_159": global_by_onset[159],
        "global_summary_onset_160": global_by_onset[160],
        "boundary_sensitivity_summary": {
            "per_fault": boundary_per_fault,
            "global": global_dual,
            "selected_onset": None,
            "coequal_onsets": [159, 160],
        },
        "admitted_reference_pairwise_results": pairwise,
        "statistical_analysis": statistical,
    }
    return {
        **artifact_core,
        "boundary_changed_trajectories": changed_rows,
        "analysis_payload_sha256": canonical_sha256(artifact_core),
    }


def compare_reproduced_rows(
    primary_rows: Sequence[Mapping[str, object]],
    reproduced_rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    """Return the first deterministic difference without hiding either run."""

    first_difference: dict[str, object] | None = None
    maximum = max(len(primary_rows), len(reproduced_rows))
    for index in range(maximum):
        left = primary_rows[index] if index < len(primary_rows) else None
        right = reproduced_rows[index] if index < len(reproduced_rows) else None
        if left != right:
            first_difference = {
                "record_index": index,
                "primary_identity": (
                    None
                    if left is None
                    else [
                        left.get("faultNumber"),
                        left.get("simulationRun"),
                        left.get("evidence_channel_identifier"),
                    ]
                ),
                "reproduced_identity": (
                    None
                    if right is None
                    else [
                        right.get("faultNumber"),
                        right.get("simulationRun"),
                        right.get("evidence_channel_identifier"),
                    ]
                ),
                "primary_row_sha256": (
                    None if left is None else canonical_sha256(dict(left))
                ),
                "reproduced_row_sha256": (
                    None if right is None else canonical_sha256(dict(right))
                ),
            }
            break
    without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.deterministic_diff",
        "status": "no_differences" if first_difference is None else "different",
        "primary_record_count": len(primary_rows),
        "reproduced_record_count": len(reproduced_rows),
        "first_difference": first_difference,
        "experiment_valid": first_difference is None,
    }
    return {
        **without_hash,
        "diff_payload_sha256": canonical_sha256(without_hash),
    }
