"""Resumable Stage 3.3 campaign orchestration.

Raw Rieth data and all trajectory-level results remain outside Git.  Every
phase has a completion manifest written last; existing immutable artifacts are
verified byte-for-byte and never overwritten.  The protocol is frozen before
FaultFree Testing value access, and Bank D receives an exclusive opening event
before Faulty Testing value access.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import shutil
import subprocess
import sys
from typing import Any, Final, Iterable, Mapping, Sequence

from stage3.admission.serialization import (
    canonical_json_bytes,
    canonical_sha256,
    load_strict_json,
)
from stage3.tep.arbitration_validation import (
    FROZEN_ARBITRATION_EXPECTATIONS_SHA256,
    render_arbitration_report,
    run_arbitration_validation,
)
from stage3.tep.authority_checkpoint import evaluate_dual_boundary_fault
from stage3.tep.authority_runner import (
    AuthorityTrajectoryInput,
    DualBoundaryBindings,
    evaluate_dual_boundary_records,
)
from stage3.tep.bank_d_analysis import (
    PRIMARY_CHANNEL,
    analyze_bank_d_rows,
    compare_reproduced_rows,
)
from stage3.tep.configuration import (
    FROZEN_EFFECTIVE_PROFILES_SHA256,
    FROZEN_TEP_CONFIGURATION_SHA256,
    tep_configuration_snapshot,
)
from stage3.tep.extraction import (
    build_extraction_manifest,
    sha256_file,
    validate_extraction_bindings,
)
from stage3.tep.normal_gate import (
    RawScalarTrajectory,
    calibrate_scalar_references,
    evaluate_normal_trajectories,
    iter_scalar_fault_groups,
    load_scalar_bank,
    render_normal_gate_report,
    summarize_normal_authority,
)
from stage3.tep.onset_authority import validate_dual_boundary_contract
from stage3.tep.output_guard import (
    ExternalArtifactKind,
    atomic_replace_checkpoint_bytes,
    atomic_write_bytes,
    git_worktree_root,
    validate_external_destination,
)
from stage3.tep.protocol import (
    DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
    EXPECTED_RAW_DATASET_SHA256,
    build_protocol_payload_v2,
    freeze_protocol_v2,
    validate_frozen_protocol_v2,
)
from stage3.tep.representation_validation import (
    FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
    FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256,
    render_representation_report,
    run_representation_validation,
)
from stage3.tep.runner import DetectorSpec
from stage3.tep.seals import (
    REQUIRED_ARTIFACTS_V2,
    ArtifactReference,
    evaluate_bank_d_admission_v2,
    open_bank_d_once_v2,
    validate_bank_d_open_event_v2,
)
from stage3.tep.statistics import (
    classify_boundary_interpretation,
    summarize_dual_boundary_rows,
)


RAW_FILE_CONTRACT: Final[dict[str, dict[str, object]]] = {
    "TEP_FaultFree_Training.RData": {
        "bytes": 24_678_017,
        "md5": "ec126484534331f85001d8c4ebce6d17",
        "sha256": EXPECTED_RAW_DATASET_SHA256["TEP_FaultFree_Training.RData"],
        "object": "fault_free_training",
        "rows": 250_000,
        "columns": 55,
        "faults": (0,),
        "runs": 500,
        "horizon": 500,
    },
    "TEP_FaultFree_Testing.RData": {
        "bytes": 47_327_663,
        "md5": "38ad9810fc871026157086ae2c2f0ee9",
        "sha256": EXPECTED_RAW_DATASET_SHA256["TEP_FaultFree_Testing.RData"],
        "object": "fault_free_testing",
        "rows": 480_000,
        "columns": 55,
        "faults": (0,),
        "runs": 500,
        "horizon": 960,
    },
    "TEP_Faulty_Training.RData": {
        "bytes": 494_063_194,
        "md5": "c5f594d54c47e620ff877feb58407fda",
        "sha256": EXPECTED_RAW_DATASET_SHA256["TEP_Faulty_Training.RData"],
        "object": "faulty_training",
        "rows": 5_000_000,
        "columns": 55,
        "faults": tuple(range(1, 21)),
        "runs": 500,
        "horizon": 500,
    },
    "TEP_Faulty_Testing.RData": {
        "bytes": 836_882_037,
        "md5": "556bdb64c83021bc0c5f92e427753565",
        "sha256": EXPECTED_RAW_DATASET_SHA256["TEP_Faulty_Testing.RData"],
        "object": "faulty_testing",
        "rows": 9_600_000,
        "columns": 55,
        "faults": tuple(range(1, 21)),
        "runs": 500,
        "horizon": 960,
    },
}

OUTPUT_DIRECTORIES: Final[tuple[str, ...]] = (
    "authority",
    "arbitration",
    "bank_d/ablations/checkpoints/d_only",
    "bank_d/ablations/checkpoints/g_only",
    "bank_d/primary/checkpoints",
    "calibration",
    "environment",
    "extracts",
    "logs",
    "manifests",
    "normal_gate",
    "protocol",
    "recovery",
    "reports",
    "representation",
    "reproducibility/run_2/checkpoints",
)

SOURCE_FILES: Final[tuple[str, ...]] = (
    "gold_line/core/dmreda_reference_clean.py",
    "gold_line/benchmarks/fair_baseline_scaffold.py",
    "gold_line/evaluation/alarm_metrics.py",
    "stage3/tep/arbitration_validation.py",
    "stage3/tep/authority_checkpoint.py",
    "stage3/tep/authority_runner.py",
    "stage3/tep/bank_d_analysis.py",
    "stage3/tep/campaign.py",
    "stage3/tep/checkpoints.py",
    "stage3/tep/configuration.py",
    "stage3/tep/dual_boundary.py",
    "stage3/tep/extraction.py",
    "stage3/tep/normal_gate.py",
    "stage3/tep/onset_authority.py",
    "stage3/tep/output_guard.py",
    "stage3/tep/protocol.py",
    "stage3/tep/representation_validation.py",
    "stage3/tep/seals.py",
    "stage3/tep/statistics.py",
    "scripts/stage3/extract_tep_xmeas7.R",
    "scripts/stage3/run_stage3_3_campaign.py",
)

PRIMARY_RESULT_FILES: Final[dict[str, str]] = {
    "trajectory_results_dual_boundary": (
        "bank_d/primary/trajectory_results_dual_boundary.jsonl"
    ),
    "per_fault_summary_onset_159": "bank_d/primary/per_fault_summary_onset_159.json",
    "per_fault_summary_onset_160": "bank_d/primary/per_fault_summary_onset_160.json",
    "global_summary_onset_159": "bank_d/primary/global_summary_onset_159.json",
    "global_summary_onset_160": "bank_d/primary/global_summary_onset_160.json",
    "boundary_sensitivity_summary": (
        "bank_d/primary/boundary_sensitivity_summary.json"
    ),
    "admitted_reference_pairwise_results": (
        "bank_d/primary/admitted_reference_pairwise_results.json"
    ),
    "statistical_analysis": "bank_d/primary/statistical_analysis.json",
    "boundary_changed_trajectories": (
        "bank_d/primary/boundary_changed_trajectories.jsonl"
    ),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace(
        "+00:00", "Z"
    )


def _digest_file(path: Path, algorithm: str = "sha256") -> str:
    digest = hashlib.new(algorithm)
    with Path(path).open("rb") as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def _raw_file_observation(path: Path) -> dict[str, object]:
    """Read one raw artifact once while deriving both publisher digests."""

    size = 0
    md5 = hashlib.md5(usedforsecurity=False)
    sha256 = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while block := handle.read(1024 * 1024):
            size += len(block)
            md5.update(block)
            sha256.update(block)
    return {"bytes": size, "md5": md5.hexdigest(), "sha256": sha256.hexdigest()}


def _validate_raw_file_identity(paths: "CampaignPaths", name: str) -> dict[str, object]:
    """Fail closed unless a raw file still has its frozen publisher identity."""

    if name not in RAW_FILE_CONTRACT:
        raise ValueError(f"unknown raw-file contract: {name}")
    path = paths.dataset(name)
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError(f"raw dataset artifact is absent or not regular: {name}")
    observed = _raw_file_observation(path)
    expected = RAW_FILE_CONTRACT[name]
    if any(observed[field] != expected[field] for field in ("bytes", "md5", "sha256")):
        raise RuntimeError(f"raw dataset identity mismatch: {name}")
    return observed


@dataclass(frozen=True)
class CampaignPaths:
    repository_root: Path
    dataset_root: Path
    output_root: Path
    recovery_root: Path

    def __post_init__(self) -> None:
        repository = Path(self.repository_root).resolve(strict=True)
        dataset = Path(self.dataset_root).resolve(strict=True)
        output = Path(self.output_root).resolve(strict=True)
        recovery = Path(self.recovery_root).resolve(strict=True)
        if not (repository / ".git").exists():
            raise ValueError("repository_root is not a Git worktree")
        if not dataset.is_dir() or not output.is_dir() or not recovery.is_dir():
            raise ValueError(
                "dataset_root, output_root, and recovery_root must be existing directories"
            )
        if output == repository or repository in output.parents:
            raise PermissionError("scientific output root must remain outside Git")
        if git_worktree_root(output) is not None:
            raise PermissionError("scientific output root must not be a Git worktree")
        for protected in (repository, dataset, output):
            if (
                recovery == protected
                or recovery in protected.parents
                or protected in recovery.parents
            ):
                raise PermissionError(
                    "recovery root must not overlap Git, raw data, or scientific output"
                )
        if git_worktree_root(recovery) is not None:
            raise PermissionError("recovery root must not be a Git worktree")
        object.__setattr__(self, "repository_root", repository)
        object.__setattr__(self, "dataset_root", dataset)
        object.__setattr__(self, "output_root", output)
        object.__setattr__(self, "recovery_root", recovery)

    def output(self, relative: str) -> Path:
        return self.output_root / relative

    def dataset(self, name: str) -> Path:
        return self.dataset_root / name

    def repository(self, relative: str) -> Path:
        return self.repository_root / relative


def ensure_output_layout(paths: CampaignPaths) -> None:
    for relative in OUTPUT_DIRECTORIES:
        destination = paths.output(relative)
        current = paths.output_root
        for part in Path(relative).parts:
            current = current / part
            if current.exists() or current.is_symlink():
                if current.is_symlink() or not current.is_dir():
                    raise PermissionError(
                        "campaign output path contains a symlink or non-directory"
                    )
            else:
                current.mkdir(mode=0o700)
        if destination.resolve(strict=True).parent != destination.parent.resolve(
            strict=True
        ):
            raise PermissionError("campaign output directory resolution changed")


def _publish_bytes(
    paths: CampaignPaths,
    relative: str,
    payload: bytes,
    kind: ExternalArtifactKind,
) -> str:
    destination = paths.output(relative)
    if destination.exists():
        validate_external_destination(
            destination,
            external_root=paths.output_root,
            kind=kind,
            require_absent=False,
        )
        if destination.is_symlink() or not destination.is_file():
            raise PermissionError("existing immutable artifact is not a regular file")
        observed = destination.read_bytes()
        if observed != payload:
            raise FileExistsError(f"immutable artifact differs: {relative}")
    else:
        atomic_write_bytes(
            destination,
            payload,
            external_root=paths.output_root,
            kind=kind,
        )
    return _digest_file(destination)


def publish_json(paths: CampaignPaths, relative: str, payload: Mapping[str, object]) -> str:
    return _publish_bytes(
        paths,
        relative,
        canonical_json_bytes(dict(payload)) + b"\n",
        ExternalArtifactKind.IMMUTABLE_JSON,
    )


def publish_jsonl(
    paths: CampaignPaths,
    relative: str,
    rows: Sequence[Mapping[str, object]],
    *,
    allow_empty: bool = False,
) -> str:
    if not rows and not allow_empty:
        raise ValueError("immutable scientific JSONL cannot be empty")
    payload = b"".join(canonical_json_bytes(dict(row)) + b"\n" for row in rows)
    return _publish_bytes(
        paths,
        relative,
        payload,
        ExternalArtifactKind.IMMUTABLE_JSONL,
    )


def _load_canonical_jsonl(path: Path, *, allow_empty: bool = False) -> tuple[dict[str, object], ...]:
    raw = Path(path).read_bytes()
    if not raw:
        if allow_empty:
            return ()
        raise ValueError(f"scientific JSONL is empty: {path.name}")
    if not raw.endswith(b"\n"):
        raise ValueError(f"scientific JSONL has a truncated final line: {path.name}")
    rows: list[dict[str, object]] = []
    for line in raw.splitlines():
        value = json.loads(
            line,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ValueError(f"non-finite JSON token: {token}")
            ),
        )
        if not isinstance(value, dict) or canonical_json_bytes(value) != line:
            raise ValueError(f"scientific JSONL is noncanonical: {path.name}")
        rows.append(value)
    return tuple(rows)


def publish_markdown(paths: CampaignPaths, relative: str, text: str) -> str:
    return _publish_bytes(
        paths,
        relative,
        text.encode("utf-8"),
        ExternalArtifactKind.MARKDOWN_REPORT,
    )


def publish_hash_manifest(paths: CampaignPaths, relative: str, text: str) -> str:
    return _publish_bytes(
        paths,
        relative,
        text.encode("utf-8"),
        ExternalArtifactKind.HASH_MANIFEST,
    )


def update_progress_ledger(
    paths: CampaignPaths,
    *,
    phase: str,
    status: str,
    source_commit: str,
    details: Mapping[str, object] | None = None,
) -> str:
    """Append one logical event through an atomic, self-hashed ledger rewrite."""

    if not phase or status not in {"started", "completed", "stopped", "resumed"}:
        raise ValueError("progress phase/status is invalid")
    path = paths.output("logs/STAGE3_3_PROGRESS_LEDGER.json")
    events: list[object] = []
    if path.exists():
        validate_external_destination(
            path,
            external_root=paths.output_root,
            kind=ExternalArtifactKind.PROGRESS_LEDGER,
            require_absent=False,
        )
        existing = load_strict_json(path)
        if not isinstance(existing, Mapping):
            raise ValueError("progress ledger is malformed")
        without_hash = dict(existing)
        stored = without_hash.pop("ledger_payload_sha256", None)
        if stored != canonical_sha256(without_hash):
            raise ValueError("progress ledger content hash is invalid")
        if existing.get("document_type") != "dmreda.stage3_3.progress_ledger":
            raise ValueError("progress ledger document type is invalid")
        current_events = existing.get("events")
        if not isinstance(current_events, list):
            raise ValueError("progress ledger events are malformed")
        events = list(current_events)
    event = {
        "sequence": len(events) + 1,
        "recorded_at_utc": utc_now(),
        "phase": phase,
        "status": status,
        "source_commit": source_commit,
        "details": dict(details or {}),
    }
    events.append(event)
    without_hash = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.progress_ledger",
        "event_count": len(events),
        "events": events,
    }
    payload = {
        **without_hash,
        "ledger_payload_sha256": canonical_sha256(without_hash),
    }
    encoded = canonical_json_bytes(payload) + b"\n"
    atomic_replace_checkpoint_bytes(
        path,
        encoded,
        external_root=paths.output_root,
        kind=ExternalArtifactKind.PROGRESS_LEDGER,
    )
    return sha256_file(path)


def _git(paths: CampaignPaths, *arguments: str) -> str:
    run = subprocess.run(
        ["git", *arguments],
        cwd=paths.repository_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if run.returncode != 0:
        raise RuntimeError(f"git {' '.join(arguments)} failed: {run.stderr.strip()}")
    return run.stdout.strip()


def current_source_commit(paths: CampaignPaths) -> str:
    value = _git(paths, "rev-parse", "HEAD")
    if len(value) != 40:
        raise ValueError("current source commit is invalid")
    return value


def require_clean_source(paths: CampaignPaths) -> str:
    if _git(paths, "branch", "--show-current") != (
        "research/dmreda-stage3-full-claim-validation"
    ):
        raise RuntimeError("campaign must run from the frozen Stage 3 branch")
    if _git(paths, "status", "--porcelain=v1", "--untracked-files=all"):
        raise RuntimeError("campaign requires a clean worktree")
    diff_check = subprocess.run(
        ["git", "diff", "--check"],
        cwd=paths.repository_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if diff_check.returncode != 0:
        raise RuntimeError("git diff --check failed")
    return current_source_commit(paths)


def build_raw_integrity(paths: CampaignPaths) -> dict[str, object]:
    files: dict[str, object] = {}
    passed = True
    for name, expected in RAW_FILE_CONTRACT.items():
        path = paths.dataset(name)
        identity = _raw_file_observation(path)
        observed: dict[str, object] = {
            "logical_name": name,
            **identity,
            "values_deserialized": False,
        }
        matches = (
            observed["bytes"] == expected["bytes"]
            and observed["md5"] == expected["md5"]
            and observed["sha256"] == expected["sha256"]
        )
        observed["matches_publisher_identity"] = matches
        passed = passed and matches
        files[name] = observed
    return {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.raw_integrity",
        "status": "passed" if passed else "failed",
        "access_scope": "byte_integrity_only_no_r_object_deserialization",
        "raw_dataset_hashes": dict(EXPECTED_RAW_DATASET_SHA256),
        "files": files,
    }


def _source_hashes(paths: CampaignPaths) -> dict[str, str]:
    missing = [relative for relative in SOURCE_FILES if not paths.repository(relative).is_file()]
    if missing:
        raise FileNotFoundError(f"campaign source files are missing: {missing}")
    return {relative: sha256_file(paths.repository(relative)) for relative in SOURCE_FILES}


def _run_full_tests(paths: CampaignPaths, *, phase: str) -> dict[str, object]:
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    run = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests"],
        cwd=paths.repository_root,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
    )
    combined = run.stdout + "\n" + run.stderr
    match = re.search(r"Ran (\d+) tests?", combined)
    count = None if match is None else int(match.group(1))
    return {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.test_report",
        "status": "passed" if run.returncode == 0 and count is not None else "failed",
        "phase": phase,
        "source_commit": current_source_commit(paths),
        "command": "python -m unittest discover -s tests",
        "test_count": count,
        "exit_code": run.returncode,
        "dual_boundary_tests_passed": run.returncode == 0,
    }


def _physical_memory_bytes() -> int | None:
    if sys.platform == "darwin":
        run = subprocess.run(
            ["sysctl", "-n", "hw.memsize"],
            check=False,
            capture_output=True,
            text=True,
        )
        if run.returncode == 0 and run.stdout.strip().isdigit():
            return int(run.stdout.strip())
    try:
        pages = int(os.sysconf("SC_PHYS_PAGES"))
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
    except (AttributeError, OSError, TypeError, ValueError):
        return None
    return pages * page_size if pages > 0 and page_size > 0 else None


def _available_memory_bytes() -> int | None:
    if sys.platform == "darwin":
        run = subprocess.run(
            ["vm_stat"],
            check=False,
            capture_output=True,
            text=True,
        )
        page_match = re.search(r"page size of (\d+) bytes", run.stdout)
        if run.returncode == 0 and page_match is not None:
            pages = 0
            for label in ("Pages free", "Pages inactive", "Pages speculative"):
                match = re.search(rf"^{label}:\s+(\d+)\.", run.stdout, re.MULTILINE)
                if match is not None:
                    pages += int(match.group(1))
            if pages > 0:
                return pages * int(page_match.group(1))
    meminfo = Path("/proc/meminfo")
    if meminfo.is_file():
        match = re.search(
            r"^MemAvailable:\s+(\d+)\s+kB$",
            meminfo.read_text(encoding="ascii"),
            re.MULTILINE,
        )
        if match is not None:
            return int(match.group(1)) * 1024
    return None


def _normal_memory_probe_job(
    payload: tuple[
        RawScalarTrajectory,
        tuple[DetectorSpec, ...],
        str,
        str,
        str,
        str,
    ]
) -> dict[str, object]:
    trajectory, detectors, input_sha, protocol_sha, runner_sha, source_commit = payload
    rows = evaluate_normal_trajectories(
        (trajectory,),
        detectors,
        input_sha256=input_sha,
        protocol_sha256=protocol_sha,
        runner_sha256=runner_sha,
        source_commit=source_commit,
        workers=1,
        require_frozen_campaign_shape=False,
    )
    raw_rss = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    rss_bytes = raw_rss if sys.platform == "darwin" else raw_rss * 1024
    return {
        "rss_bytes": rss_bytes,
        "ru_maxrss_raw": raw_rss,
        "result_sha256": canonical_sha256({"rows": list(rows)}),
    }


def _record_worker_memory_probe(
    paths: CampaignPaths,
    *,
    source_commit: str,
    protocol_sha256: str,
    trajectory: RawScalarTrajectory,
    detectors: Sequence[DetectorSpec],
    input_sha256: str,
    runner_sha256: str,
) -> Mapping[str, object]:
    """Measure one isolated real worker before production multiprocessing."""

    destination = paths.output("environment/worker_memory_probe_stage3_3.json")
    if destination.exists():
        existing = load_strict_json(destination)
        if not isinstance(existing, Mapping) or (
            existing.get("source_commit") != source_commit
            or existing.get("protocol_sha256") != protocol_sha256
        ):
            raise RuntimeError("existing worker-memory probe is stale")
        return existing
    with ProcessPoolExecutor(max_workers=1) as executor:
        measured = executor.submit(
            _normal_memory_probe_job,
            (
                trajectory,
                tuple(detectors),
                input_sha256,
                protocol_sha256,
                runner_sha256,
                source_commit,
            ),
        ).result()
    rss_bytes = int(measured["rss_bytes"])
    raw_rss = int(measured["ru_maxrss_raw"])
    if rss_bytes <= 0:
        raise MemoryError("isolated worker RSS measurement failed")
    physical = _physical_memory_bytes()
    available = _available_memory_bytes()
    if available is None or available <= 0:
        raise MemoryError("available-memory measurement failed")
    reserve = max(2 * 1024**3, available // 4)
    usable = max(0, available - reserve)
    calculated = usable // (rss_bytes * 2)
    maximum = min(8, calculated)
    if maximum < 2:
        raise MemoryError("measured memory capacity cannot safely support two workers")
    report = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.worker_memory_probe",
        "status": "measured",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha256,
        "probe_workers": 1,
        "probe_trajectory_count": 1,
        "probe_evidence_channel_count": len(detectors),
        "probe_result_sha256": measured["result_sha256"],
        "ru_maxrss_raw": raw_rss,
        "ru_maxrss_units": "bytes" if sys.platform == "darwin" else "kibibytes",
        "conservative_rss_bytes": rss_bytes,
        "physical_memory_bytes": physical,
        "available_memory_bytes_at_probe": available,
        "reserved_memory_bytes": reserve,
        "per_worker_safety_factor": 2,
        "host": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "maximum_campaign_workers": int(maximum),
    }
    publish_json(paths, "environment/worker_memory_probe_stage3_3.json", report)
    return report


def _enforce_worker_memory_limit(
    paths: CampaignPaths,
    *,
    source_commit: str,
    protocol_sha256: str,
    workers: int,
) -> Mapping[str, object]:
    """Require every production phase to honor the durable memory probe."""

    probe = load_strict_json(
        paths.output("environment/worker_memory_probe_stage3_3.json")
    )
    if not isinstance(probe, Mapping) or any(
        probe.get(name) != value
        for name, value in {
            "status": "measured",
            "source_commit": source_commit,
            "protocol_sha256": protocol_sha256,
        }.items()
    ):
        raise RuntimeError("worker-memory probe is absent, malformed, or stale")
    maximum = probe.get("maximum_campaign_workers")
    if not isinstance(maximum, int) or maximum < 2 or maximum > 8:
        raise RuntimeError("worker-memory probe contains an invalid worker bound")
    if probe.get("probe_workers") != 1 or not isinstance(
        probe.get("conservative_rss_bytes"), int
    ):
        raise RuntimeError("worker-memory probe derivation fields are invalid")
    expected_host = {
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
    }
    if probe.get("host") != expected_host:
        raise RuntimeError("worker-memory probe belongs to a different host/runtime")
    available = _available_memory_bytes()
    if available is None or available <= 0:
        raise MemoryError("current available-memory measurement failed")
    reserve = max(2 * 1024**3, available // 4)
    current_maximum = min(
        8,
        max(0, available - reserve)
        // (int(probe["conservative_rss_bytes"]) * 2),
    )
    if current_maximum < 2:
        raise MemoryError("current memory capacity cannot safely support two workers")
    if workers > min(maximum, current_maximum):
        raise MemoryError(
            "requested worker count exceeds the durable or current memory bound"
        )
    return probe


def _validate_campaign_extraction_manifest(
    manifest: Mapping[str, object], *, raw_name: str
) -> None:
    """Bind a generic extraction manifest to the exact Stage 3.3 shape."""

    contract = RAW_FILE_CONTRACT[raw_name]
    source = manifest.get("source")
    validation = manifest.get("validation")
    faults = tuple(int(value) for value in contract["faults"])
    expected = {
        "row_count": contract["rows"],
        "trajectory_count": len(faults) * int(contract["runs"]),
        "first_key": [faults[0], 1, 1],
        "last_key": [faults[-1], contract["runs"], contract["horizon"]],
    }
    if not isinstance(source, Mapping) or (
        source.get("logical_name") != raw_name
        or source.get("object_name") != contract["object"]
        or source.get("sha256") != contract["sha256"]
    ):
        raise RuntimeError("extraction source/object binding differs from frozen contract")
    if not isinstance(validation, Mapping) or any(
        validation.get(name) != value for name, value in expected.items()
    ):
        raise RuntimeError("extraction cardinality binding differs from frozen contract")


def _run_r_extraction(
    paths: CampaignPaths,
    *,
    raw_name: str,
    output_relative: str,
    manifest_relative: str,
    long_run: bool = False,
) -> tuple[Path, Mapping[str, object]]:
    contract = RAW_FILE_CONTRACT[raw_name]
    output = paths.output(output_relative)
    manifest_path = paths.output(manifest_relative)
    source = paths.dataset(raw_name)
    extractor = paths.repository("scripts/stage3/extract_tep_xmeas7.R")
    before = _validate_raw_file_identity(paths, raw_name)
    if output.exists() or manifest_path.exists():
        if output.exists() and not manifest_path.exists():
            validate_external_destination(
                output,
                external_root=paths.output_root,
                kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
                require_absent=False,
            )
            if output.is_symlink():
                raise PermissionError("orphan extraction output is a symlink")
            recovered = build_extraction_manifest(
                dataset_identifier="tep-rieth-v1",
                expected_object=str(contract["object"]),
                source_path=source,
                extractor_script_path=extractor,
                output_path=output,
            )
            _validate_campaign_extraction_manifest(recovered, raw_name=raw_name)
            after = _validate_raw_file_identity(paths, raw_name)
            if after != before:
                raise RuntimeError("raw dataset changed during orphan recovery")
            publish_json(paths, manifest_relative, recovered)
            update_progress_ledger(
                paths,
                phase="orphan_extraction_recovery",
                status="completed",
                source_commit=current_source_commit(paths),
                details={
                    "raw_logical_name": raw_name,
                    "output_sha256": recovered["output"]["sha256"],
                    "reconstructed_manifest_only": True,
                },
            )
            return output, recovered
        if manifest_path.exists() and not output.exists():
            raise RuntimeError("extraction output/manifest pair is incomplete")
        validate_external_destination(
            output,
            external_root=paths.output_root,
            kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
            require_absent=False,
        )
        validate_external_destination(
            manifest_path,
            external_root=paths.output_root,
            kind=ExternalArtifactKind.IMMUTABLE_JSON,
            require_absent=False,
        )
        if output.is_symlink() or manifest_path.is_symlink():
            raise PermissionError("existing extraction pair must not contain symlinks")
        manifest = load_strict_json(manifest_path)
        if not isinstance(manifest, Mapping):
            raise ValueError("extraction manifest is malformed")
        validate_extraction_bindings(
            manifest,
            source_path=source,
            extractor_script_path=extractor,
            output_path=output,
        )
        _validate_campaign_extraction_manifest(manifest, raw_name=raw_name)
        after = _validate_raw_file_identity(paths, raw_name)
        if after != before:
            raise RuntimeError("raw dataset changed during resumed extraction validation")
        if manifest.get("source", {}).get("sha256") != before["sha256"]:
            raise RuntimeError("extraction manifest is not bound to the frozen raw file")
        return output, manifest

    validate_external_destination(
        output,
        external_root=paths.output_root,
        kind=ExternalArtifactKind.SCALAR_TRAJECTORY,
    )
    rscript = shutil.which("Rscript")
    if rscript is None:
        raise RuntimeError("Rscript is required for authoritative RData extraction")
    command = [
        rscript,
        "--vanilla",
        str(extractor),
        "--source",
        str(source),
        "--output",
        str(output),
        "--external-root",
        str(paths.output_root),
        "--expected-object",
        str(contract["object"]),
        "--expected-rows",
        str(contract["rows"]),
        "--expected-columns",
        str(contract["columns"]),
        "--expected-fault-numbers",
        ",".join(str(value) for value in contract["faults"]),
        "--expected-runs-per-fault",
        str(contract["runs"]),
        "--expected-samples-per-run",
        str(contract["horizon"]),
    ]
    if long_run and shutil.which("caffeinate"):
        command = [shutil.which("caffeinate") or "caffeinate", "-dimsu", *command]
    run = subprocess.run(command, check=False, capture_output=True, text=True)
    if run.returncode != 0:
        raise RuntimeError(f"R extraction failed: {run.stderr.strip()}")
    after = _validate_raw_file_identity(paths, raw_name)
    if after != before:
        raise RuntimeError("raw dataset changed during authoritative extraction")
    manifest = build_extraction_manifest(
        dataset_identifier="tep-rieth-v1",
        expected_object=str(contract["object"]),
        source_path=source,
        extractor_script_path=extractor,
        output_path=output,
    )
    _validate_campaign_extraction_manifest(manifest, raw_name=raw_name)
    if manifest.get("source", {}).get("sha256") != before["sha256"]:
        raise RuntimeError("new extraction manifest is not bound to frozen raw identity")
    publish_json(paths, manifest_relative, manifest)
    return output, manifest


def _layer_manifest(
    *,
    layer: str,
    result_relative: str,
    result_payload: Mapping[str, object],
    result_file_sha256: str,
    report_relative: str,
    report_file_sha256: str,
) -> dict[str, object]:
    without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": f"dmreda.stage3_3.{layer}_completion_manifest",
        "status": "complete_and_verified",
        "result_logical_name": result_relative,
        "result_file_sha256": result_file_sha256,
        "result_payload_sha256": result_payload["result_sha256"],
        "report_logical_name": report_relative,
        "report_file_sha256": report_file_sha256,
    }
    return {**without_hash, "manifest_sha256": canonical_sha256(without_hash)}


def _configuration_index(
    records: Mapping[str, Mapping[str, object]], *, source_commit: str
) -> dict[str, object]:
    without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.scalar_reference_configuration_index",
        "status": "frozen",
        "source_commit": source_commit,
        "configuration_sha256": {
            name: records[name]["configuration_sha256"] for name in sorted(records)
        },
        "records": {name: dict(records[name]) for name in sorted(records)},
    }
    return {**without_hash, "index_payload_sha256": canonical_sha256(without_hash)}


def _pre_freeze_access_evidence(source_commit: str) -> dict[str, object]:
    return {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.pre_freeze_access_evidence",
        "status": "complete",
        "source_commit": source_commit,
        "fault_free_training_values_accessed": True,
        "fault_free_training_access_scope": (
            "all_500_scalar_runs_deserialized_for_schema_and_complete_extract_validation"
        ),
        "fault_free_training_calibration_use": "simulationRun_101_through_200_only",
        "fault_free_testing_values_accessed": False,
        "faulty_testing_values_accessed": False,
        "detector_outcome_rows_created": False,
        "bank_d_state": "sealed_unopened",
    }


def _progress_ledger_contains_phase(
    paths: CampaignPaths, phases: set[str]
) -> bool:
    ledger_path = paths.output("logs/STAGE3_3_PROGRESS_LEDGER.json")
    if not ledger_path.exists():
        return False
    ledger = load_strict_json(ledger_path)
    if not isinstance(ledger, Mapping):
        raise ValueError("progress ledger is malformed")
    without_hash = dict(ledger)
    stored = without_hash.pop("ledger_payload_sha256", None)
    events = ledger.get("events")
    if stored != canonical_sha256(without_hash) or not isinstance(events, list):
        raise ValueError("progress ledger integrity is invalid")
    return any(
        isinstance(event, Mapping) and event.get("phase") in phases
        for event in events
    )


def _files_under(paths: CampaignPaths, relative: str) -> tuple[Path, ...]:
    root = paths.output(relative)
    if not root.exists():
        return ()
    return tuple(
        path
        for path in root.rglob("*")
        if path.is_file() or path.is_symlink()
    )


def _assert_testing_unopened_before_freeze(paths: CampaignPaths) -> None:
    forbidden = (
        "authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json",
        "normal_gate/normal_gate_manifest.json",
        "protocol/BANK_D_ADMISSION_SEAL_V2.json",
        "protocol/BANK_D_OPEN_EVENT_V2.json",
        "extracts/fault_free_testing_xmeas7.csv.gz",
        "extracts/fault_free_testing_xmeas7.manifest.json",
        "extracts/faulty_testing_xmeas7.csv.gz",
        "extracts/faulty_testing_xmeas7.manifest.json",
        "normal_gate/fault_free_testing_extraction.json",
        "normal_gate/dmreda_normal_trajectory_results.jsonl",
        "normal_gate/scalar_reference_normal_trajectory_results.jsonl",
        "normal_gate/dmreda_normal_summary.json",
        "normal_gate/scalar_reference_admission.json",
        "normal_gate/normal_gate_report.md",
        "bank_d/primary/primary_result_manifest.json",
    )
    present = [relative for relative in forbidden if paths.output(relative).exists()]
    derived_files = (
        *_files_under(paths, "bank_d"),
        *_files_under(paths, "reproducibility"),
        *(
            path
            for path in _files_under(paths, "extracts")
            if "testing" in path.name.lower()
        ),
    )
    prior_access_event = _progress_ledger_contains_phase(
        paths,
        {
            "independent_normal_gate",
            "bank_d_primary",
            "bank_d_primary_fault",
            "secondary_ablations",
            "deterministic_reproduction",
            "deterministic_reproduction_fault",
            "final_reporting_and_packaging",
            "blocked_reporting_and_packaging",
        },
    )
    if present or derived_files or prior_access_event:
        raise PermissionError(
            "Testing-access evidence exists before first protocol freeze: "
            f"{present + [str(path.relative_to(paths.output_root)) for path in derived_files]}"
        )


def _assert_bank_d_unopened(paths: CampaignPaths) -> None:
    forbidden = (
        "protocol/BANK_D_OPEN_EVENT_V2.json",
        "extracts/faulty_testing_xmeas7.csv.gz",
        "extracts/faulty_testing_xmeas7.manifest.json",
        "extracts/faulty_testing_extraction_manifest.json",
        "bank_d/primary/primary_result_manifest.json",
        "manifests/FINAL_ARTIFACT_MANIFEST_V2.json",
    )
    present = [relative for relative in forbidden if paths.output(relative).exists()]
    derived_files = (
        *_files_under(paths, "bank_d"),
        *_files_under(paths, "reproducibility"),
        *(
            path
            for path in _files_under(paths, "extracts")
            if "faulty_testing" in path.name.lower()
        ),
    )
    prior_access_event = _progress_ledger_contains_phase(
        paths,
        {
            "bank_d_primary",
            "bank_d_primary_fault",
            "secondary_ablations",
            "deterministic_reproduction",
            "deterministic_reproduction_fault",
            "final_reporting_and_packaging",
        },
    )
    if present or derived_files or prior_access_event:
        raise PermissionError("Bank D has prior or uncertain access evidence")


def _assert_fault_free_testing_open_is_not_reconstructed(
    paths: CampaignPaths,
) -> None:
    """Reject a missing marker when any normal-Testing derivative already exists."""

    marker = paths.output("authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json")
    if marker.exists():
        return
    forbidden = (
        "extracts/fault_free_testing_xmeas7.csv.gz",
        "extracts/fault_free_testing_xmeas7.manifest.json",
        "normal_gate/fault_free_testing_extraction.json",
        "normal_gate/dmreda_normal_trajectory_results.jsonl",
        "normal_gate/scalar_reference_normal_trajectory_results.jsonl",
        "normal_gate/dmreda_normal_summary.json",
        "normal_gate/scalar_reference_admission.json",
        "normal_gate/normal_gate_report.md",
        "normal_gate/normal_gate_manifest.json",
        "protocol/BANK_D_ADMISSION_SEAL_V2.json",
    )
    present = [relative for relative in forbidden if paths.output(relative).exists()]
    present.extend(
        str(path.relative_to(paths.output_root))
        for path in _files_under(paths, "extracts")
        if "fault_free_testing" in path.name.lower()
    )
    prior_access_event = _progress_ledger_contains_phase(
        paths, {"independent_normal_gate"}
    )
    if present or prior_access_event:
        raise PermissionError(
            "FaultFree Testing open marker is absent despite derived access evidence"
        )


def _validate_frozen_prefreeze_evidence(
    paths: CampaignPaths, protocol: Mapping[str, object]
) -> None:
    """Verify every pre-freeze dependency before first Testing-value access."""

    if _source_hashes(paths) != protocol.get("source_hashes"):
        raise RuntimeError("current campaign source hashes differ from frozen protocol")
    candidate_path = paths.output("protocol/onset_mapping_candidate.json")
    if sha256_file(candidate_path) != DUAL_BOUNDARY_CANDIDATE_FILE_SHA256:
        raise RuntimeError("dual-boundary candidate file changed after freeze")
    candidate = load_strict_json(candidate_path)
    dual = protocol.get("dual_boundary_contract")
    if not isinstance(candidate, Mapping) or not isinstance(dual, Mapping) or (
        dual.get("candidate_payload_sha256") != canonical_sha256(candidate)
    ):
        raise RuntimeError("dual-boundary candidate payload differs from protocol")

    layers = protocol.get("layer_contracts")
    if not isinstance(layers, Mapping):
        raise ValueError("protocol layer bindings are malformed")
    for name, relative in (
        ("layer_a", "representation/representation_validation_results.json"),
        ("layer_b", "arbitration/arbitration_validation_results.json"),
    ):
        binding = layers.get(name)
        result_path = paths.output(relative)
        result = load_strict_json(result_path)
        if (
            not isinstance(binding, Mapping)
            or not isinstance(result, Mapping)
            or result.get("status") != "passed"
            or result.get("result_sha256") != binding.get("result_payload_sha256")
            or sha256_file(result_path) != binding.get("result_file_sha256")
        ):
            raise RuntimeError(f"frozen {name} evidence is absent, stale, or invalid")

    prefreeze = protocol.get("pre_freeze_validation")
    access = protocol.get("testing_access_state_at_freeze")
    if not isinstance(prefreeze, Mapping) or not isinstance(access, Mapping):
        raise ValueError("protocol pre-freeze bindings are malformed")
    bound_paths = {
        "full_test_report_sha256": paths.output(
            "environment/test_report_stage3_3_pre_freeze.json"
        ),
        "output_guard_report_sha256": paths.output(
            "environment/output_guard_report_stage3_3_pre_freeze.json"
        ),
        "git_state_sha256": paths.output(
            "environment/git_state_stage3_3_pre_freeze.json"
        ),
    }
    if any(
        sha256_file(path) != prefreeze.get(field)
        for field, path in bound_paths.items()
    ):
        raise RuntimeError("pre-freeze test, output, or Git evidence changed")
    access_path = paths.output(
        "authority/access_evidence_manifest_stage3_3_pre_freeze.json"
    )
    access_payload = load_strict_json(access_path)
    if (
        sha256_file(access_path) != access.get("access_evidence_sha256")
        or not isinstance(access_payload, Mapping)
        or access_payload.get("fault_free_testing_values_accessed") is not False
        or access_payload.get("faulty_testing_values_accessed") is not False
    ):
        raise RuntimeError("pre-freeze Testing-access evidence is invalid")
    raw = load_strict_json(paths.output("environment/raw_integrity_stage3_3.json"))
    if (
        not isinstance(raw, Mapping)
        or raw.get("status") != "passed"
        or raw.get("raw_dataset_hashes") != EXPECTED_RAW_DATASET_SHA256
    ):
        raise RuntimeError("pre-freeze raw-integrity evidence is invalid")
    reference_index = load_strict_json(
        paths.output("calibration/scalar_reference_configurations_v2.json")
    )
    expected_records = {
        name: {key: value for key, value in record.items() if key != "scientific_role"}
        for name, record in protocol["scalar_evidence_references"].items()
    }
    if (
        not isinstance(reference_index, Mapping)
        or reference_index.get("source_commit") != protocol.get("source_commit")
        or reference_index.get("records") != expected_records
    ):
        raise RuntimeError("scalar-reference configuration index is stale")
    implementation = load_strict_json(
        paths.output("environment/dual_boundary_implementation_report.json")
    )
    if (
        not isinstance(implementation, Mapping)
        or implementation.get("status") != "passed"
        or implementation.get("candidate_file_sha256")
        != DUAL_BOUNDARY_CANDIDATE_FILE_SHA256
        or implementation.get("tests_passed") is not True
    ):
        raise RuntimeError("dual-boundary implementation evidence is invalid")


def run_prefreeze(paths: CampaignPaths) -> Mapping[str, object]:
    """Execute all permitted pre-Testing work and freeze protocol V2."""

    ensure_output_layout(paths)
    protocol_paths = (
        paths.output("protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"),
        paths.output("protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md"),
        paths.output("protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"),
    )
    if any(path.exists() for path in protocol_paths):
        if not all(path.exists() for path in protocol_paths):
            raise RuntimeError("protocol V2 freeze set is partial")
        protocol = validate_frozen_protocol_v2(
            json_path=protocol_paths[0],
            markdown_path=protocol_paths[1],
            manifest_path=protocol_paths[2],
        )
        source_commit = require_clean_source(paths)
        if protocol.get("source_commit") != source_commit:
            raise RuntimeError("frozen protocol source differs from current HEAD")
        _validate_frozen_prefreeze_evidence(paths, protocol)
        update_progress_ledger(
            paths,
            phase="protocol_v2",
            status="resumed",
            source_commit=source_commit,
            details={"protocol_sha256": canonical_sha256(protocol)},
        )
        return protocol

    source_commit = require_clean_source(paths)
    _assert_testing_unopened_before_freeze(paths)
    update_progress_ledger(
        paths,
        phase="prefreeze",
        status="started",
        source_commit=source_commit,
        details={"testing_values_opened": False},
    )
    test_report = _run_full_tests(paths, phase="pre_protocol_freeze")
    if test_report["status"] != "passed":
        raise RuntimeError("full repository test suite failed before protocol work")
    candidate_path = paths.output("protocol/onset_mapping_candidate.json")
    if sha256_file(candidate_path) != DUAL_BOUNDARY_CANDIDATE_FILE_SHA256:
        raise RuntimeError("dual-boundary candidate file hash mismatch")
    candidate = load_strict_json(candidate_path)
    if not isinstance(candidate, Mapping):
        raise ValueError("dual-boundary candidate is malformed")
    validate_dual_boundary_contract(candidate)
    dual_boundary_adoption = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.dual_boundary_protocol_adoption",
        "status": "prepared_for_v2_freeze",
        "candidate_file_sha256": DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        "candidate_payload_sha256": canonical_sha256(candidate),
        "coequal_python_onset_indices": [159, 160],
        "selected_mapping": None,
        "scientific_value_access_authorized_by_this_artifact": False,
        "authorization_requires_completed_protocol_v2_freeze": True,
    }
    publish_json(
        paths, "protocol/dual_boundary_contract.json", dual_boundary_adoption
    )

    raw_integrity = build_raw_integrity(paths)
    raw_integrity_sha = publish_json(
        paths, "environment/raw_integrity_stage3_3.json", raw_integrity
    )
    if raw_integrity["status"] != "passed":
        raise RuntimeError("raw dataset integrity failed")

    layer_a = run_representation_validation()
    layer_a_file_sha = publish_json(
        paths, "representation/representation_validation_results.json", layer_a
    )
    fingerprints = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.representation_fingerprints",
        "result_payload_sha256": layer_a["result_sha256"],
        "same_energy_separation_matrix": layer_a["same_energy_separation_matrix"],
        "equal_peak_separation_matrix": layer_a["equal_peak_separation_matrix"],
        "pairwise_fingerprint_distance_definition": layer_a[
            "pairwise_fingerprint_distance_definition"
        ],
        "interpretation": layer_a["fingerprint_interpretation"],
    }
    publish_json(paths, "representation/same_energy_fingerprints.json", fingerprints)
    layer_a_report_sha = publish_markdown(
        paths,
        "representation/representation_validation_report.md",
        render_representation_report(layer_a),
    )
    publish_json(
        paths,
        "representation/representation_validation_manifest.json",
        _layer_manifest(
            layer="layer_a",
            result_relative="representation/representation_validation_results.json",
            result_payload=layer_a,
            result_file_sha256=layer_a_file_sha,
            report_relative="representation/representation_validation_report.md",
            report_file_sha256=layer_a_report_sha,
        ),
    )
    if layer_a["status"] != "passed":
        raise RuntimeError("Layer A representation contract failed")

    layer_b = run_arbitration_validation()
    layer_b_file_sha = publish_json(
        paths, "arbitration/arbitration_validation_results.json", layer_b
    )
    layer_b_report_sha = publish_markdown(
        paths,
        "arbitration/arbitration_validation_report.md",
        render_arbitration_report(layer_b),
    )
    publish_json(
        paths,
        "arbitration/arbitration_validation_manifest.json",
        _layer_manifest(
            layer="layer_b",
            result_relative="arbitration/arbitration_validation_results.json",
            result_payload=layer_b,
            result_file_sha256=layer_b_file_sha,
            report_relative="arbitration/arbitration_validation_report.md",
            report_file_sha256=layer_b_report_sha,
        ),
    )
    if layer_b["status"] != "passed":
        raise RuntimeError("Layer B arbitration contract failed")

    training_extract, training_manifest = _run_r_extraction(
        paths,
        raw_name="TEP_FaultFree_Training.RData",
        output_relative="extracts/fault_free_training_xmeas7.csv.gz",
        manifest_relative="extracts/fault_free_training_xmeas7.manifest.json",
    )
    training_bank = load_scalar_bank(
        training_extract,
        partition="fault_free_training",
        expected_fault_numbers=(0,),
        expected_runs_per_fault=500,
        expected_horizon=500,
        retain_simulation_runs=tuple(range(101, 201)),
        expected_extract_sha256=str(training_manifest["output"]["sha256"]),
    )
    calibration, reference_records, _ = calibrate_scalar_references(
        training_bank.trajectories
    )
    calibration_without_hash = dict(calibration)
    calibration_without_hash.pop("calibration_payload_sha256")
    calibration_bound_without_hash: dict[str, object] = {
        **calibration_without_hash,
        "source_commit": source_commit,
        "source_rdata_sha256": EXPECTED_RAW_DATASET_SHA256[
            "TEP_FaultFree_Training.RData"
        ],
        "extraction_manifest_sha256": sha256_file(
            paths.output("extracts/fault_free_training_xmeas7.manifest.json")
        ),
        "extract_sha256": training_bank.extract_sha256,
    }
    calibration_bound = {
        **calibration_bound_without_hash,
        "calibration_payload_sha256": canonical_sha256(calibration_bound_without_hash),
    }
    publish_json(
        paths, "normal_gate/scalar_reference_calibration.json", calibration_bound
    )
    configuration_index = _configuration_index(
        reference_records, source_commit=source_commit
    )
    publish_json(
        paths,
        "calibration/scalar_reference_configurations_v2.json",
        configuration_index,
    )

    dmreda_config = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.frozen_core_configuration",
        "status": "frozen",
        "source_commit": source_commit,
        "configuration": tep_configuration_snapshot(),
        "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "effective_profiles_sha256": FROZEN_EFFECTIVE_PROFILES_SHA256,
    }
    publish_json(
        paths, "calibration/dmreda_frozen_configuration_stage3_3.json", dmreda_config
    )

    test_report_sha = publish_json(
        paths, "environment/test_report_stage3_3_pre_freeze.json", test_report
    )
    source_hashes = _source_hashes(paths)
    publish_json(
        paths,
        "environment/source_hashes_stage3_3.json",
        {
            "schema_version": "1.0.0",
            "document_type": "dmreda.stage3_3.source_hashes",
            "source_commit": source_commit,
            "source_hashes": source_hashes,
        },
    )
    git_state = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.git_state",
        "status": "clean",
        "branch": "research/dmreda-stage3-full-claim-validation",
        "source_commit": source_commit,
        "diff_check_passed": True,
    }
    git_state_sha = publish_json(
        paths, "environment/git_state_stage3_3_pre_freeze.json", git_state
    )
    output_guard = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.output_guard_report",
        "status": "passed",
        "immutable_no_clobber": True,
        "external_root_containment": True,
        "checkpoint_replacement_only": True,
        "source_commit": source_commit,
    }
    output_guard_sha = publish_json(
        paths,
        "environment/output_guard_report_stage3_3_pre_freeze.json",
        output_guard,
    )
    access = _pre_freeze_access_evidence(source_commit)
    access_sha = publish_json(
        paths,
        "authority/access_evidence_manifest_stage3_3_pre_freeze.json",
        access,
    )
    authority_source_path = paths.output("authority/dataset_authority_report.json")
    authority_source = load_strict_json(authority_source_path)
    if not isinstance(authority_source, Mapping) or (
        authority_source.get("authority_status") != "verified_primary_source"
        or authority_source.get("admission_level") != "claim_grade_candidate"
        or authority_source.get("dataset_identifier") != "tep-rieth-v1"
        or authority_source.get("license_status")
        != "custom_terms_manually_reviewed_and_accepted_by_user"
        or authority_source.get("raw_files")
        != {
            name: {
                "bytes": contract["bytes"],
                "md5": contract["md5"],
                "sha256": contract["sha256"],
            }
            for name, contract in RAW_FILE_CONTRACT.items()
        }
    ):
        raise RuntimeError("durable TEP authority/license evidence is incomplete")
    dataset_authority = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.dataset_authority",
        "authority_status": "verified_primary_source",
        "admission_level": "claim_grade_candidate",
        "dataset_identifier": "tep-rieth-v1",
        "doi": authority_source["source"]["doi"],
        "authority_source_report_sha256": sha256_file(authority_source_path),
        "license_status": authority_source["license_status"],
        "license_summary": authority_source["license_summary"],
        "independent_recording_identity": authority_source[
            "independent_recording_identity"
        ],
        "onset_authority": "unresolved_but_dual_boundary_permitted",
        "selected_onset_mapping": None,
        "bank_d_admission_deferred_to_machine_derived_seal_v2": True,
        "source_audit_onset_blocker_preserved": True,
    }
    publish_json(
        paths,
        "authority/dataset_authority_report_stage3_3.json",
        dataset_authority,
    )
    dual_implementation = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.dual_boundary_implementation_report",
        "status": "passed",
        "candidate_file_sha256": DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        "candidate_payload_sha256": canonical_sha256(candidate),
        "tests_passed": True,
        "runner_sha256": source_hashes["stage3/tep/authority_runner.py"],
        "event_generation_accepts_onset": False,
        "coequal_onsets": [159, 160],
    }
    publish_json(
        paths,
        "environment/dual_boundary_implementation_report.json",
        dual_implementation,
    )

    pre_freeze_validation = {
        "status": "passed",
        "worktree_clean": require_clean_source(paths) == source_commit,
        "full_test_report_sha256": test_report_sha,
        "output_guard_report_sha256": output_guard_sha,
        "git_state_sha256": git_state_sha,
    }
    protocol = build_protocol_payload_v2(
        freeze_timestamp_utc=utc_now(),
        source_commit=source_commit,
        source_hashes=source_hashes,
        raw_dataset_hashes=EXPECTED_RAW_DATASET_SHA256,
        dataset_authority=dataset_authority,
        scalar_reference_configurations=reference_records,
        dual_boundary_contract=candidate,
        dual_boundary_candidate_file_sha256=DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        layer_a_binding={
            "status": "passed",
            "expectations_sha256": FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
            "fixture_contract_sha256": (
                FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256
            ),
            "result_payload_sha256": layer_a["result_sha256"],
            "result_file_sha256": layer_a_file_sha,
        },
        layer_b_binding={
            "status": "passed",
            "expectations_sha256": FROZEN_ARBITRATION_EXPECTATIONS_SHA256,
            "result_payload_sha256": layer_b["result_sha256"],
            "result_file_sha256": layer_b_file_sha,
            "same_sample_timeout_rearm": "unresolved_design_choice_preserved",
            "policy_changed": False,
        },
        pre_freeze_validation=pre_freeze_validation,
        access_evidence_sha256=access_sha,
        implementation_version=f"stage3.3-{source_commit[:12]}",
    )
    for destination, kind in (
        (protocol_paths[0], ExternalArtifactKind.IMMUTABLE_JSON),
        (protocol_paths[1], ExternalArtifactKind.MARKDOWN_REPORT),
        (protocol_paths[2], ExternalArtifactKind.IMMUTABLE_JSON),
    ):
        validate_external_destination(
            destination,
            external_root=paths.output_root,
            kind=kind,
        )
    freeze_protocol_v2(
        json_path=protocol_paths[0],
        markdown_path=protocol_paths[1],
        manifest_path=protocol_paths[2],
        payload=protocol,
    )
    validate_frozen_protocol_v2(
        json_path=protocol_paths[0],
        markdown_path=protocol_paths[1],
        manifest_path=protocol_paths[2],
    )
    update_progress_ledger(
        paths,
        phase="protocol_v2",
        status="completed",
        source_commit=source_commit,
        details={"protocol_sha256": canonical_sha256(protocol)},
    )
    return protocol


def detectors_from_protocol(
    protocol: Mapping[str, object], *, admitted_references: Sequence[str] | None = None
) -> tuple[DetectorSpec, ...]:
    """Reconstruct exact evidence-channel specifications from frozen protocol."""

    primary = protocol["primary_evidence_channel"]
    if not isinstance(primary, Mapping):
        raise ValueError("protocol primary evidence channel is malformed")
    detectors: list[DetectorSpec] = [
        DetectorSpec.canonical_dmreda(
            name=str(primary["name"]), mode=str(primary["mode"])
        )
    ]
    records = protocol["scalar_evidence_references"]
    if not isinstance(records, Mapping):
        raise ValueError("protocol scalar-reference records are malformed")
    names = (
        tuple(sorted(records))
        if admitted_references is None
        else tuple(sorted(admitted_references))
    )
    if any(name not in records for name in names):
        raise ValueError("admitted reference is absent from the frozen protocol")
    for name in names:
        record = records[name]
        if not isinstance(record, Mapping):
            raise ValueError("protocol scalar-reference record is malformed")
        configuration = record["configuration"]
        if not isinstance(configuration, Mapping):
            raise ValueError("protocol detector configuration is malformed")
        gate_data = configuration["gate"]
        parameters = configuration["parameters"]
        if not isinstance(gate_data, Mapping) or not isinstance(parameters, Mapping):
            raise ValueError("protocol detector gate or parameters are malformed")
        from gold_line.benchmarks.fair_baseline_scaffold import EventGateConfig

        gate = EventGateConfig(
            warmup_samples=int(gate_data["warmup_samples"]),
            persistence=int(gate_data["persistence"]),
            refractory=int(gate_data["refractory"]),
        )
        if name == "rms":
            detector = DetectorSpec.rms(
                threshold=float(configuration["threshold"]),
                gate=gate,
                window=int(parameters["window"]),
            )
        elif name == "cusum":
            detector = DetectorSpec.cusum(
                threshold=float(configuration["threshold"]),
                gate=gate,
                center=float(parameters["center"]),
                allowance=float(parameters["allowance"]),
            )
        elif name == "ewma":
            detector = DetectorSpec.ewma(
                threshold=float(configuration["threshold"]),
                gate=gate,
                center=float(parameters["center"]),
                scale=float(parameters["scale"]),
                alpha=float(parameters["alpha"]),
            )
        else:  # pragma: no cover - protocol validator owns exact names.
            raise ValueError("unsupported scalar reference")
        if detector.to_dict() != configuration or detector.detector_sha256 != record[
            "configuration_sha256"
        ]:
            raise ValueError("reconstructed detector differs from frozen protocol")
        detectors.append(detector)
    return tuple(detectors)


def _bind_payload(
    payload: Mapping[str, object],
    *,
    hash_field: str,
    artifact_bindings: Mapping[str, str],
) -> dict[str, object]:
    bound = dict(payload)
    previous = bound.pop(hash_field, None)
    bound["unbound_payload_sha256"] = previous
    bound["artifact_bindings"] = dict(sorted(artifact_bindings.items()))
    bound[hash_field] = canonical_sha256(bound)
    return bound


def _extraction_adapter(
    *,
    partition: str,
    extract_sha256: str,
    manifest_sha256: str,
    trajectory_count: int,
    horizon: int,
) -> dict[str, object]:
    return {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.scalar_extraction_adapter",
        "status": "passed",
        "partition": partition,
        "schema_verified": True,
        "trajectory_count": trajectory_count,
        "horizon": horizon,
        "extract_sha256": extract_sha256,
        "extraction_manifest_sha256": manifest_sha256,
        "channel": "xmeas_7",
        "identity_fields": ["partition", "faultNumber", "simulationRun"],
    }


def _prebank_artifacts(
    paths: CampaignPaths,
    *,
    source_commit: str,
    protocol_sha256: str,
    normal_manifest_sha256: str,
) -> dict[str, str]:
    _assert_bank_d_unopened(paths)
    if require_clean_source(paths) != source_commit:
        raise RuntimeError("source changed during normal-gate evaluation")
    current_test = {
        **_run_full_tests(paths, phase="pre_bank_d"),
        "protocol_sha256": protocol_sha256,
        "normal_gate_manifest_sha256": normal_manifest_sha256,
    }
    if current_test["status"] != "passed":
        raise RuntimeError("full repository tests failed before Bank D sealing")
    test_sha = publish_json(
        paths, "environment/test_report_stage3_3_pre_bank_d.json", current_test
    )
    output_guard = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.output_guard_report",
        "status": "passed",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha256,
        "normal_gate_manifest_sha256": normal_manifest_sha256,
        "external_artifacts_only": True,
    }
    output_sha = publish_json(
        paths, "environment/output_guard_report_stage3_3_pre_bank_d.json", output_guard
    )
    git_state = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.git_state",
        "status": "clean",
        "branch": "research/dmreda-stage3-full-claim-validation",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha256,
    }
    git_sha = publish_json(
        paths, "environment/git_state_stage3_3_pre_bank_d.json", git_state
    )
    recovery = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.pre_bank_d_recovery_integrity",
        "status": "passed",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha256,
        "bank_d_state": "sealed_unopened",
        "fault_free_testing_values_accessed": True,
        "faulty_testing_values_accessed": False,
        "normal_gate_manifest_sha256": normal_manifest_sha256,
    }
    recovery_sha = publish_json(
        paths, "recovery/recovery_integrity_stage3_3_pre_bank_d.json", recovery
    )
    access = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.pre_bank_d_access_evidence",
        "status": "complete",
        "source_commit": source_commit,
        "fault_free_testing_values_accessed": True,
        "fault_free_testing_purpose": "independent_normal_false_authority_gate",
        "faulty_testing_values_accessed": False,
        "bank_d_state": "sealed_unopened",
        "protocol_sha256": protocol_sha256,
    }
    publish_json(
        paths, "authority/access_evidence_manifest_stage3_3_pre_bank_d.json", access
    )
    return {
        "test_report": test_sha,
        "output_guard": output_sha,
        "git_state": git_sha,
        "recovery_integrity": recovery_sha,
    }


def _bank_d_reference_paths(paths: CampaignPaths) -> dict[str, Path]:
    references = {
        "protocol_json": paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"
        ),
        "protocol_freeze_manifest": paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"
        ),
        "dual_boundary_candidate": paths.output("protocol/onset_mapping_candidate.json"),
        "dual_boundary_implementation": paths.output(
            "environment/dual_boundary_implementation_report.json"
        ),
        "layer_a_result": paths.output(
            "representation/representation_validation_results.json"
        ),
        "layer_b_result": paths.output(
            "arbitration/arbitration_validation_results.json"
        ),
        "raw_integrity": paths.output("environment/raw_integrity_stage3_3.json"),
        "fault_free_testing_open_event": paths.output(
            "authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json"
        ),
        "pre_bank_d_access_evidence": paths.output(
            "authority/access_evidence_manifest_stage3_3_pre_bank_d.json"
        ),
        "fault_free_testing_extraction_manifest": paths.output(
            "extracts/fault_free_testing_xmeas7.manifest.json"
        ),
        "fault_free_testing_extraction": paths.output(
            "normal_gate/fault_free_testing_extraction.json"
        ),
        "normal_gate_manifest": paths.output("normal_gate/normal_gate_manifest.json"),
        "dmreda_normal_gate": paths.output("normal_gate/dmreda_normal_summary.json"),
        "scalar_reference_admission": paths.output(
            "normal_gate/scalar_reference_admission.json"
        ),
        "test_report": paths.output("environment/test_report_stage3_3_pre_bank_d.json"),
        "output_guard": paths.output(
            "environment/output_guard_report_stage3_3_pre_bank_d.json"
        ),
        "worker_memory_probe": paths.output(
            "environment/worker_memory_probe_stage3_3.json"
        ),
        "dmreda_configuration": paths.output(
            "calibration/dmreda_frozen_configuration_stage3_3.json"
        ),
        "scalar_reference_configurations": paths.output(
            "calibration/scalar_reference_configurations_v2.json"
        ),
        "recovery_integrity": paths.output(
            "recovery/recovery_integrity_stage3_3_pre_bank_d.json"
        ),
        "git_state": paths.output("environment/git_state_stage3_3_pre_bank_d.json"),
    }
    if set(references) != set(REQUIRED_ARTIFACTS_V2):
        raise AssertionError("Bank D V2 artifact mapping is incomplete")
    return references


def _validated_bank_d_references(paths: CampaignPaths) -> dict[str, ArtifactReference]:
    return {
        name: ArtifactReference(path, sha256_file(path))
        for name, path in _bank_d_reference_paths(paths).items()
    }


def _load_verified_bank_d_seal(
    paths: CampaignPaths,
    *,
    source_commit: str,
    protocol: Mapping[str, object],
) -> tuple[Mapping[str, object], str]:
    """Re-derive the immutable seal, including a scientifically valid denial."""

    if protocol.get("source_commit") != source_commit:
        raise RuntimeError("current source differs from the frozen protocol")
    seal_path = paths.output("protocol/BANK_D_ADMISSION_SEAL_V2.json")
    seal = load_strict_json(seal_path)
    if not isinstance(seal, Mapping):
        raise ValueError("Bank D admission seal is malformed")
    without_hash = dict(seal)
    stored = without_hash.pop("admission_record_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("Bank D admission seal content hash is invalid")
    if seal.get("source_commit") != source_commit:
        raise PermissionError("Bank D seal source commit is stale")
    evaluated_at = seal.get("evaluated_at_utc")
    if not isinstance(evaluated_at, str):
        raise ValueError("Bank D seal evaluation timestamp is invalid")
    references = _validated_bank_d_references(paths)
    rederived = evaluate_bank_d_admission_v2(
        references,
        source_commit=source_commit,
        evaluated_at_utc=evaluated_at,
    )
    if rederived != seal:
        raise PermissionError("Bank D admission seal no longer matches its evidence")
    if canonical_sha256(protocol) != canonical_sha256(
        references["protocol_json"].verify_and_load()
    ):
        raise PermissionError("Bank D seal is bound to a different protocol payload")
    return seal, sha256_file(seal_path)


def _load_admitted_bank_d_seal(
    paths: CampaignPaths,
    *,
    source_commit: str,
    protocol: Mapping[str, object],
) -> tuple[Mapping[str, object], str]:
    """Re-derive and verify an admitted seal before any Bank D value read."""

    seal, seal_sha256 = _load_verified_bank_d_seal(
        paths,
        source_commit=source_commit,
        protocol=protocol,
    )
    if seal.get("bank_d_decision") != "admitted":
        raise PermissionError("Bank D admission seal is not admitted")
    return seal, seal_sha256


def _validate_bank_d_open_binding(
    paths: CampaignPaths,
    *,
    seal: Mapping[str, object],
    seal_file_sha256: str,
) -> Mapping[str, object]:
    event = validate_bank_d_open_event_v2(
        paths.output("protocol/BANK_D_OPEN_EVENT_V2.json")
    )
    expected = {
        "admission_file_sha256": seal_file_sha256,
        "admission_record_sha256": seal["admission_record_sha256"],
        "protocol_file_sha256": seal["artifact_bindings"]["protocol_json"],
        "source_commit": seal["source_commit"],
    }
    if any(event.get(name) != value for name, value in expected.items()):
        raise PermissionError("Bank D open event is stale or cross-bound incorrectly")
    return event


def run_normal_gate(
    paths: CampaignPaths, *, workers: int = 4
) -> tuple[Mapping[str, object], Mapping[str, object]]:
    """Open only FaultFree Testing, evaluate normal authority, and derive seal V2."""

    ensure_output_layout(paths)
    if not 2 <= workers <= 8:
        raise ValueError("production normal gate requires 2..8 workers for parity")
    source_commit = require_clean_source(paths)
    protocol_path = paths.output(
        "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"
    )
    protocol_manifest_path = paths.output(
        "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"
    )
    protocol = validate_frozen_protocol_v2(
        json_path=protocol_path,
        markdown_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md"
        ),
        manifest_path=protocol_manifest_path,
    )
    if protocol["source_commit"] != source_commit:
        raise RuntimeError("current source differs from frozen protocol")
    _validate_frozen_prefreeze_evidence(paths, protocol)
    _assert_bank_d_unopened(paths)
    _assert_fault_free_testing_open_is_not_reconstructed(paths)
    protocol_sha256 = canonical_sha256(protocol)
    update_progress_ledger(
        paths,
        phase="independent_normal_gate",
        status="started",
        source_commit=source_commit,
        details={
            "protocol_sha256": protocol_sha256,
            "faulty_testing_values_accessed": False,
        },
    )
    open_record = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.fault_free_testing_open_event",
        "action": "open_fault_free_testing_for_independent_normal_gate",
        "opened_at_utc": utc_now(),
        "protocol_sha256": protocol_sha256,
        "source_commit": source_commit,
        "bank_d_state": "sealed_unopened",
    }
    open_path = paths.output("authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json")
    if open_path.exists():
        existing = load_strict_json(open_path)
        if not isinstance(existing, Mapping) or any(
            existing.get(name) != value
            for name, value in open_record.items()
            if name != "opened_at_utc"
        ):
            raise RuntimeError("FaultFree Testing open event is stale or malformed")
    else:
        publish_json(paths, "authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json", open_record)

    extract, extraction_manifest = _run_r_extraction(
        paths,
        raw_name="TEP_FaultFree_Testing.RData",
        output_relative="extracts/fault_free_testing_xmeas7.csv.gz",
        manifest_relative="extracts/fault_free_testing_xmeas7.manifest.json",
    )
    extract_sha = str(extraction_manifest["output"]["sha256"])
    bank = load_scalar_bank(
        extract,
        partition="fault_free_testing",
        expected_fault_numbers=(0,),
        expected_runs_per_fault=500,
        expected_horizon=960,
        expected_extract_sha256=extract_sha,
    )
    extraction_adapter = _extraction_adapter(
        partition="fault_free_testing",
        extract_sha256=extract_sha,
        manifest_sha256=sha256_file(
            paths.output("extracts/fault_free_testing_xmeas7.manifest.json")
        ),
        trajectory_count=500,
        horizon=960,
    )
    extraction_adapter_sha = publish_json(
        paths, "normal_gate/fault_free_testing_extraction.json", extraction_adapter
    )
    detectors = detectors_from_protocol(protocol)
    runner_sha = sha256_file(paths.repository("stage3/tep/normal_gate.py"))

    parity_subset = bank.trajectories[:8]
    memory_probe = _record_worker_memory_probe(
        paths,
        source_commit=source_commit,
        protocol_sha256=protocol_sha256,
        trajectory=parity_subset[0],
        detectors=detectors,
        input_sha256=extract_sha,
        runner_sha256=runner_sha,
    )
    _enforce_worker_memory_limit(
        paths,
        source_commit=source_commit,
        protocol_sha256=protocol_sha256,
        workers=workers,
    )
    serial = evaluate_normal_trajectories(
        parity_subset,
        detectors,
        input_sha256=extract_sha,
        protocol_sha256=protocol_sha256,
        runner_sha256=runner_sha,
        source_commit=source_commit,
        workers=1,
        require_frozen_campaign_shape=False,
    )
    parallel = evaluate_normal_trajectories(
        parity_subset,
        detectors,
        input_sha256=extract_sha,
        protocol_sha256=protocol_sha256,
        runner_sha256=runner_sha,
        source_commit=source_commit,
        workers=min(2, workers),
        require_frozen_campaign_shape=False,
    )
    if serial != parallel:
        raise RuntimeError("normal serial/parallel parity failed")

    rows = evaluate_normal_trajectories(
        bank.trajectories,
        detectors,
        input_sha256=extract_sha,
        protocol_sha256=protocol_sha256,
        runner_sha256=runner_sha,
        source_commit=source_commit,
        workers=workers,
    )
    primary_rows = tuple(
        row for row in rows if row["evidence_channel_identifier"] == PRIMARY_CHANNEL
    )
    reference_rows = tuple(
        row for row in rows if row["evidence_channel_identifier"] != PRIMARY_CHANNEL
    )
    primary_rows_sha = publish_jsonl(
        paths, "normal_gate/dmreda_normal_trajectory_results.jsonl", primary_rows
    )
    reference_rows_sha = publish_jsonl(
        paths,
        "normal_gate/scalar_reference_normal_trajectory_results.jsonl",
        reference_rows,
    )
    protocol_reference_records = {
        name: {
            key: value
            for key, value in record.items()
            if key != "scientific_role"
        }
        for name, record in protocol["scalar_evidence_references"].items()
    }
    summary, admission = summarize_normal_authority(
        rows,
        detectors=detectors,
        frozen_reference_configurations=protocol_reference_records,
    )
    bindings = {
        "fault_free_testing_extract_sha256": extract_sha,
        "fault_free_testing_extraction_adapter_sha256": extraction_adapter_sha,
        "dmreda_trajectory_results_sha256": primary_rows_sha,
        "scalar_reference_trajectory_results_sha256": reference_rows_sha,
        "protocol_sha256": protocol_sha256,
        "runner_sha256": runner_sha,
        "source_commit": source_commit,
    }
    summary = _bind_payload(
        summary, hash_field="summary_payload_sha256", artifact_bindings=bindings
    )
    summary_sha = publish_json(
        paths, "normal_gate/dmreda_normal_summary.json", summary
    )
    admission = _bind_payload(
        admission,
        hash_field="admission_payload_sha256",
        artifact_bindings={**bindings, "dmreda_normal_summary_sha256": summary_sha},
    )
    admission_sha = publish_json(
        paths, "normal_gate/scalar_reference_admission.json", admission
    )
    report_sha = publish_markdown(
        paths,
        "normal_gate/normal_gate_report.md",
        render_normal_gate_report(summary, admission),
    )
    normal_manifest_without_hash = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.normal_gate_manifest",
        "status": "complete_and_verified",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha256,
        "serial_parallel_parity": True,
        "worker_memory_probe_sha256": sha256_file(
            paths.output("environment/worker_memory_probe_stage3_3.json")
        ),
        "artifact_sha256": {
            "fault_free_testing_extraction": extraction_adapter_sha,
            "dmreda_trajectory_results": primary_rows_sha,
            "scalar_reference_trajectory_results": reference_rows_sha,
            "dmreda_normal_summary": summary_sha,
            "scalar_reference_admission": admission_sha,
            "normal_gate_report": report_sha,
        },
    }
    normal_manifest = {
        **normal_manifest_without_hash,
        "manifest_payload_sha256": canonical_sha256(normal_manifest_without_hash),
    }
    normal_manifest_sha = publish_json(
        paths, "normal_gate/normal_gate_manifest.json", normal_manifest
    )
    prebank = _prebank_artifacts(
        paths,
        source_commit=source_commit,
        protocol_sha256=protocol_sha256,
        normal_manifest_sha256=normal_manifest_sha,
    )
    references = _validated_bank_d_references(paths)
    seal_path = paths.output("protocol/BANK_D_ADMISSION_SEAL_V2.json")
    if seal_path.exists():
        existing_seal = load_strict_json(seal_path)
        if not isinstance(existing_seal, Mapping) or not isinstance(
            existing_seal.get("evaluated_at_utc"), str
        ):
            raise ValueError("existing Bank D seal is malformed")
        seal = evaluate_bank_d_admission_v2(
            references,
            source_commit=source_commit,
            evaluated_at_utc=str(existing_seal["evaluated_at_utc"]),
        )
        if seal != existing_seal:
            raise RuntimeError("existing Bank D seal is stale or inconsistent")
    else:
        seal = evaluate_bank_d_admission_v2(
            references,
            source_commit=source_commit,
            evaluated_at_utc=utc_now(),
        )
    publish_json(paths, "protocol/BANK_D_ADMISSION_SEAL_V2.json", seal)
    update_progress_ledger(
        paths,
        phase="independent_normal_gate",
        status="completed" if seal["bank_d_decision"] == "admitted" else "stopped",
        source_commit=source_commit,
        details={
            "protocol_sha256": protocol_sha256,
            "bank_d_decision": seal["bank_d_decision"],
            "dmreda_false_authority_count": summary["primary_dmreda"][
                "false_authority_count"
            ],
        },
    )
    return summary, seal


def _fault_trajectory_inputs(
    raw: Sequence[RawScalarTrajectory],
) -> tuple[AuthorityTrajectoryInput, ...]:
    return tuple(item.authority_input for item in raw)


def _all_primary_rows(paths: CampaignPaths, *, directory: str) -> tuple[dict[str, object], ...]:
    rows: list[dict[str, object]] = []
    for fault in range(1, 21):
        path = paths.output(f"{directory}/fault_{fault:02d}.results.jsonl")
        raw = path.read_bytes()
        if not raw.endswith(b"\n"):
            raise ValueError("fault result has a truncated final line")
        for line in raw.splitlines():
            value = json.loads(line)
            if not isinstance(value, dict) or canonical_json_bytes(value) != line:
                raise ValueError("fault result JSONL is not canonical")
            rows.append(value)
    return tuple(rows)


def _load_validated_primary_context(
    paths: CampaignPaths,
) -> tuple[str, Mapping[str, object], Mapping[str, object], Mapping[str, object]]:
    """Validate the complete frozen chain before any post-primary value read."""

    source_commit = require_clean_source(paths)
    protocol = validate_frozen_protocol_v2(
        json_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"
        ),
        markdown_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md"
        ),
        manifest_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"
        ),
    )
    seal, seal_file_sha = _load_admitted_bank_d_seal(
        paths, source_commit=source_commit, protocol=protocol
    )
    open_event = _validate_bank_d_open_binding(
        paths, seal=seal, seal_file_sha256=seal_file_sha
    )
    manifest_path = paths.output("bank_d/primary/primary_result_manifest.json")
    manifest = load_strict_json(manifest_path)
    if not isinstance(manifest, Mapping):
        raise ValueError("primary result manifest is malformed")
    without_hash = dict(manifest)
    stored = without_hash.pop("manifest_payload_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("primary result manifest hash is invalid")
    expected_scalars = {
        "status": "complete_immutable_primary",
        "source_commit": source_commit,
        "protocol_sha256": canonical_sha256(protocol),
        "bank_d_admission_seal_sha256": seal_file_sha,
        "bank_d_open_event_sha256": sha256_file(
            paths.output("protocol/BANK_D_OPEN_EVENT_V2.json")
        ),
        "fault_class_count": 20,
        "trajectory_count": 10_000,
        "serial_parallel_parity": True,
    }
    if any(manifest.get(name) != value for name, value in expected_scalars.items()):
        raise RuntimeError("primary result manifest has stale campaign bindings")
    if manifest.get("evidence_channels") != [
        detector.name
        for detector in detectors_from_protocol(
            protocol,
            admitted_references=tuple(seal["admitted_reference_allowlist"]),
        )
    ]:
        raise RuntimeError("primary result evidence-channel set differs from seal")
    extract = paths.output("extracts/faulty_testing_xmeas7.csv.gz")
    if sha256_file(extract) != manifest.get("faulty_testing_extract_sha256"):
        raise RuntimeError("primary scalar extract hash is stale")
    if sha256_file(
        paths.output("extracts/faulty_testing_xmeas7.manifest.json")
    ) != manifest.get("faulty_testing_extraction_manifest_sha256"):
        raise RuntimeError("primary extraction manifest hash is stale")
    if sha256_file(
        paths.output("extracts/faulty_testing_extraction_manifest.json")
    ) != manifest.get("faulty_testing_extraction_adapter_sha256"):
        raise RuntimeError("primary extraction adapter hash is stale")
    artifact_hashes = manifest.get("artifact_sha256")
    if not isinstance(artifact_hashes, Mapping) or set(artifact_hashes) != set(
        PRIMARY_RESULT_FILES
    ) or any(
        sha256_file(paths.output(relative)) != artifact_hashes.get(name)
        for name, relative in PRIMARY_RESULT_FILES.items()
    ):
        raise RuntimeError("one or more primary result artifacts are stale")
    checkpoint_hashes = manifest.get("per_fault_checkpoint_sha256")
    if not isinstance(checkpoint_hashes, Mapping) or set(checkpoint_hashes) != {
        f"fault_{fault:02d}" for fault in range(1, 21)
    }:
        raise RuntimeError("primary checkpoint manifest is incomplete")
    for fault in range(1, 21):
        key = f"fault_{fault:02d}"
        hashes = checkpoint_hashes[key]
        if not isinstance(hashes, Mapping) or (
            sha256_file(
                paths.output(
                    f"bank_d/primary/checkpoints/fault_{fault:02d}.results.jsonl"
                )
            )
            != hashes.get("result_sha256")
            or sha256_file(
                paths.output(
                    f"bank_d/primary/checkpoints/fault_{fault:02d}.checkpoint.json"
                )
            )
            != hashes.get("checkpoint_sha256")
        ):
            raise RuntimeError(f"primary fault {fault} checkpoint pair is stale")
    checkpoint_rows = _all_primary_rows(
        paths, directory="bank_d/primary/checkpoints"
    )
    aggregate_rows = _load_canonical_jsonl(
        paths.output("bank_d/primary/trajectory_results_dual_boundary.jsonl")
    )
    if aggregate_rows != checkpoint_rows:
        raise RuntimeError("primary aggregate differs from checkpoint concatenation")
    return source_commit, protocol, seal, manifest


def run_bank_d_primary(
    paths: CampaignPaths, *, workers: int = 4
) -> tuple[Mapping[str, object], ...]:
    """Open Bank D once and execute primary plus admitted reference channels."""

    if not 2 <= workers <= 8:
        raise ValueError("production Bank D run requires 2..8 workers for parity")
    source_commit = require_clean_source(paths)
    protocol = validate_frozen_protocol_v2(
        json_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"
        ),
        markdown_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md"
        ),
        manifest_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"
        ),
    )
    protocol_sha = canonical_sha256(protocol)
    seal_path = paths.output("protocol/BANK_D_ADMISSION_SEAL_V2.json")
    seal, seal_file_sha = _load_admitted_bank_d_seal(
        paths, source_commit=source_commit, protocol=protocol
    )
    _enforce_worker_memory_limit(
        paths,
        source_commit=source_commit,
        protocol_sha256=protocol_sha,
        workers=workers,
    )
    _validate_raw_file_identity(paths, "TEP_Faulty_Testing.RData")
    open_path = paths.output("protocol/BANK_D_OPEN_EVENT_V2.json")
    if open_path.exists():
        _validate_bank_d_open_binding(
            paths, seal=seal, seal_file_sha256=seal_file_sha
        )
    else:
        _assert_bank_d_unopened(paths)
        validate_external_destination(
            open_path,
            external_root=paths.output_root,
            kind=ExternalArtifactKind.IMMUTABLE_JSON,
        )
        open_bank_d_once_v2(
            admission_record_path=seal_path,
            admission_file_sha256=seal_file_sha,
            open_event_path=open_path,
            opened_at_utc=utc_now(),
        )
        _validate_bank_d_open_binding(
            paths, seal=seal, seal_file_sha256=seal_file_sha
        )
    update_progress_ledger(
        paths,
        phase="bank_d_primary",
        status="started",
        source_commit=source_commit,
        details={
            "protocol_sha256": protocol_sha,
            "bank_d_admission_seal_sha256": seal_file_sha,
            "bank_d_open_event_sha256": sha256_file(open_path),
        },
    )

    extract, extraction_manifest = _run_r_extraction(
        paths,
        raw_name="TEP_Faulty_Testing.RData",
        output_relative="extracts/faulty_testing_xmeas7.csv.gz",
        manifest_relative="extracts/faulty_testing_xmeas7.manifest.json",
        long_run=True,
    )
    extract_sha = str(extraction_manifest["output"]["sha256"])
    adapter = _extraction_adapter(
        partition="faulty_testing",
        extract_sha256=extract_sha,
        manifest_sha256=sha256_file(
            paths.output("extracts/faulty_testing_xmeas7.manifest.json")
        ),
        trajectory_count=10_000,
        horizon=960,
    )
    adapter["fault_numbers"] = list(range(1, 21))
    adapter["whole_object_single_extract"] = True
    adapter["single_extract_reason"] = (
        "avoid_twenty_full_RData_deserializations_of_the_same_836MB_archive"
    )
    adapter["scientific_consumption"] = (
        "streamed_in_sorted_single_fault_groups_with_per_fault_checkpoints"
    )
    publish_json(
        paths, "extracts/faulty_testing_extraction_manifest.json", adapter
    )
    admitted = tuple(seal["admitted_reference_allowlist"])
    detectors = detectors_from_protocol(protocol, admitted_references=admitted)
    runner_sha = sha256_file(paths.repository("stage3/tep/authority_runner.py"))
    dual_candidate = load_strict_json(paths.output("protocol/onset_mapping_candidate.json"))
    dual_sha = canonical_sha256(dual_candidate)
    bindings = DualBoundaryBindings(
        input_sha256=extract_sha,
        protocol_sha256=protocol_sha,
        dual_boundary_contract_sha256=dual_sha,
        runner_sha256=runner_sha,
        source_commit=source_commit,
    )
    parity_checked = False
    for raw_group in iter_scalar_fault_groups(
        extract,
        partition="faulty_testing",
        expected_fault_numbers=tuple(range(1, 21)),
        expected_runs_per_fault=500,
        expected_horizon=960,
        expected_extract_sha256=extract_sha,
    ):
        trajectories = _fault_trajectory_inputs(raw_group)
        if not parity_checked:
            serial = evaluate_dual_boundary_records(
                trajectories[:8], detectors, bindings=bindings, workers=1
            )
            parallel = evaluate_dual_boundary_records(
                trajectories[:8],
                detectors,
                bindings=bindings,
                workers=min(2, workers),
            )
            if serial != parallel:
                raise RuntimeError("Bank D serial/parallel parity failed")
            parity_checked = True
        fault = raw_group[0].fault_number
        completed_fault = evaluate_dual_boundary_fault(
            trajectories,
            detectors,
            bindings=bindings,
            result_path=paths.output(
                f"bank_d/primary/checkpoints/fault_{fault:02d}.results.jsonl"
            ),
            checkpoint_path=paths.output(
                f"bank_d/primary/checkpoints/fault_{fault:02d}.checkpoint.json"
            ),
            completed_at_utc=utc_now(),
            workers=workers,
            external_root=paths.output_root,
        )
        update_progress_ledger(
            paths,
            phase="bank_d_primary_fault",
            status="completed" if not completed_fault.resumed else "resumed",
            source_commit=source_commit,
            details={
                "faultNumber": fault,
                "result_sha256": completed_fault.result_sha256,
                "record_count": completed_fault.record_count,
            },
        )
    rows = _all_primary_rows(paths, directory="bank_d/primary/checkpoints")
    aggregate_sha = publish_jsonl(
        paths, "bank_d/primary/trajectory_results_dual_boundary.jsonl", rows
    )
    analysis = analyze_bank_d_rows(rows, admitted_references=admitted)
    artifact_hashes = {
        "trajectory_results_dual_boundary": aggregate_sha,
        "per_fault_summary_onset_159": publish_json(
            paths,
            "bank_d/primary/per_fault_summary_onset_159.json",
            analysis["per_fault_summary_onset_159"],
        ),
        "per_fault_summary_onset_160": publish_json(
            paths,
            "bank_d/primary/per_fault_summary_onset_160.json",
            analysis["per_fault_summary_onset_160"],
        ),
        "global_summary_onset_159": publish_json(
            paths,
            "bank_d/primary/global_summary_onset_159.json",
            analysis["global_summary_onset_159"],
        ),
        "global_summary_onset_160": publish_json(
            paths,
            "bank_d/primary/global_summary_onset_160.json",
            analysis["global_summary_onset_160"],
        ),
        "boundary_sensitivity_summary": publish_json(
            paths,
            "bank_d/primary/boundary_sensitivity_summary.json",
            analysis["boundary_sensitivity_summary"],
        ),
        "admitted_reference_pairwise_results": publish_json(
            paths,
            "bank_d/primary/admitted_reference_pairwise_results.json",
            analysis["admitted_reference_pairwise_results"],
        ),
        "statistical_analysis": publish_json(
            paths,
            "bank_d/primary/statistical_analysis.json",
            analysis["statistical_analysis"],
        ),
    }
    changed_rows = tuple(analysis["boundary_changed_trajectories"])
    artifact_hashes["boundary_changed_trajectories"] = publish_jsonl(
        paths,
        "bank_d/primary/boundary_changed_trajectories.jsonl",
        changed_rows,
        allow_empty=True,
    )
    checkpoint_hashes = {
        f"fault_{fault:02d}": {
            "result_sha256": sha256_file(
                paths.output(
                    f"bank_d/primary/checkpoints/fault_{fault:02d}.results.jsonl"
                )
            ),
            "checkpoint_sha256": sha256_file(
                paths.output(
                    f"bank_d/primary/checkpoints/fault_{fault:02d}.checkpoint.json"
                )
            ),
        }
        for fault in range(1, 21)
    }
    manifest_without_hash = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.primary_result_manifest",
        "status": "complete_immutable_primary",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha,
        "bank_d_admission_seal_sha256": sha256_file(seal_path),
        "bank_d_open_event_sha256": sha256_file(open_path),
        "faulty_testing_extract_sha256": extract_sha,
        "faulty_testing_extraction_manifest_sha256": sha256_file(
            paths.output("extracts/faulty_testing_xmeas7.manifest.json")
        ),
        "faulty_testing_extraction_adapter_sha256": sha256_file(
            paths.output("extracts/faulty_testing_extraction_manifest.json")
        ),
        "authority_runner_sha256": runner_sha,
        "analysis_runner_sha256": sha256_file(
            paths.repository("stage3/tep/bank_d_analysis.py")
        ),
        "serial_parallel_parity": parity_checked,
        "fault_class_count": 20,
        "trajectory_count": 10_000,
        "evidence_channels": [detector.name for detector in detectors],
        "per_fault_checkpoint_sha256": checkpoint_hashes,
        "artifact_sha256": artifact_hashes,
    }
    manifest = {
        **manifest_without_hash,
        "manifest_payload_sha256": canonical_sha256(manifest_without_hash),
    }
    publish_json(paths, "bank_d/primary/primary_result_manifest.json", manifest)
    update_progress_ledger(
        paths,
        phase="bank_d_primary",
        status="completed",
        source_commit=source_commit,
        details={
            "primary_manifest_sha256": sha256_file(
                paths.output("bank_d/primary/primary_result_manifest.json")
            ),
            "trajectory_result_rows": len(rows),
        },
    )
    return rows


def _ablation_summary(
    rows: Sequence[Mapping[str, object]], *, channel: str
) -> dict[str, object]:
    per_fault = {}
    for fault in range(1, 21):
        selected = [
            row
            for row in rows
            if row["faultNumber"] == fault
            and row["evidence_channel_identifier"] == channel
        ]
        per_fault[f"fault_{fault:02d}"] = summarize_dual_boundary_rows(selected)
    global_summary = summarize_dual_boundary_rows(rows)
    return {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.ablation_summary",
        "evidence_channel_identifier": channel,
        "explanatory_only": True,
        "per_fault": per_fault,
        "global": global_summary,
    }


def run_ablations(paths: CampaignPaths, *, workers: int = 4) -> Mapping[str, object]:
    """Run frozen D-only and G-only explanatory modes after primary sealing."""

    if not 2 <= workers <= 8:
        raise ValueError("production ablations require 2..8 workers")
    primary_manifest_path = paths.output("bank_d/primary/primary_result_manifest.json")
    source_commit, protocol, _, primary_manifest = _load_validated_primary_context(
        paths
    )
    protocol_sha = canonical_sha256(protocol)
    _enforce_worker_memory_limit(
        paths,
        source_commit=source_commit,
        protocol_sha256=protocol_sha,
        workers=workers,
    )
    extract = paths.output("extracts/faulty_testing_xmeas7.csv.gz")
    extract_sha = sha256_file(extract)
    dual = load_strict_json(paths.output("protocol/onset_mapping_candidate.json"))
    bindings = DualBoundaryBindings(
        input_sha256=extract_sha,
        protocol_sha256=protocol_sha,
        dual_boundary_contract_sha256=canonical_sha256(dual),
        runner_sha256=sha256_file(paths.repository("stage3/tep/authority_runner.py")),
        source_commit=source_commit,
    )
    update_progress_ledger(
        paths,
        phase="secondary_ablations",
        status="started",
        source_commit=source_commit,
        details={"primary_manifest_sha256": sha256_file(primary_manifest_path)},
    )
    mode_records: dict[str, object] = {}
    for mode, channel, directory in (
        ("D_ONLY", "dmreda_core_d_only", "d_only"),
        ("G_ONLY", "dmreda_core_g_only", "g_only"),
    ):
        detector = DetectorSpec.canonical_dmreda(name=channel, mode=mode)
        for raw_group in iter_scalar_fault_groups(
            extract,
            partition="faulty_testing",
            expected_fault_numbers=tuple(range(1, 21)),
            expected_runs_per_fault=500,
            expected_horizon=960,
            expected_extract_sha256=extract_sha,
        ):
            fault = raw_group[0].fault_number
            evaluate_dual_boundary_fault(
                _fault_trajectory_inputs(raw_group),
                (detector,),
                bindings=bindings,
                result_path=paths.output(
                    f"bank_d/ablations/checkpoints/{directory}/fault_{fault:02d}.results.jsonl"
                ),
                checkpoint_path=paths.output(
                    f"bank_d/ablations/checkpoints/{directory}/fault_{fault:02d}.checkpoint.json"
                ),
                completed_at_utc=utc_now(),
                workers=workers,
                external_root=paths.output_root,
            )
        rows = _all_primary_rows(
            paths, directory=f"bank_d/ablations/checkpoints/{directory}"
        )
        rows_sha = publish_jsonl(
            paths,
            f"bank_d/ablations/{directory}_trajectory_results_dual_boundary.jsonl",
            rows,
        )
        summary = _ablation_summary(rows, channel=channel)
        summary_sha = publish_json(
            paths,
            f"bank_d/ablations/{directory}_dual_boundary_summary.json",
            summary,
        )
        mode_records[directory] = {
            "mode": mode,
            "channel": channel,
            "configuration_sha256": detector.detector_sha256,
            "trajectory_results_sha256": rows_sha,
            "summary_sha256": summary_sha,
            "per_fault_checkpoint_sha256": {
                f"fault_{fault:02d}": {
                    "result_sha256": sha256_file(
                        paths.output(
                            f"bank_d/ablations/checkpoints/{directory}/"
                            f"fault_{fault:02d}.results.jsonl"
                        )
                    ),
                    "checkpoint_sha256": sha256_file(
                        paths.output(
                            f"bank_d/ablations/checkpoints/{directory}/"
                            f"fault_{fault:02d}.checkpoint.json"
                        )
                    ),
                }
                for fault in range(1, 21)
            },
        }
    primary_rows = _all_primary_rows(paths, directory="bank_d/primary/checkpoints")
    comparison_without_hash = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.ablation_comparison",
        "primary_channel": PRIMARY_CHANNEL,
        "primary_result_sha256": sha256_file(
            paths.output("bank_d/primary/trajectory_results_dual_boundary.jsonl")
        ),
        "modes": mode_records,
        "interpretation": "explanatory_only_no_primary_replacement_no_retuning",
        "primary_trajectory_count": len(primary_rows),
    }
    comparison = {
        **comparison_without_hash,
        "comparison_payload_sha256": canonical_sha256(comparison_without_hash),
    }
    comparison_sha = publish_json(
        paths, "bank_d/ablations/ablation_comparison.json", comparison
    )
    manifest_without_hash = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.ablation_manifest",
        "status": "complete",
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha,
        "primary_manifest_sha256": sha256_file(primary_manifest_path),
        "comparison_sha256": comparison_sha,
        "modes": mode_records,
    }
    manifest = {
        **manifest_without_hash,
        "manifest_payload_sha256": canonical_sha256(manifest_without_hash),
    }
    publish_json(paths, "bank_d/ablations/ablation_manifest.json", manifest)
    update_progress_ledger(
        paths,
        phase="secondary_ablations",
        status="completed",
        source_commit=source_commit,
        details={
            "ablation_manifest_sha256": sha256_file(
                paths.output("bank_d/ablations/ablation_manifest.json")
            )
        },
    )
    return comparison


def _load_validated_ablation_manifest(
    paths: CampaignPaths,
) -> tuple[
    str,
    Mapping[str, object],
    Mapping[str, object],
    Mapping[str, object],
    Mapping[str, object],
]:
    source_commit, protocol, seal, primary = _load_validated_primary_context(paths)
    path = paths.output("bank_d/ablations/ablation_manifest.json")
    manifest = load_strict_json(path)
    if not isinstance(manifest, Mapping):
        raise ValueError("ablation manifest is malformed")
    without_hash = dict(manifest)
    stored = without_hash.pop("manifest_payload_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("ablation manifest content hash is invalid")
    expected = {
        "status": "complete",
        "source_commit": source_commit,
        "protocol_sha256": canonical_sha256(protocol),
        "primary_manifest_sha256": sha256_file(
            paths.output("bank_d/primary/primary_result_manifest.json")
        ),
        "comparison_sha256": sha256_file(
            paths.output("bank_d/ablations/ablation_comparison.json")
        ),
    }
    if any(manifest.get(name) != value for name, value in expected.items()):
        raise RuntimeError("ablation manifest has stale predecessor bindings")
    modes = manifest.get("modes")
    if not isinstance(modes, Mapping) or set(modes) != {"d_only", "g_only"}:
        raise RuntimeError("ablation mode manifest is incomplete")
    for directory, mode, channel in (
        ("d_only", "D_ONLY", "dmreda_core_d_only"),
        ("g_only", "G_ONLY", "dmreda_core_g_only"),
    ):
        record = modes[directory]
        detector = DetectorSpec.canonical_dmreda(name=channel, mode=mode)
        if not isinstance(record, Mapping) or any(
            record.get(name) != value
            for name, value in {
                "mode": mode,
                "channel": channel,
                "configuration_sha256": detector.detector_sha256,
                "trajectory_results_sha256": sha256_file(
                    paths.output(
                        f"bank_d/ablations/{directory}_trajectory_results_dual_boundary.jsonl"
                    )
                ),
                "summary_sha256": sha256_file(
                    paths.output(
                        f"bank_d/ablations/{directory}_dual_boundary_summary.json"
                    )
                ),
            }.items()
        ):
            raise RuntimeError(f"{directory} ablation artifact binding is stale")
        checkpoints = record.get("per_fault_checkpoint_sha256")
        if not isinstance(checkpoints, Mapping):
            raise RuntimeError(f"{directory} checkpoint bindings are malformed")
        for fault in range(1, 21):
            key = f"fault_{fault:02d}"
            child = checkpoints.get(key)
            if not isinstance(child, Mapping) or (
                child.get("result_sha256")
                != sha256_file(
                    paths.output(
                        f"bank_d/ablations/checkpoints/{directory}/"
                        f"fault_{fault:02d}.results.jsonl"
                    )
                )
                or child.get("checkpoint_sha256")
                != sha256_file(
                    paths.output(
                        f"bank_d/ablations/checkpoints/{directory}/"
                        f"fault_{fault:02d}.checkpoint.json"
                    )
                )
            ):
                raise RuntimeError(f"{directory} fault {fault} checkpoint is stale")
        checkpoint_rows = _all_primary_rows(
            paths, directory=f"bank_d/ablations/checkpoints/{directory}"
        )
        aggregate_rows = _load_canonical_jsonl(
            paths.output(
                f"bank_d/ablations/{directory}_trajectory_results_dual_boundary.jsonl"
            )
        )
        if aggregate_rows != checkpoint_rows:
            raise RuntimeError(
                f"{directory} aggregate differs from checkpoint concatenation"
            )
    return source_commit, protocol, seal, primary, manifest


def run_reproduction(
    paths: CampaignPaths, *, workers: int = 4
) -> Mapping[str, object]:
    """Recompute primary and ablation rows and compare persisted analyses."""

    if not 2 <= workers <= 8:
        raise ValueError("production reproduction requires 2..8 workers")
    source_commit, protocol, seal, _, ablation_manifest = (
        _load_validated_ablation_manifest(paths)
    )
    protocol_sha = canonical_sha256(protocol)
    _enforce_worker_memory_limit(
        paths,
        source_commit=source_commit,
        protocol_sha256=protocol_sha,
        workers=workers,
    )
    admitted = tuple(seal["admitted_reference_allowlist"])
    primary_detectors = detectors_from_protocol(
        protocol, admitted_references=admitted
    )
    ablation_detectors = (
        DetectorSpec.canonical_dmreda(
            name="dmreda_core_d_only", mode="D_ONLY"
        ),
        DetectorSpec.canonical_dmreda(
            name="dmreda_core_g_only", mode="G_ONLY"
        ),
    )
    detectors = (*primary_detectors, *ablation_detectors)
    extract = paths.output("extracts/faulty_testing_xmeas7.csv.gz")
    extract_sha = sha256_file(extract)
    dual = load_strict_json(paths.output("protocol/onset_mapping_candidate.json"))
    bindings = DualBoundaryBindings(
        input_sha256=extract_sha,
        protocol_sha256=protocol_sha,
        dual_boundary_contract_sha256=canonical_sha256(dual),
        runner_sha256=sha256_file(paths.repository("stage3/tep/authority_runner.py")),
        source_commit=source_commit,
    )
    update_progress_ledger(
        paths,
        phase="deterministic_reproduction",
        status="started",
        source_commit=source_commit,
        details={
            "primary_manifest_sha256": sha256_file(
                paths.output("bank_d/primary/primary_result_manifest.json")
            ),
            "ablation_manifest_sha256": sha256_file(
                paths.output("bank_d/ablations/ablation_manifest.json")
            ),
        },
    )
    for raw_group in iter_scalar_fault_groups(
        extract,
        partition="faulty_testing",
        expected_fault_numbers=tuple(range(1, 21)),
        expected_runs_per_fault=500,
        expected_horizon=960,
        expected_extract_sha256=extract_sha,
    ):
        fault = raw_group[0].fault_number
        completed_fault = evaluate_dual_boundary_fault(
            _fault_trajectory_inputs(raw_group),
            detectors,
            bindings=bindings,
            result_path=paths.output(
                f"reproducibility/run_2/checkpoints/fault_{fault:02d}.results.jsonl"
            ),
            checkpoint_path=paths.output(
                f"reproducibility/run_2/checkpoints/fault_{fault:02d}.checkpoint.json"
            ),
            completed_at_utc=utc_now(),
            workers=workers,
            external_root=paths.output_root,
        )
        update_progress_ledger(
            paths,
            phase="deterministic_reproduction_fault",
            status="completed" if not completed_fault.resumed else "resumed",
            source_commit=source_commit,
            details={
                "faultNumber": fault,
                "result_sha256": completed_fault.result_sha256,
                "record_count": completed_fault.record_count,
            },
        )
    primary_rows = _load_canonical_jsonl(
        paths.output("bank_d/primary/trajectory_results_dual_boundary.jsonl")
    )
    reproduced_all_rows = _all_primary_rows(
        paths, directory="reproducibility/run_2/checkpoints"
    )
    primary_names = {detector.name for detector in primary_detectors}
    reproduced_rows = tuple(
        row
        for row in reproduced_all_rows
        if row["evidence_channel_identifier"] in primary_names
    )
    reproduced_d = tuple(
        row
        for row in reproduced_all_rows
        if row["evidence_channel_identifier"] == "dmreda_core_d_only"
    )
    reproduced_g = tuple(
        row
        for row in reproduced_all_rows
        if row["evidence_channel_identifier"] == "dmreda_core_g_only"
    )
    reproduced_sha = publish_jsonl(
        paths,
        "reproducibility/run_2/trajectory_results_dual_boundary.jsonl",
        reproduced_all_rows,
    )
    diff = compare_reproduced_rows(primary_rows, reproduced_rows)
    primary_d = _load_canonical_jsonl(
        paths.output("bank_d/ablations/d_only_trajectory_results_dual_boundary.jsonl")
    )
    primary_g = _load_canonical_jsonl(
        paths.output("bank_d/ablations/g_only_trajectory_results_dual_boundary.jsonl")
    )
    d_diff = compare_reproduced_rows(primary_d, reproduced_d)
    g_diff = compare_reproduced_rows(primary_g, reproduced_g)
    combined_diff = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.deterministic_diff",
        "primary": diff,
        "d_only": d_diff,
        "g_only": g_diff,
        "all_trajectory_rows_identical": all(
            record["experiment_valid"] for record in (diff, d_diff, g_diff)
        ),
    }
    diff_sha = publish_json(
        paths, "reproducibility/deterministic_diff.json", combined_diff
    )
    reproduced_analysis = analyze_bank_d_rows(
        reproduced_rows, admitted_references=admitted
    )
    persisted_analysis_equal = all(
        load_strict_json(paths.output(PRIMARY_RESULT_FILES[name]))
        == reproduced_analysis[name]
        for name in (
            "per_fault_summary_onset_159",
            "per_fault_summary_onset_160",
            "global_summary_onset_159",
            "global_summary_onset_160",
            "boundary_sensitivity_summary",
            "admitted_reference_pairwise_results",
            "statistical_analysis",
        )
    )
    persisted_boundary_rows_equal = _load_canonical_jsonl(
        paths.output(PRIMARY_RESULT_FILES["boundary_changed_trajectories"]),
        allow_empty=True,
    ) == tuple(reproduced_analysis["boundary_changed_trajectories"])
    ablation_summaries_equal = (
        _ablation_summary(reproduced_d, channel="dmreda_core_d_only")
        == load_strict_json(
            paths.output("bank_d/ablations/d_only_dual_boundary_summary.json")
        )
        and _ablation_summary(reproduced_g, channel="dmreda_core_g_only")
        == load_strict_json(
            paths.output("bank_d/ablations/g_only_dual_boundary_summary.json")
        )
    )
    all_rows_equal = bool(combined_diff["all_trajectory_rows_identical"])
    reproduction_checkpoint_hashes = {
        f"fault_{fault:02d}": {
            "result_sha256": sha256_file(
                paths.output(
                    f"reproducibility/run_2/checkpoints/fault_{fault:02d}.results.jsonl"
                )
            ),
            "checkpoint_sha256": sha256_file(
                paths.output(
                    f"reproducibility/run_2/checkpoints/fault_{fault:02d}.checkpoint.json"
                )
            ),
        }
        for fault in range(1, 21)
    }
    manifest_without_hash = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.reproduction_manifest",
        "status": (
            "identical"
            if all_rows_equal
            and persisted_analysis_equal
            and persisted_boundary_rows_equal
            and ablation_summaries_equal
            else "invalid"
        ),
        "source_commit": source_commit,
        "protocol_sha256": protocol_sha,
        "primary_result_sha256": sha256_file(
            paths.output("bank_d/primary/trajectory_results_dual_boundary.jsonl")
        ),
        "ablation_manifest_sha256": sha256_file(
            paths.output("bank_d/ablations/ablation_manifest.json")
        ),
        "ablation_manifest_payload_sha256": ablation_manifest[
            "manifest_payload_sha256"
        ],
        "reproduced_result_sha256": reproduced_sha,
        "per_fault_checkpoint_sha256": reproduction_checkpoint_hashes,
        "deterministic_diff_sha256": diff_sha,
        "primary_trajectory_rows_identical": diff["experiment_valid"],
        "d_only_trajectory_rows_identical": d_diff["experiment_valid"],
        "g_only_trajectory_rows_identical": g_diff["experiment_valid"],
        "persisted_primary_summary_and_bootstrap_identical": (
            persisted_analysis_equal
        ),
        "persisted_boundary_change_rows_identical": persisted_boundary_rows_equal,
        "persisted_ablation_summaries_identical": ablation_summaries_equal,
        "fixed_bootstrap_seed": 20_260_805,
    }
    manifest = {
        **manifest_without_hash,
        "manifest_payload_sha256": canonical_sha256(manifest_without_hash),
    }
    publish_json(paths, "reproducibility/reproduction_manifest.json", manifest)
    if manifest["status"] != "identical":
        raise RuntimeError("deterministic reproduction failed")
    update_progress_ledger(
        paths,
        phase="deterministic_reproduction",
        status="completed",
        source_commit=source_commit,
        details={
            "reproduction_manifest_sha256": sha256_file(
                paths.output("reproducibility/reproduction_manifest.json")
            )
        },
    )
    return manifest


def _load_validated_reproduction_manifest(
    paths: CampaignPaths,
) -> tuple[
    str,
    Mapping[str, object],
    Mapping[str, object],
    Mapping[str, object],
    Mapping[str, object],
    Mapping[str, object],
]:
    source_commit, protocol, seal, primary, ablation = (
        _load_validated_ablation_manifest(paths)
    )
    path = paths.output("reproducibility/reproduction_manifest.json")
    manifest = load_strict_json(path)
    if not isinstance(manifest, Mapping):
        raise ValueError("reproduction manifest is malformed")
    without_hash = dict(manifest)
    stored = without_hash.pop("manifest_payload_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("reproduction manifest content hash is invalid")
    expected = {
        "status": "identical",
        "source_commit": source_commit,
        "protocol_sha256": canonical_sha256(protocol),
        "primary_result_sha256": sha256_file(
            paths.output("bank_d/primary/trajectory_results_dual_boundary.jsonl")
        ),
        "ablation_manifest_sha256": sha256_file(
            paths.output("bank_d/ablations/ablation_manifest.json")
        ),
        "reproduced_result_sha256": sha256_file(
            paths.output("reproducibility/run_2/trajectory_results_dual_boundary.jsonl")
        ),
        "deterministic_diff_sha256": sha256_file(
            paths.output("reproducibility/deterministic_diff.json")
        ),
        "primary_trajectory_rows_identical": True,
        "d_only_trajectory_rows_identical": True,
        "g_only_trajectory_rows_identical": True,
        "persisted_primary_summary_and_bootstrap_identical": True,
        "persisted_boundary_change_rows_identical": True,
        "persisted_ablation_summaries_identical": True,
        "fixed_bootstrap_seed": 20_260_805,
    }
    if any(manifest.get(name) != value for name, value in expected.items()):
        raise RuntimeError("reproduction manifest has stale or invalid bindings")
    checkpoints = manifest.get("per_fault_checkpoint_sha256")
    if not isinstance(checkpoints, Mapping):
        raise RuntimeError("reproduction checkpoint bindings are absent")
    for fault in range(1, 21):
        key = f"fault_{fault:02d}"
        record = checkpoints.get(key)
        if not isinstance(record, Mapping) or (
            record.get("result_sha256")
            != sha256_file(
                paths.output(
                    f"reproducibility/run_2/checkpoints/fault_{fault:02d}.results.jsonl"
                )
            )
            or record.get("checkpoint_sha256")
            != sha256_file(
                paths.output(
                    f"reproducibility/run_2/checkpoints/fault_{fault:02d}.checkpoint.json"
                )
            )
        ):
            raise RuntimeError(f"reproduction fault {fault} checkpoint is stale")
    reproduced_checkpoints = _all_primary_rows(
        paths, directory="reproducibility/run_2/checkpoints"
    )
    reproduced_aggregate = _load_canonical_jsonl(
        paths.output("reproducibility/run_2/trajectory_results_dual_boundary.jsonl")
    )
    if reproduced_aggregate != reproduced_checkpoints:
        raise RuntimeError("reproduction aggregate differs from checkpoint concatenation")
    return source_commit, protocol, seal, primary, ablation, manifest


def classify_final_evidence(
    *,
    layer_a_passed: bool,
    layer_b_passed: bool,
    normal_passed: bool,
    valid_authority_count_159: int,
    valid_authority_count_160: int,
    admitted_reference_count: int,
    boundary_coequal_holm_added_value_supported: bool,
) -> str:
    """Apply the frozen conservative policy without an improvised rate cutoff."""

    if not layer_a_passed:
        return "representation_contract_failure"
    if not layer_b_passed:
        return "arbitration_contract_failure"
    if not normal_passed:
        return "unstable_normal_authority"
    if min(valid_authority_count_159, valid_authority_count_160) == 0:
        return "conservative_but_low_coverage_assurance_channel"
    if admitted_reference_count == 0 or not (
        boundary_coequal_holm_added_value_supported
    ):
        return "insufficient_evidence_for_added_value"
    return "fault_specific_evidence_coverage"


def _holm_pvalue(
    statistical: Mapping[str, object],
    *,
    onset: int,
    reference: str,
    endpoint: str,
    fault: str,
) -> float | None:
    families = statistical.get("holm_families")
    if not isinstance(families, Mapping):
        raise ValueError("Holm family artifact is malformed")
    family = families.get(f"onset_{onset}/{reference}/{endpoint}")
    if not isinstance(family, Mapping):
        raise ValueError("required Holm family is absent")
    adjusted = family.get("holm_adjusted_p_values")
    if not isinstance(adjusted, Mapping):
        raise ValueError("Holm-adjusted p-value mapping is malformed")
    value = adjusted.get(fault)
    return None if value is None else float(value)


def _reference_claim_interpretation(
    pairwise: Mapping[str, object],
    statistical: Mapping[str, object],
    *,
    onset: int,
    reference: str,
    fault: str,
) -> tuple[object, ...]:
    record = pairwise[f"onset_{onset}"][fault][reference]
    non_fp = record["non_fp_detection_discordance"]
    early = record["early_false_authority_discordance"]
    delay = record["paired_valid_detection_delay"]
    non_fp_p = _holm_pvalue(
        statistical,
        onset=onset,
        reference=reference,
        endpoint="non_fp_authority",
        fault=fault,
    )
    early_p = _holm_pvalue(
        statistical,
        onset=onset,
        reference=reference,
        endpoint="early_false_authority",
        fault=fault,
    )
    latency_p = _holm_pvalue(
        statistical,
        onset=onset,
        reference=reference,
        endpoint="paired_latency",
        fault=fault,
    )
    return (
        "dmreda_more_non_fp_authority"
        if non_fp["dmreda_detects_reference_misses"]
        > non_fp["reference_detects_dmreda_misses"]
        else "reference_more_non_fp_authority"
        if non_fp["reference_detects_dmreda_misses"]
        > non_fp["dmreda_detects_reference_misses"]
        else "non_fp_authority_tie",
        non_fp_p is not None and non_fp_p <= 0.05,
        "dmreda_more_early_false_authority"
        if early["dmreda_only"] > early["reference_only"]
        else "reference_more_early_false_authority"
        if early["reference_only"] > early["dmreda_only"]
        else "early_false_authority_tie",
        early_p is not None and early_p <= 0.05,
        None
        if delay["mean_dmreda_minus_reference"] is None
        else "dmreda_faster"
        if delay["mean_dmreda_minus_reference"] < 0
        else "reference_faster"
        if delay["mean_dmreda_minus_reference"] > 0
        else "latency_tie",
        latency_p is not None and latency_p <= 0.05,
    )


def evaluate_boundary_coequal_reference_evidence(
    pairwise: Mapping[str, object],
    statistical: Mapping[str, object],
    *,
    admitted_references: Sequence[str],
) -> tuple[bool, bool]:
    """Return (supported added value, interpretations same at both onsets)."""

    if not admitted_references:
        return False, True
    support = _boundary_reference_support_sets(
        pairwise,
        statistical,
        admitted_references=admitted_references,
    )
    interpretations_same = True
    for reference in sorted(admitted_references):
        for fault_number in range(1, 21):
            fault = f"fault_{fault_number:02d}"
            left = _reference_claim_interpretation(
                pairwise,
                statistical,
                onset=159,
                reference=reference,
                fault=fault,
            )
            right = _reference_claim_interpretation(
                pairwise,
                statistical,
                onset=160,
                reference=reference,
                fault=fault,
            )
            interpretations_same = interpretations_same and left == right
    return bool(support[159] & support[160]), interpretations_same


def _boundary_reference_support_sets(
    pairwise: Mapping[str, object],
    statistical: Mapping[str, object],
    *,
    admitted_references: Sequence[str],
) -> dict[int, set[tuple[str, str]]]:
    """Identify preregistered fault/reference support without accepting FP worsening."""

    support: dict[int, set[tuple[str, str]]] = {159: set(), 160: set()}
    family = statistical.get("coequal_non_fp_added_value_family")
    adjusted = family.get("holm_adjusted_p_values") if isinstance(family, Mapping) else None
    if not isinstance(adjusted, Mapping):
        raise ValueError("coequal added-value multiplicity family is absent")
    for onset in (159, 160):
        for reference in sorted(admitted_references):
            for fault_number in range(1, 21):
                fault = f"fault_{fault_number:02d}"
                coequal_adjusted_p = adjusted.get(f"{fault}/{reference}")
                interpretation = _reference_claim_interpretation(
                    pairwise,
                    statistical,
                    onset=onset,
                    reference=reference,
                    fault=fault,
                )
                non_fp_direction, non_fp_significant = interpretation[:2]
                early_direction = interpretation[2]
                if (
                    non_fp_direction == "dmreda_more_non_fp_authority"
                    and non_fp_significant is True
                    and coequal_adjusted_p is not None
                    and float(coequal_adjusted_p) <= 0.05
                    and early_direction != "dmreda_more_early_false_authority"
                ):
                    support[onset].add((fault, reference))
    return support


def _coequal_support_records(
    pairwise: Mapping[str, object],
    statistical: Mapping[str, object],
    *,
    admitted_references: Sequence[str],
) -> tuple[dict[str, object], ...]:
    support = _boundary_reference_support_sets(
        pairwise,
        statistical,
        admitted_references=admitted_references,
    )[159] & _boundary_reference_support_sets(
        pairwise,
        statistical,
        admitted_references=admitted_references,
    )[160]
    family = statistical["coequal_non_fp_added_value_family"]
    adjusted = family["holm_adjusted_p_values"]
    records: list[dict[str, object]] = []
    for fault, reference in sorted(support):
        record: dict[str, object] = {
            "fault": fault,
            "reference": reference,
            "coequal_holm_adjusted_p_value": adjusted[f"{fault}/{reference}"],
        }
        for onset in (159, 160):
            comparison = pairwise[f"onset_{onset}"][fault][reference]
            record[f"onset_{onset}"] = {
                "non_fp_dmreda_only": comparison["non_fp_detection_discordance"][
                    "dmreda_detects_reference_misses"
                ],
                "non_fp_reference_only": comparison[
                    "non_fp_detection_discordance"
                ]["reference_detects_dmreda_misses"],
                "early_false_authority_dmreda_only": comparison[
                    "early_false_authority_discordance"
                ]["dmreda_only"],
                "early_false_authority_reference_only": comparison[
                    "early_false_authority_discordance"
                ]["reference_only"],
                "jointly_valid_delay_count": comparison[
                    "paired_valid_detection_delay"
                ]["jointly_valid_detection_count"],
                "mean_dmreda_minus_reference_delay": comparison[
                    "paired_valid_detection_delay"
                ]["mean_dmreda_minus_reference"],
            }
        records.append(record)
    return tuple(records)


def _final_report_text(
    *,
    layer_a: Mapping[str, object],
    layer_b: Mapping[str, object],
    normal: Mapping[str, object],
    seal: Mapping[str, object],
    boundary: Mapping[str, object],
    global_159: Mapping[str, object],
    global_160: Mapping[str, object],
    per_fault_159: Mapping[str, object],
    per_fault_160: Mapping[str, object],
    reproduction: Mapping[str, object],
    evidence_category: str,
    onset_category: str,
    bank_d_opened: bool,
    boundary_coequal_holm_added_value_supported: bool,
    boundary_decision_details: Mapping[str, object],
    support_records: Sequence[Mapping[str, object]],
    d_only_summary: Mapping[str, object],
    g_only_summary: Mapping[str, object],
) -> str:
    primary_159 = global_159[PRIMARY_CHANNEL]["micro_recording_level"]
    primary_160 = global_160[PRIMARY_CHANNEL]["micro_recording_level"]
    normal_primary = normal["primary_dmreda"]
    primary_flips = boundary["global"][PRIMARY_CHANNEL]["boundary_sensitivity_counts"][
        "classification_flip_at_boundary"
    ]
    total_flips = sum(
        int(record["boundary_sensitivity_counts"]["classification_flip_at_boundary"])
        for record in boundary["global"].values()
    )
    coverage_rows: list[str] = []
    uncovered_159: list[str] = []
    uncovered_160: list[str] = []
    for fault_number in range(1, 21):
        key = f"fault_{fault_number:02d}"
        view_159 = per_fault_159[key][PRIMARY_CHANNEL]
        view_160 = per_fault_160[key][PRIMARY_CHANNEL]
        count_159 = int(view_159["counts"]["valid_authority"])
        count_160 = int(view_160["counts"]["valid_authority"])
        if count_159 == 0:
            uncovered_159.append(key)
        if count_160 == 0:
            uncovered_160.append(key)
        coverage_rows.append(
            f"| {key} | {count_159}/500 | {view_159['rates']['valid_authority']:.6f} | "
            f"{count_160}/500 | {view_160['rates']['valid_authority']:.6f} |"
        )
    if evidence_category == "fault_specific_evidence_coverage":
        next_claim = (
            "DMREDA provides a causal deterministic temporal evidence and "
            "arbitration mechanism with fault-specific TEP xmeas_7 evidence "
            "beyond at least one fairly admitted scalar reference under both "
            "co-equal onset mappings."
        )
    elif evidence_category == "conservative_but_low_coverage_assurance_channel":
        next_claim = (
            "DMREDA's representation and arbitration contracts hold, while this "
            "frozen TEP xmeas_7 application has conservatively low authority "
            "coverage and does not establish added value over scalar references."
        )
    else:
        next_claim = (
            "Only the established representation, arbitration, and observed TEP "
            "authority facts should be claimed; added value over scalar references "
            "is not established."
        )
    support_rows = []
    for record in support_records:
        left = record["onset_159"]
        right = record["onset_160"]
        support_rows.append(
            f"| {record['fault']} | {record['reference']} | "
            f"{record['coequal_holm_adjusted_p_value']:.6g} | "
            f"{left['non_fp_dmreda_only']}/{left['non_fp_reference_only']} | "
            f"{left['early_false_authority_dmreda_only']}/{left['early_false_authority_reference_only']} | "
            f"{left['jointly_valid_delay_count']} | "
            f"{right['non_fp_dmreda_only']}/{right['non_fp_reference_only']} | "
            f"{right['early_false_authority_dmreda_only']}/{right['early_false_authority_reference_only']} | "
            f"{right['jointly_valid_delay_count']} |"
        )
    ablation_rows = []
    for label, summary in (
        ("D_OR_G primary", boundary["global"][PRIMARY_CHANNEL]),
        ("D_ONLY", d_only_summary["global"]),
        ("G_ONLY", g_only_summary["global"]),
    ):
        left = summary["onset_159"]
        right = summary["onset_160"]
        ablation_rows.append(
            f"| {label} | {left['counts']['valid_authority']} | "
            f"{left['counts']['false_authority']} | {left['counts']['no_authority']} | "
            f"{right['counts']['valid_authority']} | "
            f"{right['counts']['false_authority']} | {right['counts']['no_authority']} |"
        )
    return "\n".join(
        (
            "# DMREDA TEP Stage 3.3 Full Validation Report V2",
            "",
            "## Executive verdict",
            "",
            f"Scientific evidence category: **{evidence_category}**.",
            f"Onset effect category: **{onset_category}**.",
            "",
            "DMREDA was evaluated as a causal, deterministic, bounded-state temporal evidence representation and arbitration core—not as a universal fault detector.",
            "",
            "## Direct answers",
            "",
            f"1. Representation contract held: `{layer_a['status'] == 'passed'}`.",
            f"2. Arbitration contract held: `{layer_b['status'] == 'passed'}`; same-sample timeout/rearm remains a preserved unresolved design choice.",
            f"3. Independent normal false authority: {normal_primary['false_authority_count']}/{normal_primary['trajectory_count']} (rate {normal_primary['false_authority_rate']:.6f}); admitted `{normal_primary['admitted']}`.",
            f"4. Fairly admitted scalar evidence references: {', '.join(seal['admitted_reference_allowlist']) or 'none'}.",
            f"5. Bank D opened: `{bank_d_opened}` (derived from the validated exclusive open event).",
            f"6. Post-disturbance valid-authority coverage was {primary_159['rates']['valid_authority']:.6f} at onset 159 and {primary_160['rates']['valid_authority']:.6f} at onset 160.",
            "7. Fault-class coverage remains visible in the per-fault summaries; no pooled value replaces those records.",
            "8. D-only and G-only contributions are reported as explanatory ablations without changing the D_OR_G primary.",
            f"9. Boundary-coequal Holm-adjusted added-value support: `{boundary_coequal_holm_added_value_supported}`; a single raw p-value cannot authorize this claim.",
            f"10. Trajectory/channel category flips between onset mappings: {total_flips} total; {primary_flips} in the primary DMREDA channel.",
            f"11. Boundary interpretation: `{onset_category}`; neither onset was selected.",
            f"    Boundary-specific evidence projections: `{boundary_decision_details['category_159']}` at 159 and `{boundary_decision_details['category_160']}` at 160; supported fault/reference pairs {boundary_decision_details['supported_pairs_159']} and {boundary_decision_details['supported_pairs_160']}, respectively.",
            f"12. Complete deterministic reproduction status: `{reproduction['status']}`.",
            f"13. Next claim: {next_claim}",
            "14. Negative findings, failed reference admissions, uncovered faults, boundary flips, and underpowered comparisons remain part of the result.",
            "",
            "## Fault-class authority coverage",
            "",
            "A fault class is listed as covered when at least one of its 500 independent simulation trajectories receives valid post-onset authority. This is not a diagnostic-accuracy claim.",
            "",
            f"Uncovered at onset 159: {', '.join(uncovered_159) or 'none'}.",
            f"Uncovered at onset 160: {', '.join(uncovered_160) or 'none'}.",
            "",
            "| Fault | Valid authority at 159 | Rate | Valid authority at 160 | Rate |",
            "|---|---:|---:|---:|---:|",
            *coverage_rows,
            "",
            "## Co-equal comparative support",
            "",
            "The final added-value family uses the maximum exact discordance p-value across the two co-equal onsets for each fault/reference hypothesis, followed by one Holm correction across all admitted fault/reference hypotheses. A hypothesis is supportive only when DMREDA has more non-false authority under both mappings and has no observed excess of DMREDA-only early false authority under either mapping.",
            "",
            "| Fault | Reference | Holm-adjusted co-equal p | Non-FP discordance 159 D/R | Early-FP discordance 159 D/R | Joint delay n 159 | Non-FP discordance 160 D/R | Early-FP discordance 160 D/R | Joint delay n 160 |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|",
            *(support_rows or ["| none | none | — | — | — | — | — | — | — |"]),
            "",
            f"Excluded scalar references: {json.dumps(seal['excluded_references'], sort_keys=True)}.",
            "Latency comparisons with fewer than 30 jointly valid trajectories remain underpowered; exact counts are shown above for supporting hypotheses and retained for every hypothesis in the pairwise artifact.",
            "",
            "## D/G explanatory ablation",
            "",
            "| Channel | Valid 159 | False 159 | None 159 | Valid 160 | False 160 | None 160 |",
            "|---|---:|---:|---:|---:|---:|---:|",
            *ablation_rows,
            "",
            "## Prohibited claims",
            "",
            "No universal detector superiority, fault diagnosis, fault classification, root-cause identification, MCU WCET, energy, or total-RAM claim is made.",
            "",
        )
    )


def _create_or_verify_git_bundle(
    paths: CampaignPaths, *, source_commit: str
) -> tuple[Path, str]:
    bundle_root = paths.recovery_root / "git-bundles"
    if bundle_root.exists() and (bundle_root.is_symlink() or not bundle_root.is_dir()):
        raise PermissionError("bundle root is not a regular directory")
    bundle_root.mkdir(mode=0o700, exist_ok=True)
    bundle_path = bundle_root / f"dmreda-stage3-3-{source_commit[:12]}.bundle"
    temporary = bundle_root / f".{bundle_path.name}.{os.getpid()}.tmp"
    if not bundle_path.exists():
        if temporary.exists():
            raise FileExistsError("stale temporary Git bundle requires recovery audit")
        run = subprocess.run(
            [
                "git",
                "bundle",
                "create",
                str(temporary),
                "research/dmreda-stage3-full-claim-validation",
            ],
            cwd=paths.repository_root,
            check=False,
            capture_output=True,
            text=True,
        )
        if run.returncode != 0:
            raise RuntimeError(f"Git bundle creation failed: {run.stderr.strip()}")
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        os.replace(temporary, bundle_path)
        descriptor = os.open(bundle_root, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    if bundle_path.is_symlink() or not bundle_path.is_file():
        raise PermissionError("Git bundle is not a regular file")
    verify = subprocess.run(
        ["git", "bundle", "verify", str(bundle_path)],
        cwd=paths.repository_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if verify.returncode != 0:
        raise RuntimeError(f"Git bundle verification failed: {verify.stderr.strip()}")
    heads = subprocess.run(
        ["git", "bundle", "list-heads", str(bundle_path)],
        cwd=paths.repository_root,
        check=False,
        capture_output=True,
        text=True,
    )
    expected = (
        f"{source_commit} refs/heads/"
        "research/dmreda-stage3-full-claim-validation"
    )
    if heads.returncode != 0 or heads.stdout.strip() != expected:
        raise RuntimeError("Git bundle does not advertise exactly the frozen branch HEAD")
    return bundle_path, sha256_file(bundle_path)


def _publish_bundle_receipt(
    paths: CampaignPaths,
    *,
    source_commit: str,
    bundle_path: Path,
    bundle_sha256: str,
) -> str:
    relative = bundle_path.relative_to(paths.recovery_root).as_posix()
    receipt = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.git_bundle_receipt",
        "source_commit": source_commit,
        "branch": "research/dmreda-stage3-full-claim-validation",
        "bundle_relative_to_recovery_root": relative,
        "bundle_sha256": bundle_sha256,
        "verification_commands": [
            f"shasum -a 256 <RECOVERY_ROOT>/{relative}",
            f"git bundle verify <RECOVERY_ROOT>/{relative}",
            f"git bundle list-heads <RECOVERY_ROOT>/{relative}",
        ],
        "expected_bundle_head": (
            f"{source_commit} refs/heads/"
            "research/dmreda-stage3-full-claim-validation"
        ),
    }
    return publish_json(paths, "recovery/GIT_BUNDLE_RECEIPT_V2.json", receipt)


def _publish_progress_ledger_snapshot(paths: CampaignPaths) -> str:
    ledger_path = paths.output("logs/STAGE3_3_PROGRESS_LEDGER.json")
    ledger = load_strict_json(ledger_path)
    if not isinstance(ledger, Mapping):
        raise ValueError("progress ledger is malformed at final snapshot")
    without_hash = dict(ledger)
    stored = without_hash.pop("ledger_payload_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("progress ledger is invalid at final snapshot")
    snapshot = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_3.progress_ledger_snapshot",
        "progress_ledger_file_sha256": sha256_file(ledger_path),
        "progress_ledger": dict(ledger),
    }
    return publish_json(
        paths, "recovery/PROGRESS_LEDGER_SNAPSHOT_V2.json", snapshot
    )


def _final_artifact_allowlist() -> tuple[str, ...]:
    fixed = [
        "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json",
        "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md",
        "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json",
        "protocol/BANK_D_ADMISSION_SEAL_V2.json",
        "protocol/BANK_D_OPEN_EVENT_V2.json",
        "protocol/onset_mapping_candidate.json",
        "protocol/dual_boundary_contract.json",
        "authority/dataset_authority_report_stage3_3.json",
        "authority/access_evidence_manifest_stage3_3_pre_freeze.json",
        "authority/access_evidence_manifest_stage3_3_pre_bank_d.json",
        "authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json",
        "representation/representation_validation_results.json",
        "representation/same_energy_fingerprints.json",
        "representation/representation_validation_report.md",
        "representation/representation_validation_manifest.json",
        "arbitration/arbitration_validation_results.json",
        "arbitration/arbitration_validation_report.md",
        "arbitration/arbitration_validation_manifest.json",
        "calibration/dmreda_frozen_configuration_stage3_3.json",
        "calibration/scalar_reference_configurations_v2.json",
        "normal_gate/scalar_reference_calibration.json",
        "normal_gate/fault_free_testing_extraction.json",
        "normal_gate/dmreda_normal_trajectory_results.jsonl",
        "normal_gate/scalar_reference_normal_trajectory_results.jsonl",
        "normal_gate/dmreda_normal_summary.json",
        "normal_gate/scalar_reference_admission.json",
        "normal_gate/normal_gate_report.md",
        "normal_gate/normal_gate_manifest.json",
        "extracts/fault_free_training_xmeas7.csv.gz",
        "extracts/fault_free_training_xmeas7.manifest.json",
        "extracts/fault_free_testing_xmeas7.csv.gz",
        "extracts/fault_free_testing_xmeas7.manifest.json",
        "extracts/faulty_testing_xmeas7.csv.gz",
        "extracts/faulty_testing_xmeas7.manifest.json",
        "extracts/faulty_testing_extraction_manifest.json",
        "environment/raw_integrity_stage3_3.json",
        "environment/source_hashes_stage3_3.json",
        "environment/worker_memory_probe_stage3_3.json",
        "environment/test_report_stage3_3_pre_freeze.json",
        "environment/test_report_stage3_3_pre_bank_d.json",
        "environment/test_report_stage3_3_final.json",
        "environment/git_state_stage3_3_pre_freeze.json",
        "environment/git_state_stage3_3_pre_bank_d.json",
        "environment/output_guard_report_stage3_3_pre_freeze.json",
        "environment/output_guard_report_stage3_3_pre_bank_d.json",
        "environment/dual_boundary_implementation_report.json",
        "recovery/recovery_integrity_stage3_3_pre_bank_d.json",
        "recovery/GIT_BUNDLE_RECEIPT_V2.json",
        "recovery/PROGRESS_LEDGER_SNAPSHOT_V2.json",
        *PRIMARY_RESULT_FILES.values(),
        "bank_d/primary/primary_result_manifest.json",
        "bank_d/ablations/d_only_trajectory_results_dual_boundary.jsonl",
        "bank_d/ablations/g_only_trajectory_results_dual_boundary.jsonl",
        "bank_d/ablations/d_only_dual_boundary_summary.json",
        "bank_d/ablations/g_only_dual_boundary_summary.json",
        "bank_d/ablations/ablation_comparison.json",
        "bank_d/ablations/ablation_manifest.json",
        "reproducibility/run_2/trajectory_results_dual_boundary.jsonl",
        "reproducibility/deterministic_diff.json",
        "reproducibility/reproduction_manifest.json",
        "reports/DMREDA_TEP_STAGE3_FULL_VALIDATION_REPORT_V2.md",
        "reports/DMREDA_TEP_STAGE3_EXECUTIVE_SUMMARY_V2.md",
        "reports/DMREDA_TEP_STAGE3_LIMITATIONS_V2.md",
        "reports/DUAL_BOUNDARY_RESULT_REPORT.md",
        "reports/SESSION_STATUS_V2.md",
        "reports/RESUME_STAGE3_V2.md",
    ]
    for fault in range(1, 21):
        fixed.extend(
            (
                f"bank_d/primary/checkpoints/fault_{fault:02d}.results.jsonl",
                f"bank_d/primary/checkpoints/fault_{fault:02d}.checkpoint.json",
                f"reproducibility/run_2/checkpoints/fault_{fault:02d}.results.jsonl",
                f"reproducibility/run_2/checkpoints/fault_{fault:02d}.checkpoint.json",
            )
        )
        for mode in ("d_only", "g_only"):
            fixed.extend(
                (
                    f"bank_d/ablations/checkpoints/{mode}/"
                    f"fault_{fault:02d}.results.jsonl",
                    f"bank_d/ablations/checkpoints/{mode}/"
                    f"fault_{fault:02d}.checkpoint.json",
                )
            )
    if len(fixed) != len(set(fixed)):
        raise AssertionError("final artifact allowlist contains duplicates")
    return tuple(sorted(fixed))


def _validate_artifact_allowlist(
    paths: CampaignPaths, allowlist: Sequence[str]
) -> list[dict[str, object]]:
    artifacts: list[dict[str, object]] = []
    for relative in allowlist:
        path = paths.output(relative)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required final artifact is absent: {relative}")
        if path.resolve(strict=True).relative_to(paths.output_root) != Path(relative):
            raise PermissionError("final artifact escapes its external root")
        raw = path.read_bytes()
        if not relative.endswith(".csv.gz") and (b"/" + b"Users/") in raw:
            raise ValueError(f"absolute user path leaked into final artifact: {relative}")
        if relative.endswith(".json"):
            value = load_strict_json(path)
            if not isinstance(value, Mapping):
                raise ValueError(f"final JSON artifact is not an object: {relative}")
            if raw != canonical_json_bytes(dict(value)) + b"\n":
                raise ValueError(f"final JSON artifact is noncanonical: {relative}")
        elif relative.endswith(".jsonl"):
            if raw and not raw.endswith(b"\n"):
                raise ValueError(f"final JSONL artifact is truncated: {relative}")
            for line in raw.splitlines():
                value = json.loads(
                    line,
                    parse_constant=lambda token: (_ for _ in ()).throw(
                        ValueError(f"non-finite JSON token: {token}")
                    ),
                )
                if not isinstance(value, dict) or canonical_json_bytes(value) != line:
                    raise ValueError(f"final JSONL artifact is noncanonical: {relative}")
        artifacts.append(
            {
                "logical_name": relative,
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return artifacts


def _validate_final_allowlist(paths: CampaignPaths) -> list[dict[str, object]]:
    return _validate_artifact_allowlist(paths, _final_artifact_allowlist())


def _revalidate_packaged_extractions(
    paths: CampaignPaths, *, include_faulty_testing: bool
) -> None:
    records = [
        (
            "TEP_FaultFree_Training.RData",
            "extracts/fault_free_training_xmeas7.csv.gz",
            "extracts/fault_free_training_xmeas7.manifest.json",
        ),
        (
            "TEP_FaultFree_Testing.RData",
            "extracts/fault_free_testing_xmeas7.csv.gz",
            "extracts/fault_free_testing_xmeas7.manifest.json",
        ),
    ]
    if include_faulty_testing:
        records.append(
            (
                "TEP_Faulty_Testing.RData",
                "extracts/faulty_testing_xmeas7.csv.gz",
                "extracts/faulty_testing_xmeas7.manifest.json",
            )
        )
    extractor = paths.repository("scripts/stage3/extract_tep_xmeas7.R")
    for raw_name, extract_relative, manifest_relative in records:
        _validate_raw_file_identity(paths, raw_name)
        manifest = load_strict_json(paths.output(manifest_relative))
        if not isinstance(manifest, Mapping):
            raise ValueError(f"extraction manifest is malformed: {manifest_relative}")
        validate_extraction_bindings(
            manifest,
            source_path=paths.dataset(raw_name),
            extractor_script_path=extractor,
            output_path=paths.output(extract_relative),
        )


def _blocked_artifact_allowlist() -> tuple[str, ...]:
    """Fixed recovery-package contents when the normal-authority gate denies D."""

    return tuple(
        sorted(
            (
                "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json",
                "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md",
                "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json",
                "protocol/BANK_D_ADMISSION_SEAL_V2.json",
                "protocol/onset_mapping_candidate.json",
                "protocol/dual_boundary_contract.json",
                "authority/dataset_authority_report_stage3_3.json",
                "authority/access_evidence_manifest_stage3_3_pre_freeze.json",
                "authority/access_evidence_manifest_stage3_3_pre_bank_d.json",
                "authority/FAULT_FREE_TESTING_OPEN_EVENT_V2.json",
                "representation/representation_validation_results.json",
                "representation/same_energy_fingerprints.json",
                "representation/representation_validation_report.md",
                "representation/representation_validation_manifest.json",
                "arbitration/arbitration_validation_results.json",
                "arbitration/arbitration_validation_report.md",
                "arbitration/arbitration_validation_manifest.json",
                "calibration/dmreda_frozen_configuration_stage3_3.json",
                "calibration/scalar_reference_configurations_v2.json",
                "normal_gate/scalar_reference_calibration.json",
                "normal_gate/fault_free_testing_extraction.json",
                "normal_gate/dmreda_normal_trajectory_results.jsonl",
                "normal_gate/scalar_reference_normal_trajectory_results.jsonl",
                "normal_gate/dmreda_normal_summary.json",
                "normal_gate/scalar_reference_admission.json",
                "normal_gate/normal_gate_report.md",
                "normal_gate/normal_gate_manifest.json",
                "extracts/fault_free_training_xmeas7.csv.gz",
                "extracts/fault_free_training_xmeas7.manifest.json",
                "extracts/fault_free_testing_xmeas7.csv.gz",
                "extracts/fault_free_testing_xmeas7.manifest.json",
                "environment/raw_integrity_stage3_3.json",
                "environment/source_hashes_stage3_3.json",
                "environment/worker_memory_probe_stage3_3.json",
                "environment/test_report_stage3_3_pre_freeze.json",
                "environment/test_report_stage3_3_pre_bank_d.json",
                "environment/test_report_stage3_3_blocked_final.json",
                "environment/git_state_stage3_3_pre_freeze.json",
                "environment/git_state_stage3_3_pre_bank_d.json",
                "environment/output_guard_report_stage3_3_pre_freeze.json",
                "environment/output_guard_report_stage3_3_pre_bank_d.json",
                "environment/dual_boundary_implementation_report.json",
                "recovery/recovery_integrity_stage3_3_pre_bank_d.json",
                "recovery/GIT_BUNDLE_RECEIPT_V2.json",
                "recovery/PROGRESS_LEDGER_SNAPSHOT_V2.json",
                "reports/DMREDA_TEP_STAGE3_STOP_REPORT_V2.md",
                "reports/SESSION_STATUS_V2.md",
                "reports/RESUME_STAGE3_V2.md",
            )
        )
    )


def _validate_completed_package(
    paths: CampaignPaths, *, blocked: bool, source_commit: str
) -> Mapping[str, object]:
    manifest_relative = (
        "manifests/FINAL_BLOCKED_ARTIFACT_MANIFEST_V2.json"
        if blocked
        else "manifests/FINAL_ARTIFACT_MANIFEST_V2.json"
    )
    sums_relative = (
        "manifests/SHA256SUMS_BLOCKED_V2.txt"
        if blocked
        else "manifests/SHA256SUMS_V2.txt"
    )
    manifest = load_strict_json(paths.output(manifest_relative))
    if not isinstance(manifest, Mapping):
        raise ValueError("completed-package manifest is malformed")
    without_hash = dict(manifest)
    stored = without_hash.pop("manifest_payload_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("completed-package manifest content hash is invalid")
    expected_status = (
        "complete_and_verified_blocked_package"
        if blocked
        else "complete_and_verified"
    )
    if (
        manifest.get("status") != expected_status
        or manifest.get("source_commit") != source_commit
    ):
        raise RuntimeError("completed package belongs to a stale campaign")
    allowlist = (
        _blocked_artifact_allowlist() if blocked else _final_artifact_allowlist()
    )
    artifacts = _validate_artifact_allowlist(paths, allowlist)
    if manifest.get("artifacts") != artifacts:
        raise RuntimeError("completed-package artifact inventory is stale")
    receipt_path = paths.output("recovery/GIT_BUNDLE_RECEIPT_V2.json")
    receipt = load_strict_json(receipt_path)
    if not isinstance(receipt, Mapping):
        raise ValueError("Git bundle receipt is malformed")
    expected_bundle_path = (
        paths.recovery_root / "git-bundles" / f"dmreda-stage3-3-{source_commit[:12]}.bundle"
    )
    if (
        receipt.get("source_commit") != source_commit
        or receipt.get("bundle_relative_to_recovery_root")
        != expected_bundle_path.relative_to(paths.recovery_root).as_posix()
        or not expected_bundle_path.is_file()
    ):
        raise RuntimeError("Git bundle receipt is stale or its bundle is absent")
    bundle_path, bundle_sha = _create_or_verify_git_bundle(
        paths, source_commit=source_commit
    )
    bundle_record = manifest.get("bundle")
    if not isinstance(bundle_record, Mapping) or any(
        bundle_record.get(name) != value
        for name, value in {
            "logical_name": bundle_path.name,
            "sha256": bundle_sha,
            "stored_outside_scientific_output_root": True,
            "receipt_sha256": sha256_file(receipt_path),
        }.items()
    ):
        raise RuntimeError("completed-package bundle binding is stale")
    manifest_file_sha = sha256_file(paths.output(manifest_relative))
    expected_sums = "\n".join(
        [
            *(f"{item['sha256']}  {item['logical_name']}" for item in artifacts),
            f"{manifest_file_sha}  {manifest_relative}",
        ]
    ) + "\n"
    if paths.output(sums_relative).read_text(encoding="utf-8") != expected_sums:
        raise RuntimeError("completed-package SHA-256 manifest is stale")
    return manifest


def finalize_stopped_campaign(paths: CampaignPaths) -> Mapping[str, object]:
    """Package a normal-gate denial without creating Bank D scientific output."""

    source_commit = require_clean_source(paths)
    protocol = validate_frozen_protocol_v2(
        json_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"
        ),
        markdown_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md"
        ),
        manifest_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"
        ),
    )
    _validate_frozen_prefreeze_evidence(paths, protocol)
    seal, seal_sha256 = _load_verified_bank_d_seal(
        paths,
        source_commit=source_commit,
        protocol=protocol,
    )
    if seal.get("bank_d_decision") != "denied":
        raise RuntimeError("blocked finalization requires a machine-derived denial seal")
    _assert_bank_d_unopened(paths)
    completed_path = paths.output(
        "manifests/FINAL_BLOCKED_ARTIFACT_MANIFEST_V2.json"
    )
    if completed_path.exists():
        completed = _validate_completed_package(
            paths, blocked=True, source_commit=source_commit
        )
        return {
            "status": "stopped_at_normal_gate_or_bank_d_seal",
            "source_commit": source_commit,
            "scientific_status": completed["scientific_status"],
            "bank_d_opened": False,
            "bundle_logical_name": completed["bundle"]["logical_name"],
            "bundle_sha256": completed["bundle"]["sha256"],
            "blocked_manifest_sha256": sha256_file(completed_path),
            "worktree_clean": True,
        }
    normal = load_strict_json(paths.output("normal_gate/dmreda_normal_summary.json"))
    if not isinstance(normal, Mapping):
        raise ValueError("normal-authority summary is malformed")
    reasons = seal.get("reasons")
    if not isinstance(reasons, list) or not reasons:
        raise ValueError("denied seal does not contain explicit blocker reasons")
    normal_gate_reason_set = {
        "dmreda_normal_false_authority_gate_failed",
        "normal_summary_and_admission_disagree",
    }
    scientific_status = (
        "unstable_normal_authority"
        if set(str(reason) for reason in reasons).issubset(normal_gate_reason_set)
        else "bank_d_admission_denied_integrity_or_gate_failure"
    )
    update_progress_ledger(
        paths,
        phase="blocked_reporting_and_packaging",
        status="started",
        source_commit=source_commit,
        details={"bank_d_decision": "denied", "bank_d_opened": False},
    )
    final_test = _run_full_tests(paths, phase="blocked_final")
    if final_test["status"] != "passed":
        raise RuntimeError("blocked-package full repository tests failed")
    final_test_sha = publish_json(
        paths, "environment/test_report_stage3_3_blocked_final.json", final_test
    )
    primary = normal.get("primary_dmreda")
    if isinstance(primary, Mapping):
        primary_observation = (
            f"{primary.get('false_authority_count', 'invalid')}/"
            f"{primary.get('trajectory_count', normal.get('run_count', 'invalid'))}"
        )
        primary_limit = primary.get("max_false_authority_count", "invalid")
    else:
        primary_observation = "unavailable_due_to_invalid_normal_evidence"
        primary_limit = "unavailable"
    stop_report = "\n".join(
        (
            "# DMREDA TEP Stage 3.3 Stop Report V2",
            "",
            "The campaign stopped at the machine-derived Bank D admission gate.",
            "",
            f"- Scientific stop status: `{scientific_status}`.",
            f"- Seal reasons: {', '.join(str(reason) for reason in reasons)}.",
            f"- DMREDA normal false authority: {primary_observation}.",
            f"- Frozen maximum allowed count: {primary_limit}.",
            "- Bank D: sealed and unopened.",
            "- Faulty Testing values: not accessed by this campaign.",
            "- Disturbed outcome rows or rankings: none.",
            f"- Scientific status: {scientific_status}; no claim-grade Layer C result.",
            "",
            "The representation and arbitration artifacts remain engineering evidence only. The denial is preserved; thresholds, native event semantics, and the co-equal onset contract were not changed to obtain admission.",
            "",
        )
    )
    report_sha = publish_markdown(
        paths, "reports/DMREDA_TEP_STAGE3_STOP_REPORT_V2.md", stop_report
    )
    status_text = "\n".join(
        (
            "# Stage 3.3 Session Status V2",
            "",
            "- Branch: `research/dmreda-stage3-full-claim-validation`",
            f"- HEAD: `{source_commit}`",
            "- Worktree: `clean`",
            f"- Scientific status: `{scientific_status}`",
            "- Bank D: `sealed_unopened`",
            "- Detector ranking: `not_produced`",
            "",
        )
    )
    status_sha = publish_markdown(paths, "reports/SESSION_STATUS_V2.md", status_text)
    resume_sha = publish_markdown(
        paths,
        "reports/RESUME_STAGE3_V2.md",
        "# Resume Stage 3.3 V2\n\nFrom the scientific output root, run `shasum -a 256 -c manifests/SHA256SUMS_BLOCKED_V2.txt`. Then follow `recovery/GIT_BUNDLE_RECEIPT_V2.json` with the private recovery root to verify the Git bundle. Check out the recorded branch and HEAD, validate the clean worktree, then inspect the denial seal and stop report. Do not open Bank D under this frozen protocol. A new scientific campaign requires an explicit new protocol; do not retune this result.\n",
    )
    bundle_path, bundle_sha = _create_or_verify_git_bundle(
        paths, source_commit=source_commit
    )
    bundle_receipt_sha = _publish_bundle_receipt(
        paths,
        source_commit=source_commit,
        bundle_path=bundle_path,
        bundle_sha256=bundle_sha,
    )
    _revalidate_packaged_extractions(paths, include_faulty_testing=False)
    update_progress_ledger(
        paths,
        phase="blocked_reporting_and_packaging",
        status="completed",
        source_commit=source_commit,
        details={
            "bank_d_decision": "denied",
            "bank_d_opened": False,
            "bundle_sha256": bundle_sha,
            "stop_report_sha256": report_sha,
        },
    )
    ledger_snapshot_sha = _publish_progress_ledger_snapshot(paths)
    artifacts = _validate_artifact_allowlist(
        paths, _blocked_artifact_allowlist()
    )
    manifest_without_hash = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.blocked_artifact_manifest_v2",
        "status": "complete_and_verified_blocked_package",
        "scientific_status": scientific_status,
        "bank_d_denial_reasons": list(reasons),
        "source_commit": source_commit,
        "protocol_sha256": canonical_sha256(protocol),
        "bank_d_admission_seal_sha256": seal_sha256,
        "bank_d_opened": False,
        "faulty_testing_values_accessed": False,
        "outcome_rows_created": False,
        "final_test_report_sha256": final_test_sha,
        "progress_ledger_snapshot_sha256": ledger_snapshot_sha,
        "report_sha256": {
            "stop_report": report_sha,
            "session_status": status_sha,
            "resume": resume_sha,
        },
        "bundle": {
            "logical_name": bundle_path.name,
            "sha256": bundle_sha,
            "stored_outside_scientific_output_root": True,
            "receipt_sha256": bundle_receipt_sha,
        },
        "artifacts": artifacts,
    }
    manifest = {
        **manifest_without_hash,
        "manifest_payload_sha256": canonical_sha256(manifest_without_hash),
    }
    publish_json(
        paths, "manifests/FINAL_BLOCKED_ARTIFACT_MANIFEST_V2.json", manifest
    )
    manifest_sha = sha256_file(
        paths.output("manifests/FINAL_BLOCKED_ARTIFACT_MANIFEST_V2.json")
    )
    sha_lines = [f"{item['sha256']}  {item['logical_name']}" for item in artifacts]
    sha_lines.extend(
        (
            f"{manifest_sha}  manifests/FINAL_BLOCKED_ARTIFACT_MANIFEST_V2.json",
        )
    )
    publish_hash_manifest(
        paths, "manifests/SHA256SUMS_BLOCKED_V2.txt", "\n".join(sha_lines) + "\n"
    )
    return {
        "status": "stopped_at_normal_gate_or_bank_d_seal",
        "source_commit": source_commit,
        "scientific_status": scientific_status,
        "bank_d_opened": False,
        "bundle_logical_name": bundle_path.name,
        "bundle_sha256": bundle_sha,
        "blocked_manifest_sha256": manifest_sha,
        "worktree_clean": require_clean_source(paths) == source_commit,
    }


def finalize_campaign(paths: CampaignPaths) -> Mapping[str, object]:
    """Write final reports, manifests, status records, and a private Git bundle."""

    source_commit, protocol, seal, _, _, reproduction = (
        _load_validated_reproduction_manifest(paths)
    )
    seal_file_sha = sha256_file(paths.output("protocol/BANK_D_ADMISSION_SEAL_V2.json"))
    open_event = _validate_bank_d_open_binding(
        paths, seal=seal, seal_file_sha256=seal_file_sha
    )
    bank_d_opened = open_event.get("action") == "open_bank_d_once"
    completed_path = paths.output("manifests/FINAL_ARTIFACT_MANIFEST_V2.json")
    if completed_path.exists():
        completed = _validate_completed_package(
            paths, blocked=False, source_commit=source_commit
        )
        return {
            "source_commit": source_commit,
            "evidence_category": completed["evidence_category"],
            "onset_effect_category": completed["onset_effect_category"],
            "bundle_logical_name": completed["bundle"]["logical_name"],
            "bundle_sha256": completed["bundle"]["sha256"],
            "final_manifest_sha256": sha256_file(completed_path),
            "worktree_clean": True,
        }
    update_progress_ledger(
        paths,
        phase="final_reporting_and_packaging",
        status="started",
        source_commit=source_commit,
        details={
            "protocol_sha256": canonical_sha256(protocol),
            "bank_d_open_event_sha256": sha256_file(
                paths.output("protocol/BANK_D_OPEN_EVENT_V2.json")
            ),
        },
    )
    final_test = _run_full_tests(paths, phase="final")
    if final_test["status"] != "passed":
        raise RuntimeError("final full repository test suite failed")
    final_test_sha = publish_json(
        paths, "environment/test_report_stage3_3_final.json", final_test
    )
    layer_a = load_strict_json(
        paths.output("representation/representation_validation_results.json")
    )
    layer_b = load_strict_json(
        paths.output("arbitration/arbitration_validation_results.json")
    )
    normal = load_strict_json(paths.output("normal_gate/dmreda_normal_summary.json"))
    boundary = load_strict_json(
        paths.output("bank_d/primary/boundary_sensitivity_summary.json")
    )
    global_159 = load_strict_json(
        paths.output("bank_d/primary/global_summary_onset_159.json")
    )
    global_160 = load_strict_json(
        paths.output("bank_d/primary/global_summary_onset_160.json")
    )
    per_fault_159 = load_strict_json(
        paths.output("bank_d/primary/per_fault_summary_onset_159.json")
    )
    per_fault_160 = load_strict_json(
        paths.output("bank_d/primary/per_fault_summary_onset_160.json")
    )
    primary_159 = global_159[PRIMARY_CHANNEL]["micro_recording_level"]
    primary_160 = global_160[PRIMARY_CHANNEL]["micro_recording_level"]
    admitted = tuple(seal["admitted_reference_allowlist"])
    pairwise = load_strict_json(
        paths.output("bank_d/primary/admitted_reference_pairwise_results.json")
    )
    statistical = load_strict_json(
        paths.output("bank_d/primary/statistical_analysis.json")
    )
    d_only_summary = load_strict_json(
        paths.output("bank_d/ablations/d_only_dual_boundary_summary.json")
    )
    g_only_summary = load_strict_json(
        paths.output("bank_d/ablations/g_only_dual_boundary_summary.json")
    )
    direct_added, reference_interpretations_same = (
        evaluate_boundary_coequal_reference_evidence(
            pairwise,
            statistical,
            admitted_references=admitted,
        )
    )
    boundary_support = _boundary_reference_support_sets(
        pairwise,
        statistical,
        admitted_references=admitted,
    )
    support_records = _coequal_support_records(
        pairwise,
        statistical,
        admitted_references=admitted,
    )
    evidence_category = classify_final_evidence(
        layer_a_passed=layer_a["status"] == "passed",
        layer_b_passed=layer_b["status"] == "passed",
        normal_passed=normal["status"] == "passed",
        valid_authority_count_159=int(primary_159["counts"]["valid_authority"]),
        valid_authority_count_160=int(primary_160["counts"]["valid_authority"]),
        admitted_reference_count=len(admitted),
        boundary_coequal_holm_added_value_supported=direct_added,
    )
    primary_flips = int(
        boundary["global"][PRIMARY_CHANNEL]["boundary_sensitivity_counts"][
            "classification_flip_at_boundary"
        ]
    )
    total_flips = sum(
        int(record["boundary_sensitivity_counts"]["classification_flip_at_boundary"])
        for record in boundary["global"].values()
    )
    boundary_categories = {
        159: classify_final_evidence(
            layer_a_passed=layer_a["status"] == "passed",
            layer_b_passed=layer_b["status"] == "passed",
            normal_passed=normal["status"] == "passed",
            valid_authority_count_159=int(primary_159["counts"]["valid_authority"]),
            valid_authority_count_160=int(primary_159["counts"]["valid_authority"]),
            admitted_reference_count=len(admitted),
            boundary_coequal_holm_added_value_supported=bool(boundary_support[159]),
        ),
        160: classify_final_evidence(
            layer_a_passed=layer_a["status"] == "passed",
            layer_b_passed=layer_b["status"] == "passed",
            normal_passed=normal["status"] == "passed",
            valid_authority_count_159=int(primary_160["counts"]["valid_authority"]),
            valid_authority_count_160=int(primary_160["counts"]["valid_authority"]),
            admitted_reference_count=len(admitted),
            boundary_coequal_holm_added_value_supported=bool(boundary_support[160]),
        ),
    }
    covered_faults = {
        onset: {
            key
            for key, channels in per_fault.items()
            if int(channels[PRIMARY_CHANNEL]["counts"]["valid_authority"]) > 0
        }
        for onset, per_fault in ((159, per_fault_159), (160, per_fault_160))
    }
    final_evidence_category_same = (
        boundary_categories[159] == boundary_categories[160]
    )
    high_level_conclusions_same = (
        covered_faults[159] == covered_faults[160]
        and bool(boundary_support[159]) == bool(boundary_support[160])
    )
    no_claim_unique_to_one_boundary = (
        final_evidence_category_same
        and covered_faults[159] == covered_faults[160]
        and boundary_support[159] == boundary_support[160]
    )
    onset_category = classify_boundary_interpretation(
        classification_flip_count=total_flips,
        final_evidence_category_same=final_evidence_category_same,
        high_level_conclusions_same=high_level_conclusions_same,
        admitted_reference_interpretations_same=reference_interpretations_same,
        no_claim_unique_to_one_boundary=no_claim_unique_to_one_boundary,
    )
    full_report = _final_report_text(
        layer_a=layer_a,
        layer_b=layer_b,
        normal=normal,
        seal=seal,
        boundary=boundary,
        global_159=global_159,
        global_160=global_160,
        per_fault_159=per_fault_159,
        per_fault_160=per_fault_160,
        reproduction=reproduction,
        evidence_category=evidence_category,
        onset_category=onset_category,
        bank_d_opened=bank_d_opened,
        boundary_coequal_holm_added_value_supported=direct_added,
        boundary_decision_details={
            "category_159": boundary_categories[159],
            "category_160": boundary_categories[160],
            "supported_pairs_159": len(boundary_support[159]),
            "supported_pairs_160": len(boundary_support[160]),
        },
        support_records=support_records,
        d_only_summary=d_only_summary,
        g_only_summary=g_only_summary,
    )
    report_hashes = {
        "full_report": publish_markdown(
            paths,
            "reports/DMREDA_TEP_STAGE3_FULL_VALIDATION_REPORT_V2.md",
            full_report,
        ),
        "executive_summary": publish_markdown(
            paths,
            "reports/DMREDA_TEP_STAGE3_EXECUTIVE_SUMMARY_V2.md",
            "\n".join(full_report.splitlines()[:18]) + "\n",
        ),
        "limitations": publish_markdown(
            paths,
            "reports/DMREDA_TEP_STAGE3_LIMITATIONS_V2.md",
            "# Stage 3.3 Limitations V2\n\nThe exact Rieth V1 testing onset remains unresolved; both boundaries are co-equal. TEP is simulated, xmeas_7 is one scalar assurance channel, recordings within fault classes share a generator family, and scalar-reference admission is limited to the frozen normal-risk contract. The publisher's Faulty Testing R object was extracted once to avoid twenty complete 836 MB RData deserializations, then consumed in deterministic single-fault groups with immutable per-fault checkpoints; this is a compute/recovery choice, not extra scientific independence. No universal detector, diagnosis, embedded timing, energy, or total-RAM claim follows.\n",
        ),
        "dual_boundary_report": publish_markdown(
            paths,
            "reports/DUAL_BOUNDARY_RESULT_REPORT.md",
            f"# Dual-Boundary Result\n\nCategory: `{onset_category}`. Classification flips across all confirmatory channels: {total_flips}; primary DMREDA flips: {primary_flips}. Both onset mappings remain co-equal; no favorable boundary was selected.\n",
        ),
    }
    session = "\n".join(
        (
            "# Stage 3.3 Session Status V2",
            "",
            f"- Branch: `research/dmreda-stage3-full-claim-validation`",
            f"- HEAD: `{source_commit}`",
            f"- Worktree: `clean`",
            f"- Evidence category: `{evidence_category}`",
            f"- Onset category: `{onset_category}`",
            f"- Bank D: `{'opened_once' if bank_d_opened else 'not_opened'}`",
            f"- Reproduction: `{reproduction['status']}`",
            "",
        )
    )
    report_hashes["session_status"] = publish_markdown(
        paths, "reports/SESSION_STATUS_V2.md", session
    )
    report_hashes["resume"] = publish_markdown(
        paths,
        "reports/RESUME_STAGE3_V2.md",
        "# Resume Stage 3.3 V2\n\nFrom the scientific output root, run `shasum -a 256 -c manifests/SHA256SUMS_V2.txt`. Then follow `recovery/GIT_BUNDLE_RECEIPT_V2.json` with the private recovery root to verify the Git bundle. Check out the recorded branch/HEAD, verify the clean worktree, then inspect the final report and manifest. Do not rerun Bank D automatically; the one-time opening record and immutable primary manifest already exist.\n",
    )

    bundle_path, bundle_sha = _create_or_verify_git_bundle(
        paths, source_commit=source_commit
    )
    bundle_receipt_sha = _publish_bundle_receipt(
        paths,
        source_commit=source_commit,
        bundle_path=bundle_path,
        bundle_sha256=bundle_sha,
    )
    _revalidate_packaged_extractions(paths, include_faulty_testing=True)
    update_progress_ledger(
        paths,
        phase="final_reporting_and_packaging",
        status="completed",
        source_commit=source_commit,
        details={
            "bundle_sha256": bundle_sha,
            "evidence_category": evidence_category,
            "onset_effect_category": onset_category,
            "full_report_sha256": report_hashes["full_report"],
        },
    )
    ledger_snapshot_sha = _publish_progress_ledger_snapshot(paths)
    versioned_files = _validate_final_allowlist(paths)
    final_manifest_without_hash = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.final_artifact_manifest_v2",
        "status": "complete_and_verified",
        "source_commit": source_commit,
        "evidence_category": evidence_category,
        "onset_effect_category": onset_category,
        "bank_d_opened": bank_d_opened,
        "bank_d_open_event_sha256": sha256_file(
            paths.output("protocol/BANK_D_OPEN_EVENT_V2.json")
        ),
        "protocol_sha256": canonical_sha256(protocol),
        "reproduction_status": reproduction["status"],
        "final_test_report_sha256": final_test_sha,
        "progress_ledger_snapshot_sha256": ledger_snapshot_sha,
        "report_sha256": report_hashes,
        "bundle": {
            "logical_name": bundle_path.name,
            "sha256": bundle_sha,
            "stored_outside_scientific_output_root": True,
            "receipt_sha256": bundle_receipt_sha,
        },
        "artifacts": versioned_files,
    }
    final_manifest = {
        **final_manifest_without_hash,
        "manifest_payload_sha256": canonical_sha256(final_manifest_without_hash),
    }
    publish_json(paths, "manifests/FINAL_ARTIFACT_MANIFEST_V2.json", final_manifest)
    sha_lines = [f"{item['sha256']}  {item['logical_name']}" for item in versioned_files]
    final_manifest_file_sha = sha256_file(
        paths.output("manifests/FINAL_ARTIFACT_MANIFEST_V2.json")
    )
    sha_lines.append(
        f"{final_manifest_file_sha}  manifests/FINAL_ARTIFACT_MANIFEST_V2.json"
    )
    publish_hash_manifest(
        paths, "manifests/SHA256SUMS_V2.txt", "\n".join(sha_lines) + "\n"
    )
    return {
        "source_commit": source_commit,
        "evidence_category": evidence_category,
        "onset_effect_category": onset_category,
        "bundle_logical_name": bundle_path.name,
        "bundle_sha256": bundle_sha,
        "final_manifest_sha256": final_manifest_file_sha,
        "worktree_clean": require_clean_source(paths) == source_commit,
    }


def finalize_campaign_state(paths: CampaignPaths) -> Mapping[str, object]:
    """Finalize either side of the verified normal-gate decision.

    This is the safe standalone ``finalize`` entry point.  In particular, a
    denied seal must produce the blocked final manifest instead of entering
    the admitted-only Bank D reporting path.
    """

    source_commit = require_clean_source(paths)
    protocol = validate_frozen_protocol_v2(
        json_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.json"
        ),
        markdown_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.md"
        ),
        manifest_path=paths.output(
            "protocol/DMREDA_TEP_XMEAS7_STAGE3_FULL_PROTOCOL_V2.manifest.json"
        ),
    )
    seal, _ = _load_verified_bank_d_seal(
        paths,
        source_commit=source_commit,
        protocol=protocol,
    )
    decision = seal.get("bank_d_decision")
    if decision == "denied":
        return finalize_stopped_campaign(paths)
    if decision == "admitted":
        return finalize_campaign(paths)
    raise RuntimeError("verified Bank D seal has no recognized decision")


def run_full_campaign(paths: CampaignPaths, *, workers: int = 4) -> Mapping[str, object]:
    """Resume from durable phase manifests without reopening completed phases."""

    protocol = run_prefreeze(paths)
    source_commit = require_clean_source(paths)
    seal_path = paths.output("protocol/BANK_D_ADMISSION_SEAL_V2.json")
    if seal_path.exists():
        seal, seal_sha256 = _load_verified_bank_d_seal(
            paths,
            source_commit=source_commit,
            protocol=protocol,
        )
        open_path = paths.output("protocol/BANK_D_OPEN_EVENT_V2.json")
        if open_path.exists():
            if seal.get("bank_d_decision") != "admitted":
                raise PermissionError("a denied campaign contains a Bank D open event")
            _validate_bank_d_open_binding(
                paths,
                seal=seal,
                seal_file_sha256=seal_sha256,
            )
    else:
        _, seal = run_normal_gate(paths, workers=workers)
    if seal.get("bank_d_decision") != "admitted":
        return finalize_stopped_campaign(paths)
    if paths.output("bank_d/primary/primary_result_manifest.json").exists():
        _load_validated_primary_context(paths)
    else:
        run_bank_d_primary(paths, workers=workers)
    if paths.output("bank_d/ablations/ablation_manifest.json").exists():
        _load_validated_ablation_manifest(paths)
    else:
        run_ablations(paths, workers=workers)
    if paths.output("reproducibility/reproduction_manifest.json").exists():
        _load_validated_reproduction_manifest(paths)
    else:
        run_reproduction(paths, workers=workers)
    return finalize_campaign(paths)
