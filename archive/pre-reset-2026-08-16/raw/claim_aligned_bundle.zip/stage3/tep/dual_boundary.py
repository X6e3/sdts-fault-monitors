"""Pure dual-boundary binding for onset-independent event authority.

This module never generates evidence, reads a dataset, or executes a detector.
It classifies one already-authoritative event sequence against the two frozen
Rieth V1 onset candidates.  The first event owns the complete trajectory.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

from stage3.admission.serialization import canonical_json_bytes, canonical_sha256


ONSET_INDEX_159 = 159
ONSET_INDEX_160 = 160
FROZEN_ONSET_INDICES = (ONSET_INDEX_159, ONSET_INDEX_160)

AUTHORITY_OUTCOMES = (
    "false_authority",
    "valid_authority",
    "no_authority",
    "invalid",
)
BOUNDARY_SENSITIVITY_CATEGORIES = (
    "classification_flip_at_boundary",
    "latency_shift_only",
    "false_authority_under_both",
    "no_authority_under_both",
    "invalid",
)


@dataclass(frozen=True)
class AuthorityOutcome:
    """One onset-relative authority outcome with no detector-centric aliases."""

    outcome: str
    latency_samples: int | None

    def __post_init__(self) -> None:
        if self.outcome not in AUTHORITY_OUTCOMES:
            raise ValueError("unknown authority outcome")
        if self.outcome == "valid_authority":
            if (
                isinstance(self.latency_samples, bool)
                or not isinstance(self.latency_samples, int)
                or self.latency_samples < 0
            ):
                raise ValueError("valid authority requires a non-negative latency")
        elif self.latency_samples is not None:
            raise ValueError("only valid authority may have latency")

    def to_dict(self) -> dict[str, int | str | None]:
        return {
            "outcome": self.outcome,
            "latency_samples": self.latency_samples,
        }


@dataclass(frozen=True)
class DualBoundaryClassification:
    """Co-equal outcomes bound to one immutable authoritative event sequence."""

    trace_length: int
    authoritative_event_indices: tuple[int, ...]
    outcome_onset_159: AuthorityOutcome
    outcome_onset_160: AuthorityOutcome
    boundary_sensitivity_category: str
    mutually_exclusive_outcome_changed: bool
    latency_shift_only: bool
    integrity_failure_reason: str | None = None

    def __post_init__(self) -> None:
        if self.boundary_sensitivity_category not in BOUNDARY_SENSITIVITY_CATEGORIES:
            raise ValueError("unknown boundary-sensitivity category")
        if not isinstance(self.mutually_exclusive_outcome_changed, bool):
            raise TypeError("mutually_exclusive_outcome_changed must be boolean")
        if not isinstance(self.latency_shift_only, bool):
            raise TypeError("latency_shift_only must be boolean")
        if self.boundary_sensitivity_category == "invalid":
            if not isinstance(self.integrity_failure_reason, str) or not (
                self.integrity_failure_reason.strip()
            ):
                raise ValueError("invalid classification requires an integrity reason")
            if (
                self.outcome_onset_159.outcome != "invalid"
                or self.outcome_onset_160.outcome != "invalid"
            ):
                raise ValueError("invalid classification must be invalid at both onsets")
            if self.mutually_exclusive_outcome_changed or self.latency_shift_only:
                raise ValueError("invalid classification cannot assert an outcome change")
        elif self.integrity_failure_reason is not None:
            raise ValueError("valid classifications cannot carry an integrity failure")

    @property
    def first_authoritative_event(self) -> int | None:
        return (
            self.authoritative_event_indices[0]
            if self.authoritative_event_indices
            else None
        )

    @property
    def authoritative_events_sha256(self) -> str:
        return canonical_sha256(list(self.authoritative_event_indices))

    def to_dict(self) -> dict[str, object]:
        return {
            "authoritative_event_indices": list(self.authoritative_event_indices),
            "authoritative_event_count": len(self.authoritative_event_indices),
            "first_authoritative_event": self.first_authoritative_event,
            "authoritative_events_sha256": self.authoritative_events_sha256,
            "outcome_onset_159": self.outcome_onset_159.outcome,
            "latency_onset_159": self.outcome_onset_159.latency_samples,
            "outcome_onset_160": self.outcome_onset_160.outcome,
            "latency_onset_160": self.outcome_onset_160.latency_samples,
            "boundary_sensitivity_category": self.boundary_sensitivity_category,
            "mutually_exclusive_outcome_changed": (
                self.mutually_exclusive_outcome_changed
            ),
            "latency_shift_only": self.latency_shift_only,
            "integrity_failure_reason": self.integrity_failure_reason,
        }


def _validate_trace_length(trace_length: int) -> None:
    if isinstance(trace_length, bool) or not isinstance(trace_length, int):
        raise TypeError("trace_length must be an integer")
    if trace_length <= ONSET_INDEX_160:
        raise ValueError("trace must contain both frozen onset indices")


def _validated_event_indices(
    event_indices: Iterable[int], *, trace_length: int
) -> tuple[int, ...]:
    if isinstance(event_indices, (str, bytes)):
        raise TypeError("event_indices must be an iterable of integers")
    events = tuple(event_indices)
    for event in events:
        if isinstance(event, bool) or not isinstance(event, int):
            raise TypeError("authoritative event indices must be integers")
        if not 0 <= event < trace_length:
            raise ValueError("authoritative event lies outside the trace")
    if any(right <= left for left, right in zip(events, events[1:])):
        raise ValueError("authoritative events must be unique and strictly increasing")
    return events


def classify_dual_boundary_authority(
    event_indices: Iterable[int], *, trace_length: int
) -> DualBoundaryClassification:
    """Bind one authoritative event sequence to both frozen onset candidates."""

    _validate_trace_length(trace_length)
    events = _validated_event_indices(event_indices, trace_length=trace_length)
    if not events:
        classification = DualBoundaryClassification(
            trace_length=trace_length,
            authoritative_event_indices=events,
            outcome_onset_159=AuthorityOutcome("no_authority", None),
            outcome_onset_160=AuthorityOutcome("no_authority", None),
            boundary_sensitivity_category="no_authority_under_both",
            mutually_exclusive_outcome_changed=False,
            latency_shift_only=False,
        )
    else:
        first = events[0]
        if first < ONSET_INDEX_159:
            classification = DualBoundaryClassification(
                trace_length=trace_length,
                authoritative_event_indices=events,
                outcome_onset_159=AuthorityOutcome("false_authority", None),
                outcome_onset_160=AuthorityOutcome("false_authority", None),
                boundary_sensitivity_category="false_authority_under_both",
                mutually_exclusive_outcome_changed=False,
                latency_shift_only=False,
            )
        elif first == ONSET_INDEX_159:
            classification = DualBoundaryClassification(
                trace_length=trace_length,
                authoritative_event_indices=events,
                outcome_onset_159=AuthorityOutcome("valid_authority", 0),
                outcome_onset_160=AuthorityOutcome("false_authority", None),
                boundary_sensitivity_category="classification_flip_at_boundary",
                mutually_exclusive_outcome_changed=True,
                latency_shift_only=False,
            )
        else:
            classification = DualBoundaryClassification(
                trace_length=trace_length,
                authoritative_event_indices=events,
                outcome_onset_159=AuthorityOutcome(
                    "valid_authority", first - ONSET_INDEX_159
                ),
                outcome_onset_160=AuthorityOutcome(
                    "valid_authority", first - ONSET_INDEX_160
                ),
                boundary_sensitivity_category="latency_shift_only",
                mutually_exclusive_outcome_changed=False,
                latency_shift_only=True,
            )
    validate_dual_boundary_classification(classification)
    return classification


def invalid_dual_boundary_classification(
    *, trace_length: int, integrity_failure_reason: str
) -> DualBoundaryClassification:
    """Create an explicit invalid record for a detected integrity failure only."""

    _validate_trace_length(trace_length)
    classification = DualBoundaryClassification(
        trace_length=trace_length,
        authoritative_event_indices=(),
        outcome_onset_159=AuthorityOutcome("invalid", None),
        outcome_onset_160=AuthorityOutcome("invalid", None),
        boundary_sensitivity_category="invalid",
        mutually_exclusive_outcome_changed=False,
        latency_shift_only=False,
        integrity_failure_reason=integrity_failure_reason,
    )
    validate_dual_boundary_classification(classification)
    return classification


def validate_dual_boundary_classification(
    classification: DualBoundaryClassification,
) -> None:
    """Prove a classification is the unique result of its event sequence."""

    _validate_trace_length(classification.trace_length)
    events = _validated_event_indices(
        classification.authoritative_event_indices,
        trace_length=classification.trace_length,
    )
    if classification.boundary_sensitivity_category == "invalid":
        if events:
            raise ValueError("invalid classification cannot assert event evidence")
        canonical_json_bytes(classification.to_dict())
        return

    # Avoid recursive validation: reconstruct the exact expected fields locally.
    first = events[0] if events else None
    if first is None:
        expected_values = (
            "no_authority",
            None,
            "no_authority",
            None,
            "no_authority_under_both",
            False,
            False,
        )
    elif first < ONSET_INDEX_159:
        expected_values = (
            "false_authority",
            None,
            "false_authority",
            None,
            "false_authority_under_both",
            False,
            False,
        )
    elif first == ONSET_INDEX_159:
        expected_values = (
            "valid_authority",
            0,
            "false_authority",
            None,
            "classification_flip_at_boundary",
            True,
            False,
        )
    else:
        expected_values = (
            "valid_authority",
            first - ONSET_INDEX_159,
            "valid_authority",
            first - ONSET_INDEX_160,
            "latency_shift_only",
            False,
            True,
        )
    observed_values = (
        classification.outcome_onset_159.outcome,
        classification.outcome_onset_159.latency_samples,
        classification.outcome_onset_160.outcome,
        classification.outcome_onset_160.latency_samples,
        classification.boundary_sensitivity_category,
        classification.mutually_exclusive_outcome_changed,
        classification.latency_shift_only,
    )
    if observed_values != expected_values:
        raise ValueError("classification does not follow first-event ownership")
    canonical_json_bytes(classification.to_dict())


def validate_dual_boundary_row(row: Mapping[str, object]) -> None:
    """Validate the classification fields embedded in a machine result row."""

    required = set(DualBoundaryClassification(
        trace_length=ONSET_INDEX_160 + 1,
        authoritative_event_indices=(),
        outcome_onset_159=AuthorityOutcome("no_authority", None),
        outcome_onset_160=AuthorityOutcome("no_authority", None),
        boundary_sensitivity_category="no_authority_under_both",
        mutually_exclusive_outcome_changed=False,
        latency_shift_only=False,
    ).to_dict())
    if not required.issubset(row):
        raise ValueError("dual-boundary row is missing classification fields")
    events = row["authoritative_event_indices"]
    if not isinstance(events, list):
        raise TypeError("authoritative_event_indices must be a JSON list")
    trace_length = row.get("sample_count")
    if isinstance(trace_length, bool) or not isinstance(trace_length, int):
        raise TypeError("sample_count must be an integer")
    if row["boundary_sensitivity_category"] == "invalid":
        rebuilt = invalid_dual_boundary_classification(
            trace_length=trace_length,
            integrity_failure_reason=str(row["integrity_failure_reason"]),
        )
    else:
        rebuilt = classify_dual_boundary_authority(events, trace_length=trace_length)
    for key, value in rebuilt.to_dict().items():
        if row.get(key) != value:
            raise ValueError(f"dual-boundary row field is inconsistent: {key}")
