"""Deterministic synthetic validation of the DMREDA representation contract.

This module exercises the causal representation before any TEP Testing values
are opened. The hard gates are mechanism contracts. Fingerprint distances are
characterization results and are deliberately not uniqueness tests.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Iterable, Mapping, Sequence

import numpy as np

from gold_line.core.dmreda_reference_clean import DMREDAResult, compute_dmreda_reference
from stage3.admission.serialization import canonical_sha256
from stage3.tep.configuration import (
    FROZEN_TEP_CONFIGURATION_SHA256,
    build_effective_profiles,
    build_tep_core_kwargs,
)


REPRESENTATION_CONTRACT_VERSION = "1.0.0"
PREFIX_CHECK_LENGTHS = (
    1,
    2,
    7,
    8,
    11,
    12,
    16,
    17,
    32,
    33,
    49,
    50,
    51,
    91,
    92,
    93,
    149,
    150,
    151,
    191,
    192,
    193,
    319,
    320,
)
REPRESENTATION_TRACE_FIELDS = (
    "mu",
    "e",
    "e1",
    "e_baseline",
    "e_baseline_safe",
    "d",
    "g_raw",
    "g",
    "r",
    "a",
    "a_slow",
    "state",
    "m_eff",
    "confirm_len_eff",
)

# These expectations are defined independently of the eventual synthetic
# outputs. Altering them changes the contract hash and requires a protocol
# revision.
REPRESENTATION_EXPECTATIONS_V1: Mapping[str, object] = {
    "hard_gates": {
        "deterministic_complete_trace": "all Core traces and events repeat exactly",
        "prefix_causality": "prefix-identical inputs have identical representation prefixes",
        "warmup_representation_invariance": (
            "warmup 0 and 92 have identical representation and adaptive-state traces"
        ),
        "contracted_bounds": {
            "d": [-5.0, 5.0],
            "g_raw": [-10.0, 10.0],
            "g": [-10.0, 10.0],
            "a": [0.0, 1.0],
            "a_slow": [0.0, 1.0],
            "state": sorted(build_effective_profiles()),
        },
        "finite_representation": "all floating representation traces are finite",
        "mode_independent_representation": (
            "D_ONLY, G_ONLY, and D_OR_G share identical representation traces"
        ),
    },
    "characterization_only": {
        "d": "positive integrated mass and peaks summarize structural energy deviation",
        "g": "positive integrated mass and peaks summarize finite-lag temporal growth",
        "d_or_g": "native authority is reported without imposing a union-of-events claim",
        "same_energy": "pairwise fingerprint distances are reported without a uniqueness gate",
        "equal_peak": "pairwise fingerprint distances are reported without a uniqueness gate",
    },
    "forbidden_success_definition": "every signal has a unique fingerprint",
}

# Literal hashes are filled only after the expectation and fixture contracts
# have been reviewed. They make later accidental edits fail closed.
FROZEN_REPRESENTATION_EXPECTATIONS_SHA256 = (
    "a8942fc787f51a0ded6c7068b0cd643c69dda1cefe2f00a0268d4aca63ed7de4"
)
FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256 = (
    "fc36572ff5417aeb6f0477e57325c8dd747ba0dc40ce91ae40634bd2a612b8c7"
)


@dataclass(frozen=True)
class SyntheticFixture:
    name: str
    family: str
    samples: np.ndarray
    generator: Mapping[str, object]

    def __post_init__(self) -> None:
        values = np.asarray(self.samples, dtype=np.float64)
        if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
            raise ValueError(f"fixture {self.name!r} must contain a finite 1-D signal")
        object.__setattr__(self, "samples", values.copy())


def _signal_sha256(samples: np.ndarray) -> str:
    values = np.asarray(samples, dtype="<f8")
    return hashlib.sha256(values.tobytes(order="C")).hexdigest()


def build_representation_fixtures(*, length: int = 512) -> tuple[SyntheticFixture, ...]:
    """Build the frozen deterministic signal family used by Layer A."""

    if length != 512:
        raise ValueError("Layer A fixture length is frozen at 512 samples")
    start = 180
    fixtures: list[SyntheticFixture] = []

    def add(name: str, family: str, signal: np.ndarray, **generator: object) -> None:
        fixtures.append(
            SyntheticFixture(
                name=name,
                family=family,
                samples=signal,
                generator={"length": length, "start": start, **generator},
            )
        )

    add("constant_zero", "control", np.zeros(length), shape="constant", value=0.0)

    signal = np.zeros(length)
    signal[start] = 4.0
    add("impulse", "canonical", signal, shape="single_sample", amplitude=4.0)

    signal = np.zeros(length)
    signal[start : start + 8] = 1.5
    add("short_burst", "canonical", signal, shape="rectangular", amplitude=1.5, width=8)

    signal = np.zeros(length)
    signal[start : start + 50] = 1.0
    add("finite_step", "canonical", signal, shape="rectangular", amplitude=1.0, width=50)

    signal = np.zeros(length)
    signal[start:] = 1.0
    add("persistent_step", "canonical", signal, shape="persistent_step", amplitude=1.0)

    signal = np.zeros(length)
    signal[start : start + 96] = np.linspace(0.0, 2.0, 96, endpoint=True)
    add("ramp", "canonical", signal, shape="finite_linear_ramp", peak=2.0, width=96)

    signal = np.zeros(length)
    signal[120:] = np.linspace(0.0, 1.2, length - 120, endpoint=True)
    add("slow_drift", "canonical", signal, shape="linear_drift", peak=1.2, start=120)

    signal = np.zeros(length)
    phase = np.arange(128, dtype=np.float64)
    signal[start : start + 128] = 1.5 * np.sin(2.0 * np.pi * phase / 16.0)
    add("oscillation", "canonical", signal, shape="sine", amplitude=1.5, period=16, width=128)

    signal = np.zeros(length)
    signal[start : start + 96] = np.where(np.arange(96) % 2 == 0, 1.0, -1.0)
    add("alternating", "canonical", signal, shape="alternating_sign", amplitude=1.0, width=96)

    signal = np.zeros(length)
    for offset in (0, 32, 64, 96):
        signal[start + offset : start + offset + 6] = 1.4
    add(
        "repeated_intermittent",
        "canonical",
        signal,
        shape="four_rectangular_bursts",
        amplitude=1.4,
        width=6,
        spacing=32,
    )

    same_energy_specs = (
        ("same_energy_impulse", 1, math.sqrt(8.0)),
        ("same_energy_burst", 8, 1.0),
        ("same_energy_step", 32, 0.5),
    )
    for name, width, amplitude in same_energy_specs:
        signal = np.zeros(length)
        signal[start : start + width] = amplitude
        add(
            name,
            "same_energy",
            signal,
            shape="rectangular",
            amplitude=amplitude,
            width=width,
            squared_energy=8.0,
        )

    for name, width in (
        ("equal_peak_impulse", 1),
        ("equal_peak_burst", 8),
        ("equal_peak_step", 40),
    ):
        signal = np.zeros(length)
        signal[start : start + width] = 2.0
        add(
            name,
            "equal_peak",
            signal,
            shape="rectangular",
            amplitude=2.0,
            width=width,
        )

    noise = np.random.default_rng(31001).normal(0.0, 0.02, length)
    add("normal_noise", "control", noise, distribution="normal", sigma=0.02, seed=31001)

    prefix = np.random.default_rng(31002).normal(0.0, 0.01, length)
    prefix_a = prefix.copy()
    prefix_b = prefix.copy()
    prefix_length = 320
    prefix_a[prefix_length:] += 1.0
    prefix_b[prefix_length:] += np.linspace(0.0, 1.5, length - prefix_length)
    add(
        "prefix_pair_step_suffix",
        "prefix_pair",
        prefix_a,
        shared_seed=31002,
        prefix_length=prefix_length,
        suffix="step",
    )
    add(
        "prefix_pair_ramp_suffix",
        "prefix_pair",
        prefix_b,
        shared_seed=31002,
        prefix_length=prefix_length,
        suffix="ramp",
    )
    return tuple(fixtures)


def representation_fixture_contract(
    fixtures: Iterable[SyntheticFixture] | None = None,
) -> dict[str, object]:
    selected = tuple(build_representation_fixtures() if fixtures is None else fixtures)
    return {
        "contract_version": REPRESENTATION_CONTRACT_VERSION,
        "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "fixtures": [
            {
                "fixture_name": fixture.name,
                "family": fixture.family,
                "generator": dict(fixture.generator),
                "sample_count": int(fixture.samples.size),
                "sample_sha256": _signal_sha256(fixture.samples),
            }
            for fixture in selected
        ],
        "prefix_check_lengths": list(PREFIX_CHECK_LENGTHS),
        "trace_fields": list(REPRESENTATION_TRACE_FIELDS),
    }


def _all_trace_equal(left: DMREDAResult, right: DMREDAResult) -> bool:
    return all(
        np.array_equal(getattr(left, field), getattr(right, field))
        for field in REPRESENTATION_TRACE_FIELDS + ("pending", "confirmed", "event_active")
    ) and left.event_times == right.event_times


def _representation_equal(left: DMREDAResult, right: DMREDAResult) -> bool:
    return all(
        np.array_equal(getattr(left, field), getattr(right, field))
        for field in REPRESENTATION_TRACE_FIELDS
    )


def _first_true(mask: np.ndarray) -> int | None:
    indices = np.flatnonzero(mask)
    return int(indices[0]) if indices.size else None


def _processing_state(result: DMREDAResult) -> np.ndarray:
    """Recover the state used to process each sample.

    ``result.state[t]`` is post-transition on regime ticks. The representation
    and candidate predicate at ``t`` use the state entering that sample.
    """

    states = np.empty_like(result.state)
    states[0] = 0
    states[1:] = result.state[:-1]
    return states


def _profile_thresholds(result: DMREDAResult) -> tuple[np.ndarray, np.ndarray]:
    profiles = build_effective_profiles()
    processing_state = _processing_state(result)
    d_threshold = np.asarray([profiles[int(state)].th_d for state in processing_state])
    g_threshold = np.asarray([profiles[int(state)].th_g for state in processing_state])
    return d_threshold, g_threshold


def _longest_true_run(mask: np.ndarray) -> int:
    longest = current = 0
    for value in mask.tolist():
        current = current + 1 if value else 0
        longest = max(longest, current)
    return longest


def _metrics(result: DMREDAResult) -> dict[str, object]:
    d_positive = np.maximum(result.d, 0.0)
    g_positive = np.maximum(result.g, 0.0)
    d_threshold, g_threshold = _profile_thresholds(result)
    evidence = (result.d > d_threshold) | (result.g > g_threshold)
    occupancy = {
        str(state): int(np.count_nonzero(result.state == state))
        for state in sorted(set(int(value) for value in result.state.tolist()))
    }
    return {
        "integrated_d_mass": float(np.sum(d_positive)),
        "integrated_g_mass": float(np.sum(np.abs(result.g))),
        "integrated_positive_g_mass": float(np.sum(g_positive)),
        "signed_d_integral": float(np.sum(result.d)),
        "signed_g_integral": float(np.sum(result.g)),
        "peak_d": float(np.max(result.d)),
        "peak_g": float(np.max(result.g)),
        "peak_absolute_g": float(np.max(np.abs(result.g))),
        "evidence_onset": _first_true(evidence),
        "evidence_duration_samples": int(np.count_nonzero(evidence)),
        "longest_contiguous_evidence_run": _longest_true_run(evidence),
        "d_candidate_sample_count": int(np.count_nonzero(result.d > d_threshold)),
        "g_candidate_sample_count": int(np.count_nonzero(result.g > g_threshold)),
        "d_or_g_candidate_sample_count": int(np.count_nonzero(evidence)),
        "pending_open_time": _first_true(result.pending),
        "confirmation_time": _first_true(result.confirmed),
        "authority_time": int(result.event_times[0]) if result.event_times else None,
        "authority_indices": [int(value) for value in result.event_times],
        "state_occupancy_samples": occupancy,
        "regime_transition_count": int(np.count_nonzero(np.diff(result.state))),
    }


FINGERPRINT_FIELDS = (
    "integrated_d_mass",
    "integrated_g_mass",
    "peak_d",
    "peak_g",
    "evidence_duration_samples",
    "regime_transition_count",
)


def _fingerprint(metrics: Mapping[str, object]) -> list[float]:
    return [float(metrics[field]) for field in FINGERPRINT_FIELDS]


def _distance_matrix(results: Mapping[str, DMREDAResult]) -> dict[str, dict[str, float]]:
    """Return normalized trace distance over the contracted D/G ranges."""

    return {
        left: {
            right: float(
                np.sqrt(
                    np.mean(
                        ((results[left].d - results[right].d) / 10.0) ** 2
                        + ((results[left].g - results[right].g) / 20.0) ** 2
                    )
                )
            )
            for right in sorted(results)
        }
        for left in sorted(results)
    }


def _trace_sha256(result: DMREDAResult, fields: Sequence[str]) -> str:
    digest = hashlib.sha256()
    for field in fields:
        values = np.asarray(getattr(result, field))
        digest.update(field.encode("ascii"))
        digest.update(str(values.dtype).encode("ascii"))
        digest.update(np.asarray(values.shape, dtype="<i8").tobytes())
        digest.update(values.tobytes(order="C"))
    return digest.hexdigest()


def _validate_contracted_state(result: DMREDAResult) -> bool:
    profiles = build_effective_profiles()
    if not np.all((result.d >= -5.0) & (result.d <= 5.0)):
        return False
    if not np.all((result.g_raw >= -10.0) & (result.g_raw <= 10.0)):
        return False
    if not np.all((result.g >= -10.0) & (result.g <= 10.0)):
        return False
    if not np.all((result.a >= 0.0) & (result.a <= 1.0)):
        return False
    if not np.all((result.a_slow >= 0.0) & (result.a_slow <= 1.0)):
        return False
    if not np.all(result.e >= 0.0) or not np.all(result.e1 >= -5e-12):
        return False
    if not np.all(result.e_baseline >= -5e-12) or not np.all(result.r >= 0.0):
        return False
    for index, state_value in enumerate(result.state):
        state = int(state_value)
        if state not in profiles:
            return False
        profile = profiles[state]
        if int(result.m_eff[index]) not in profile.m_set:
            return False
        if not profile.confirm_min <= int(result.confirm_len_eff[index]) <= profile.confirm_max:
            return False
    return True


def _all_float_traces_finite(result: DMREDAResult) -> bool:
    return all(
        np.all(np.isfinite(getattr(result, field)))
        for field in (
            "mu",
            "e",
            "e1",
            "e_baseline",
            "e_baseline_safe",
            "d",
            "g_raw",
            "g",
            "r",
            "a",
            "a_slow",
        )
    )


def run_representation_validation(
    fixtures: Iterable[SyntheticFixture] | None = None,
) -> dict[str, object]:
    """Run Layer A and return a strict-JSON-compatible result payload."""

    selected = tuple(build_representation_fixtures() if fixtures is None else fixtures)
    if not selected:
        raise ValueError("at least one representation fixture is required")
    names = [fixture.name for fixture in selected]
    if len(names) != len(set(names)):
        raise ValueError("representation fixture names must be unique")

    rows: list[dict[str, object]] = []
    determinism_checks: list[bool] = []
    warmup_checks: list[bool] = []
    bounds_checks: list[bool] = []
    finite_checks: list[bool] = []
    mode_checks: list[bool] = []
    results: dict[str, DMREDAResult] = {}

    for fixture in selected:
        primary = compute_dmreda_reference(fixture.samples, **build_tep_core_kwargs())
        repeated = compute_dmreda_reference(fixture.samples, **build_tep_core_kwargs())
        no_warmup_kwargs = build_tep_core_kwargs()
        no_warmup_kwargs["warmup_samples"] = 0
        no_warmup = compute_dmreda_reference(fixture.samples, **no_warmup_kwargs)

        mode_events: dict[str, list[int]] = {}
        mode_representations: list[DMREDAResult] = []
        for mode in ("D_ONLY", "G_ONLY", "D_OR_G"):
            mode_kwargs = build_tep_core_kwargs()
            mode_kwargs["mode"] = mode
            mode_result = compute_dmreda_reference(fixture.samples, **mode_kwargs)
            mode_events[mode] = [int(value) for value in mode_result.event_times]
            mode_representations.append(mode_result)

        metrics = _metrics(primary)
        deterministic = _all_trace_equal(primary, repeated)
        warmup_invariant = _representation_equal(primary, no_warmup)
        contracted = _validate_contracted_state(primary)
        finite = _all_float_traces_finite(primary)
        mode_invariant = all(
            _representation_equal(mode_representations[0], result)
            for result in mode_representations[1:]
        )
        determinism_checks.append(deterministic)
        warmup_checks.append(warmup_invariant)
        bounds_checks.append(contracted)
        finite_checks.append(finite)
        mode_checks.append(mode_invariant)
        results[fixture.name] = primary
        rows.append(
            {
                "fixture_name": fixture.name,
                "family": fixture.family,
                "generator": dict(fixture.generator),
                "sample_count": int(fixture.samples.size),
                "sample_sha256": _signal_sha256(fixture.samples),
                "squared_energy": float(np.dot(fixture.samples, fixture.samples)),
                "peak_absolute_input": float(np.max(np.abs(fixture.samples))),
                "metrics": metrics,
                "fingerprint_fields": list(FINGERPRINT_FIELDS),
                "fingerprint": _fingerprint(metrics),
                "representation_trace_sha256": _trace_sha256(
                    primary, REPRESENTATION_TRACE_FIELDS
                ),
                "authority_trace_sha256": _trace_sha256(
                    primary, ("pending", "confirmed", "event_active")
                ),
                "mode_authority_indices": mode_events,
                "checks": {
                    "deterministic_complete_trace": deterministic,
                    "warmup_representation_invariance": warmup_invariant,
                    "contracted_bounds": contracted,
                    "finite_representation": finite,
                    "mode_independent_representation": mode_invariant,
                },
            }
        )

    prefix_rows = [fixture for fixture in selected if fixture.family == "prefix_pair"]
    prefix_causality = False
    prefix_checks: dict[str, bool] = {}
    if len(prefix_rows) == 2:
        prefix_length = int(prefix_rows[0].generator["prefix_length"])
        for check_length in PREFIX_CHECK_LENGTHS:
            if check_length > prefix_length:
                raise AssertionError("prefix check exceeds the frozen common prefix")
            prefix_checks[str(check_length)] = all(
                np.array_equal(
                    getattr(results[prefix_rows[0].name], field)[:check_length],
                    getattr(results[prefix_rows[1].name], field)[:check_length],
                )
                for field in REPRESENTATION_TRACE_FIELDS
            )
        prefix_causality = all(prefix_checks.values())

    constant = results.get("constant_zero")
    constant_zero_behavior = bool(
        constant is not None
        and np.array_equal(constant.d, -np.ones_like(constant.d))
        and np.array_equal(constant.g, np.zeros_like(constant.g))
        and np.array_equal(constant.state, np.zeros_like(constant.state))
        and constant.event_times == []
    )

    distance_matrix = _distance_matrix(results)
    same_energy_names = sorted(
        str(row["fixture_name"]) for row in rows if row["family"] == "same_energy"
    )
    equal_peak_names = sorted(
        str(row["fixture_name"]) for row in rows if row["family"] == "equal_peak"
    )
    hard_checks = {
        "deterministic_complete_trace": all(determinism_checks),
        "prefix_causality": prefix_causality,
        "warmup_representation_invariance": all(warmup_checks),
        "contracted_bounds": all(bounds_checks),
        "finite_representation": all(finite_checks),
        "mode_independent_representation": all(mode_checks),
        "constant_zero_reference_behavior": constant_zero_behavior,
    }
    fixture_contract = representation_fixture_contract(selected)
    fixture_contract_sha256 = canonical_sha256(fixture_contract)
    expectations_sha256 = canonical_sha256(REPRESENTATION_EXPECTATIONS_V1)
    frozen_contract_hashes_match = (
        fixture_contract_sha256 == FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256
        and expectations_sha256 == FROZEN_REPRESENTATION_EXPECTATIONS_SHA256
    )
    hard_checks["frozen_contract_hashes_match"] = frozen_contract_hashes_match
    payload: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.tep.stage3_3.representation_validation",
        "contract_version": REPRESENTATION_CONTRACT_VERSION,
        "expectations": dict(REPRESENTATION_EXPECTATIONS_V1),
        "expectations_sha256": expectations_sha256,
        "fixture_contract": fixture_contract,
        "fixture_contract_sha256": fixture_contract_sha256,
        "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "fixture_count": len(rows),
        "fixture_rows": rows,
        "hard_contract_checks": hard_checks,
        "prefix_causality_checks": prefix_checks,
        "pairwise_fingerprint_distance": distance_matrix,
        "pairwise_fingerprint_distance_definition": (
            "sqrt(mean(((D_i-D_j)/10)^2 + ((G_i-G_j)/20)^2))"
        ),
        "same_energy_separation_matrix": {
            left: {right: distance_matrix[left][right] for right in same_energy_names}
            for left in same_energy_names
        },
        "equal_peak_separation_matrix": {
            left: {right: distance_matrix[left][right] for right in equal_peak_names}
            for left in equal_peak_names
        },
        "fingerprint_interpretation": (
            "characterization_only; zero or repeated distances do not fail Layer A"
        ),
        "status": "passed" if all(hard_checks.values()) else "failed",
    }
    payload["result_sha256"] = canonical_sha256(payload)
    return payload


def render_representation_report(payload: Mapping[str, object]) -> str:
    """Render a concise human-readable Layer A report."""

    checks = payload["hard_contract_checks"]
    lines = [
        "# DMREDA Stage 3.3 Layer A Representation Validation",
        "",
        f"Status: `{payload['status']}`",
        "",
        "This synthetic suite validates causal representation mechanics; it is not TEP outcome evidence.",
        "",
        "## Hard contracts",
        "",
    ]
    for name, value in sorted(checks.items()):
        lines.append(f"- `{name}`: `{'passed' if value else 'failed'}`")
    lines.extend(
        [
            "",
            "## Characterization scope",
            "",
            f"- Deterministic fixtures: {payload['fixture_count']}",
            "- Integrated D/G evidence, peaks, timing, authority, state occupancy, and regime transitions are recorded per fixture.",
            "- Pairwise, same-energy, and equal-peak fingerprint distances are descriptive only.",
            "- No requirement that every signal have a unique fingerprint was applied.",
            "",
            f"Result SHA-256: `{payload['result_sha256']}`",
            "",
        ]
    )
    return "\n".join(lines)
