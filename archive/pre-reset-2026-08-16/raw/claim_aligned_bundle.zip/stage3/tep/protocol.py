"""Canonical corrected Stage 3.2 protocol construction and immutable freeze."""

from __future__ import annotations

import hashlib
import math
import os
from pathlib import Path
from typing import Mapping, Sequence

from stage3.admission.contracts import SHA256_PATTERN
from stage3.admission.serialization import (
    canonical_json_bytes,
    canonical_sha256,
    load_strict_json,
    validate_no_machine_paths,
)

from .configuration import (
    FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
    FROZEN_TEP_CONFIGURATION_SHA256,
    tep_affine_configuration_snapshot,
    tep_configuration_snapshot,
)
from .onset_authority import validate_dual_boundary_contract
from .representation_validation import (
    FROZEN_REPRESENTATION_EXPECTATIONS_SHA256,
    FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256,
)
from .arbitration_validation import FROZEN_ARBITRATION_EXPECTATIONS_SHA256


SCIENTIFIC_IDENTITY = (
    "causal_deterministic_bounded_state_temporal_evidence_representation_and_arbitration_core"
)
SCIENTIFIC_LAYERS = {
    "layer_a": "representation_validation",
    "layer_b": "arbitration_and_external_event_authority_validation",
    "layer_c": "tep_xmeas_7_assurance_channel_application",
}
SCALAR_REFERENCES = {
    "rms": "classical_scalar_evidence_reference",
    "cusum": "classical_scalar_evidence_reference",
    "ewma": "classical_scalar_evidence_reference",
}

DUAL_BOUNDARY_CANDIDATE_FILE_SHA256 = (
    "17b3c9bd055e85efc252d447c3fefe180c35ba32bba79d0005763871e7107b02"
)
EXPECTED_RAW_DATASET_SHA256 = {
    "TEP_FaultFree_Training.RData": (
        "12d1055b852763fac09ef36bd7c9612a800c8bf7b6f75f344d12119206f9e940"
    ),
    "TEP_FaultFree_Testing.RData": (
        "4f45afafa469793eeb7203fb9ed10ed0b1724c73c9c95537f15a0889ade0ebd4"
    ),
    "TEP_Faulty_Training.RData": (
        "058df8bd90c5f575f44d2f6085bdd3bc3662e3e9cc25a50e34af42be3748952b"
    ),
    "TEP_Faulty_Testing.RData": (
        "c2f1aabc77498efda4d5f9ad81ecc829e2fcd98752b84cf5b2a06558cabacc36"
    ),
}

V2_PARTITIONS = {
    "scaling_fit": "fault_free_training:simulationRun=1..100",
    "kappa_selection_spent": "fault_free_training:simulationRun=101..200",
    "scalar_threshold_calibration": "fault_free_training:simulationRun=101..200",
    "independent_normal_generalization": "fault_free_testing:simulationRun=1..500",
    "bank_d": "faulty_testing:faultNumber=1..20,simulationRun=1..500",
}

V2_STOP_RULES = (
    "repository_integrity_failure",
    "source_or_configuration_hash_mismatch",
    "layer_a_contract_failure",
    "layer_b_contract_failure",
    "protocol_v2_freeze_failure",
    "raw_hash_or_schema_mismatch",
    "output_containment_failure",
    "test_failure",
    "post_outcome_boundary_selection_detected",
    "dmreda_normal_false_authority_count_above_25",
    "bank_d_admission_denied",
    "serial_parallel_parity_failure",
    "checkpoint_integrity_failure",
    "deterministic_reproduction_failure",
)

V2_REFERENCE_POLICY = {
    "primary_bank_d_admission_depends_on_scalar_reference_admission": False,
    "admission_status_values": ["admitted_reference", "not_admitted_reference"],
    "failed_reference_excluded_from_confirmatory_bank_d_pairwise_analysis": True,
    "zero_admitted_references_blocks_primary_dmreda_application": False,
    "zero_admitted_references_authorizes_added_value_claim": False,
}

V2_EVIDENCE_CLASSIFICATION_POLICY = {
    "ordering": [
        "representation_contract_failure",
        "arbitration_contract_failure",
        "unstable_normal_authority",
        "conservative_but_low_coverage_assurance_channel",
        "insufficient_evidence_for_added_value",
        "fault_specific_evidence_coverage",
        "useful_assurance_channel",
        "structural_evidence_advantage",
        "strong_broad_evidence_core_result",
    ],
    "automatic_rules": {
        "zero_valid_authority_under_either_coequal_boundary": (
            "conservative_but_low_coverage_assurance_channel"
        ),
        "no_admitted_reference_or_no_boundary_coequal_holm_supported_added_value": (
            "insufficient_evidence_for_added_value"
        ),
        "boundary_coequal_holm_supported_fault_specific_added_value": (
            "fault_specific_evidence_coverage"
        ),
    },
    "unregistered_coverage_cutoff_prohibited": True,
    "single_raw_p_value_cannot_authorize_added_value": True,
    "added_value_multiplicity_family": (
        "intersection_union_max_p_across_coequal_onsets_then_holm_across_all_"
        "admitted_reference_by_fault_hypotheses"
    ),
    "early_false_authority_harm_rule": (
        "no_observed_dmreda_only_excess_under_either_coequal_boundary"
    ),
    "automatic_selection_of_higher_claim_categories": False,
}


def _require_hashes(values: Mapping[str, str], name: str) -> None:
    if not values or any(not SHA256_PATTERN.fullmatch(value) for value in values.values()):
        raise ValueError(f"{name} must be a non-empty SHA-256 mapping")


def build_protocol_payload(
    *,
    freeze_timestamp_utc: str,
    source_commit: str,
    source_hashes: Mapping[str, str],
    raw_dataset_hashes: Mapping[str, str],
    dataset_authority: Mapping[str, object],
    baseline_configurations: Mapping[str, object],
    onset_mapping: Mapping[str, object],
    implementation_version: str,
) -> dict[str, object]:
    """Build the first valid protocol with the corrected evidence-core identity."""

    if not freeze_timestamp_utc.endswith("Z"):
        raise ValueError("freeze timestamp must be explicit UTC")
    if not (
        len(source_commit) == 40
        and all(character in "0123456789abcdef" for character in source_commit)
    ):
        raise ValueError("source_commit must be a Git SHA-1 identity")
    _require_hashes(source_hashes, "source_hashes")
    _require_hashes(raw_dataset_hashes, "raw_dataset_hashes")
    if onset_mapping.get("status") != "resolved":
        raise ValueError("onset mapping must be authoritative and resolved before freeze")
    if set(baseline_configurations) != set(SCALAR_REFERENCES):
        raise ValueError("RMS, CUSUM, and EWMA configurations are required")

    payload: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.tep.stage3_2.full_protocol",
        "protocol_version": "1.0.0",
        "implementation_version": implementation_version,
        "status": "frozen",
        "freeze_timestamp_utc": freeze_timestamp_utc,
        "source_commit": source_commit,
        "scientific_identity": {
            "primary": SCIENTIFIC_IDENTITY,
            "layers": dict(SCIENTIFIC_LAYERS),
            "primary_question": (
                "Does the frozen Core preserve its causal representation and event-authority "
                "contracts and provide useful TEP xmeas_7 assurance-channel coverage at "
                "controlled independent normal false-authority risk, including evidence not "
                "captured by simpler scalar score channels?"
            ),
            "prohibited_framing": [
                "universal_detector_superiority",
                "dmreda_defined_by_cusum_ewma_or_rms",
                "structural_manifold_as_core_fsm",
            ],
        },
        "source_hashes": dict(sorted(source_hashes.items())),
        "raw_dataset_hashes": dict(sorted(raw_dataset_hashes.items())),
        "dataset_authority": dict(dataset_authority),
        "channel_and_core_configuration": tep_configuration_snapshot(),
        "scalar_evidence_references": {
            name: {
                "scientific_role": SCALAR_REFERENCES[name],
                "configuration": baseline_configurations[name],
            }
            for name in sorted(SCALAR_REFERENCES)
        },
        "event_authority_contract": {
            "dmreda": "native_pending_confirmation_refractory_external_authority",
            "scalar_references": "shared_external_threshold_persistence_refractory_gate",
            "fairness": "matched_achieved_independent_normal_false_authority_risk",
            "first_event_owns_run": True,
            "early_false_authority_cannot_be_redeemed": True,
        },
        "partitions": {
            "scaling": "fault_free_training:simulationRun=1..100",
            "kappa_selection_spent": "fault_free_training:simulationRun=101..200",
            "baseline_threshold_calibration": "fault_free_training:simulationRun=101..200",
            "independent_normal_generalization": "fault_free_testing:simulationRun=1..500",
            "bank_d": "faulty_testing:all_publisher_fault_classes_and_runs",
        },
        "onset_mapping": dict(onset_mapping),
        "finite_horizon_metrics": {
            "alarm_indexing": "zero_based",
            "censored_run_restricted_time": "full_trace_length",
            "conditional_delay_population": "valid_post_onset_detections_only",
            "false_positive_delay": None,
            "miss_delay": None,
            "independent_unit": "trajectory_or_fault_episode",
        },
        "acceptance_gates": {
            "dmreda_normal_max_fp_count": 25,
            "dmreda_normal_run_count": 500,
            "scalar_reference_max_fp_count_difference": 10,
            "scalar_reference_max_restricted_time_sum_difference": 24000,
            "baseline_calibration_target_fp_count": 3,
            "baseline_calibration_target_restricted_time_sum": 49283,
        },
        "inference": {
            "bootstrap_base_seed": 20260805,
            "bootstrap_replicates": 10000,
            "paired_outcome_table": "complete_3_by_3",
            "holm_families": [
                "early_false_authority_discordance",
                "non_fp_detection_discordance",
                "paired_valid_detection_delay",
            ],
        },
        "output_roles": [
            "authority",
            "protocol",
            "environment",
            "extracts",
            "calibration",
            "normal_gate",
            "bank_d",
            "reproducibility",
            "reports",
            "logs",
            "manifests",
        ],
        "stop_rules": [
            "raw_hash_mismatch",
            "test_failure",
            "output_containment_failure",
            "unresolved_onset_authority",
            "dmreda_normal_fp_count_above_25",
            "any_scalar_reference_risk_match_failure",
            "bank_d_admission_denied",
            "serial_parallel_parity_failure",
            "deterministic_reproduction_failure",
        ],
        "no_retuning_declaration": {
            "declared": True,
            "dmreda_numerical_configuration_frozen": True,
            "scalar_reference_structural_parameters_frozen": True,
            "fault_free_testing_not_used_for_tuning": True,
            "faulty_testing_not_used_for_tuning": True,
        },
    }
    validate_protocol_payload(payload)
    return payload


def validate_protocol_payload(payload: Mapping[str, object]) -> None:
    validate_no_machine_paths(payload)
    if payload.get("schema_version") != "1.0.0" or payload.get("status") != "frozen":
        raise ValueError("unsupported or unfrozen protocol")
    identity = payload.get("scientific_identity")
    if not isinstance(identity, Mapping) or identity.get("primary") != SCIENTIFIC_IDENTITY:
        raise ValueError("protocol does not bind the corrected scientific identity")
    layers = identity.get("layers")
    if layers != SCIENTIFIC_LAYERS:
        raise ValueError("protocol must bind the three corrected scientific layers")
    event = payload.get("event_authority_contract")
    if not isinstance(event, Mapping) or event.get("dmreda") != (
        "native_pending_confirmation_refractory_external_authority"
    ):
        raise ValueError("protocol does not preserve native DMREDA event authority")
    declaration = payload.get("no_retuning_declaration")
    if not isinstance(declaration, Mapping) or declaration.get("declared") is not True:
        raise ValueError("protocol requires an explicit no-retuning declaration")
    canonical_json_bytes(payload)


def _protocol_markdown(payload: Mapping[str, object]) -> str:
    onset = payload["onset_mapping"]
    assert isinstance(onset, Mapping)
    return "\n".join(
        (
            "# DMREDA TEP xmeas_7 Stage 3.2 Frozen Protocol",
            "",
            f"Status: **{payload['status']}**",
            "",
            "## Scientific identity",
            "",
            "DMREDA is evaluated as a causal, deterministic, bounded-state temporal evidence representation and arbitration core.",
            "",
            "- Layer A: representation validation",
            "- Layer B: arbitration and external event-authority validation",
            "- Layer C: TEP xmeas_7 assurance-channel application",
            "",
            "RMS, CUSUM, and EWMA are classical scalar evidence references under matched achieved normal false-authority risk. They do not define DMREDA and do not use its native event mechanism.",
            "",
            "## Frozen bindings",
            "",
            f"- Source commit: `{payload['source_commit']}`",
            f"- Freeze time: `{payload['freeze_timestamp_utc']}`",
            f"- Python onset index: `{onset['python_onset_index']}`",
            "- Primary mode: `D_or_G`",
            "- Warm-up: `92` samples",
            "- Sensitivity multiplier: `2.5` on `th_d`, `th_g`, `th_d2`, and `th_a` only",
            "",
            "## Authority rule",
            "",
            "The first authority-bearing event owns the complete trajectory. Early false authority cannot be redeemed; false positives and misses have no valid detection delay.",
            "",
            "## Stop rule",
            "",
            "Faulty Testing remains sealed unless every frozen test, integrity, onset, normal-generalization, matched-risk, and output-containment gate passes.",
            "",
        )
    )


def _exclusive_write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def freeze_protocol(
    *,
    json_path: Path,
    markdown_path: Path,
    manifest_path: Path,
    payload: Mapping[str, object],
) -> dict[str, object]:
    """Write immutable protocol files; the manifest is the completion marker."""

    validate_protocol_payload(payload)
    paths = (Path(json_path), Path(markdown_path), Path(manifest_path))
    if len(set(paths)) != 3 or any(path.exists() for path in paths):
        raise FileExistsError("protocol paths must be distinct and unused")
    json_bytes = canonical_json_bytes(payload) + b"\n"
    markdown_bytes = _protocol_markdown(payload).encode("utf-8")
    _exclusive_write(paths[0], json_bytes)
    _exclusive_write(paths[1], markdown_bytes)
    manifest_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.tep.stage3_2.protocol_freeze_manifest",
        "status": "complete_and_verified",
        "protocol_json_sha256": hashlib.sha256(json_bytes).hexdigest(),
        "protocol_markdown_sha256": hashlib.sha256(markdown_bytes).hexdigest(),
        "canonical_protocol_payload_sha256": canonical_sha256(payload),
        "source_commit": payload["source_commit"],
    }
    manifest = dict(manifest_without_hash)
    manifest["freeze_manifest_sha256"] = canonical_sha256(manifest_without_hash)
    _exclusive_write(paths[2], canonical_json_bytes(manifest) + b"\n")
    return manifest


def validate_frozen_protocol(
    *, json_path: Path, markdown_path: Path, manifest_path: Path
) -> Mapping[str, object]:
    manifest = load_strict_json(Path(manifest_path))
    if not isinstance(manifest, Mapping) or manifest.get("status") != "complete_and_verified":
        raise ValueError("protocol freeze manifest is incomplete")
    without_hash = dict(manifest)
    stored = without_hash.pop("freeze_manifest_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("protocol freeze manifest hash mismatch")
    json_bytes = Path(json_path).read_bytes()
    markdown_bytes = Path(markdown_path).read_bytes()
    if hashlib.sha256(json_bytes).hexdigest() != manifest["protocol_json_sha256"]:
        raise ValueError("protocol JSON file hash mismatch")
    if hashlib.sha256(markdown_bytes).hexdigest() != manifest["protocol_markdown_sha256"]:
        raise ValueError("protocol Markdown file hash mismatch")
    payload = load_strict_json(Path(json_path))
    if not isinstance(payload, Mapping):
        raise ValueError("protocol JSON must contain an object")
    validate_protocol_payload(payload)
    if canonical_sha256(payload) != manifest["canonical_protocol_payload_sha256"]:
        raise ValueError("canonical protocol payload hash mismatch")
    return payload


def _validate_layer_a_binding(binding: Mapping[str, object]) -> None:
    required = {
        "status",
        "expectations_sha256",
        "fixture_contract_sha256",
        "result_payload_sha256",
        "result_file_sha256",
    }
    if set(binding) != required or binding.get("status") != "passed":
        raise ValueError("Layer A binding is incomplete or failed")
    if binding.get("expectations_sha256") != (
        FROZEN_REPRESENTATION_EXPECTATIONS_SHA256
    ):
        raise ValueError("Layer A expectation contract changed")
    if binding.get("fixture_contract_sha256") != (
        FROZEN_REPRESENTATION_FIXTURE_CONTRACT_SHA256
    ):
        raise ValueError("Layer A fixture contract changed")
    _require_hashes(
        {
            name: str(binding[name])
            for name in ("result_payload_sha256", "result_file_sha256")
        },
        "Layer A result hashes",
    )


def _validate_layer_b_binding(binding: Mapping[str, object]) -> None:
    required = {
        "status",
        "expectations_sha256",
        "result_payload_sha256",
        "result_file_sha256",
        "same_sample_timeout_rearm",
        "policy_changed",
    }
    if set(binding) != required or binding.get("status") != "passed":
        raise ValueError("Layer B binding is incomplete or failed")
    if binding.get("expectations_sha256") != FROZEN_ARBITRATION_EXPECTATIONS_SHA256:
        raise ValueError("Layer B expectation contract changed")
    if binding.get("same_sample_timeout_rearm") != (
        "unresolved_design_choice_preserved"
    ) or binding.get("policy_changed") is not False:
        raise ValueError("Layer B silently changes an unresolved Core semantic")
    _require_hashes(
        {
            name: str(binding[name])
            for name in ("result_payload_sha256", "result_file_sha256")
        },
        "Layer B result hashes",
    )


def _validate_scalar_reference_configurations_v2(
    records: Mapping[str, object],
) -> None:
    if set(records) != set(SCALAR_REFERENCES):
        raise ValueError("V2 requires the exact RMS, CUSUM, and EWMA reference set")
    structural = {
        "rms": {"window": 32},
        "cusum": {
            "allowance": 0.5,
            "allowance_sigma": 0.5,
            "center": 0.0,
            "scale": 1.0,
        },
        "ewma": {"alpha": 2.0 / 33.0, "center": 0.0, "scale": 1.0},
    }
    gate = {"warmup_samples": 92, "persistence": 20, "refractory": 80}
    objective = [
        "absolute_false_positive_count_deviation",
        "absolute_restricted_time_sum_deviation",
        "higher_threshold",
    ]
    for name in sorted(SCALAR_REFERENCES):
        record = records[name]
        if not isinstance(record, Mapping) or set(record) != {
            "status",
            "configuration",
            "configuration_sha256",
            "structural_parameters",
            "calibration",
        }:
            raise ValueError(f"{name} frozen configuration record is malformed")
        if record.get("status") != "frozen_from_fault_free_training_101_200":
            raise ValueError(f"{name} configuration is not frozen from the permitted bank")
        configuration = record.get("configuration")
        if not isinstance(configuration, Mapping):
            raise ValueError(f"{name} detector configuration is malformed")
        if configuration.get("name") != name or configuration.get("kind") != name:
            raise ValueError(f"{name} detector identity is invalid")
        threshold = configuration.get("threshold")
        if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not (
            math.isfinite(float(threshold))
        ):
            raise ValueError(f"{name} threshold must be finite")
        if configuration.get("gate") != gate:
            raise ValueError(f"{name} gate differs from the frozen reference gate")
        if record.get("structural_parameters") != structural[name]:
            raise ValueError(f"{name} structural parameters changed")
        configuration_hash = record.get("configuration_sha256")
        if not isinstance(configuration_hash, str) or not SHA256_PATTERN.fullmatch(
            configuration_hash
        ) or configuration_hash != canonical_sha256(configuration):
            raise ValueError(f"{name} configuration hash is invalid")
        calibration = record.get("calibration")
        if not isinstance(calibration, Mapping) or set(calibration) != {
            "partition",
            "simulation_runs",
            "trajectory_count",
            "horizon",
            "target_false_authority_count",
            "target_restricted_time_sum",
            "selection_objective",
            "input_bank_sha256",
            "calibration_result_sha256",
        }:
            raise ValueError(f"{name} calibration binding is malformed")
        if (
            calibration.get("partition") != "fault_free_training"
            or calibration.get("simulation_runs") != [101, 200]
            or calibration.get("trajectory_count") != 100
            or calibration.get("horizon") != 500
            or calibration.get("target_false_authority_count") != 3
            or calibration.get("target_restricted_time_sum") != 49283
            or calibration.get("selection_objective") != objective
        ):
            raise ValueError(f"{name} calibration contract changed")
        _require_hashes(
            {
                "input_bank_sha256": str(calibration.get("input_bank_sha256")),
                "calibration_result_sha256": str(
                    calibration.get("calibration_result_sha256")
                ),
            },
            f"{name} calibration hashes",
        )


def build_protocol_payload_v2(
    *,
    freeze_timestamp_utc: str,
    source_commit: str,
    source_hashes: Mapping[str, str],
    raw_dataset_hashes: Mapping[str, str],
    dataset_authority: Mapping[str, object],
    scalar_reference_configurations: Mapping[str, object],
    dual_boundary_contract: Mapping[str, object],
    dual_boundary_candidate_file_sha256: str,
    layer_a_binding: Mapping[str, object],
    layer_b_binding: Mapping[str, object],
    pre_freeze_validation: Mapping[str, object],
    access_evidence_sha256: str,
    implementation_version: str,
) -> dict[str, object]:
    """Build the corrected, co-equal-boundary Stage 3.3 protocol."""

    if not freeze_timestamp_utc.endswith("Z"):
        raise ValueError("freeze timestamp must be explicit UTC")
    if not (
        len(source_commit) == 40
        and all(character in "0123456789abcdef" for character in source_commit)
    ):
        raise ValueError("source_commit must be a Git SHA-1 identity")
    _require_hashes(source_hashes, "source_hashes")
    _require_hashes(raw_dataset_hashes, "raw_dataset_hashes")
    if not SHA256_PATTERN.fullmatch(access_evidence_sha256):
        raise ValueError("access evidence hash is invalid")
    validate_dual_boundary_contract(dual_boundary_contract)
    _validate_layer_a_binding(layer_a_binding)
    _validate_layer_b_binding(layer_b_binding)
    _validate_scalar_reference_configurations_v2(scalar_reference_configurations)

    payload: dict[str, object] = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.tep.stage3_3.full_protocol_v2",
        "protocol_version": "2.0.0",
        "implementation_version": implementation_version,
        "status": "frozen",
        "freeze_timestamp_utc": freeze_timestamp_utc,
        "source_commit": source_commit,
        "scientific_identity": {
            "primary": SCIENTIFIC_IDENTITY,
            "layers": dict(SCIENTIFIC_LAYERS),
            "primary_question": (
                "Does the frozen temporal evidence representation and arbitration Core "
                "preserve its contracts and provide useful xmeas_7 assurance-channel "
                "authority coverage at controlled independent normal false-authority risk, "
                "including evidence not captured by independently admitted scalar references?"
            ),
            "prohibited_framing": [
                "universal_detector_superiority",
                "dmreda_defined_by_cusum_ewma_or_rms",
                "post_outcome_boundary_selection",
                "structural_manifold_as_core_fsm",
            ],
        },
        "source_hashes": dict(sorted(source_hashes.items())),
        "raw_dataset_hashes": dict(sorted(raw_dataset_hashes.items())),
        "dataset_authority": dict(dataset_authority),
        "channel_and_core_configuration": tep_configuration_snapshot(),
        "preprocessing_contract": {
            "configuration": tep_affine_configuration_snapshot(),
            "configuration_sha256": FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
            "application_count_per_trajectory": 1,
            "shared_by_all_evidence_channels": True,
            "full_trace_normalization_prohibited": True,
            "label_dependent_preprocessing_prohibited": True,
        },
        "primary_evidence_channel": {
            "name": "dmreda_core_d_or_g",
            "mode": "D_OR_G",
            "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
            "native_event_authority": True,
        },
        "secondary_ablations": ["D_ONLY", "G_ONLY"],
        "scalar_evidence_references": {
            name: {
                "scientific_role": SCALAR_REFERENCES[name],
                **dict(scalar_reference_configurations[name]),
            }
            for name in sorted(SCALAR_REFERENCES)
        },
        "scalar_reference_admission_policy": dict(V2_REFERENCE_POLICY),
        "event_authority_contract": {
            "dmreda": "native_pending_confirmation_refractory_external_authority",
            "scalar_references": "shared_external_threshold_persistence_refractory_gate",
            "fairness": "matched_achieved_independent_normal_false_authority_risk",
            "first_event_owns_complete_trajectory": True,
            "early_false_authority_cannot_be_redeemed": True,
            "false_authority_latency": None,
            "no_authority_latency": None,
        },
        "dual_boundary_contract": {
            "candidate_file_sha256": dual_boundary_candidate_file_sha256,
            "candidate_payload_sha256": canonical_sha256(dual_boundary_contract),
            "candidate_payload": dict(dual_boundary_contract),
            "coequal_python_onset_indices": [159, 160],
            "selected_mapping": None,
            "unique_primary_boundary": False,
            "event_generation_accepts_onset": False,
            "post_outcome_selection_prohibited": True,
            "changed_trajectory_disclosure_required": True,
            "boundary_categories": [
                "classification_flip_at_boundary",
                "latency_shift_only",
                "false_authority_under_both",
                "no_authority_under_both",
                "invalid",
            ],
            "conclusion_categories": [
                "exact_boundary_invariant",
                "conclusion_boundary_robust",
                "boundary_material",
            ],
        },
        "layer_contracts": {
            "layer_a": dict(layer_a_binding),
            "layer_b": dict(layer_b_binding),
            "layer_c": "tep_xmeas_7_assurance_channel_application",
        },
        "partitions": dict(V2_PARTITIONS),
        "finite_horizon_metrics": {
            "alarm_indexing": "zero_based",
            "horizon": 960,
            "censored_run_restricted_time": "full_trace_length",
            "conditional_latency_population": "valid_authority_only",
            "independent_unit": "trajectory_or_fault_episode",
            "report_micro_and_equal_fault_macro": True,
        },
        "acceptance_gates": {
            "dmreda_normal_max_false_authority_count": 25,
            "dmreda_normal_trajectory_count": 500,
            "dmreda_normal_max_false_authority_rate": 0.05,
            "scalar_reference_max_false_authority_count_difference": 10,
            "scalar_reference_max_restricted_time_sum_difference": 24000,
            "scalar_reference_max_false_authority_rate_difference": 0.02,
            "scalar_reference_max_rmta_difference_samples": 48,
            "calibration_target_false_authority_count": 3,
            "calibration_target_restricted_time_sum": 49283,
        },
        "inference": {
            "bootstrap_seed": 20260805,
            "bootstrap_replicates": 10000,
            "independent_unit": "trajectory_or_fault_episode",
            "paired_outcome_table": "complete_authority_contingency",
            "multiple_testing_adjustment": "Holm",
            "final_added_value_family": (
                "max_exact_p_across_onsets_159_160_per_fault_reference_then_"
                "one_holm_family_across_all_admitted_fault_reference_pairs"
            ),
            "early_false_authority_harm_rule": (
                "no_observed_dmreda_only_excess_under_either_onset"
            ),
        },
        "evidence_classification_policy": dict(
            V2_EVIDENCE_CLASSIFICATION_POLICY
        ),
        "checkpoint_contract": {
            "one_checkpoint_per_fault_class": True,
            "deterministic_sorted_order": True,
            "result_written_before_completion_marker": True,
            "bind_source_protocol_input_configuration_count_and_result_hash": True,
            "partial_pair_fails_closed": True,
            "validated_orphan_result_may_reconstruct_checkpoint": True,
            "orphan_checkpoint_without_result_fails_closed": True,
        },
        "output_contract": {
            "raw_and_scalar_extracts_outside_git": True,
            "immutable_results_no_clobber": True,
            "atomic_replace_limited_to_checkpoints_and_ledgers": True,
            "strict_json_no_nan_or_infinity": True,
            "absolute_user_paths_prohibited": True,
        },
        "reproducibility_contract": {
            "serial_parallel_event_and_outcome_equality": True,
            "second_complete_run_required": True,
            "fixed_bootstrap_seed": 20260805,
            "timestamp_fields_excluded_from_deterministic_hashes_only": True,
        },
        "pre_freeze_validation": dict(pre_freeze_validation),
        "testing_access_state_at_freeze": {
            "access_evidence_sha256": access_evidence_sha256,
            "fault_free_testing_values_accessed": False,
            "faulty_testing_values_accessed": False,
            "bank_d_state": "sealed_unopened",
        },
        "stop_rules": list(V2_STOP_RULES),
        "no_retuning_declaration": {
            "declared": True,
            "dmreda_numerical_configuration_frozen": True,
            "scalar_reference_structural_parameters_frozen": True,
            "fault_free_testing_not_used_for_tuning": True,
            "faulty_testing_not_used_for_tuning": True,
            "onset_selection_after_outcomes_prohibited": True,
        },
    }
    validate_protocol_payload_v2(payload)
    return payload


def validate_protocol_payload_v2(payload: Mapping[str, object]) -> None:
    """Strictly validate the full corrected V2 protocol."""

    validate_no_machine_paths(payload)
    if (
        payload.get("schema_version") != "2.0.0"
        or payload.get("document_type") != "dmreda.tep.stage3_3.full_protocol_v2"
        or payload.get("protocol_version") != "2.0.0"
        or payload.get("status") != "frozen"
    ):
        raise ValueError("unsupported or unfrozen V2 protocol")
    source_commit = payload.get("source_commit")
    if not (
        isinstance(source_commit, str)
        and len(source_commit) == 40
        and all(character in "0123456789abcdef" for character in source_commit)
    ):
        raise ValueError("V2 source commit is invalid")
    identity = payload.get("scientific_identity")
    if not isinstance(identity, Mapping) or identity.get("primary") != SCIENTIFIC_IDENTITY:
        raise ValueError("V2 scientific identity is invalid")
    if identity.get("layers") != SCIENTIFIC_LAYERS:
        raise ValueError("V2 must bind all three corrected scientific layers")
    if payload.get("raw_dataset_hashes") != EXPECTED_RAW_DATASET_SHA256:
        raise ValueError("V2 raw dataset identities differ from Rieth V1")
    source_hashes = payload.get("source_hashes")
    if not isinstance(source_hashes, Mapping):
        raise ValueError("V2 source hashes are missing")
    _require_hashes(source_hashes, "source_hashes")  # type: ignore[arg-type]
    authority = payload.get("dataset_authority")
    if not isinstance(authority, Mapping) or authority.get("authority_status") != (
        "verified_primary_source"
    ) or authority.get("admission_level") != "claim_grade_candidate":
        raise ValueError("dataset authority does not support a claim-grade candidate")
    if payload.get("channel_and_core_configuration") != tep_configuration_snapshot():
        raise ValueError("V2 Core numerical configuration changed")
    preprocessing = payload.get("preprocessing_contract")
    if not isinstance(preprocessing, Mapping) or preprocessing != {
        "configuration": tep_affine_configuration_snapshot(),
        "configuration_sha256": FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
        "application_count_per_trajectory": 1,
        "shared_by_all_evidence_channels": True,
        "full_trace_normalization_prohibited": True,
        "label_dependent_preprocessing_prohibited": True,
    }:
        raise ValueError("V2 preprocessing contract changed")
    primary = payload.get("primary_evidence_channel")
    if not isinstance(primary, Mapping) or primary != {
        "name": "dmreda_core_d_or_g",
        "mode": "D_OR_G",
        "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "native_event_authority": True,
    }:
        raise ValueError("V2 primary evidence-channel configuration changed")
    if payload.get("secondary_ablations") != ["D_ONLY", "G_ONLY"]:
        raise ValueError("V2 ablation modes changed")
    references = payload.get("scalar_evidence_references")
    if not isinstance(references, Mapping) or set(references) != set(SCALAR_REFERENCES):
        raise ValueError("V2 scalar-reference set is invalid")
    stripped: dict[str, object] = {}
    for name in sorted(SCALAR_REFERENCES):
        record = references[name]
        if not isinstance(record, Mapping) or record.get("scientific_role") != (
            SCALAR_REFERENCES[name]
        ):
            raise ValueError(f"{name} scientific role is invalid")
        child = dict(record)
        child.pop("scientific_role")
        stripped[name] = child
    _validate_scalar_reference_configurations_v2(stripped)
    if payload.get("scalar_reference_admission_policy") != V2_REFERENCE_POLICY:
        raise ValueError("scalar-reference admission has become a primary veto")
    event = payload.get("event_authority_contract")
    if not isinstance(event, Mapping) or event != {
        "dmreda": "native_pending_confirmation_refractory_external_authority",
        "scalar_references": "shared_external_threshold_persistence_refractory_gate",
        "fairness": "matched_achieved_independent_normal_false_authority_risk",
        "first_event_owns_complete_trajectory": True,
        "early_false_authority_cannot_be_redeemed": True,
        "false_authority_latency": None,
        "no_authority_latency": None,
    }:
        raise ValueError("V2 event-authority contract changed")
    dual = payload.get("dual_boundary_contract")
    if not isinstance(dual, Mapping):
        raise ValueError("V2 dual-boundary contract is missing")
    if dual.get("candidate_file_sha256") != DUAL_BOUNDARY_CANDIDATE_FILE_SHA256:
        raise ValueError("dual-boundary candidate file hash changed")
    candidate_payload = dual.get("candidate_payload")
    if not isinstance(candidate_payload, Mapping):
        raise ValueError("dual-boundary candidate payload is missing")
    validate_dual_boundary_contract(candidate_payload)
    if dual.get("candidate_payload_sha256") != canonical_sha256(candidate_payload):
        raise ValueError("dual-boundary candidate payload hash is invalid")
    expected_dual = {
        "coequal_python_onset_indices": [159, 160],
        "selected_mapping": None,
        "unique_primary_boundary": False,
        "event_generation_accepts_onset": False,
        "post_outcome_selection_prohibited": True,
        "changed_trajectory_disclosure_required": True,
        "boundary_categories": [
            "classification_flip_at_boundary",
            "latency_shift_only",
            "false_authority_under_both",
            "no_authority_under_both",
            "invalid",
        ],
        "conclusion_categories": [
            "exact_boundary_invariant",
            "conclusion_boundary_robust",
            "boundary_material",
        ],
    }
    if any(dual.get(name) != value for name, value in expected_dual.items()):
        raise ValueError("V2 co-equal dual-boundary policy changed")
    layers = payload.get("layer_contracts")
    if not isinstance(layers, Mapping) or set(layers) != {"layer_a", "layer_b", "layer_c"}:
        raise ValueError("V2 layer bindings are incomplete")
    if not isinstance(layers["layer_a"], Mapping) or not isinstance(
        layers["layer_b"], Mapping
    ):
        raise ValueError("V2 Layer A/B bindings are malformed")
    _validate_layer_a_binding(layers["layer_a"])
    _validate_layer_b_binding(layers["layer_b"])
    if layers["layer_c"] != "tep_xmeas_7_assurance_channel_application":
        raise ValueError("V2 Layer C identity changed")
    if payload.get("partitions") != V2_PARTITIONS:
        raise ValueError("V2 partition ownership changed")
    gates = payload.get("acceptance_gates")
    if not isinstance(gates, Mapping) or gates != {
        "dmreda_normal_max_false_authority_count": 25,
        "dmreda_normal_trajectory_count": 500,
        "dmreda_normal_max_false_authority_rate": 0.05,
        "scalar_reference_max_false_authority_count_difference": 10,
        "scalar_reference_max_restricted_time_sum_difference": 24000,
        "scalar_reference_max_false_authority_rate_difference": 0.02,
        "scalar_reference_max_rmta_difference_samples": 48,
        "calibration_target_false_authority_count": 3,
        "calibration_target_restricted_time_sum": 49283,
    }:
        raise ValueError("V2 acceptance gates changed")
    if payload.get("stop_rules") != list(V2_STOP_RULES):
        raise ValueError("V2 stop rules changed")
    if payload.get("evidence_classification_policy") != (
        V2_EVIDENCE_CLASSIFICATION_POLICY
    ):
        raise ValueError("V2 evidence-classification policy changed")
    if "any_scalar_reference_risk_match_failure" in payload.get("stop_rules", []):
        raise ValueError("scalar-reference failure cannot be a primary stop rule")
    pre_freeze = payload.get("pre_freeze_validation")
    if not isinstance(pre_freeze, Mapping) or pre_freeze.get("status") != "passed" or (
        pre_freeze.get("worktree_clean") is not True
    ):
        raise ValueError("pre-freeze validation is incomplete")
    for name in ("full_test_report_sha256", "output_guard_report_sha256", "git_state_sha256"):
        value = pre_freeze.get(name)
        if not isinstance(value, str) or not SHA256_PATTERN.fullmatch(value):
            raise ValueError(f"pre-freeze {name} is invalid")
    access = payload.get("testing_access_state_at_freeze")
    if not isinstance(access, Mapping) or access.get("fault_free_testing_values_accessed") is not False or (
        access.get("faulty_testing_values_accessed") is not False
    ) or access.get("bank_d_state") != "sealed_unopened":
        raise ValueError("Testing values must remain unopened at V2 freeze")
    access_hash = access.get("access_evidence_sha256")
    if not isinstance(access_hash, str) or not SHA256_PATTERN.fullmatch(access_hash):
        raise ValueError("V2 access-evidence binding is invalid")
    declaration = payload.get("no_retuning_declaration")
    if not isinstance(declaration, Mapping) or any(value is not True for value in declaration.values()):
        raise ValueError("V2 no-retuning declaration is incomplete")
    canonical_json_bytes(payload)


def _protocol_markdown_v2(payload: Mapping[str, object]) -> str:
    references = payload["scalar_evidence_references"]
    return "\n".join(
        (
            "# DMREDA TEP xmeas_7 Stage 3.3 Frozen Protocol V2",
            "",
            f"Status: **{payload['status']}**",
            "",
            "## Scientific identity",
            "",
            "DMREDA is a causal, deterministic, bounded-state temporal evidence representation and arbitration core.",
            "",
            "- Layer A: representation validation",
            "- Layer B: arbitration and external event-authority validation",
            "- Layer C: TEP xmeas_7 assurance-channel application",
            "",
            "RMS, CUSUM, and EWMA are classical scalar evidence references. Their independent admission cannot veto the primary DMREDA application.",
            "",
            "## Co-equal onset contract",
            "",
            "- Candidate 1: final normal label 159, first affected label 160, Python onset index 159",
            "- Candidate 2: final normal label 160, first affected label 161, Python onset index 160",
            "- Neither mapping is uniquely primary.",
            "- Events and evidence are generated once without an onset, then classified under both mappings.",
            "- Selecting the more favorable boundary after outcomes is prohibited.",
            "",
            "## Frozen numerical contract",
            "",
            "- Channel: `xmeas_7`",
            "- Scaling: `(raw_x - 2705.0) / 7.561259999999865`, exactly once",
            "- Primary mode: `D_OR_G`",
            "- Warm-up: `92` samples",
            "- Sensitivity multiplier: `2.5` on `th_d`, `th_g`, `th_d2`, and `th_a` only",
            "",
            "## Scalar-reference configurations",
            "",
            *(
                f"- `{name}`: `{references[name]['configuration_sha256']}`"
                for name in sorted(SCALAR_REFERENCES)
            ),
            "",
            "## Authority and stop rules",
            "",
            "The first authority owns the complete trajectory. False authority and no authority have no valid latency. Comparator admission failure only excludes that comparator; it does not deny primary Bank D admission.",
            "",
            f"Source commit: `{payload['source_commit']}`",
            "",
        )
    )


def freeze_protocol_v2(
    *,
    json_path: Path,
    markdown_path: Path,
    manifest_path: Path,
    payload: Mapping[str, object],
) -> dict[str, object]:
    """Exclusively publish V2 protocol files; write the manifest last."""

    validate_protocol_payload_v2(payload)
    paths = (Path(json_path), Path(markdown_path), Path(manifest_path))
    if len(set(paths)) != 3 or any(path.exists() for path in paths):
        raise FileExistsError("V2 protocol paths must be distinct and unused")
    json_bytes = canonical_json_bytes(payload) + b"\n"
    markdown_bytes = _protocol_markdown_v2(payload).encode("utf-8")
    _exclusive_write(paths[0], json_bytes)
    _exclusive_write(paths[1], markdown_bytes)
    manifest_without_hash: dict[str, object] = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.tep.stage3_3.protocol_v2_freeze_manifest",
        "status": "complete_and_verified",
        "protocol_json_sha256": hashlib.sha256(json_bytes).hexdigest(),
        "protocol_markdown_sha256": hashlib.sha256(markdown_bytes).hexdigest(),
        "canonical_protocol_payload_sha256": canonical_sha256(payload),
        "source_commit": payload["source_commit"],
        "dual_boundary_candidate_file_sha256": DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        "layer_a_result_payload_sha256": payload["layer_contracts"]["layer_a"][
            "result_payload_sha256"
        ],
        "layer_b_result_payload_sha256": payload["layer_contracts"]["layer_b"][
            "result_payload_sha256"
        ],
    }
    manifest = dict(manifest_without_hash)
    manifest["freeze_manifest_sha256"] = canonical_sha256(manifest_without_hash)
    _exclusive_write(paths[2], canonical_json_bytes(manifest) + b"\n")
    return manifest


def validate_frozen_protocol_v2(
    *, json_path: Path, markdown_path: Path, manifest_path: Path
) -> Mapping[str, object]:
    manifest = load_strict_json(Path(manifest_path))
    if not isinstance(manifest, Mapping) or manifest.get("status") != (
        "complete_and_verified"
    ) or manifest.get("document_type") != (
        "dmreda.tep.stage3_3.protocol_v2_freeze_manifest"
    ):
        raise ValueError("V2 protocol freeze manifest is incomplete")
    without_hash = dict(manifest)
    stored = without_hash.pop("freeze_manifest_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("V2 protocol freeze manifest hash mismatch")
    json_bytes = Path(json_path).read_bytes()
    markdown_bytes = Path(markdown_path).read_bytes()
    if hashlib.sha256(json_bytes).hexdigest() != manifest["protocol_json_sha256"]:
        raise ValueError("V2 protocol JSON file hash mismatch")
    if hashlib.sha256(markdown_bytes).hexdigest() != manifest[
        "protocol_markdown_sha256"
    ]:
        raise ValueError("V2 protocol Markdown file hash mismatch")
    payload = load_strict_json(Path(json_path))
    if not isinstance(payload, Mapping):
        raise ValueError("V2 protocol JSON must contain an object")
    validate_protocol_payload_v2(payload)
    if canonical_sha256(payload) != manifest["canonical_protocol_payload_sha256"]:
        raise ValueError("V2 canonical protocol payload hash mismatch")
    if manifest["source_commit"] != payload["source_commit"]:
        raise ValueError("V2 manifest source commit mismatch")
    return payload
