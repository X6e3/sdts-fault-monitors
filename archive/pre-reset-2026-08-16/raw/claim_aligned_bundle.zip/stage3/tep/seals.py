"""Artifact-derived Stage 3.2 Bank D admission and one-time opening records."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
from typing import Mapping

from stage3.admission.contracts import SHA256_PATTERN
from stage3.admission.serialization import (
    atomic_write_json,
    canonical_json_bytes,
    canonical_sha256,
    load_strict_json,
)
from stage3.tep.configuration import (
    FROZEN_EFFECTIVE_PROFILES_SHA256,
    FROZEN_TEP_CONFIGURATION_SHA256,
)
from stage3.tep.extraction import validate_extraction_manifest
from stage3.tep.protocol import (
    DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
    EXPECTED_RAW_DATASET_SHA256,
    validate_protocol_payload_v2,
)


REQUIRED_ARTIFACTS = (
    "protocol",
    "normal_gate",
    "baseline_admission",
    "onset_mapping",
    "test_report",
    "output_guard",
    "dmreda_configuration",
    "baseline_configurations",
)
REQUIRED_SCALAR_REFERENCES = ("rms", "cusum", "ewma")

REQUIRED_ARTIFACTS_V2 = (
    "protocol_json",
    "protocol_freeze_manifest",
    "dual_boundary_candidate",
    "dual_boundary_implementation",
    "layer_a_result",
    "layer_b_result",
    "raw_integrity",
    "fault_free_testing_open_event",
    "pre_bank_d_access_evidence",
    "fault_free_testing_extraction_manifest",
    "fault_free_testing_extraction",
    "normal_gate_manifest",
    "dmreda_normal_gate",
    "scalar_reference_admission",
    "test_report",
    "output_guard",
    "worker_memory_probe",
    "dmreda_configuration",
    "scalar_reference_configurations",
    "recovery_integrity",
    "git_state",
)


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class ArtifactReference:
    """Runtime path plus the digest frozen before admission evaluation."""

    path: Path
    sha256: str

    def __post_init__(self) -> None:
        if not SHA256_PATTERN.fullmatch(self.sha256):
            raise ValueError("artifact SHA-256 must be lowercase hexadecimal")

    def verify_and_load(self) -> Mapping[str, object]:
        path = Path(self.path)
        if not path.is_file():
            raise FileNotFoundError(path)
        actual = _file_sha256(path)
        if actual != self.sha256:
            raise ValueError(f"artifact hash mismatch: {path.name}")
        payload = load_strict_json(path)
        if not isinstance(payload, Mapping):
            raise ValueError(f"artifact must contain a JSON object: {path.name}")
        return payload


def _passed(payload: Mapping[str, object], *keys: str) -> bool:
    value: object = payload
    for key in keys:
        if not isinstance(value, Mapping) or key not in value:
            return False
        value = value[key]
    return value is True


def evaluate_bank_d_admission(
    artifacts: Mapping[str, ArtifactReference],
    *,
    source_commit: str,
    no_retuning_declared: bool,
) -> dict[str, object]:
    """Derive admission from verified artifacts instead of caller booleans."""

    if set(artifacts) != set(REQUIRED_ARTIFACTS):
        missing = sorted(set(REQUIRED_ARTIFACTS) - set(artifacts))
        extra = sorted(set(artifacts) - set(REQUIRED_ARTIFACTS))
        raise ValueError(f"artifact set mismatch; missing={missing}, extra={extra}")
    if not (
        len(source_commit) == 40
        and all(character in "0123456789abcdef" for character in source_commit)
    ):
        raise ValueError("source_commit must be a lowercase Git commit identity")

    loaded = {name: artifacts[name].verify_and_load() for name in REQUIRED_ARTIFACTS}
    reasons: list[str] = []

    protocol = loaded["protocol"]
    identity = protocol.get("scientific_identity")
    if protocol.get("status") != "frozen":
        reasons.append("protocol_not_frozen")
    if not isinstance(identity, Mapping) or identity.get("primary") != (
        "causal_deterministic_bounded_state_temporal_evidence_representation_and_arbitration_core"
    ):
        reasons.append("scientific_identity_not_corrected")
    if protocol.get("source_commit") != source_commit:
        reasons.append("protocol_source_commit_mismatch")

    if not _passed(loaded["normal_gate"], "dmreda", "passed"):
        reasons.append("dmreda_normal_generalization_gate_failed")

    baseline = loaded["baseline_admission"]
    references = baseline.get("scalar_evidence_references")
    if baseline.get("all_references_admitted") is not True:
        reasons.append("scalar_reference_risk_matching_failed")
    if not isinstance(references, Mapping) or set(references) != set(
        REQUIRED_SCALAR_REFERENCES
    ):
        reasons.append("required_scalar_reference_set_incomplete")
    elif any(
        not isinstance(references[name], Mapping)
        or references[name].get("admitted") is not True
        for name in REQUIRED_SCALAR_REFERENCES
    ):
        reasons.append("one_or_more_scalar_references_not_admitted")

    onset = loaded["onset_mapping"]
    if onset.get("status") != "resolved" or not isinstance(
        onset.get("python_onset_index"), int
    ):
        reasons.append("onset_mapping_unresolved")

    if loaded["test_report"].get("status") != "passed":
        reasons.append("test_suite_not_passed")
    if loaded["output_guard"].get("status") != "passed":
        reasons.append("output_guard_not_passed")
    if not no_retuning_declared:
        reasons.append("no_retuning_declaration_missing")

    bindings = {name: artifacts[name].sha256 for name in REQUIRED_ARTIFACTS}
    payload_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_2.bank_d_admission",
        "status": "admitted" if not reasons else "denied",
        "scientific_identity": (
            "causal_deterministic_bounded_state_temporal_evidence_representation_and_arbitration_core"
        ),
        "source_commit": source_commit,
        "artifact_bindings": bindings,
        "no_retuning_declared": no_retuning_declared,
        "reasons": reasons,
    }
    payload = dict(payload_without_hash)
    payload["admission_record_sha256"] = canonical_sha256(payload_without_hash)
    return payload


def write_admission_record(path: Path, record: Mapping[str, object]) -> None:
    expected = record.get("admission_record_sha256")
    without_hash = dict(record)
    without_hash.pop("admission_record_sha256", None)
    if expected != canonical_sha256(without_hash):
        raise ValueError("admission record hash is invalid")
    atomic_write_json(path, record)
    directory = os.open(Path(path).parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def open_bank_d_once(
    *,
    admission_record_path: Path,
    admission_file_sha256: str,
    open_event_path: Path,
    opened_at_utc: str,
) -> dict[str, object]:
    """Create the one-time audit event immediately before value access.

    Creation uses ``O_EXCL``.  A truncated file after interruption is an
    uncertain open event and therefore fails closed instead of being retried.
    """

    admission_record_path = Path(admission_record_path)
    if _file_sha256(admission_record_path) != admission_file_sha256:
        raise ValueError("admission file hash mismatch")
    admission = load_strict_json(admission_record_path)
    if not isinstance(admission, Mapping) or admission.get("status") != "admitted":
        raise PermissionError("Bank D requires an admitted authorization record")
    stored_hash = admission.get("admission_record_sha256")
    without_hash = dict(admission)
    without_hash.pop("admission_record_sha256", None)
    if stored_hash != canonical_sha256(without_hash):
        raise ValueError("admission record content hash mismatch")
    if not opened_at_utc.endswith("Z"):
        raise ValueError("opened_at_utc must be an explicit UTC timestamp")

    event_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_2.bank_d_open_event",
        "action": "open_bank_d",
        "opened_at_utc": opened_at_utc,
        "admission_file_sha256": admission_file_sha256,
        "admission_record_sha256": stored_hash,
        "protocol_sha256": admission["artifact_bindings"]["protocol"],
        "source_commit": admission["source_commit"],
    }
    event = dict(event_without_hash)
    event["audit_event_sha256"] = canonical_sha256(event_without_hash)
    payload = canonical_json_bytes(event) + b"\n"

    path = Path(open_event_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except BaseException:
        # Preserve a partial exclusive marker: retrying would falsely claim an
        # untouched Bank D after an interruption at the opening boundary.
        raise
    return event


def validate_bank_d_open_event(path: Path) -> Mapping[str, object]:
    event = load_strict_json(Path(path))
    if not isinstance(event, Mapping) or event.get("action") != "open_bank_d":
        raise ValueError("invalid Bank D opening event")
    stored = event.get("audit_event_sha256")
    without_hash = dict(event)
    without_hash.pop("audit_event_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("Bank D opening event hash mismatch")
    return event


def _valid_sha256(value: object) -> bool:
    return isinstance(value, str) and bool(SHA256_PATTERN.fullmatch(value))


def _content_hash_valid(payload: Mapping[str, object], field: str) -> bool:
    without_hash = dict(payload)
    stored = without_hash.pop(field, None)
    return _valid_sha256(stored) and stored == canonical_sha256(without_hash)


def _validated_reference_statuses(
    admission: Mapping[str, object], reasons: list[str]
) -> tuple[dict[str, str], list[str], dict[str, str]]:
    references = admission.get("scalar_evidence_references")
    statuses: dict[str, str] = {}
    allowlist: list[str] = []
    excluded: dict[str, str] = {}
    if not isinstance(references, Mapping) or set(references) != set(
        REQUIRED_SCALAR_REFERENCES
    ):
        reasons.append("scalar_reference_admission_artifact_malformed")
        return statuses, allowlist, excluded
    for name in sorted(REQUIRED_SCALAR_REFERENCES):
        value = references[name]
        status = value.get("admission_status") if isinstance(value, Mapping) else None
        if status not in {"admitted_reference", "not_admitted_reference"}:
            reasons.append(f"{name}_reference_admission_status_invalid")
            continue
        statuses[name] = status
        if status == "admitted_reference":
            allowlist.append(name)
        else:
            risk = value.get("risk_matched")
            contracts = value.get("contracts_valid")
            if risk is False and contracts is False:
                excluded[name] = "risk_not_matched_and_contract_invalid"
            elif risk is False:
                excluded[name] = "risk_not_matched"
            elif contracts is False:
                excluded[name] = "contract_invalid"
            else:
                excluded[name] = "not_admitted_without_valid_reason"
                reasons.append(f"{name}_reference_exclusion_reason_invalid")
    recorded_allowlist = admission.get("admitted_reference_allowlist")
    if recorded_allowlist != allowlist:
        reasons.append("scalar_reference_allowlist_mismatch")
    if admission.get("primary_bank_d_veto_from_reference_failure") is not False:
        reasons.append("scalar_reference_failure_became_primary_veto")
    return statuses, allowlist, excluded


def evaluate_bank_d_admission_v2(
    artifacts: Mapping[str, ArtifactReference],
    *,
    source_commit: str,
    evaluated_at_utc: str,
) -> dict[str, object]:
    """Derive the Stage 3.3 Bank D decision from hash-verified artifacts.

    A well-formed ``not_admitted_reference`` never denies the primary DMREDA
    application. Missing or malformed reference evidence remains an integrity
    failure and therefore does deny access.
    """

    if set(artifacts) != set(REQUIRED_ARTIFACTS_V2):
        missing = sorted(set(REQUIRED_ARTIFACTS_V2) - set(artifacts))
        extra = sorted(set(artifacts) - set(REQUIRED_ARTIFACTS_V2))
        raise ValueError(f"V2 artifact set mismatch; missing={missing}, extra={extra}")
    if not (
        len(source_commit) == 40
        and all(character in "0123456789abcdef" for character in source_commit)
    ):
        raise ValueError("source_commit must be a lowercase Git commit identity")
    if not evaluated_at_utc.endswith("Z"):
        raise ValueError("evaluated_at_utc must be an explicit UTC timestamp")

    loaded = {
        name: artifacts[name].verify_and_load() for name in REQUIRED_ARTIFACTS_V2
    }
    reasons: list[str] = []
    protocol = loaded["protocol_json"]
    try:
        validate_protocol_payload_v2(protocol)
    except (TypeError, ValueError):
        reasons.append("protocol_v2_invalid")
    if protocol.get("source_commit") != source_commit:
        reasons.append("protocol_source_commit_mismatch")

    freeze = loaded["protocol_freeze_manifest"]
    freeze_without_hash = dict(freeze)
    freeze_hash = freeze_without_hash.pop("freeze_manifest_sha256", None)
    if (
        freeze.get("document_type")
        != "dmreda.tep.stage3_3.protocol_v2_freeze_manifest"
        or freeze.get("status") != "complete_and_verified"
        or freeze_hash != canonical_sha256(freeze_without_hash)
        or freeze.get("protocol_json_sha256") != artifacts["protocol_json"].sha256
        or freeze.get("canonical_protocol_payload_sha256")
        != canonical_sha256(protocol)
        or freeze.get("source_commit") != source_commit
    ):
        reasons.append("protocol_v2_freeze_manifest_invalid")

    if artifacts["dual_boundary_candidate"].sha256 != (
        DUAL_BOUNDARY_CANDIDATE_FILE_SHA256
    ):
        reasons.append("dual_boundary_candidate_hash_mismatch")
    candidate = loaded["dual_boundary_candidate"]
    protocol_dual = protocol.get("dual_boundary_contract")
    if not isinstance(protocol_dual, Mapping) or protocol_dual.get(
        "candidate_payload_sha256"
    ) != canonical_sha256(candidate):
        reasons.append("dual_boundary_candidate_payload_mismatch")

    implementation = loaded["dual_boundary_implementation"]
    if (
        implementation.get("status") != "passed"
        or implementation.get("candidate_file_sha256")
        != DUAL_BOUNDARY_CANDIDATE_FILE_SHA256
        or implementation.get("tests_passed") is not True
        or not _valid_sha256(implementation.get("runner_sha256"))
        or implementation.get("event_generation_accepts_onset") is not False
        or implementation.get("coequal_onsets") != [159, 160]
    ):
        reasons.append("dual_boundary_implementation_invalid")

    layers = protocol.get("layer_contracts")
    for artifact_name, layer_name in (
        ("layer_a_result", "layer_a"),
        ("layer_b_result", "layer_b"),
    ):
        result = loaded[artifact_name]
        binding = layers.get(layer_name) if isinstance(layers, Mapping) else None
        if (
            result.get("status") != "passed"
            or not isinstance(binding, Mapping)
            or result.get("result_sha256") != binding.get("result_payload_sha256")
            or artifacts[artifact_name].sha256 != binding.get("result_file_sha256")
        ):
            reasons.append(f"{layer_name}_result_invalid")

    raw = loaded["raw_integrity"]
    if raw.get("status") != "passed" or raw.get("raw_dataset_hashes") != (
        EXPECTED_RAW_DATASET_SHA256
    ):
        reasons.append("raw_dataset_integrity_failed")

    extraction_manifest = loaded["fault_free_testing_extraction_manifest"]
    try:
        validate_extraction_manifest(extraction_manifest)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        reasons.append("fault_free_testing_extraction_manifest_invalid")
    extraction_source = extraction_manifest.get("source")
    extraction_output = extraction_manifest.get("output")
    extraction_validation = extraction_manifest.get("validation")
    if (
        not isinstance(extraction_source, Mapping)
        or extraction_source.get("logical_name") != "TEP_FaultFree_Testing.RData"
        or extraction_source.get("object_name") != "fault_free_testing"
        or extraction_source.get("sha256")
        != EXPECTED_RAW_DATASET_SHA256["TEP_FaultFree_Testing.RData"]
        or not isinstance(extraction_output, Mapping)
        or not _valid_sha256(extraction_output.get("sha256"))
        or not isinstance(extraction_validation, Mapping)
        or extraction_validation.get("row_count") != 480_000
        or extraction_validation.get("trajectory_count") != 500
        or extraction_validation.get("first_key") != [0, 1, 1]
        or extraction_validation.get("last_key") != [0, 500, 960]
    ):
        reasons.append("fault_free_testing_extraction_manifest_binding_invalid")

    fault_free_open = loaded["fault_free_testing_open_event"]
    if (
        fault_free_open.get("document_type")
        != "dmreda.stage3_3.fault_free_testing_open_event"
        or fault_free_open.get("action")
        != "open_fault_free_testing_for_independent_normal_gate"
        or fault_free_open.get("protocol_sha256") != canonical_sha256(protocol)
        or fault_free_open.get("source_commit") != source_commit
        or fault_free_open.get("bank_d_state") != "sealed_unopened"
    ):
        reasons.append("fault_free_testing_open_event_invalid")
    pre_bank_access = loaded["pre_bank_d_access_evidence"]
    if (
        pre_bank_access.get("status") != "complete"
        or pre_bank_access.get("source_commit") != source_commit
        or pre_bank_access.get("protocol_sha256") != canonical_sha256(protocol)
        or pre_bank_access.get("fault_free_testing_values_accessed") is not True
        or pre_bank_access.get("faulty_testing_values_accessed") is not False
        or pre_bank_access.get("bank_d_state") != "sealed_unopened"
    ):
        reasons.append("pre_bank_d_access_evidence_invalid")

    extraction = loaded["fault_free_testing_extraction"]
    if (
        extraction.get("status") != "passed"
        or extraction.get("partition") != "fault_free_testing"
        or extraction.get("schema_verified") is not True
        or extraction.get("trajectory_count") != 500
        or extraction.get("horizon") != 960
        or not _valid_sha256(extraction.get("extract_sha256"))
        or extraction.get("extraction_manifest_sha256")
        != artifacts["fault_free_testing_extraction_manifest"].sha256
        or not isinstance(extraction_output, Mapping)
        or extraction.get("extract_sha256") != extraction_output.get("sha256")
    ):
        reasons.append("fault_free_testing_extraction_invalid")

    normal = loaded["dmreda_normal_gate"]
    primary = normal.get("primary_dmreda")
    if (
        normal.get("status") != "passed"
        or not isinstance(primary, Mapping)
        or primary.get("admitted") is not True
        or primary.get("false_authority_count") is None
        or isinstance(primary.get("false_authority_count"), bool)
        or not isinstance(primary.get("false_authority_count"), int)
        or primary.get("false_authority_count") < 0
        or primary.get("false_authority_count") > 25
        or normal.get("run_count") != 500
        or normal.get("horizon") != 960
        or not isinstance(primary.get("restricted_time_sum"), int)
        or isinstance(primary.get("restricted_time_sum"), bool)
        or not 0 <= primary.get("restricted_time_sum", -1) <= 480_000
        or primary.get("configuration_sha256") != FROZEN_TEP_CONFIGURATION_SHA256
        or not _content_hash_valid(normal, "summary_payload_sha256")
    ):
        reasons.append("dmreda_normal_false_authority_gate_failed")

    admission = loaded["scalar_reference_admission"]
    if not _content_hash_valid(admission, "admission_payload_sha256"):
        reasons.append("scalar_reference_admission_content_hash_invalid")
    statuses, allowlist, excluded = _validated_reference_statuses(admission, reasons)

    normal_manifest = loaded["normal_gate_manifest"]
    normal_artifacts = normal_manifest.get("artifact_sha256")
    if (
        normal_manifest.get("document_type")
        != "dmreda.stage3_3.normal_gate_manifest"
        or normal_manifest.get("status") != "complete_and_verified"
        or normal_manifest.get("source_commit") != source_commit
        or normal_manifest.get("protocol_sha256") != canonical_sha256(protocol)
        or normal_manifest.get("serial_parallel_parity") is not True
        or normal_manifest.get("worker_memory_probe_sha256")
        != artifacts["worker_memory_probe"].sha256
        or not _content_hash_valid(normal_manifest, "manifest_payload_sha256")
        or not isinstance(normal_artifacts, Mapping)
        or normal_artifacts.get("fault_free_testing_extraction")
        != artifacts["fault_free_testing_extraction"].sha256
        or normal_artifacts.get("dmreda_normal_summary")
        != artifacts["dmreda_normal_gate"].sha256
        or normal_artifacts.get("scalar_reference_admission")
        != artifacts["scalar_reference_admission"].sha256
    ):
        reasons.append("normal_gate_completion_manifest_invalid")

    expected_normal_bindings = {
        "fault_free_testing_extract_sha256": extraction.get("extract_sha256"),
        "fault_free_testing_extraction_adapter_sha256": artifacts[
            "fault_free_testing_extraction"
        ].sha256,
        "dmreda_trajectory_results_sha256": (
            normal_artifacts.get("dmreda_trajectory_results")
            if isinstance(normal_artifacts, Mapping)
            else None
        ),
        "scalar_reference_trajectory_results_sha256": (
            normal_artifacts.get("scalar_reference_trajectory_results")
            if isinstance(normal_artifacts, Mapping)
            else None
        ),
        "protocol_sha256": canonical_sha256(protocol),
        "runner_sha256": (
            protocol.get("source_hashes", {}).get("stage3/tep/normal_gate.py")
            if isinstance(protocol.get("source_hashes"), Mapping)
            else None
        ),
        "source_commit": source_commit,
    }
    normal_bindings = normal.get("artifact_bindings")
    admission_bindings = admission.get("artifact_bindings")
    if normal_bindings != expected_normal_bindings:
        reasons.append("normal_summary_artifact_binding_invalid")
    if admission_bindings != {
        **expected_normal_bindings,
        "dmreda_normal_summary_sha256": artifacts["dmreda_normal_gate"].sha256,
    }:
        reasons.append("scalar_reference_admission_artifact_binding_invalid")
    admission_primary = admission.get("primary_dmreda")
    summary_admitted = primary.get("admitted") if isinstance(primary, Mapping) else None
    admission_admitted = admission.get("dmreda_primary_admitted")
    admission_primary_admitted = (
        admission_primary.get("admitted")
        if isinstance(admission_primary, Mapping)
        else None
    )
    if (
        not isinstance(summary_admitted, bool)
        or not isinstance(admission_admitted, bool)
        or not isinstance(admission_primary_admitted, bool)
        or admission_admitted is not summary_admitted
        or admission_primary_admitted is not summary_admitted
        or not isinstance(admission_primary, Mapping)
        or not isinstance(primary, Mapping)
        or admission_primary.get("false_authority_count")
        != primary.get("false_authority_count")
        or admission_primary.get("restricted_time_sum")
        != primary.get("restricted_time_sum")
    ):
        reasons.append("normal_summary_and_admission_disagree")

    test_report = loaded["test_report"]
    if (
        test_report.get("status") != "passed"
        or test_report.get("source_commit") != source_commit
        or test_report.get("dual_boundary_tests_passed") is not True
        or test_report.get("protocol_sha256") != canonical_sha256(protocol)
    ):
        reasons.append("test_suite_not_passed")
    if (
        loaded["output_guard"].get("status") != "passed"
        or loaded["output_guard"].get("source_commit") != source_commit
        or loaded["output_guard"].get("protocol_sha256")
        != canonical_sha256(protocol)
    ):
        reasons.append("output_guard_not_passed")
    worker_memory = loaded["worker_memory_probe"]
    maximum_workers = worker_memory.get("maximum_campaign_workers")
    worker_rss = worker_memory.get("conservative_rss_bytes")
    available_at_probe = worker_memory.get("available_memory_bytes_at_probe")
    reserve_at_probe = worker_memory.get("reserved_memory_bytes")
    expected_worker_maximum = (
        min(
            8,
            max(0, available_at_probe - reserve_at_probe) // (worker_rss * 2),
        )
        if all(
            isinstance(value, int) and not isinstance(value, bool) and value > 0
            for value in (worker_rss, available_at_probe, reserve_at_probe)
        )
        else None
    )
    if (
        worker_memory.get("status") != "measured"
        or worker_memory.get("source_commit") != source_commit
        or worker_memory.get("protocol_sha256") != canonical_sha256(protocol)
        or worker_memory.get("probe_workers") != 1
        or worker_memory.get("per_worker_safety_factor") != 2
        or not isinstance(worker_memory.get("host"), Mapping)
        or not isinstance(maximum_workers, int)
        or isinstance(maximum_workers, bool)
        or not 2 <= maximum_workers <= 8
        or maximum_workers != expected_worker_maximum
    ):
        reasons.append("worker_memory_probe_invalid")
    recovery = loaded["recovery_integrity"]
    if (
        recovery.get("status") != "passed"
        or recovery.get("bank_d_state") != "sealed_unopened"
        or recovery.get("faulty_testing_values_accessed") is not False
        or recovery.get("source_commit") != source_commit
        or recovery.get("protocol_sha256") != canonical_sha256(protocol)
    ):
        reasons.append("recovery_or_bank_d_state_invalid")
    git_state = loaded["git_state"]
    if (
        git_state.get("status") != "clean"
        or git_state.get("source_commit") != source_commit
        or git_state.get("protocol_sha256") != canonical_sha256(protocol)
    ):
        reasons.append("git_state_not_clean_or_stale")
    dmreda_configuration = loaded["dmreda_configuration"]
    if (
        dmreda_configuration.get("configuration_sha256")
        != FROZEN_TEP_CONFIGURATION_SHA256
        or dmreda_configuration.get("effective_profiles_sha256")
        != FROZEN_EFFECTIVE_PROFILES_SHA256
        or dmreda_configuration.get("source_commit") != source_commit
    ):
        reasons.append("dmreda_configuration_invalid")
    scalar_configurations = loaded["scalar_reference_configurations"]
    protocol_references = protocol.get("scalar_evidence_references")
    expected_configuration_hashes = (
        {
            name: protocol_references[name]["configuration_sha256"]
            for name in REQUIRED_SCALAR_REFERENCES
        }
        if isinstance(protocol_references, Mapping)
        and set(protocol_references) == set(REQUIRED_SCALAR_REFERENCES)
        else None
    )
    expected_configuration_records = (
        {
            name: {
                key: value
                for key, value in protocol_references[name].items()
                if key != "scientific_role"
            }
            for name in REQUIRED_SCALAR_REFERENCES
        }
        if isinstance(protocol_references, Mapping)
        and set(protocol_references) == set(REQUIRED_SCALAR_REFERENCES)
        else None
    )
    if (
        scalar_configurations.get("status") != "frozen"
        or scalar_configurations.get("source_commit") != source_commit
        or scalar_configurations.get("configuration_sha256")
        != expected_configuration_hashes
        or scalar_configurations.get("records") != expected_configuration_records
    ):
        reasons.append("scalar_reference_configurations_invalid")

    declaration = protocol.get("no_retuning_declaration")
    no_retuning_derived = bool(
        isinstance(declaration, Mapping)
        and declaration
        and all(value is True for value in declaration.values())
    )
    if not no_retuning_derived:
        reasons.append("no_retuning_declaration_invalid")

    payload_without_hash: dict[str, object] = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.bank_d_admission_v2",
        "status": "admitted" if not reasons else "denied",
        "bank_d_decision": "admitted" if not reasons else "denied",
        "evaluated_at_utc": evaluated_at_utc,
        "scientific_identity": (
            "causal_deterministic_bounded_state_temporal_evidence_representation_and_arbitration_core"
        ),
        "source_commit": source_commit,
        "artifact_bindings": {
            name: artifacts[name].sha256 for name in REQUIRED_ARTIFACTS_V2
        },
        "core_configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "effective_profiles_sha256": FROZEN_EFFECTIVE_PROFILES_SHA256,
        "dual_boundary_candidate_sha256": DUAL_BOUNDARY_CANDIDATE_FILE_SHA256,
        "dual_boundary_implementation_sha256": artifacts[
            "dual_boundary_implementation"
        ].sha256,
        "layer_a_result_sha256": artifacts["layer_a_result"].sha256,
        "layer_b_result_sha256": artifacts["layer_b_result"].sha256,
        "normal_gate_result_sha256": artifacts["dmreda_normal_gate"].sha256,
        "raw_dataset_hashes": dict(EXPECTED_RAW_DATASET_SHA256),
        "scalar_reference_admission_statuses": statuses,
        "admitted_reference_allowlist": allowlist,
        "excluded_references": excluded,
        "primary_bank_d_veto_from_reference_failure": False,
        "added_value_beyond_scalar_references_claim_authorized": (
            not reasons and bool(allowlist)
        ),
        "no_retuning_derived_from_protocol": no_retuning_derived,
        "reasons": reasons,
    }
    payload = dict(payload_without_hash)
    payload["admission_record_sha256"] = canonical_sha256(payload_without_hash)
    return payload


def open_bank_d_once_v2(
    *,
    admission_record_path: Path,
    admission_file_sha256: str,
    open_event_path: Path,
    opened_at_utc: str,
) -> dict[str, object]:
    """Create the exclusive V2 Bank D open event immediately before access."""

    admission_record_path = Path(admission_record_path)
    if _file_sha256(admission_record_path) != admission_file_sha256:
        raise ValueError("V2 admission file hash mismatch")
    admission = load_strict_json(admission_record_path)
    if not isinstance(admission, Mapping) or admission.get("document_type") != (
        "dmreda.stage3_3.bank_d_admission_v2"
    ) or admission.get("bank_d_decision") != "admitted":
        raise PermissionError("Bank D requires an admitted V2 authorization record")
    stored = admission.get("admission_record_sha256")
    without_hash = dict(admission)
    without_hash.pop("admission_record_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("V2 admission record content hash mismatch")
    if not opened_at_utc.endswith("Z"):
        raise ValueError("opened_at_utc must be an explicit UTC timestamp")
    event_without_hash: dict[str, object] = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.bank_d_open_event_v2",
        "action": "open_bank_d_once",
        "opened_at_utc": opened_at_utc,
        "admission_file_sha256": admission_file_sha256,
        "admission_record_sha256": stored,
        "protocol_file_sha256": admission["artifact_bindings"]["protocol_json"],
        "source_commit": admission["source_commit"],
        "coequal_onset_indices": [159, 160],
    }
    event = dict(event_without_hash)
    event["audit_event_sha256"] = canonical_sha256(event_without_hash)
    payload = canonical_json_bytes(event) + b"\n"
    path = Path(open_event_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)
    return event


def validate_bank_d_open_event_v2(path: Path) -> Mapping[str, object]:
    event = load_strict_json(Path(path))
    if not isinstance(event, Mapping) or event.get("document_type") != (
        "dmreda.stage3_3.bank_d_open_event_v2"
    ) or event.get("action") != "open_bank_d_once" or event.get(
        "coequal_onset_indices"
    ) != [159, 160]:
        raise ValueError("invalid V2 Bank D opening event")
    stored = event.get("audit_event_sha256")
    without_hash = dict(event)
    without_hash.pop("audit_event_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("V2 Bank D opening event hash mismatch")
    return event
