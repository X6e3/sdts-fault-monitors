"""Fail-closed containment for Stage 3 TEP extraction outputs.

Raw datasets and derived trajectories are deliberately kept outside Git.  The
checks in this module operate on resolved paths so that a symlink cannot make a
destination appear external while actually targeting a worktree.
"""

from __future__ import annotations

from enum import Enum
import os
from pathlib import Path
import tempfile
from typing import Final


class ExternalArtifactKind(str, Enum):
    """The small set of external artifacts this campaign may create."""

    SCALAR_TRAJECTORY = "scalar_trajectory"
    EXTRACTION_MANIFEST = "extraction_manifest"
    AUDIT_LOG = "audit_log"
    IMMUTABLE_JSON = "immutable_json"
    IMMUTABLE_JSONL = "immutable_jsonl"
    MARKDOWN_REPORT = "markdown_report"
    HASH_MANIFEST = "hash_manifest"
    CHECKPOINT_JSON = "checkpoint_json"
    PROGRESS_LEDGER = "progress_ledger"


_FORBIDDEN_RELATIVE_PARTS: Final[frozenset[str]] = frozenset(
    {
        ".cache",
        ".git",
        ".venv",
        "__pycache__",
        "archive",
        "archives",
        "cache",
        "caches",
        "credentials",
        "dataset-audit",
        "downloads",
        "raw",
        "raw-data",
        "raw_data",
        "raw_datasets",
        "venv",
        "venvs",
    }
)
_FORBIDDEN_NAMES: Final[frozenset[str]] = frozenset(
    {
        ".env",
        "credentials.json",
        "id_ed25519",
        "id_rsa",
        "kaggle.json",
        ".netrc",
        "netrc",
    }
)
_FORBIDDEN_ENDINGS: Final[tuple[str, ...]] = (
    ".7z",
    ".bundle",
    ".h5",
    ".hdf5",
    ".key",
    ".mat",
    ".npy",
    ".npz",
    ".parquet",
    ".pem",
    ".rda",
    ".rdata",
    ".tar",
    ".tar.gz",
    ".tgz",
    ".zip",
)


def _inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def git_worktree_root(path: Path) -> Path | None:
    """Return the nearest containing Git worktree based on its `.git` marker."""

    resolved = Path(path).resolve(strict=False)
    start = resolved if resolved.is_dir() else resolved.parent
    for candidate in (start, *start.parents):
        marker = candidate / ".git"
        if marker.is_dir() or marker.is_file() or marker.is_symlink():
            return candidate
    return None


def _validate_relative_artifact_path(relative: Path) -> None:
    lowered_parts = tuple(part.lower() for part in relative.parts)
    if any(part in _FORBIDDEN_RELATIVE_PARTS for part in lowered_parts):
        raise ValueError("output path contains a forbidden payload directory")

    lowered_name = relative.name.lower()
    if lowered_name in _FORBIDDEN_NAMES:
        raise ValueError("output filename is reserved for credentials")
    if any(lowered_name.endswith(ending) for ending in _FORBIDDEN_ENDINGS):
        raise ValueError("raw, archive, credential, or recovery payload is forbidden")


def _validate_kind(path: Path, kind: ExternalArtifactKind) -> None:
    lowered = path.name.lower()
    if kind is ExternalArtifactKind.SCALAR_TRAJECTORY:
        if not lowered.endswith(".csv.gz"):
            raise ValueError("scalar trajectories must use the .csv.gz suffix")
    elif kind is ExternalArtifactKind.EXTRACTION_MANIFEST:
        if not lowered.endswith(".json"):
            raise ValueError("extraction manifests must use the .json suffix")
    elif kind is ExternalArtifactKind.AUDIT_LOG:
        if not (lowered.endswith(".log") or lowered.endswith(".txt")):
            raise ValueError("audit logs must use the .log or .txt suffix")
    elif kind is ExternalArtifactKind.IMMUTABLE_JSON:
        if not lowered.endswith(".json"):
            raise ValueError("immutable JSON artifacts must use the .json suffix")
    elif kind is ExternalArtifactKind.IMMUTABLE_JSONL:
        if not lowered.endswith(".jsonl"):
            raise ValueError("immutable JSONL artifacts must use the .jsonl suffix")
    elif kind is ExternalArtifactKind.MARKDOWN_REPORT:
        if not lowered.endswith(".md"):
            raise ValueError("Markdown reports must use the .md suffix")
    elif kind is ExternalArtifactKind.HASH_MANIFEST:
        if not (
            lowered.endswith(".txt")
            or lowered.endswith(".sha256")
            or lowered.endswith(".sha256sum")
        ):
            raise ValueError("hash manifests must use .txt, .sha256, or .sha256sum")
    elif kind is ExternalArtifactKind.CHECKPOINT_JSON:
        if not lowered.endswith(".json"):
            raise ValueError("checkpoint artifacts must use the .json suffix")
    elif kind is ExternalArtifactKind.PROGRESS_LEDGER:
        if not (
            lowered.endswith(".json")
            or lowered.endswith(".jsonl")
            or lowered.endswith(".log")
        ):
            raise ValueError("progress ledgers must use .json, .jsonl, or .log")
    else:  # pragma: no cover - Enum makes this unreachable for typed callers.
        raise ValueError(f"unsupported external artifact kind: {kind!r}")


def validate_external_destination(
    destination: Path,
    *,
    external_root: Path,
    kind: ExternalArtifactKind,
    require_absent: bool = True,
) -> Path:
    """Resolve and authorize one output destination outside every worktree.

    The designated external root and the destination parent must already exist.
    This avoids creating directories through an unchecked symlink chain.
    """

    root_input = Path(external_root)
    if not root_input.exists() or not root_input.is_dir():
        raise ValueError("designated external root must be an existing directory")
    root = root_input.resolve(strict=True)
    if git_worktree_root(root) is not None:
        raise PermissionError("designated external root is inside a Git worktree")

    raw_destination = Path(destination)
    if raw_destination.is_symlink():
        raise PermissionError("output destination must not be a symlink")
    raw_parent = raw_destination.parent
    if not raw_parent.exists() or not raw_parent.is_dir():
        raise ValueError("output parent must be an existing directory")

    resolved_parent = raw_parent.resolve(strict=True)
    resolved = (resolved_parent / raw_destination.name).resolve(strict=False)
    if not _inside(resolved, root):
        raise PermissionError("output destination escapes the designated external root")
    if git_worktree_root(resolved_parent) is not None:
        raise PermissionError("output destination is inside a Git worktree")

    relative = resolved.relative_to(root)
    _validate_relative_artifact_path(relative)
    _validate_kind(resolved, kind)
    if require_absent and resolved.exists():
        raise FileExistsError(f"refusing to overwrite external artifact: {resolved.name}")
    return resolved


def atomic_write_bytes(
    destination: Path,
    payload: bytes,
    *,
    external_root: Path,
    kind: ExternalArtifactKind,
    mode: int = 0o600,
) -> Path:
    """Write an authorized external artifact through a same-directory rename."""

    if not isinstance(payload, bytes):
        raise TypeError("atomic payload must be bytes")
    resolved = validate_external_destination(
        destination,
        external_root=external_root,
        kind=kind,
        require_absent=True,
    )
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{resolved.name}.", suffix=".tmp", dir=resolved.parent
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "wb") as handle:
            descriptor = -1
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())

        # Recheck after the write so a changed parent symlink or late-created
        # destination fails closed before publication.
        validate_external_destination(
            resolved,
            external_root=external_root,
            kind=kind,
            require_absent=True,
        )
        os.replace(temporary, resolved)
        directory_descriptor = os.open(resolved.parent, os.O_RDONLY)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)
    except BaseException:
        if descriptor >= 0:
            os.close(descriptor)
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise
    return resolved


def atomic_write_text(
    destination: Path,
    text: str,
    *,
    external_root: Path,
    kind: ExternalArtifactKind,
    encoding: str = "utf-8",
) -> Path:
    """UTF-8-friendly wrapper around :func:`atomic_write_bytes`."""

    return atomic_write_bytes(
        destination,
        text.encode(encoding),
        external_root=external_root,
        kind=kind,
    )


_REPLACEABLE_KINDS: Final[frozenset[ExternalArtifactKind]] = frozenset(
    {
        ExternalArtifactKind.CHECKPOINT_JSON,
        ExternalArtifactKind.PROGRESS_LEDGER,
    }
)


def atomic_replace_checkpoint_bytes(
    destination: Path,
    payload: bytes,
    *,
    external_root: Path,
    kind: ExternalArtifactKind,
    mode: int = 0o600,
) -> Path:
    """Atomically replace only a typed checkpoint or progress ledger.

    Immutable scientific results deliberately have no overwrite API.
    """

    if kind not in _REPLACEABLE_KINDS:
        raise ValueError("only checkpoint or progress-ledger artifacts are replaceable")
    if not isinstance(payload, bytes):
        raise TypeError("atomic payload must be bytes")
    resolved = validate_external_destination(
        destination,
        external_root=external_root,
        kind=kind,
        require_absent=False,
    )
    if resolved.exists() and not resolved.is_file():
        raise ValueError("replaceable artifact must be a regular file")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{resolved.name}.", suffix=".tmp", dir=resolved.parent
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "wb") as handle:
            descriptor = -1
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        validate_external_destination(
            resolved,
            external_root=external_root,
            kind=kind,
            require_absent=False,
        )
        os.replace(temporary, resolved)
        directory_descriptor = os.open(resolved.parent, os.O_RDONLY)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)
    except BaseException:
        if descriptor >= 0:
            os.close(descriptor)
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise
    return resolved
