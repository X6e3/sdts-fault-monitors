"""Deterministic, resumable per-fault evaluation runner for Stage 3.2."""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
import hashlib
import math
from pathlib import Path
import struct
from typing import Mapping, Sequence

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    EventGateConfig,
    baseline_event_contract,
    evaluate_dmreda_core_fsm,
    evaluate_score_trace,
    ewma_mean_score,
    trailing_rms_score,
    two_sided_cusum_score,
)
from gold_line.evaluation.alarm_metrics import RunOutcome
from stage3.admission.serialization import canonical_sha256
from stage3.tep.checkpoints import (
    CheckpointValidationError,
    build_complete_checkpoint,
    read_canonical_checkpoint_strict,
    read_canonical_jsonl_strict,
    validate_complete_checkpoint,
    write_canonical_checkpoint_atomic,
    write_canonical_jsonl_atomic,
)
from stage3.tep.configuration import (
    FROZEN_TEP_CONFIGURATION_SHA256,
    build_tep_core_kwargs,
)


MAX_PROCESS_WORKERS = 8
_DETECTOR_KINDS = {"dmreda_core", "rms", "cusum", "ewma"}
_DMREDA_MODES = {"D_ONLY", "G_ONLY", "D_OR_G"}
_SHA256_CHARS = frozenset("0123456789abcdef")
_RESULT_ROW_KEYS = {
    "schema_version",
    "fault_id",
    "trajectory_id",
    "simulation_run",
    "sample_count",
    "sample_sha256",
    "onset_index",
    "detector_name",
    "outcome",
    "first_alarm",
    "false_positive",
    "detected",
    "missed",
    "valid_detection_delay_samples",
    "input_sha256",
    "protocol_sha256",
    "onset_sha256",
    "runner_sha256",
    "detector_sha256",
    "trajectory_set_sha256",
    "binding_sha256",
}


def _validate_sha256(value: str, name: str) -> None:
    if not isinstance(value, str) or len(value) != 64 or any(
        character not in _SHA256_CHARS for character in value
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest")


@dataclass(frozen=True)
class EvaluationBindings:
    input_sha256: str
    protocol_sha256: str
    onset_sha256: str
    runner_sha256: str

    def __post_init__(self) -> None:
        for name in ("input_sha256", "protocol_sha256", "onset_sha256", "runner_sha256"):
            _validate_sha256(getattr(self, name), name)


@dataclass(frozen=True)
class TrajectoryInput:
    fault_id: str
    trajectory_id: str
    simulation_run: int
    samples: tuple[float, ...]
    onset_index: int

    def __post_init__(self) -> None:
        if not isinstance(self.fault_id, str) or not self.fault_id:
            raise ValueError("fault_id must be a non-empty string")
        if not isinstance(self.trajectory_id, str) or not self.trajectory_id:
            raise ValueError("trajectory_id must be a non-empty string")
        if isinstance(self.simulation_run, bool) or not isinstance(self.simulation_run, int):
            raise ValueError("simulation_run must be an integer")
        if not isinstance(self.samples, tuple) or not self.samples:
            raise ValueError("samples must be a non-empty tuple")
        values = np.asarray(self.samples, dtype=np.float64)
        if values.ndim != 1 or not np.all(np.isfinite(values)):
            raise ValueError("samples must be a finite one-dimensional sequence")
        if isinstance(self.onset_index, bool) or not isinstance(self.onset_index, int):
            raise ValueError("onset_index must be an integer")
        if not 0 <= self.onset_index < len(self.samples):
            raise ValueError("onset_index must lie inside the trajectory")

    @property
    def sample_sha256(self) -> str:
        values = np.ascontiguousarray(self.samples, dtype=np.dtype("<f8"))
        digest = hashlib.sha256()
        digest.update(b"dmreda-stage3-tep-trajectory-v1\0")
        digest.update(struct.pack(">Q", len(values)))
        digest.update(values.tobytes(order="C"))
        return digest.hexdigest()


@dataclass(frozen=True)
class DetectorSpec:
    name: str
    kind: str
    threshold: float | None = None
    gate: EventGateConfig | None = None
    parameters: tuple[tuple[str, int | float], ...] = ()
    dmreda_mode: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("detector name must be non-empty")
        if self.kind not in _DETECTOR_KINDS:
            raise ValueError(f"unknown detector kind: {self.kind}")
        names = [name for name, _ in self.parameters]
        if names != sorted(names) or len(names) != len(set(names)):
            raise ValueError("detector parameters must have unique sorted names")
        for name, value in self.parameters:
            if not name or isinstance(value, bool) or not math.isfinite(float(value)):
                raise ValueError("detector parameters must be named finite numbers")

        if self.kind == "dmreda_core":
            if self.threshold is not None or self.gate is not None or self.parameters:
                raise ValueError("canonical DMREDA does not use baseline score parameters")
            if self.dmreda_mode not in _DMREDA_MODES:
                raise ValueError("DMREDA mode must be D_ONLY, G_ONLY, or D_OR_G")
            return
        if self.dmreda_mode is not None:
            raise ValueError("scalar evidence references cannot declare a DMREDA mode")
        if self.threshold is None or not math.isfinite(self.threshold):
            raise ValueError("baseline threshold must be finite")
        if self.gate is None:
            raise ValueError("baseline detector requires an event gate")
        self.gate.validate()
        required = {
            "rms": {"window"},
            "cusum": {"allowance", "center"},
            "ewma": {"alpha", "center", "scale"},
        }[self.kind]
        if set(names) != required:
            raise ValueError(f"{self.kind} parameters must be exactly {sorted(required)}")

    @classmethod
    def canonical_dmreda(
        cls, *, name: str = "dmreda_core", mode: str = "D_OR_G"
    ) -> "DetectorSpec":
        return cls(name=name, kind="dmreda_core", dmreda_mode=mode.upper())

    @classmethod
    def rms(
        cls, *, threshold: float, gate: EventGateConfig, window: int = 32, name: str = "rms"
    ) -> "DetectorSpec":
        if isinstance(window, bool) or not isinstance(window, int) or window <= 0:
            raise ValueError("RMS window must be a positive integer")
        return cls(
            name=name,
            kind="rms",
            threshold=float(threshold),
            gate=gate,
            parameters=(("window", window),),
        )

    @classmethod
    def cusum(
        cls,
        *,
        threshold: float,
        gate: EventGateConfig,
        center: float,
        allowance: float,
        name: str = "cusum",
    ) -> "DetectorSpec":
        if allowance < 0.0:
            raise ValueError("CUSUM allowance must be non-negative")
        return cls(
            name=name,
            kind="cusum",
            threshold=float(threshold),
            gate=gate,
            parameters=(("allowance", float(allowance)), ("center", float(center))),
        )

    @classmethod
    def ewma(
        cls,
        *,
        threshold: float,
        gate: EventGateConfig,
        center: float,
        scale: float,
        alpha: float = 2.0 / 33.0,
        name: str = "ewma",
    ) -> "DetectorSpec":
        if scale <= 0.0 or not 0.0 < alpha <= 1.0:
            raise ValueError("EWMA scale must be positive and alpha must be in (0, 1]")
        return cls(
            name=name,
            kind="ewma",
            threshold=float(threshold),
            gate=gate,
            parameters=(
                ("alpha", float(alpha)),
                ("center", float(center)),
                ("scale", float(scale)),
            ),
        )

    def parameter_mapping(self) -> dict[str, int | float]:
        return dict(self.parameters)

    def to_dict(self) -> dict[str, object]:
        if self.kind == "dmreda_core":
            return {
                "name": self.name,
                "kind": self.kind,
                "canonical_tep_configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
                "native_event_authority": True,
                "mode": self.dmreda_mode,
            }
        assert self.gate is not None
        return {
            "name": self.name,
            "kind": self.kind,
            "threshold": self.threshold,
            "parameters": self.parameter_mapping(),
            "gate": asdict(self.gate),
            "event_contract": asdict(baseline_event_contract(self.gate)),
        }

    @property
    def detector_sha256(self) -> str:
        return canonical_sha256(self.to_dict())


@dataclass(frozen=True)
class FaultEvaluationRun:
    fault_id: str
    trajectory_count: int
    binding_sha256: str
    result_sha256: str
    rows: tuple[Mapping[str, object], ...]
    resumed: bool


def _evaluate_outcome(trajectory: TrajectoryInput, detector: DetectorSpec) -> RunOutcome:
    signal = np.asarray(trajectory.samples, dtype=np.float64)
    if detector.kind == "dmreda_core":
        core_kwargs = build_tep_core_kwargs()
        assert detector.dmreda_mode is not None
        core_kwargs["mode"] = detector.dmreda_mode
        return evaluate_dmreda_core_fsm(
            signal,
            onset=trajectory.onset_index,
            core_kwargs=core_kwargs,
        )

    assert detector.gate is not None
    parameters = detector.parameter_mapping()
    if detector.kind == "rms":
        scores = trailing_rms_score(signal, window=int(parameters["window"]))
    elif detector.kind == "cusum":
        scores = two_sided_cusum_score(
            signal,
            center=float(parameters["center"]),
            allowance=float(parameters["allowance"]),
        )
    else:
        scores = ewma_mean_score(
            signal,
            center=float(parameters["center"]),
            scale=float(parameters["scale"]),
            alpha=float(parameters["alpha"]),
        )
    assert detector.threshold is not None
    return evaluate_score_trace(
        scores,
        threshold=detector.threshold,
        gate=detector.gate,
        onset=trajectory.onset_index,
    )


def _evaluate_job(job: tuple[TrajectoryInput, DetectorSpec]) -> dict[str, object]:
    trajectory, detector = job
    outcome = _evaluate_outcome(trajectory, detector)
    return {
        "schema_version": "1.0.0",
        "fault_id": trajectory.fault_id,
        "trajectory_id": trajectory.trajectory_id,
        "simulation_run": trajectory.simulation_run,
        "sample_count": len(trajectory.samples),
        "sample_sha256": trajectory.sample_sha256,
        "onset_index": trajectory.onset_index,
        "detector_name": detector.name,
        **outcome.to_dict(),
    }


def _ordered_trajectories(
    trajectories: Sequence[TrajectoryInput],
) -> tuple[TrajectoryInput, ...]:
    if not trajectories:
        raise ValueError("at least one trajectory is required")
    ordered = tuple(sorted(trajectories, key=lambda item: (item.simulation_run, item.trajectory_id)))
    fault_ids = {item.fault_id for item in ordered}
    if len(fault_ids) != 1:
        raise ValueError("one per-fault result cannot mix fault identities")
    identities = [item.trajectory_id for item in ordered]
    if len(identities) != len(set(identities)):
        raise ValueError("trajectory identities must be unique")
    simulation_runs = [item.simulation_run for item in ordered]
    if len(simulation_runs) != len(set(simulation_runs)):
        raise ValueError("simulation_run identities must be unique within one fault")
    return ordered


def _trajectory_set_sha256(trajectories: Sequence[TrajectoryInput]) -> str:
    return canonical_sha256(
        [
            {
                "fault_id": item.fault_id,
                "trajectory_id": item.trajectory_id,
                "simulation_run": item.simulation_run,
                "sample_count": len(item.samples),
                "sample_sha256": item.sample_sha256,
                "onset_index": item.onset_index,
            }
            for item in trajectories
        ]
    )


def _binding_payload(
    trajectories: Sequence[TrajectoryInput],
    detector: DetectorSpec,
    bindings: EvaluationBindings,
) -> dict[str, object]:
    return {
        "fault_id": trajectories[0].fault_id,
        "input_sha256": bindings.input_sha256,
        "protocol_sha256": bindings.protocol_sha256,
        "onset_sha256": bindings.onset_sha256,
        "runner_sha256": bindings.runner_sha256,
        "detector_sha256": detector.detector_sha256,
        "trajectory_set_sha256": _trajectory_set_sha256(trajectories),
    }


def _decorate_rows(
    rows: Sequence[Mapping[str, object]], binding_payload: Mapping[str, object]
) -> tuple[dict[str, object], ...]:
    binding_hash = canonical_sha256(dict(binding_payload))
    return tuple(
        {
            **dict(row),
            **dict(binding_payload),
            "binding_sha256": binding_hash,
        }
        for row in rows
    )


def _validate_result_rows(
    rows: Sequence[Mapping[str, object]],
    *,
    ordered: Sequence[TrajectoryInput],
    detector: DetectorSpec,
    binding_payload: Mapping[str, object],
) -> None:
    expected_ids = [item.trajectory_id for item in ordered]
    observed_ids = [row.get("trajectory_id") for row in rows]
    if len(rows) != len(ordered):
        raise CheckpointValidationError("result trajectory count is incomplete")
    if len(observed_ids) != len(set(observed_ids)):
        raise CheckpointValidationError("result contains duplicate trajectory identities")
    if observed_ids != expected_ids:
        raise CheckpointValidationError("result trajectory identity order is stale")

    binding_hash = canonical_sha256(dict(binding_payload))
    expected_by_id = {item.trajectory_id: item for item in ordered}
    for row in rows:
        if set(row) != _RESULT_ROW_KEYS:
            raise CheckpointValidationError(
                "result row field set is incomplete or unexpected"
            )
        if row["schema_version"] != "1.0.0":
            raise CheckpointValidationError("unsupported result row schema")
        identity = row["trajectory_id"]
        if not isinstance(identity, str):
            raise CheckpointValidationError("result trajectory identity is invalid")
        trajectory = expected_by_id[identity]
        expected_binding_fields = {
            **dict(binding_payload),
            "binding_sha256": binding_hash,
        }
        if any(row.get(name) != value for name, value in expected_binding_fields.items()):
            raise CheckpointValidationError("result row binding is stale or tampered")
        if row.get("fault_id") != trajectory.fault_id:
            raise CheckpointValidationError("result row fault identity is invalid")
        if row.get("simulation_run") != trajectory.simulation_run:
            raise CheckpointValidationError("result row simulation identity is invalid")
        if row.get("sample_count") != len(trajectory.samples):
            raise CheckpointValidationError("result row sample count is invalid")
        if row.get("sample_sha256") != trajectory.sample_sha256:
            raise CheckpointValidationError("result row input hash is invalid")
        if row.get("onset_index") != trajectory.onset_index:
            raise CheckpointValidationError("result row onset is invalid")
        if row.get("detector_name") != detector.name:
            raise CheckpointValidationError("result row detector identity is invalid")

        if any(
            not isinstance(row[name], bool)
            for name in ("false_positive", "detected", "missed")
        ):
            raise CheckpointValidationError("result outcome flags must be booleans")
        first_alarm = row["first_alarm"]
        delay = row["valid_detection_delay_samples"]
        if first_alarm is not None and (
            isinstance(first_alarm, bool) or not isinstance(first_alarm, int)
        ):
            raise CheckpointValidationError("result first alarm must be an integer or null")
        if delay is not None and (isinstance(delay, bool) or not isinstance(delay, int)):
            raise CheckpointValidationError("result delay must be an integer or null")
        try:
            outcome = RunOutcome(
                first_alarm=first_alarm,
                false_positive=row["false_positive"],
                detected=row["detected"],
                missed=row["missed"],
                delay_samples=delay,
            )
        except ValueError as error:
            raise CheckpointValidationError(f"invalid result outcome: {error}") from error
        if row.get("outcome") != outcome.outcome:
            raise CheckpointValidationError("result outcome label is invalid")


def evaluate_fault(
    trajectories: Sequence[TrajectoryInput],
    detector: DetectorSpec,
    *,
    bindings: EvaluationBindings,
    result_path: Path,
    checkpoint_path: Path,
    workers: int = 1,
    resume: bool = True,
) -> FaultEvaluationRun:
    """Evaluate or strictly resume one complete fault/detector result."""

    if isinstance(workers, bool) or not isinstance(workers, int):
        raise ValueError("workers must be an integer")
    if not 1 <= workers <= MAX_PROCESS_WORKERS:
        raise ValueError(f"workers must be in [1, {MAX_PROCESS_WORKERS}]")
    ordered = _ordered_trajectories(trajectories)
    identities = [item.trajectory_id for item in ordered]
    binding_payload = _binding_payload(ordered, detector, bindings)
    binding_hash = canonical_sha256(binding_payload)
    result_path = Path(result_path)
    checkpoint_path = Path(checkpoint_path)

    result_exists = result_path.exists()
    checkpoint_exists = checkpoint_path.exists()
    if result_exists or checkpoint_exists:
        if not resume:
            raise FileExistsError("result/checkpoint already exists and resume is disabled")
        if not (result_exists and checkpoint_exists):
            raise CheckpointValidationError(
                "result/checkpoint pair is incomplete; refusing automatic overwrite"
            )
        checkpoint = read_canonical_checkpoint_strict(checkpoint_path)
        expected_result_hash = validate_complete_checkpoint(
            checkpoint,
            expected_bindings=binding_payload,
            expected_ordered_trajectory_ids=identities,
        )
        rows, observed_result_hash = read_canonical_jsonl_strict(result_path)
        _validate_result_rows(
            rows,
            ordered=ordered,
            detector=detector,
            binding_payload=binding_payload,
        )
        if observed_result_hash != expected_result_hash:
            raise CheckpointValidationError("result hash does not match checkpoint")
        return FaultEvaluationRun(
            fault_id=ordered[0].fault_id,
            trajectory_count=len(ordered),
            binding_sha256=binding_hash,
            result_sha256=observed_result_hash,
            rows=rows,
            resumed=True,
        )

    jobs = tuple((trajectory, detector) for trajectory in ordered)
    if workers == 1:
        bare_rows = tuple(_evaluate_job(job) for job in jobs)
    else:
        bounded_workers = min(workers, len(jobs), MAX_PROCESS_WORKERS)
        with ProcessPoolExecutor(max_workers=bounded_workers) as executor:
            bare_rows = tuple(executor.map(_evaluate_job, jobs, chunksize=1))
    rows = _decorate_rows(bare_rows, binding_payload)
    _validate_result_rows(
        rows,
        ordered=ordered,
        detector=detector,
        binding_payload=binding_payload,
    )

    result_hash = write_canonical_jsonl_atomic(result_path, rows)
    checkpoint = build_complete_checkpoint(
        bindings=binding_payload,
        ordered_trajectory_ids=identities,
        result_sha256=result_hash,
    )
    write_canonical_checkpoint_atomic(checkpoint_path, checkpoint)
    return FaultEvaluationRun(
        fault_id=ordered[0].fault_id,
        trajectory_count=len(ordered),
        binding_sha256=binding_hash,
        result_sha256=result_hash,
        rows=rows,
        resumed=False,
    )
