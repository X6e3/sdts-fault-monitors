"""Immutable Stage 3.2 configuration for the TEP ``xmeas_7`` campaign.

This module adapts the domain to the canonical Core contract.  It does not
alter the Core defaults: each caller receives fresh profile and transition
mappings, and the four approved sensitivity thresholds are the only profile
fields changed by the frozen multiplier.
"""

from __future__ import annotations

from dataclasses import dataclass, fields, replace
import math
from typing import Mapping, Sequence

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    DEFAULT_TRANSITIONS,
    DMREDAProfile,
    RegimeTransition,
    apply_fixed_input_scale,
)
from stage3.admission.serialization import canonical_sha256


TEP_KAPPA = 2.5
TEP_THRESHOLD_FIELDS = ("th_d", "th_g", "th_d2", "th_a")


@dataclass(frozen=True)
class TepAffineConfiguration:
    """Fixed, normal-only affine preprocessing authority for ``xmeas_7``."""

    channel_name: str
    offset: float
    scale: float
    equation: str
    fitted_partition: str
    fitted_simulation_runs: tuple[int, int]

    def __post_init__(self) -> None:
        if self.channel_name != "xmeas_7":
            raise ValueError("the frozen TEP channel must be xmeas_7")
        if not math.isfinite(self.offset):
            raise ValueError("offset must be finite")
        if not math.isfinite(self.scale) or self.scale <= 0.0:
            raise ValueError("scale must be finite and positive")
        if self.fitted_partition != "fault_free_training":
            raise ValueError("affine parameters must come from fault-free training")
        if self.fitted_simulation_runs != (1, 100):
            raise ValueError("affine authority is frozen to simulationRun 1 through 100")


TEP_AFFINE_CONFIGURATION = TepAffineConfiguration(
    channel_name="xmeas_7",
    offset=2705.0,
    scale=7.561259999999865,
    equation="scaled_x[t] = (raw_x[t] - offset) / scale",
    fitted_partition="fault_free_training",
    fitted_simulation_runs=(1, 100),
)


def apply_tep_affine_scale(samples: Sequence[float]) -> np.ndarray:
    """Apply the fixed TEP affine equation without evaluated-trace fitting."""

    return apply_fixed_input_scale(
        samples,
        offset=TEP_AFFINE_CONFIGURATION.offset,
        scale=TEP_AFFINE_CONFIGURATION.scale,
    )


def build_effective_profiles() -> dict[int, DMREDAProfile]:
    """Return fresh profiles with only the four frozen thresholds multiplied."""

    return {
        state: replace(
            profile,
            **{
                field_name: getattr(profile, field_name) * TEP_KAPPA
                for field_name in TEP_THRESHOLD_FIELDS
            },
        )
        for state, profile in sorted(DEFAULT_PROFILES.items())
    }


def build_unchanged_transitions() -> dict[int, RegimeTransition]:
    """Return a fresh mapping whose transition values equal the Core defaults."""

    return {
        state: replace(transition)
        for state, transition in sorted(DEFAULT_TRANSITIONS.items())
    }


def build_tep_core_kwargs() -> dict[str, object]:
    """Return a fresh kwargs mapping for the frozen canonical Core run."""

    return {
        "regime_tick": 50,
        "initial_state": 0,
        "profiles": build_effective_profiles(),
        "transitions": build_unchanged_transitions(),
        "mode": "D_or_G",
        "warmup_samples": 92,
    }


def _profile_payload(profile: DMREDAProfile) -> dict[str, object]:
    payload: dict[str, object] = {}
    for field in fields(DMREDAProfile):
        value = getattr(profile, field.name)
        payload[field.name] = list(value) if isinstance(value, tuple) else value
    return payload


def effective_profiles_snapshot(
    profiles: Mapping[int, DMREDAProfile] | None = None,
) -> dict[str, dict[str, object]]:
    """Return a canonical JSON-compatible profile snapshot."""

    selected = build_effective_profiles() if profiles is None else profiles
    return {
        str(state): _profile_payload(selected[state])
        for state in sorted(selected)
    }


def transitions_snapshot(
    transitions: Mapping[int, RegimeTransition] | None = None,
) -> dict[str, dict[str, float | None]]:
    """Return a canonical JSON-compatible transition snapshot."""

    selected = build_unchanged_transitions() if transitions is None else transitions
    return {
        str(state): {
            "up_threshold": selected[state].up_threshold,
            "down_threshold": selected[state].down_threshold,
        }
        for state in sorted(selected)
    }


def effective_profiles_sha256() -> str:
    return canonical_sha256(effective_profiles_snapshot())


def transitions_sha256() -> str:
    return canonical_sha256(transitions_snapshot())


def tep_configuration_snapshot() -> dict[str, object]:
    """Return the complete claim-bound configuration in canonical form."""

    return {
        "schema_version": "1.0.0",
        "channel": {
            "name": TEP_AFFINE_CONFIGURATION.channel_name,
            "equation": TEP_AFFINE_CONFIGURATION.equation,
            "offset": TEP_AFFINE_CONFIGURATION.offset,
            "scale": TEP_AFFINE_CONFIGURATION.scale,
            "fitted_partition": TEP_AFFINE_CONFIGURATION.fitted_partition,
            "fitted_simulation_runs": list(
                TEP_AFFINE_CONFIGURATION.fitted_simulation_runs
            ),
        },
        "sensitivity": {
            "kappa": TEP_KAPPA,
            "multiplied_profile_fields": list(TEP_THRESHOLD_FIELDS),
        },
        "core": {
            "regime_tick": 50,
            "initial_state": 0,
            "mode": "D_or_G",
            "warmup_samples": 92,
            "effective_profiles_sha256": effective_profiles_sha256(),
            "transitions_sha256": transitions_sha256(),
            "profiles": effective_profiles_snapshot(),
            "transitions": transitions_snapshot(),
        },
    }


def tep_affine_configuration_snapshot() -> dict[str, object]:
    """Return the frozen input transform as a standalone hashable contract."""

    return dict(tep_configuration_snapshot()["channel"])


def tep_affine_configuration_sha256() -> str:
    return canonical_sha256(tep_affine_configuration_snapshot())


def tep_configuration_sha256() -> str:
    return canonical_sha256(tep_configuration_snapshot())


FROZEN_EFFECTIVE_PROFILES_SHA256 = effective_profiles_sha256()
FROZEN_TRANSITIONS_SHA256 = transitions_sha256()
FROZEN_TEP_CONFIGURATION_SHA256 = tep_configuration_sha256()
FROZEN_TEP_AFFINE_CONFIGURATION_SHA256 = tep_affine_configuration_sha256()
