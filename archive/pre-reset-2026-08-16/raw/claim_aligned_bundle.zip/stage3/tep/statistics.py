"""Recording-level Stage 3.2 summaries and paired evidence comparisons.

Samples are never treated as independent trials.  Early false authority,
valid post-onset detection, and miss remain distinct throughout this module.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from typing import Iterable, Mapping, Sequence

import numpy as np

from gold_line.evaluation.alarm_metrics import RunOutcome


OUTCOME_CATEGORIES = ("false_positive", "valid_detection", "miss")


def wilson_interval(successes: int, total: int, *, z: float = 1.959963984540054) -> tuple[float, float]:
    """Return a two-sided Wilson interval without sample-level replication."""

    if not isinstance(successes, int) or not isinstance(total, int):
        raise TypeError("successes and total must be integers")
    if total <= 0 or successes < 0 or successes > total:
        raise ValueError("invalid binomial counts")
    proportion = successes / total
    denominator = 1.0 + z * z / total
    center = (proportion + z * z / (2.0 * total)) / denominator
    radius = (
        z
        * math.sqrt(
            proportion * (1.0 - proportion) / total
            + z * z / (4.0 * total * total)
        )
        / denominator
    )
    return max(0.0, center - radius), min(1.0, center + radius)


def _percentiles(values: Sequence[int | float]) -> dict[str, float | None]:
    if not values:
        return {
            "minimum": None,
            "p10": None,
            "p25": None,
            "median": None,
            "p75": None,
            "p90": None,
            "maximum": None,
        }
    array = np.asarray(values, dtype=np.float64)
    quantiles = np.quantile(array, [0.10, 0.25, 0.50, 0.75, 0.90])
    return {
        "minimum": float(np.min(array)),
        "p10": float(quantiles[0]),
        "p25": float(quantiles[1]),
        "median": float(quantiles[2]),
        "p75": float(quantiles[3]),
        "p90": float(quantiles[4]),
        "maximum": float(np.max(array)),
    }


def summarize_run_outcomes(
    outcomes: Sequence[RunOutcome],
    *,
    onset: int,
    trace_length: int,
) -> dict[str, object]:
    """Summarize mutually exclusive recording-level outcomes.

    Restricted post-onset time excludes early-FP runs.  A miss contributes
    ``trace_length - onset`` under the frozen finite-horizon convention.
    """

    if not outcomes:
        raise ValueError("at least one run outcome is required")
    if onset < 0 or onset >= trace_length:
        raise ValueError("onset must lie inside the trace")
    counts = {
        "false_positive": sum(item.false_positive for item in outcomes),
        "valid_detection": sum(item.detected for item in outcomes),
        "miss": sum(item.missed for item in outcomes),
    }
    total = len(outcomes)
    if sum(counts.values()) != total:
        raise ValueError("outcome accounting is not mutually exhaustive")
    delays = [
        item.delay_samples
        for item in outcomes
        if item.detected and item.delay_samples is not None
    ]
    restricted = [
        item.delay_samples if item.detected else trace_length - onset
        for item in outcomes
        if not item.false_positive
    ]
    rates = {name: count / total for name, count in counts.items()}
    intervals = {
        name: list(wilson_interval(count, total)) for name, count in counts.items()
    }
    return {
        "trajectory_count": total,
        "counts": counts,
        "rates": rates,
        "wilson_95_intervals": intervals,
        "conditional_valid_detection_delay_samples": {
            "contributing_trajectory_count": len(delays),
            "mean": None if not delays else float(sum(delays) / len(delays)),
            **_percentiles(delays),
        },
        "restricted_post_onset_time_to_detection": {
            "contributing_non_fp_trajectory_count": len(restricted),
            "miss_assignment_samples": trace_length - onset,
            "mean": None if not restricted else float(sum(restricted) / len(restricted)),
            **_percentiles(restricted),
        },
    }


def evaluate_normal_admission(
    *,
    dmreda_fp_count: int,
    dmreda_restricted_sum: int,
    baseline_results: Mapping[str, tuple[int, int]],
    run_count: int = 500,
    dmreda_max_fp_count: int = 25,
    baseline_max_fp_difference: int = 10,
    baseline_max_restricted_sum_difference: int = 48 * 500,
) -> dict[str, object]:
    """Apply exact integer normal-risk gates without floating boundary drift."""

    if run_count <= 0:
        raise ValueError("run_count must be positive")
    if not (0 <= dmreda_fp_count <= run_count):
        raise ValueError("invalid DMREDA false-positive count")
    dmreda_passed = dmreda_fp_count <= dmreda_max_fp_count
    references: dict[str, object] = {}
    for name in sorted(baseline_results):
        fp_count, restricted_sum = baseline_results[name]
        if not (0 <= fp_count <= run_count):
            raise ValueError(f"invalid {name} false-positive count")
        fp_difference = abs(fp_count - dmreda_fp_count)
        restricted_difference = abs(restricted_sum - dmreda_restricted_sum)
        passed = (
            dmreda_passed
            and fp_difference <= baseline_max_fp_difference
            and restricted_difference <= baseline_max_restricted_sum_difference
        )
        references[name] = {
            "false_positive_count": fp_count,
            "restricted_time_sum": restricted_sum,
            "absolute_fp_count_difference": fp_difference,
            "absolute_restricted_time_sum_difference": restricted_difference,
            "admitted": passed,
        }
    return {
        "run_count": run_count,
        "dmreda": {
            "false_positive_count": dmreda_fp_count,
            "restricted_time_sum": dmreda_restricted_sum,
            "max_false_positive_count": dmreda_max_fp_count,
            "passed": dmreda_passed,
        },
        "reference_limits": {
            "max_fp_count_difference": baseline_max_fp_difference,
            "max_restricted_time_sum_difference": baseline_max_restricted_sum_difference,
        },
        "scalar_evidence_references": references,
        "all_references_admitted": dmreda_passed
        and bool(references)
        and all(bool(value["admitted"]) for value in references.values()),
    }


def evaluate_normal_admission_v2(
    *,
    dmreda_false_authority_count: int,
    dmreda_restricted_time_sum: int,
    reference_results: Mapping[str, tuple[int, int]],
    reference_contracts_valid: Mapping[str, bool],
    run_count: int = 500,
    dmreda_max_false_authority_count: int = 25,
    reference_max_count_difference: int = 10,
    reference_max_restricted_sum_difference: int = 24_000,
    horizon: int = 960,
) -> dict[str, object]:
    """Apply Stage 3.3 primary and per-reference normal admission separately."""

    required = {"rms", "cusum", "ewma"}
    if set(reference_results) != required or set(reference_contracts_valid) != required:
        raise ValueError("Stage 3.3 requires exact RMS, CUSUM, and EWMA records")
    if run_count <= 0:
        raise ValueError("run_count must be positive")
    if isinstance(horizon, bool) or not isinstance(horizon, int) or horizon <= 0:
        raise ValueError("horizon must be a positive integer")
    if not 0 <= dmreda_false_authority_count <= run_count:
        raise ValueError("invalid DMREDA false-authority count")
    if isinstance(dmreda_restricted_time_sum, bool) or not isinstance(
        dmreda_restricted_time_sum, int
    ):
        raise TypeError("DMREDA restricted-time sum must be an integer")
    if not 0 <= dmreda_restricted_time_sum <= run_count * horizon:
        raise ValueError("DMREDA restricted-time sum lies outside the finite horizon")
    primary_admitted = (
        dmreda_false_authority_count <= dmreda_max_false_authority_count
    )
    references: dict[str, object] = {}
    for name in sorted(required):
        count, restricted_sum = reference_results[name]
        if not 0 <= count <= run_count:
            raise ValueError(f"invalid {name} false-authority count")
        if isinstance(restricted_sum, bool) or not isinstance(restricted_sum, int):
            raise TypeError(f"{name} restricted-time sum must be an integer")
        if not 0 <= restricted_sum <= run_count * horizon:
            raise ValueError(f"{name} restricted-time sum lies outside the finite horizon")
        if not isinstance(reference_contracts_valid[name], bool):
            raise TypeError(f"{name} contract-valid flag must be boolean")
        count_difference = abs(count - dmreda_false_authority_count)
        restricted_difference = abs(restricted_sum - dmreda_restricted_time_sum)
        risk_matched = (
            count_difference <= reference_max_count_difference
            and restricted_difference <= reference_max_restricted_sum_difference
        )
        admitted = risk_matched and reference_contracts_valid[name]
        references[name] = {
            "false_authority_count": count,
            "restricted_time_sum": restricted_sum,
            "absolute_false_authority_count_difference": count_difference,
            "absolute_restricted_time_sum_difference": restricted_difference,
            "risk_matched": risk_matched,
            "contracts_valid": reference_contracts_valid[name],
            "admission_status": (
                "admitted_reference" if admitted else "not_admitted_reference"
            ),
            "confirmatory_bank_d_pairwise_authorized": (
                primary_admitted and admitted
            ),
        }
    admitted_names = [
        name
        for name, value in references.items()
        if value["admission_status"] == "admitted_reference"
    ]
    return {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.normal_authority_admission",
        "run_count": run_count,
        "primary_dmreda": {
            "false_authority_count": dmreda_false_authority_count,
            "restricted_time_sum": dmreda_restricted_time_sum,
            "max_false_authority_count": dmreda_max_false_authority_count,
            "admitted": primary_admitted,
        },
        "reference_limits": {
            "max_false_authority_count_difference": reference_max_count_difference,
            "max_restricted_time_sum_difference": (
                reference_max_restricted_sum_difference
            ),
        },
        "scalar_evidence_references": references,
        "admitted_reference_allowlist": admitted_names,
        "all_references_admitted": len(admitted_names) == len(required),
        "primary_bank_d_veto_from_reference_failure": False,
        "added_value_beyond_scalar_references_claim_authorized": (
            primary_admitted and bool(admitted_names)
        ),
    }


def _authority_outcome_summary(
    rows: Sequence[Mapping[str, object]], *, onset_index: int, trace_length: int
) -> dict[str, object]:
    suffix = str(onset_index)
    outcome_key = f"outcome_onset_{suffix}"
    latency_key = f"latency_onset_{suffix}"
    categories = ("false_authority", "valid_authority", "no_authority")
    counts = {
        category: sum(row[outcome_key] == category for row in rows)
        for category in categories
    }
    total = len(rows)
    if sum(counts.values()) != total:
        raise ValueError("dual-boundary outcome accounting is not exhaustive")
    latencies = [
        row[latency_key]
        for row in rows
        if row[outcome_key] == "valid_authority"
    ]
    if any(isinstance(value, bool) or not isinstance(value, int) for value in latencies):
        raise ValueError("valid-authority latency is malformed")
    restricted = [
        row[latency_key]
        if row[outcome_key] == "valid_authority"
        else trace_length - onset_index
        for row in rows
        if row[outcome_key] != "false_authority"
    ]
    return {
        "onset_index": onset_index,
        "trajectory_count": total,
        "counts": counts,
        "rates": {name: count / total for name, count in counts.items()},
        "wilson_95_intervals": {
            name: list(wilson_interval(count, total))
            for name, count in counts.items()
        },
        "conditional_valid_authority_latency_samples": {
            "contributing_trajectory_count": len(latencies),
            "mean": None if not latencies else float(sum(latencies) / len(latencies)),
            **_percentiles(latencies),
        },
        "restricted_post_onset_time_to_authority": {
            "contributing_non_false_authority_count": len(restricted),
            "no_authority_assignment_samples": trace_length - onset_index,
            "mean": None if not restricted else float(sum(restricted) / len(restricted)),
            **_percentiles(restricted),
        },
    }


def summarize_dual_boundary_rows(
    rows: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    """Summarize one fault/evidence-channel group under both co-equal onsets."""

    if not rows:
        raise ValueError("dual-boundary summary requires at least one row")
    from stage3.tep.dual_boundary import (
        BOUNDARY_SENSITIVITY_CATEGORIES,
        validate_dual_boundary_row,
    )

    trace_lengths = {row.get("sample_count") for row in rows}
    if len(trace_lengths) != 1:
        raise ValueError("dual-boundary rows must share one trace length")
    trace_length = next(iter(trace_lengths))
    if isinstance(trace_length, bool) or not isinstance(trace_length, int):
        raise TypeError("dual-boundary trace length must be an integer")
    for row in rows:
        validate_dual_boundary_row(row)
    category_counts = {
        category: sum(row["boundary_sensitivity_category"] == category for row in rows)
        for category in BOUNDARY_SENSITIVITY_CATEGORIES
    }
    total = len(rows)
    if sum(category_counts.values()) != total:
        raise ValueError("boundary-sensitivity accounting is not exhaustive")
    invalid_count = category_counts["invalid"]
    base: dict[str, object] = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.dual_boundary_summary",
        "trajectory_count": total,
        "boundary_sensitivity_counts": category_counts,
        "classification_flip_rate": (
            category_counts["classification_flip_at_boundary"] / total
        ),
        "invalid_count": invalid_count,
    }
    if invalid_count:
        return {
            **base,
            "status": "invalid",
            "stop_required": True,
            "reason": "one_or_more_integrity_invalid_trajectory_records",
        }

    onset_159 = _authority_outcome_summary(
        rows, onset_index=159, trace_length=trace_length
    )
    onset_160 = _authority_outcome_summary(
        rows, onset_index=160, trace_length=trace_length
    )
    flip_count = category_counts["classification_flip_at_boundary"]
    latency_only_count = category_counts["latency_shift_only"]
    false_both_count = category_counts["false_authority_under_both"]
    no_both_count = category_counts["no_authority_under_both"]
    if onset_159["counts"]["valid_authority"] != flip_count + latency_only_count:
        raise AssertionError("onset-159 valid-authority identity failed")
    if onset_160["counts"]["valid_authority"] != latency_only_count:
        raise AssertionError("onset-160 valid-authority identity failed")
    if onset_159["counts"]["false_authority"] != false_both_count:
        raise AssertionError("onset-159 false-authority identity failed")
    if onset_160["counts"]["false_authority"] != false_both_count + flip_count:
        raise AssertionError("onset-160 false-authority identity failed")
    if (
        onset_159["counts"]["no_authority"] != no_both_count
        or onset_160["counts"]["no_authority"] != no_both_count
    ):
        raise AssertionError("no-authority boundary identity failed")
    return {
        **base,
        "status": "complete",
        "stop_required": False,
        "valid_authority_under_both_count": latency_only_count,
        "false_authority_under_both_count": false_both_count,
        "no_authority_under_both_count": no_both_count,
        "onset_159": onset_159,
        "onset_160": onset_160,
        "exact_differences": {
            "authority_coverage_rate_onset_159_minus_160": flip_count / total,
            "false_authority_rate_onset_159_minus_160": -flip_count / total,
            "no_authority_rate_onset_159_minus_160": 0.0,
        },
        "onset_effect_interpretation": (
            "exact_boundary_invariant"
            if flip_count == 0
            else "requires_claim_level_interpretation"
        ),
    }


def classify_boundary_interpretation(
    *,
    classification_flip_count: int,
    final_evidence_category_same: bool,
    high_level_conclusions_same: bool,
    admitted_reference_interpretations_same: bool,
    no_claim_unique_to_one_boundary: bool,
) -> str:
    """Apply the qualitative boundary interpretation without a hidden threshold."""

    if isinstance(classification_flip_count, bool) or not isinstance(
        classification_flip_count, int
    ) or classification_flip_count < 0:
        raise ValueError("classification_flip_count must be a non-negative integer")
    flags = (
        final_evidence_category_same,
        high_level_conclusions_same,
        admitted_reference_interpretations_same,
        no_claim_unique_to_one_boundary,
    )
    if any(not isinstance(flag, bool) for flag in flags):
        raise TypeError("boundary interpretation inputs must be explicit booleans")
    if classification_flip_count == 0:
        return "exact_boundary_invariant"
    if all(flags):
        return "conclusion_boundary_robust"
    return "boundary_material"


def paired_outcome_table(
    dmreda: Sequence[RunOutcome], baseline: Sequence[RunOutcome]
) -> dict[str, dict[str, int]]:
    """Return the complete 3-by-3 paired outcome contingency table."""

    if len(dmreda) != len(baseline) or not dmreda:
        raise ValueError("paired outcome vectors must be non-empty and aligned")
    table = {
        left: {right: 0 for right in OUTCOME_CATEGORIES}
        for left in OUTCOME_CATEGORIES
    }
    for left, right in zip(dmreda, baseline):
        table[left.outcome][right.outcome] += 1
    if sum(sum(row.values()) for row in table.values()) != len(dmreda):
        raise AssertionError("paired table accounting failed")
    return table


def deterministic_endpoint_seed(
    base_seed: int, *, fault: str, comparator: str, endpoint: str
) -> int:
    identity = f"dmreda-stage3-bootstrap-v1\0{base_seed}\0{fault}\0{comparator}\0{endpoint}"
    return int.from_bytes(hashlib.sha256(identity.encode("utf-8")).digest()[:8], "big")


def _exact_discordance_pvalue(left_only: int, right_only: int) -> float | None:
    discordant = left_only + right_only
    if discordant == 0:
        return None
    try:
        from scipy.stats import binomtest

        return float(binomtest(min(left_only, right_only), discordant, 0.5).pvalue)
    except ImportError:  # pragma: no cover - pinned scientific environment has SciPy
        probability = sum(
            math.comb(discordant, index) for index in range(min(left_only, right_only) + 1)
        ) / (2**discordant)
        return float(min(1.0, 2.0 * probability))


def _bootstrap_difference_intervals(
    differences: np.ndarray, *, seed: int, replicates: int
) -> dict[str, list[float] | int]:
    if replicates <= 0:
        raise ValueError("bootstrap replicates must be positive")
    # Canonicalize paired values so a harmless trajectory-order change cannot
    # perturb the fixed-seed resampling stream.
    differences = np.sort(np.asarray(differences, dtype=np.float64))
    rng = np.random.default_rng(seed)
    count = int(differences.size)
    means = np.empty(replicates, dtype=np.float64)
    medians = np.empty(replicates, dtype=np.float64)
    for index in range(replicates):
        resample = differences[rng.integers(0, count, size=count)]
        means[index] = np.mean(resample)
        medians[index] = np.median(resample)
    return {
        "replicates": replicates,
        "mean_difference_95_interval": [
            float(value) for value in np.quantile(means, [0.025, 0.975])
        ],
        "median_difference_95_interval": [
            float(value) for value in np.quantile(medians, [0.025, 0.975])
        ],
    }


def paired_comparison(
    dmreda: Sequence[RunOutcome],
    baseline: Sequence[RunOutcome],
    *,
    fault: str,
    comparator: str,
    base_seed: int = 20260805,
    bootstrap_replicates: int = 10000,
) -> dict[str, object]:
    """Compare authority outcomes and jointly valid delays without category loss."""

    table = paired_outcome_table(dmreda, baseline)
    dm_fp_baseline_not = sum(
        table["false_positive"][category]
        for category in ("valid_detection", "miss")
    )
    baseline_fp_dm_not = sum(
        table[category]["false_positive"]
        for category in ("valid_detection", "miss")
    )
    dm_detect_baseline_miss = table["valid_detection"]["miss"]
    baseline_detect_dm_miss = table["miss"]["valid_detection"]

    differences = np.asarray(
        [
            int(left.delay_samples) - int(right.delay_samples)
            for left, right in zip(dmreda, baseline)
            if left.detected and right.detected
        ],
        dtype=np.float64,
    )
    delay: dict[str, object] = {
        "jointly_valid_detection_count": int(differences.size),
        "dmreda_faster_count": int(np.sum(differences < 0.0)),
        "tie_count": int(np.sum(differences == 0.0)),
        "reference_faster_count": int(np.sum(differences > 0.0)),
        "mean_dmreda_minus_reference": None,
        "median_dmreda_minus_reference": None,
        "difference_percentiles": _percentiles(differences.tolist()),
        "bootstrap": None,
        "wilcoxon": None,
    }
    if differences.size:
        delay["mean_dmreda_minus_reference"] = float(np.mean(differences))
        delay["median_dmreda_minus_reference"] = float(np.median(differences))
        bootstrap_seed = deterministic_endpoint_seed(
            base_seed, fault=fault, comparator=comparator, endpoint="paired_delay"
        )
        delay["bootstrap"] = {
            "seed": bootstrap_seed,
            **_bootstrap_difference_intervals(
                differences, seed=bootstrap_seed, replicates=bootstrap_replicates
            ),
        }
        if np.all(differences == 0.0):
            delay["wilcoxon"] = {
                "p_value": None,
                "statistic": None,
                "reason": "all_paired_differences_are_zero",
            }
        else:
            try:
                from scipy.stats import wilcoxon

                result = wilcoxon(differences)
                delay["wilcoxon"] = {
                    "p_value": float(result.pvalue),
                    "statistic": float(result.statistic),
                    "reason": None,
                }
            except (ImportError, ValueError) as error:
                delay["wilcoxon"] = {
                    "p_value": None,
                    "statistic": None,
                    "reason": f"not_computable:{type(error).__name__}",
                }

    return {
        "trajectory_count": len(dmreda),
        "outcome_table_dmreda_rows_reference_columns": table,
        "early_false_authority_discordance": {
            "dmreda_only": dm_fp_baseline_not,
            "reference_only": baseline_fp_dm_not,
            "exact_p_value": _exact_discordance_pvalue(
                dm_fp_baseline_not, baseline_fp_dm_not
            ),
        },
        "non_fp_detection_discordance": {
            "dmreda_detects_reference_misses": dm_detect_baseline_miss,
            "reference_detects_dmreda_misses": baseline_detect_dm_miss,
            "exact_p_value": _exact_discordance_pvalue(
                dm_detect_baseline_miss, baseline_detect_dm_miss
            ),
        },
        "paired_valid_detection_delay": delay,
    }


def holm_adjust(p_values: Mapping[str, float | None]) -> dict[str, float | None]:
    """Holm-adjust one preregistered family while preserving null entries."""

    finite: list[tuple[str, float]] = []
    for name, value in p_values.items():
        if value is None:
            continue
        numeric = float(value)
        if not math.isfinite(numeric) or not 0.0 <= numeric <= 1.0:
            raise ValueError(f"invalid p-value for {name}")
        finite.append((name, numeric))
    finite.sort(key=lambda item: (item[1], item[0]))
    adjusted: dict[str, float | None] = {name: None for name in p_values}
    running = 0.0
    count = len(finite)
    for rank, (name, value) in enumerate(finite):
        candidate = min(1.0, (count - rank) * value)
        running = max(running, candidate)
        adjusted[name] = running
    return adjusted
