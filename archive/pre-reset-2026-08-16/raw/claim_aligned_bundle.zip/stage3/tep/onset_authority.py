"""Fail-closed onset-boundary contracts for the Rieth TEP V1 campaign.

This module performs label/index bookkeeping only.  It does not read TEP
values, construct detector inputs, or authorize scientific data access.
"""

from __future__ import annotations

from typing import Mapping

from stage3.admission.contracts import SHA256_PATTERN
from stage3.admission.serialization import canonical_json_bytes


DUAL_BOUNDARY_STATUS = "unresolved_but_dual_boundary_permitted"
DUAL_BOUNDARY_CONTRACT_STATUS = "frozen_dual_boundary_fallback"

_EXPECTED_CANDIDATES = (
    {
        "mapping_id": "label_160_index_159",
        "final_pre_fault_sample_label": 159,
        "first_fault_affected_sample_label": 160,
        "python_onset_index": 159,
    },
    {
        "mapping_id": "label_161_index_160",
        "final_pre_fault_sample_label": 160,
        "first_fault_affected_sample_label": 161,
        "python_onset_index": 160,
    },
)


def sample_label_to_python_index(
    sample_label: int, *, first_sample_label: int = 1
) -> int:
    """Map an integer dataset label to a zero-based Python index.

    Rieth V1 labels samples from one, so labels 160 and 161 map to indices
    159 and 160 respectively.  The explicit origin prevents an indexing
    convention from being inferred at a scientific boundary.
    """

    for value, name in (
        (sample_label, "sample_label"),
        (first_sample_label, "first_sample_label"),
    ):
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(f"{name} must be an integer")
    if first_sample_label < 0:
        raise ValueError("first_sample_label must be non-negative")
    if sample_label < first_sample_label:
        raise ValueError("sample_label precedes the declared label origin")
    return sample_label - first_sample_label


def build_dual_boundary_contract(
    *,
    frozen_at_utc: str,
    source_commit: str,
    onset_authority_evidence_sha256: str,
) -> dict[str, object]:
    """Build the non-selective fallback contract without authorizing access."""

    payload: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3_2.onset_mapping_candidate",
        "authority_decision": DUAL_BOUNDARY_STATUS,
        "contract_status": DUAL_BOUNDARY_CONTRACT_STATUS,
        "protocol_adoption_status": "pending_review_and_full_protocol_freeze",
        "frozen_at_utc": frozen_at_utc,
        "source_commit": source_commit,
        "onset_authority_evidence_sha256": onset_authority_evidence_sha256,
        "dataset_sample_labels": "one_based_1_through_960",
        "python_indices": "zero_based_0_through_959",
        "selected_mapping": None,
        "unique_primary_boundary": False,
        "candidate_mappings": [dict(candidate) for candidate in _EXPECTED_CANDIDATES],
        "execution_contract": {
            "evaluate_all_candidate_boundaries": True,
            "identical_evidence_and_detector_configurations": True,
            "report_both_result_sets": True,
            "expose_every_boundary_changed_trajectory": True,
            "post_outcome_boundary_selection_prohibited": True,
            "neither_result_is_uniquely_primary": True,
            "classify_conclusions_as_boundary_sensitive_or_insensitive": True,
        },
        "scientific_value_access_authorized": False,
        "bank_d_state_required_before_full_protocol_freeze": "sealed_unopened",
    }
    validate_dual_boundary_contract(payload)
    return payload


def validate_dual_boundary_contract(payload: Mapping[str, object]) -> None:
    """Validate the exact two-boundary fallback and its fail-closed guards."""

    if payload.get("schema_version") != "1.0.0":
        raise ValueError("unsupported onset contract schema")
    if payload.get("document_type") != "dmreda.stage3_2.onset_mapping_candidate":
        raise ValueError("unexpected onset contract document type")
    if payload.get("authority_decision") != DUAL_BOUNDARY_STATUS:
        raise ValueError("onset authority decision is not the dual-boundary outcome")
    if payload.get("contract_status") != DUAL_BOUNDARY_CONTRACT_STATUS:
        raise ValueError("dual-boundary fallback is not frozen")
    if payload.get("protocol_adoption_status") != (
        "pending_review_and_full_protocol_freeze"
    ):
        raise ValueError("full protocol adoption state is invalid")
    frozen_at_utc = payload.get("frozen_at_utc")
    if not isinstance(frozen_at_utc, str) or not frozen_at_utc.endswith("Z"):
        raise ValueError("frozen_at_utc must be an explicit UTC timestamp")
    source_commit = payload.get("source_commit")
    if not (
        isinstance(source_commit, str)
        and len(source_commit) == 40
        and all(character in "0123456789abcdef" for character in source_commit)
    ):
        raise ValueError("source_commit must be a lowercase Git SHA-1 identity")
    evidence_sha256 = payload.get("onset_authority_evidence_sha256")
    if not isinstance(evidence_sha256, str) or not SHA256_PATTERN.fullmatch(
        evidence_sha256
    ):
        raise ValueError("onset evidence binding must be a lowercase SHA-256")

    if payload.get("dataset_sample_labels") != "one_based_1_through_960":
        raise ValueError("dataset label origin is not frozen")
    if payload.get("python_indices") != "zero_based_0_through_959":
        raise ValueError("Python index origin is not frozen")
    if payload.get("selected_mapping") is not None:
        raise ValueError("an unresolved fallback cannot select a mapping")
    if payload.get("unique_primary_boundary") is not False:
        raise ValueError("neither boundary may be uniquely primary")

    candidates = payload.get("candidate_mappings")
    if candidates != list(_EXPECTED_CANDIDATES):
        raise ValueError("candidate boundaries differ from the frozen contract")
    for candidate in _EXPECTED_CANDIDATES:
        affected = candidate["first_fault_affected_sample_label"]
        if sample_label_to_python_index(affected) != candidate["python_onset_index"]:
            raise ValueError("candidate label/index mapping is inconsistent")
        if candidate["final_pre_fault_sample_label"] + 1 != affected:
            raise ValueError("candidate boundary labels are not adjacent")

    execution = payload.get("execution_contract")
    required_guards = {
        "evaluate_all_candidate_boundaries",
        "identical_evidence_and_detector_configurations",
        "report_both_result_sets",
        "expose_every_boundary_changed_trajectory",
        "post_outcome_boundary_selection_prohibited",
        "neither_result_is_uniquely_primary",
        "classify_conclusions_as_boundary_sensitive_or_insensitive",
    }
    if not isinstance(execution, Mapping) or set(execution) != required_guards:
        raise ValueError("dual-boundary execution guards are incomplete")
    if any(execution[guard] is not True for guard in required_guards):
        raise ValueError("every dual-boundary execution guard must be enabled")
    if payload.get("scientific_value_access_authorized") is not False:
        raise ValueError("the onset fallback must not authorize scientific access")
    if payload.get("bank_d_state_required_before_full_protocol_freeze") != (
        "sealed_unopened"
    ):
        raise ValueError("Bank D must remain sealed before full protocol freeze")

    canonical_json_bytes(payload)
