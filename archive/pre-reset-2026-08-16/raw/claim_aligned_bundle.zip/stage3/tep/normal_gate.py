"""Independent normal-authority evaluation for the Stage 3.3 TEP campaign.

The functions in this module keep three authorities separate:

* the R extractor owns raw-table schema and row ordering;
* the frozen affine contract owns raw ``xmeas_7`` to Core input conversion;
* each evidence channel owns its native event semantics.

No onset or disturbed label is accepted anywhere in this module.  A confirmed
event on a normal trajectory is unnecessary external authority; a run with no
event is explicitly right-censored at its finite horizon.
"""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
import csv
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import gzip
import hashlib
import math
from pathlib import Path
from typing import Any, Final, Iterator, Mapping, Sequence

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    EventGateConfig,
    calibrate_baseline_suite_to_run_risk,
    signal_bank_hash,
)
from gold_line.core.dmreda_reference_clean import compute_dmreda_reference
from stage3.admission.serialization import canonical_sha256
from stage3.tep.authority_runner import (
    AuthorityTrajectoryInput,
    generate_onset_independent_authority,
)
from stage3.tep.configuration import (
    FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
    FROZEN_TEP_CONFIGURATION_SHA256,
    apply_tep_affine_scale,
    build_tep_core_kwargs,
)
from stage3.tep.extraction import SCALAR_COLUMNS, sha256_file
from stage3.tep.runner import DetectorSpec, MAX_PROCESS_WORKERS
from stage3.tep.statistics import evaluate_normal_admission_v2, wilson_interval


NORMAL_RESULT_SCHEMA_VERSION: Final[str] = "dmreda.stage3_3.normal-authority-row.v1"
NORMAL_SUMMARY_SCHEMA_VERSION: Final[str] = "dmreda.stage3_3.normal-authority-summary.v1"
REFERENCE_CALIBRATION_SCHEMA_VERSION: Final[str] = (
    "dmreda.stage3_3.scalar-reference-calibration.v1"
)
FROZEN_REFERENCE_GATE: Final[EventGateConfig] = EventGateConfig(
    warmup_samples=92,
    persistence=20,
    refractory=80,
)
FROZEN_CALIBRATION_RUNS: Final[tuple[int, int]] = (101, 200)
FROZEN_CALIBRATION_HORIZON: Final[int] = 500
FROZEN_CALIBRATION_TARGET_COUNT: Final[int] = 3
FROZEN_CALIBRATION_TARGET_RESTRICTED_SUM: Final[int] = 49_283
FROZEN_NORMAL_RUN_COUNT: Final[int] = 500
FROZEN_NORMAL_HORIZON: Final[int] = 960


def _validate_digest(value: str, name: str, *, length: int = 64) -> None:
    if not isinstance(value, str) or len(value) != length or any(
        character not in "0123456789abcdef" for character in value
    ):
        raise ValueError(f"{name} must be lowercase hexadecimal length {length}")


def _parse_identity(value: str, *, name: str, row_number: int) -> int:
    if not value or value != value.strip():
        raise ValueError(f"empty or padded {name} at CSV row {row_number}")
    try:
        number = Decimal(value)
    except InvalidOperation as error:
        raise ValueError(f"invalid {name} at CSV row {row_number}") from error
    if not number.is_finite() or number != number.to_integral_value():
        raise ValueError(f"non-integral {name} at CSV row {row_number}")
    parsed = int(number)
    minimum = 0 if name == "faultNumber" else 1
    if parsed < minimum or str(parsed) != value:
        raise ValueError(f"non-canonical {name} at CSV row {row_number}")
    return parsed


def _parse_sample(value: str, *, row_number: int) -> float:
    if not value or value != value.strip():
        raise ValueError(f"empty or padded xmeas_7 at CSV row {row_number}")
    try:
        parsed = float(value)
    except ValueError as error:
        raise ValueError(f"invalid xmeas_7 at CSV row {row_number}") from error
    if not math.isfinite(parsed):
        raise ValueError(f"non-finite xmeas_7 at CSV row {row_number}")
    return parsed


@dataclass(frozen=True)
class RawScalarTrajectory:
    """One independent Rieth trajectory before fixed affine scaling."""

    partition: str
    fault_number: int
    simulation_run: int
    raw_samples: tuple[float, ...]

    def __post_init__(self) -> None:
        if self.partition not in {
            "fault_free_training",
            "fault_free_testing",
            "faulty_training",
            "faulty_testing",
            "synthetic",
        }:
            raise ValueError("partition is not a recognized TEP role")
        if isinstance(self.fault_number, bool) or not isinstance(
            self.fault_number, int
        ) or self.fault_number < 0:
            raise ValueError("fault_number must be a non-negative integer")
        if isinstance(self.simulation_run, bool) or not isinstance(
            self.simulation_run, int
        ) or self.simulation_run < 1:
            raise ValueError("simulation_run must be a positive integer")
        values = np.asarray(self.raw_samples, dtype=np.float64)
        if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
            raise ValueError("raw_samples must be a non-empty finite vector")

    @property
    def trajectory_identifier(self) -> str:
        return (
            f"tep-rieth-v1/{self.partition}/"
            f"fault_{self.fault_number:02d}/run_{self.simulation_run:03d}"
        )

    @property
    def authority_input(self) -> AuthorityTrajectoryInput:
        return AuthorityTrajectoryInput.from_raw_xmeas_7(
            fault_number=self.fault_number,
            simulation_run=self.simulation_run,
            trajectory_identifier=self.trajectory_identifier,
            raw_samples=self.raw_samples,
        )

    @property
    def raw_sample_sha256(self) -> str:
        value = self.authority_input.raw_sample_sha256
        assert value is not None
        return value


@dataclass(frozen=True)
class ScalarBank:
    """A strictly validated scalar extract with an optional retained run subset."""

    extract_sha256: str
    partition: str
    fault_numbers: tuple[int, ...]
    runs_per_fault: int
    horizon: int
    total_row_count: int
    trajectories: tuple[RawScalarTrajectory, ...]
    retained_simulation_runs: tuple[int, ...]
    bank_sha256: str


def _raw_bank_sha256(trajectories: Sequence[RawScalarTrajectory]) -> str:
    payload = [
        {
            "faultNumber": trajectory.fault_number,
            "partition": trajectory.partition,
            "simulationRun": trajectory.simulation_run,
            "trajectory_identifier": trajectory.trajectory_identifier,
            "raw_sample_sha256": trajectory.raw_sample_sha256,
            "sample_count": len(trajectory.raw_samples),
        }
        for trajectory in trajectories
    ]
    return canonical_sha256(
        {
            "schema": "dmreda-stage3-raw-scalar-bank-v1",
            "ordered_trajectories": payload,
        }
    )


def load_scalar_bank(
    path: Path,
    *,
    partition: str,
    expected_fault_numbers: Sequence[int],
    expected_runs_per_fault: int,
    expected_horizon: int,
    retain_simulation_runs: Sequence[int] | None = None,
    expected_extract_sha256: str | None = None,
) -> ScalarBank:
    """Stream and validate one complete sorted scalar extract.

    Every source row is validated even when only a calibration subset is
    retained.  Recording ownership is established before filtering; slicing a
    single recording into pseudo-independent units is therefore impossible.
    """

    path = Path(path)
    if partition not in {
        "fault_free_training",
        "fault_free_testing",
        "faulty_training",
        "faulty_testing",
        "synthetic",
    }:
        raise ValueError("partition is not a recognized TEP role")
    actual_extract_sha256 = sha256_file(path)
    if partition != "synthetic":
        if expected_extract_sha256 is None:
            raise ValueError("scientific scalar loading requires a frozen extract hash")
        _validate_digest(expected_extract_sha256, "expected_extract_sha256")
        if actual_extract_sha256 != expected_extract_sha256:
            raise ValueError("scalar extract hash differs from its frozen manifest")
    elif expected_extract_sha256 is not None:
        _validate_digest(expected_extract_sha256, "expected_extract_sha256")
        if actual_extract_sha256 != expected_extract_sha256:
            raise ValueError("synthetic scalar extract hash mismatch")
    faults = tuple(expected_fault_numbers)
    if not faults or faults != tuple(sorted(set(faults))) or any(
        isinstance(value, bool) or not isinstance(value, int) or value < 0
        for value in faults
    ):
        raise ValueError("expected_fault_numbers must be unique sorted integers")
    for value, name in (
        (expected_runs_per_fault, "expected_runs_per_fault"),
        (expected_horizon, "expected_horizon"),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"{name} must be a positive integer")
    retained = (
        tuple(range(1, expected_runs_per_fault + 1))
        if retain_simulation_runs is None
        else tuple(retain_simulation_runs)
    )
    if not retained or retained != tuple(sorted(set(retained))) or any(
        isinstance(value, bool)
        or not isinstance(value, int)
        or not 1 <= value <= expected_runs_per_fault
        for value in retained
    ):
        raise ValueError("retained simulation runs are invalid")
    retained_set = set(retained)
    trajectories: list[RawScalarTrajectory] = []
    row_count = 0

    try:
        with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle, strict=True)
            try:
                header = next(reader)
            except StopIteration as error:
                raise ValueError("scalar extract is empty") from error
            if tuple(header) != SCALAR_COLUMNS:
                raise ValueError("scalar extract header or column order is invalid")

            for fault_number in faults:
                for simulation_run in range(1, expected_runs_per_fault + 1):
                    samples: list[float] | None = (
                        [] if simulation_run in retained_set else None
                    )
                    for sample_label in range(1, expected_horizon + 1):
                        try:
                            row = next(reader)
                        except StopIteration as error:
                            raise ValueError("scalar extract ended before its declared shape") from error
                        row_number = row_count + 2
                        if len(row) != len(SCALAR_COLUMNS):
                            raise ValueError(
                                f"invalid column count at CSV row {row_number}"
                            )
                        observed = (
                            _parse_identity(
                                row[0], name="faultNumber", row_number=row_number
                            ),
                            _parse_identity(
                                row[1], name="simulationRun", row_number=row_number
                            ),
                            _parse_identity(row[2], name="sample", row_number=row_number),
                        )
                        expected = (fault_number, simulation_run, sample_label)
                        if observed != expected:
                            raise ValueError(
                                f"scalar identity mismatch at CSV row {row_number}: "
                                f"expected {expected}, observed {observed}"
                            )
                        value = _parse_sample(row[3], row_number=row_number)
                        if samples is not None:
                            samples.append(value)
                        row_count += 1
                    if samples is not None:
                        trajectories.append(
                            RawScalarTrajectory(
                                partition=partition,
                                fault_number=fault_number,
                                simulation_run=simulation_run,
                                raw_samples=tuple(samples),
                            )
                        )
            try:
                extra = next(reader)
            except StopIteration:
                extra = None
            if extra is not None:
                raise ValueError("scalar extract contains rows beyond its declared shape")
    except (gzip.BadGzipFile, EOFError) as error:
        raise ValueError("invalid or truncated gzip scalar extract") from error

    expected_rows = len(faults) * expected_runs_per_fault * expected_horizon
    if row_count != expected_rows:
        raise AssertionError("validated scalar row count differs from declared shape")
    if sha256_file(path) != actual_extract_sha256:
        raise ValueError("scalar extract changed while it was being consumed")
    expected_retained = len(faults) * len(retained)
    if len(trajectories) != expected_retained:
        raise AssertionError("retained trajectory count is inconsistent")
    return ScalarBank(
        extract_sha256=actual_extract_sha256,
        partition=partition,
        fault_numbers=faults,
        runs_per_fault=expected_runs_per_fault,
        horizon=expected_horizon,
        total_row_count=row_count,
        trajectories=tuple(trajectories),
        retained_simulation_runs=retained,
        bank_sha256=_raw_bank_sha256(trajectories),
    )


def iter_scalar_fault_groups(
    path: Path,
    *,
    partition: str,
    expected_fault_numbers: Sequence[int],
    expected_runs_per_fault: int,
    expected_horizon: int,
    expected_extract_sha256: str,
) -> Iterator[tuple[RawScalarTrajectory, ...]]:
    """Validate the full extract, then yield one bounded fault group at a time."""

    faults = tuple(expected_fault_numbers)
    load_scalar_bank(
        path,
        partition=partition,
        expected_fault_numbers=faults,
        expected_runs_per_fault=expected_runs_per_fault,
        expected_horizon=expected_horizon,
        retain_simulation_runs=(1,),
        expected_extract_sha256=expected_extract_sha256,
    )
    with gzip.open(Path(path), "rt", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle, strict=True)
        try:
            header = next(reader)
        except StopIteration as error:  # pragma: no cover - first pass owns this case
            raise ValueError("scalar extract changed after validation") from error
        if tuple(header) != SCALAR_COLUMNS:
            raise ValueError("scalar extract header changed after validation")
        row_count = 0
        for fault_number in faults:
            trajectories: list[RawScalarTrajectory] = []
            for simulation_run in range(1, expected_runs_per_fault + 1):
                samples: list[float] = []
                for sample_label in range(1, expected_horizon + 1):
                    try:
                        row = next(reader)
                    except StopIteration as error:
                        raise ValueError("scalar extract changed after validation") from error
                    row_number = row_count + 2
                    if len(row) != len(SCALAR_COLUMNS):
                        raise ValueError("scalar extract changed after validation")
                    observed = (
                        _parse_identity(
                            row[0], name="faultNumber", row_number=row_number
                        ),
                        _parse_identity(
                            row[1], name="simulationRun", row_number=row_number
                        ),
                        _parse_identity(row[2], name="sample", row_number=row_number),
                    )
                    if observed != (fault_number, simulation_run, sample_label):
                        raise ValueError("scalar extract identity changed after validation")
                    samples.append(_parse_sample(row[3], row_number=row_number))
                    row_count += 1
                trajectories.append(
                    RawScalarTrajectory(
                        partition=partition,
                        fault_number=fault_number,
                        simulation_run=simulation_run,
                        raw_samples=tuple(samples),
                    )
                )
            yield tuple(trajectories)
        try:
            extra = next(reader)
        except StopIteration:
            extra = None
        if extra is not None:
            raise ValueError("scalar extract gained rows after validation")
    if sha256_file(Path(path)) != expected_extract_sha256:
        raise ValueError("scalar extract changed during fault-group consumption")


def _detector_from_calibration(name: str, calibrated: Any) -> DetectorSpec:
    parameters = dict(calibrated.frozen_parameters)
    if name == "rms":
        return DetectorSpec.rms(
            threshold=calibrated.threshold,
            gate=calibrated.gate,
            window=int(parameters["window"]),
        )
    if name == "cusum":
        return DetectorSpec.cusum(
            threshold=calibrated.threshold,
            gate=calibrated.gate,
            center=float(parameters["center"]),
            allowance=float(parameters["allowance"]),
        )
    if name == "ewma":
        return DetectorSpec.ewma(
            threshold=calibrated.threshold,
            gate=calibrated.gate,
            center=float(parameters["center"]),
            scale=float(parameters["scale"]),
            alpha=float(parameters["alpha"]),
        )
    raise ValueError(f"unsupported scalar reference: {name}")


def _structural_parameters(name: str) -> dict[str, int | float]:
    if name == "rms":
        return {"window": 32}
    if name == "cusum":
        return {
            "allowance": 0.5,
            "allowance_sigma": 0.5,
            "center": 0.0,
            "scale": 1.0,
        }
    if name == "ewma":
        return {"alpha": 2.0 / 33.0, "center": 0.0, "scale": 1.0}
    raise ValueError(f"unsupported scalar reference: {name}")


def calibrate_scalar_references(
    trajectories: Sequence[RawScalarTrajectory],
    *,
    target_false_authority_count: int = FROZEN_CALIBRATION_TARGET_COUNT,
    target_restricted_time_sum: int = FROZEN_CALIBRATION_TARGET_RESTRICTED_SUM,
    require_frozen_campaign_shape: bool = True,
) -> tuple[dict[str, object], dict[str, dict[str, object]], tuple[DetectorSpec, ...]]:
    """Calibrate only scalar thresholds on the authorized normal-training bank."""

    ordered = tuple(sorted(trajectories, key=lambda item: item.simulation_run))
    if not ordered or any(item.fault_number != 0 for item in ordered):
        raise ValueError("reference calibration requires fault-free trajectories")
    if any(
        item.partition not in {"fault_free_training", "synthetic"}
        for item in ordered
    ):
        raise ValueError("reference calibration requires fault-free training ownership")
    run_ids = tuple(item.simulation_run for item in ordered)
    if len(run_ids) != len(set(run_ids)):
        raise ValueError("reference calibration trajectory identities duplicate")
    horizons = {len(item.raw_samples) for item in ordered}
    if len(horizons) != 1:
        raise ValueError("reference calibration trajectories must share one horizon")
    horizon = next(iter(horizons))
    if require_frozen_campaign_shape and (
        any(item.partition != "fault_free_training" for item in ordered)
        or run_ids != tuple(range(101, 201))
        or horizon != FROZEN_CALIBRATION_HORIZON
    ):
        raise ValueError("calibration bank is not fault-free training runs 101..200")

    scaled = tuple(apply_tep_affine_scale(item.raw_samples) for item in ordered)
    calibrated = calibrate_baseline_suite_to_run_risk(
        scaled,
        gate=FROZEN_REFERENCE_GATE,
        target_false_positive_count=target_false_authority_count,
        target_restricted_time_sum=target_restricted_time_sum,
    )
    scaled_bank_sha256 = signal_bank_hash(scaled)
    detector_specs = tuple(
        _detector_from_calibration(name, calibrated[name])
        for name in sorted(calibrated)
    )
    config_records: dict[str, dict[str, object]] = {}
    calibration_results: dict[str, object] = {}
    for detector in detector_specs:
        result = calibrated[detector.name]
        configuration = detector.to_dict()
        calibration_results[detector.name] = result.to_dict()
        config_records[detector.name] = {
            "status": "frozen_from_fault_free_training_101_200",
            "configuration": configuration,
            "configuration_sha256": canonical_sha256(configuration),
            "structural_parameters": _structural_parameters(detector.name),
            "calibration": {
                "partition": "fault_free_training",
                "simulation_runs": [101, 200],
                "trajectory_count": len(ordered),
                "horizon": horizon,
                "target_false_authority_count": target_false_authority_count,
                "target_restricted_time_sum": target_restricted_time_sum,
                "selection_objective": [
                    "absolute_false_positive_count_deviation",
                    "absolute_restricted_time_sum_deviation",
                    "higher_threshold",
                ],
                "input_bank_sha256": scaled_bank_sha256,
                "calibration_result_sha256": result.calibration.calibration_result_sha256,
            },
        }

    artifact_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": REFERENCE_CALIBRATION_SCHEMA_VERSION,
        "status": "complete_and_frozen",
        "partition": "fault_free_training",
        "simulation_runs": [run_ids[0], run_ids[-1]],
        "trajectory_count": len(ordered),
        "horizon": horizon,
        "raw_trajectory_bank_sha256": _raw_bank_sha256(ordered),
        "scaled_trajectory_bank_sha256": scaled_bank_sha256,
        "preprocessing_configuration_sha256": (
            FROZEN_TEP_AFFINE_CONFIGURATION_SHA256
        ),
        "event_gate": {
            "warmup_samples": FROZEN_REFERENCE_GATE.warmup_samples,
            "persistence": FROZEN_REFERENCE_GATE.persistence,
            "refractory": FROZEN_REFERENCE_GATE.refractory,
        },
        "target_false_authority_count": target_false_authority_count,
        "target_restricted_time_sum": target_restricted_time_sum,
        "reference_results": calibration_results,
        "frozen_reference_configurations": config_records,
    }
    artifact = dict(artifact_without_hash)
    artifact["calibration_payload_sha256"] = canonical_sha256(artifact_without_hash)
    return artifact, config_records, detector_specs


def _public_pending_open_count(pending: np.ndarray) -> int:
    previous = np.concatenate((np.array([False]), np.asarray(pending[:-1], dtype=bool)))
    return int(np.count_nonzero(np.asarray(pending, dtype=bool) & ~previous))


def _evaluate_normal_job(
    job: tuple[RawScalarTrajectory, DetectorSpec, str, str, str, str]
) -> dict[str, object]:
    trajectory, detector, input_sha256, protocol_sha256, runner_sha256, source_commit = job
    authority_input = trajectory.authority_input
    signal = np.asarray(authority_input.samples, dtype=np.float64)
    state_occupancy: dict[str, int] | None = None
    regime_transitions: int | None = None
    pending_open_count: int | None = None
    pending_sample_count: int | None = None
    confirmation_count: int | None = None

    if detector.kind == "dmreda_core":
        kwargs = build_tep_core_kwargs()
        assert detector.dmreda_mode is not None
        kwargs["mode"] = detector.dmreda_mode
        result = compute_dmreda_reference(signal, **kwargs)
        events = tuple(int(value) for value in result.event_times)
        states, counts = np.unique(result.state, return_counts=True)
        state_occupancy = {
            str(int(state)): int(count) for state, count in zip(states, counts)
        }
        regime_transitions = int(np.count_nonzero(np.diff(result.state)))
        pending_open_count = _public_pending_open_count(result.pending)
        pending_sample_count = int(np.count_nonzero(result.pending))
        confirmation_count = int(np.count_nonzero(result.confirmed))
        generated = generate_onset_independent_authority(signal, detector)
        if events != generated.authoritative_event_indices:
            raise AssertionError("normal DMREDA authority disagrees with shared generator")
    else:
        generated = generate_onset_independent_authority(signal, detector)
        events = generated.authoritative_event_indices

    first = events[0] if events else None
    sample_count = len(authority_input.samples)
    row_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": NORMAL_RESULT_SCHEMA_VERSION,
        "faultNumber": trajectory.fault_number,
        "simulationRun": trajectory.simulation_run,
        "trajectory_identifier": trajectory.trajectory_identifier,
        "evidence_channel_identifier": detector.name,
        "sample_count": sample_count,
        "raw_sample_sha256": authority_input.raw_sample_sha256,
        "scaled_sample_sha256": authority_input.sample_sha256,
        "preprocessing_configuration_sha256": (
            authority_input.preprocessing_configuration_sha256
        ),
        "configuration_sha256": detector.detector_sha256,
        "authoritative_event_indices": list(events),
        "authoritative_event_count": len(events),
        "first_authority_index": first,
        "unnecessary_authority": first is not None,
        "censored": first is None,
        "restricted_time_to_authority": sample_count if first is None else first,
        "state_occupancy_samples": state_occupancy,
        "regime_transition_count": regime_transitions,
        "pending_open_count_from_public_trace": pending_open_count,
        "pending_sample_count": pending_sample_count,
        "confirmation_count": confirmation_count,
        "input_sha256": input_sha256,
        "protocol_sha256": protocol_sha256,
        "runner_sha256": runner_sha256,
        "source_commit": source_commit,
    }
    row = dict(row_without_hash)
    row["row_sha256"] = canonical_sha256(row_without_hash)
    return row


def evaluate_normal_trajectories(
    trajectories: Sequence[RawScalarTrajectory],
    detectors: Sequence[DetectorSpec],
    *,
    input_sha256: str,
    protocol_sha256: str,
    runner_sha256: str,
    source_commit: str,
    workers: int = 1,
    require_frozen_campaign_shape: bool = True,
) -> tuple[dict[str, object], ...]:
    """Evaluate native authority on independent normal recordings."""

    _validate_digest(input_sha256, "input_sha256")
    _validate_digest(protocol_sha256, "protocol_sha256")
    _validate_digest(runner_sha256, "runner_sha256")
    _validate_digest(source_commit, "source_commit", length=40)
    if isinstance(workers, bool) or not isinstance(workers, int) or not (
        1 <= workers <= MAX_PROCESS_WORKERS
    ):
        raise ValueError(f"workers must be in [1, {MAX_PROCESS_WORKERS}]")
    ordered_trajectories = tuple(
        sorted(trajectories, key=lambda item: (item.fault_number, item.simulation_run))
    )
    ordered_detectors = tuple(sorted(detectors, key=lambda item: item.name))
    if not ordered_trajectories or not ordered_detectors:
        raise ValueError("normal evaluation requires trajectories and channels")
    if any(item.fault_number != 0 for item in ordered_trajectories):
        raise ValueError("normal evaluation cannot contain faulty trajectories")
    if any(
        item.partition not in {"fault_free_testing", "synthetic"}
        for item in ordered_trajectories
    ):
        raise ValueError("normal evaluation requires fault-free testing ownership")
    identities = [item.simulation_run for item in ordered_trajectories]
    if len(identities) != len(set(identities)):
        raise ValueError("normal trajectory identities duplicate")
    if len({item.name for item in ordered_detectors}) != len(ordered_detectors):
        raise ValueError("evidence-channel identifiers duplicate")
    if require_frozen_campaign_shape:
        if {item.name for item in ordered_detectors} != {
            "dmreda_core_d_or_g",
            "rms",
            "cusum",
            "ewma",
        }:
            raise ValueError("scientific normal evaluation requires the frozen channel set")
        primary_specs = [
            item for item in ordered_detectors if item.name == "dmreda_core_d_or_g"
        ]
        if (
            len(primary_specs) != 1
            or primary_specs[0].kind != "dmreda_core"
            or primary_specs[0].dmreda_mode != "D_OR_G"
        ):
            raise ValueError("scientific normal evaluation requires frozen D_OR_G")
    if require_frozen_campaign_shape and (
        any(item.partition != "fault_free_testing" for item in ordered_trajectories)
        or identities != list(range(1, FROZEN_NORMAL_RUN_COUNT + 1))
        or any(
            len(item.raw_samples) != FROZEN_NORMAL_HORIZON
            for item in ordered_trajectories
        )
    ):
        raise ValueError("normal bank is not FaultFree Testing runs 1..500")
    jobs = tuple(
        (
            trajectory,
            detector,
            input_sha256,
            protocol_sha256,
            runner_sha256,
            source_commit,
        )
        for trajectory in ordered_trajectories
        for detector in ordered_detectors
    )
    if workers == 1:
        rows = tuple(_evaluate_normal_job(job) for job in jobs)
    else:
        with ProcessPoolExecutor(
            max_workers=min(workers, len(jobs), MAX_PROCESS_WORKERS)
        ) as executor:
            rows = tuple(executor.map(_evaluate_normal_job, jobs, chunksize=1))
    expected = [
        (trajectory.simulation_run, detector.name)
        for trajectory in ordered_trajectories
        for detector in ordered_detectors
    ]
    observed = [
        (int(row["simulationRun"]), str(row["evidence_channel_identifier"]))
        for row in rows
    ]
    if observed != expected:
        raise AssertionError("normal result ordering changed")
    return rows


def _quantiles(values: Sequence[int]) -> dict[str, float | int | None]:
    if not values:
        return {
            "minimum": None,
            "p10": None,
            "median": None,
            "p90": None,
            "maximum": None,
        }
    array = np.asarray(values, dtype=np.float64)
    return {
        "minimum": int(np.min(array)),
        "p10": float(np.quantile(array, 0.10)),
        "median": float(np.quantile(array, 0.50)),
        "p90": float(np.quantile(array, 0.90)),
        "maximum": int(np.max(array)),
    }


def _reference_record_matches_detector(
    name: str,
    record: Mapping[str, object] | None,
    detector: DetectorSpec,
) -> bool:
    if not isinstance(record, Mapping) or set(record) != {
        "status",
        "configuration",
        "configuration_sha256",
        "structural_parameters",
        "calibration",
    }:
        return False
    configuration = detector.to_dict()
    if (
        record.get("status") != "frozen_from_fault_free_training_101_200"
        or record.get("configuration") != configuration
        or record.get("configuration_sha256") != canonical_sha256(configuration)
        or record.get("structural_parameters") != _structural_parameters(name)
    ):
        return False
    calibration = record.get("calibration")
    if not isinstance(calibration, Mapping) or set(calibration) != {
        "partition",
        "simulation_runs",
        "trajectory_count",
        "horizon",
        "target_false_authority_count",
        "target_restricted_time_sum",
        "selection_objective",
        "input_bank_sha256",
        "calibration_result_sha256",
    }:
        return False
    if (
        calibration.get("partition") != "fault_free_training"
        or calibration.get("simulation_runs") != [101, 200]
        or calibration.get("trajectory_count") != 100
        or calibration.get("horizon") != 500
        or calibration.get("target_false_authority_count") != 3
        or calibration.get("target_restricted_time_sum") != 49_283
        or calibration.get("selection_objective")
        != [
            "absolute_false_positive_count_deviation",
            "absolute_restricted_time_sum_deviation",
            "higher_threshold",
        ]
    ):
        return False
    try:
        _validate_digest(str(calibration.get("input_bank_sha256")), "input bank")
        _validate_digest(
            str(calibration.get("calibration_result_sha256")),
            "calibration result",
        )
    except ValueError:
        return False
    return True


def _validate_normal_row(
    row: Mapping[str, object],
    *,
    detector: DetectorSpec,
    require_frozen_campaign_shape: bool,
) -> None:
    required = {
        "schema_version",
        "document_type",
        "faultNumber",
        "simulationRun",
        "trajectory_identifier",
        "evidence_channel_identifier",
        "sample_count",
        "raw_sample_sha256",
        "scaled_sample_sha256",
        "preprocessing_configuration_sha256",
        "configuration_sha256",
        "authoritative_event_indices",
        "authoritative_event_count",
        "first_authority_index",
        "unnecessary_authority",
        "censored",
        "restricted_time_to_authority",
        "state_occupancy_samples",
        "regime_transition_count",
        "pending_open_count_from_public_trace",
        "pending_sample_count",
        "confirmation_count",
        "input_sha256",
        "protocol_sha256",
        "runner_sha256",
        "source_commit",
        "row_sha256",
    }
    if set(row) != required:
        raise ValueError("normal result row schema is incomplete or unexpected")
    if row.get("schema_version") != "1.0.0" or row.get("document_type") != (
        NORMAL_RESULT_SCHEMA_VERSION
    ):
        raise ValueError("normal result row version is invalid")
    if row.get("faultNumber") != 0:
        raise ValueError("normal result row contains a non-normal fault identity")
    run = row.get("simulationRun")
    horizon = row.get("sample_count")
    if (
        isinstance(run, bool)
        or not isinstance(run, int)
        or run < 1
        or isinstance(horizon, bool)
        or not isinstance(horizon, int)
        or horizon < 1
    ):
        raise ValueError("normal result identity or horizon is invalid")
    if require_frozen_campaign_shape and (run > 500 or horizon != 960):
        raise ValueError("normal result lies outside the frozen Testing shape")
    expected_identifier = (
        f"tep-rieth-v1/{'fault_free_testing' if require_frozen_campaign_shape else 'synthetic'}/"
        f"fault_00/run_{run:03d}"
    )
    if row.get("trajectory_identifier") != expected_identifier:
        raise ValueError("normal trajectory identifier is not canonical")
    if row.get("evidence_channel_identifier") != detector.name:
        raise ValueError("normal evidence-channel identity is invalid")
    if row.get("configuration_sha256") != detector.detector_sha256:
        raise ValueError("normal row configuration hash is stale")
    for name in (
        "raw_sample_sha256",
        "scaled_sample_sha256",
        "input_sha256",
        "protocol_sha256",
        "runner_sha256",
    ):
        _validate_digest(str(row.get(name)), name)
    _validate_digest(str(row.get("source_commit")), "source_commit", length=40)
    if row.get("preprocessing_configuration_sha256") != (
        FROZEN_TEP_AFFINE_CONFIGURATION_SHA256
    ):
        raise ValueError("normal row preprocessing contract is stale")
    events = row.get("authoritative_event_indices")
    if not isinstance(events, list) or any(
        isinstance(value, bool)
        or not isinstance(value, int)
        or not 0 <= value < horizon
        for value in events
    ) or events != sorted(set(events)):
        raise ValueError("normal row event list is invalid")
    if row.get("authoritative_event_count") != len(events):
        raise ValueError("normal row event count is inconsistent")
    first = events[0] if events else None
    if row.get("first_authority_index") != first:
        raise ValueError("normal row first authority is inconsistent")
    if row.get("unnecessary_authority") is not (first is not None) or row.get(
        "censored"
    ) is not (first is None):
        raise ValueError("normal authority and censoring indicators are inconsistent")
    expected_restricted = horizon if first is None else first
    if row.get("restricted_time_to_authority") != expected_restricted:
        raise ValueError("normal restricted time is inconsistent")
    metrics = (
        "regime_transition_count",
        "pending_open_count_from_public_trace",
        "pending_sample_count",
        "confirmation_count",
    )
    if detector.kind == "dmreda_core":
        occupancy = row.get("state_occupancy_samples")
        if not isinstance(occupancy, Mapping) or sum(
            int(value) for value in occupancy.values()
        ) != horizon:
            raise ValueError("DMREDA state occupancy is invalid")
        if any(
            isinstance(row.get(name), bool)
            or not isinstance(row.get(name), int)
            or int(row[name]) < 0
            for name in metrics
        ):
            raise ValueError("DMREDA normal trace metric is invalid")
        if row.get("confirmation_count") != len(events):
            raise ValueError("DMREDA confirmation and event counts disagree")
    elif row.get("state_occupancy_samples") is not None or any(
        row.get(name) is not None for name in metrics
    ):
        raise ValueError("scalar reference row contains DMREDA-only traces")
    without_hash = dict(row)
    stored = without_hash.pop("row_sha256", None)
    if stored != canonical_sha256(without_hash):
        raise ValueError("normal result row hash is invalid")


def summarize_normal_authority(
    rows: Sequence[Mapping[str, object]],
    *,
    detectors: Sequence[DetectorSpec],
    frozen_reference_configurations: Mapping[str, Mapping[str, object]] | None = None,
    require_frozen_campaign_shape: bool = True,
) -> tuple[dict[str, object], dict[str, object]]:
    """Build recording-level finite-horizon summaries and V2 admissions."""

    if not rows:
        raise ValueError("normal authority summary requires rows")
    detector_by_name = {detector.name: detector for detector in detectors}
    if len(detector_by_name) != len(detectors):
        raise ValueError("detector names duplicate")
    grouped: dict[str, list[Mapping[str, object]]] = {
        name: [] for name in detector_by_name
    }
    for row in rows:
        name = row.get("evidence_channel_identifier")
        if name not in grouped:
            raise ValueError("normal result contains an unexpected channel")
        _validate_normal_row(
            row,
            detector=detector_by_name[str(name)],
            require_frozen_campaign_shape=require_frozen_campaign_shape,
        )
        grouped[str(name)].append(row)

    expected_count = FROZEN_NORMAL_RUN_COUNT if require_frozen_campaign_shape else None
    summaries: dict[str, dict[str, object]] = {}
    for name in sorted(grouped):
        channel_rows = grouped[name]
        if expected_count is not None and len(channel_rows) != expected_count:
            raise ValueError("normal channel does not contain 500 trajectories")
        if not channel_rows:
            raise ValueError("normal channel contains no trajectories")
        simulations = [int(row["simulationRun"]) for row in channel_rows]
        if simulations != sorted(set(simulations)):
            raise ValueError("normal channel trajectory order or identity is invalid")
        expected_simulations = (
            list(range(1, FROZEN_NORMAL_RUN_COUNT + 1))
            if require_frozen_campaign_shape
            else sorted(simulations)
        )
        if simulations != expected_simulations:
            raise ValueError("normal channel simulation identities are incomplete")
        horizons = {int(row["sample_count"]) for row in channel_rows}
        if len(horizons) != 1:
            raise ValueError("normal channel horizons differ")
        horizon = next(iter(horizons))
        events = [
            int(row["first_authority_index"])
            for row in channel_rows
            if row["first_authority_index"] is not None
        ]
        false_count = len(events)
        censored_count = len(channel_rows) - false_count
        restricted = [int(row["restricted_time_to_authority"]) for row in channel_rows]
        wilson = wilson_interval(false_count, len(channel_rows))
        record: dict[str, object] = {
            "evidence_channel_identifier": name,
            "configuration_sha256": detector_by_name[name].detector_sha256,
            "trajectory_count": len(channel_rows),
            "calibration_horizon": horizon,
            "false_authority_count": false_count,
            "false_authority_rate": false_count / len(channel_rows),
            "false_authority_rate_wilson_95_interval": list(wilson),
            "censoring_count": censored_count,
            "censoring_rate": censored_count / len(channel_rows),
            "restricted_time_sum": int(sum(restricted)),
            "restricted_mean_time_to_authority": float(
                sum(restricted) / len(restricted)
            ),
            "observed_first_authority_time": _quantiles(events),
            "total_authoritative_event_count": int(
                sum(int(row["authoritative_event_count"]) for row in channel_rows)
            ),
        }
        if detector_by_name[name].kind == "dmreda_core":
            occupancy: dict[str, int] = {}
            for row in channel_rows:
                child = row["state_occupancy_samples"]
                if not isinstance(child, Mapping):
                    raise ValueError("DMREDA normal row lacks state occupancy")
                for state, count in child.items():
                    occupancy[str(state)] = occupancy.get(str(state), 0) + int(count)
            record.update(
                {
                    "state_occupancy_samples": dict(sorted(occupancy.items())),
                    "state_occupancy_rates": {
                        state: count / (len(channel_rows) * horizon)
                        for state, count in sorted(occupancy.items())
                    },
                    "regime_transition_count": int(
                        sum(int(row["regime_transition_count"]) for row in channel_rows)
                    ),
                    "pending_open_count_from_public_trace": int(
                        sum(
                            int(row["pending_open_count_from_public_trace"])
                            for row in channel_rows
                        )
                    ),
                    "pending_sample_count": int(
                        sum(int(row["pending_sample_count"]) for row in channel_rows)
                    ),
                    "confirmation_count": int(
                        sum(int(row["confirmation_count"]) for row in channel_rows)
                    ),
                }
            )
        summaries[name] = record

    dmreda_names = [
        name for name, detector in detector_by_name.items() if detector.kind == "dmreda_core"
    ]
    if len(dmreda_names) != 1:
        raise ValueError("normal gate requires exactly one DMREDA primary channel")
    dmreda_name = dmreda_names[0]
    dmreda_detector = detector_by_name[dmreda_name]
    if require_frozen_campaign_shape and (
        dmreda_name != "dmreda_core_d_or_g"
        or dmreda_detector.dmreda_mode != "D_OR_G"
    ):
        raise ValueError("scientific normal gate requires frozen D_OR_G primary identity")
    required_references = {"rms", "cusum", "ewma"}
    if not required_references.issubset(detector_by_name):
        raise ValueError("normal gate requires RMS, CUSUM, and EWMA references")
    primary = summaries[dmreda_name]
    identity_bindings = {
        (
            int(row["simulationRun"]),
            str(row["raw_sample_sha256"]),
            str(row["scaled_sample_sha256"]),
            str(row["input_sha256"]),
            str(row["protocol_sha256"]),
            str(row["runner_sha256"]),
            str(row["source_commit"]),
        )
        for row in grouped[dmreda_name]
    }
    for name in sorted(required_references):
        reference_bindings = {
            (
                int(row["simulationRun"]),
                str(row["raw_sample_sha256"]),
                str(row["scaled_sample_sha256"]),
                str(row["input_sha256"]),
                str(row["protocol_sha256"]),
                str(row["runner_sha256"]),
                str(row["source_commit"]),
            )
            for row in grouped[name]
        }
        if reference_bindings != identity_bindings:
            raise ValueError("normal channels do not share identical input bindings")
    reference_values = {
        name: (
            int(summaries[name]["false_authority_count"]),
            int(summaries[name]["restricted_time_sum"]),
        )
        for name in sorted(required_references)
    }
    expected_parameters = {
            "rms": {"window": 32},
            "cusum": {"allowance": 0.5, "center": 0.0},
            "ewma": {"alpha": 2.0 / 33.0, "center": 0.0, "scale": 1.0},
    }
    if require_frozen_campaign_shape and frozen_reference_configurations is None:
        raise ValueError("scientific normal gate requires protocol-frozen reference records")
    contract_validity = {
        name: detector_by_name[name].kind == name
        and detector_by_name[name].gate == FROZEN_REFERENCE_GATE
        and detector_by_name[name].parameter_mapping() == expected_parameters[name]
        and (
            frozen_reference_configurations is None
            or _reference_record_matches_detector(
                name,
                frozen_reference_configurations.get(name),
                detector_by_name[name],
            )
        )
        for name in sorted(required_references)
    }
    admission = evaluate_normal_admission_v2(
        dmreda_false_authority_count=int(primary["false_authority_count"]),
        dmreda_restricted_time_sum=int(primary["restricted_time_sum"]),
        reference_results=reference_values,
        reference_contracts_valid=contract_validity,
        run_count=len(grouped[dmreda_name]),
    )
    primary_admitted = bool(admission["primary_dmreda"]["admitted"])
    summary_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": NORMAL_SUMMARY_SCHEMA_VERSION,
        "status": "passed" if primary_admitted else "failed",
        "run_count": len(grouped[dmreda_name]),
        "horizon": int(primary["calibration_horizon"]),
        "finite_horizon_interpretation": {
            "censored_run_assignment": "full_trace_length",
            "classical_uncensored_arl_claimed": False,
            "independent_unit": "simulation_trajectory",
        },
        "primary_dmreda": {
            **dict(primary),
            "admitted": primary_admitted,
            "max_false_authority_count": 25,
            "evidence_channel_configuration_sha256": primary[
                "configuration_sha256"
            ],
            "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        },
        "scalar_evidence_reference_summaries": {
            name: summaries[name] for name in sorted(required_references)
        },
        "pending_open_metric_note": (
            "counted from public pending false-to-true segments; an internal same-sample "
            "timeout/rearm can remain inside one observable segment"
        ),
    }
    summary = dict(summary_without_hash)
    summary["summary_payload_sha256"] = canonical_sha256(summary_without_hash)
    admission_without_hash = dict(admission)
    admission_without_hash["status"] = "complete"
    admission_without_hash["dmreda_primary_admitted"] = primary_admitted
    admission_payload = dict(admission_without_hash)
    admission_payload["admission_payload_sha256"] = canonical_sha256(
        admission_without_hash
    )
    return summary, admission_payload


def render_normal_gate_report(
    summary: Mapping[str, object], admission: Mapping[str, object]
) -> str:
    """Render a concise human-readable authority report without rankings."""

    primary = summary["primary_dmreda"]
    references = admission["scalar_evidence_references"]
    lines = [
        "# Stage 3.3 Independent Normal Authority Gate",
        "",
        f"Status: **{summary['status']}**",
        "",
        "This is a finite-horizon normal-authority assessment, not an uncensored classical ARL estimate.",
        "",
        "## Primary evidence core",
        "",
        (
            f"DMREDA produced unnecessary authority on {primary['false_authority_count']} "
            f"of {primary['trajectory_count']} independent normal trajectories "
            f"(rate {primary['false_authority_rate']:.6f}); restricted mean time to "
            f"authority was {primary['restricted_mean_time_to_authority']:.6f} samples."
        ),
        "",
        "## Scalar evidence reference admission",
        "",
    ]
    for name in sorted(references):
        record = references[name]
        lines.append(
            f"- `{name}`: `{record['admission_status']}`; count difference "
            f"{record['absolute_false_authority_count_difference']}, restricted-time "
            f"sum difference {record['absolute_restricted_time_sum_difference']}."
        )
    lines.extend(
        (
            "",
            "Comparator failure does not veto the primary DMREDA Bank D application. A failed reference is excluded from confirmatory pairwise analysis and is not retuned on Testing.",
            "",
        )
    )
    return "\n".join(lines)
