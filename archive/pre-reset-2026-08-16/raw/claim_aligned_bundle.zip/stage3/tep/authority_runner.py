"""Onset-independent evidence generation and dual-boundary row binding.

The evidence/event computation functions in this module accept no onset.  One
authoritative event sequence is generated per trajectory and evidence channel,
hashed with its onset-independent traces, and only then classified against the
two co-equal Rieth V1 onset candidates.
"""

from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
import hashlib
import inspect
from pathlib import Path
import struct
from typing import Mapping, Sequence

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    confirmed_alarm_times,
    ewma_mean_score,
    trailing_rms_score,
    two_sided_cusum_score,
)
from gold_line.core.dmreda_reference_clean import compute_dmreda_reference
from stage3.admission.serialization import canonical_sha256
from stage3.tep.checkpoints import (
    CheckpointValidationError,
    read_canonical_jsonl_strict,
    write_canonical_jsonl_atomic,
)
from stage3.tep.configuration import (
    FROZEN_TEP_AFFINE_CONFIGURATION_SHA256,
    apply_tep_affine_scale,
    build_tep_core_kwargs,
)
from stage3.tep.dual_boundary import (
    classify_dual_boundary_authority,
    validate_dual_boundary_row,
)
from stage3.tep.runner import DetectorSpec, MAX_PROCESS_WORKERS


_SHA256_CHARS = frozenset("0123456789abcdef")
_ROW_KEYS = {
    "schema_version",
    "document_type",
    "faultNumber",
    "simulationRun",
    "trajectory_identifier",
    "evidence_channel_identifier",
    "sample_count",
    "sample_sha256",
    "sample_domain",
    "raw_sample_sha256",
    "preprocessing_configuration_sha256",
    "input_sha256",
    "configuration_sha256",
    "preprocessing_trace_sha256",
    "representation_trace_sha256",
    "score_trace_sha256",
    "event_gate_trace_sha256",
    "state_evolution_sha256",
    "onset_independent_artifact_sha256",
    "authoritative_event_indices",
    "authoritative_event_count",
    "first_authoritative_event",
    "authoritative_events_sha256",
    "outcome_onset_159",
    "latency_onset_159",
    "outcome_onset_160",
    "latency_onset_160",
    "boundary_sensitivity_category",
    "mutually_exclusive_outcome_changed",
    "latency_shift_only",
    "integrity_failure_reason",
    "protocol_sha256",
    "dual_boundary_contract_sha256",
    "runner_sha256",
    "source_commit",
    "trajectory_set_sha256",
    "binding_sha256",
}


def _validate_sha256(value: str, name: str) -> None:
    if not isinstance(value, str) or len(value) != 64 or any(
        character not in _SHA256_CHARS for character in value
    ):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest")


def _validate_source_commit(value: str) -> None:
    if not isinstance(value, str) or len(value) != 40 or any(
        character not in _SHA256_CHARS for character in value
    ):
        raise ValueError("source_commit must be a lowercase Git SHA-1 identity")


def _little_endian_array(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values)
    if array.dtype.kind == "b":
        dtype = np.dtype("u1")
    elif array.dtype.kind in "iu":
        dtype = np.dtype("<i8")
    elif array.dtype.kind == "f":
        dtype = np.dtype("<f8")
    else:
        raise TypeError("only bool, integer, and floating traces are hashable")
    return np.ascontiguousarray(array, dtype=dtype)


def _hash_named_arrays(
    schema: str, arrays: Sequence[tuple[str, np.ndarray]]
) -> str:
    digest = hashlib.sha256()
    digest.update(schema.encode("utf-8") + b"\0")
    for name, values in arrays:
        array = _little_endian_array(values)
        digest.update(name.encode("utf-8") + b"\0")
        digest.update(str(array.dtype).encode("ascii") + b"\0")
        digest.update(struct.pack(">Q", array.ndim))
        for size in array.shape:
            digest.update(struct.pack(">Q", size))
        digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def _sample_sha256(samples: Sequence[float]) -> str:
    values = np.asarray(samples, dtype=np.float64)
    if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
        raise ValueError("samples must be a non-empty finite one-dimensional sequence")
    return _hash_named_arrays("dmreda-stage3-scaled-samples-v2", (("samples", values),))


def _raw_sample_sha256(samples: Sequence[float]) -> str:
    values = np.asarray(samples, dtype=np.float64)
    if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
        raise ValueError("raw samples must be a non-empty finite one-dimensional sequence")
    return _hash_named_arrays(
        "dmreda-stage3-raw-xmeas7-samples-v2", (("samples", values),)
    )


@dataclass(frozen=True)
class AuthorityTrajectoryInput:
    fault_number: int
    simulation_run: int
    trajectory_identifier: str
    samples: tuple[float, ...]
    sample_domain: str = "synthetic_pre_scaled_fixture"
    raw_sample_sha256: str | None = None
    preprocessing_configuration_sha256: str | None = None

    def __post_init__(self) -> None:
        for value, name, minimum in (
            (self.fault_number, "fault_number", 0),
            (self.simulation_run, "simulation_run", 1),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
                raise ValueError(f"{name} must be an integer >= {minimum}")
        if not isinstance(self.trajectory_identifier, str) or not (
            self.trajectory_identifier.strip()
        ):
            raise ValueError("trajectory_identifier must be non-empty")
        _sample_sha256(self.samples)
        if self.sample_domain == "synthetic_pre_scaled_fixture":
            if (
                self.raw_sample_sha256 is not None
                or self.preprocessing_configuration_sha256 is not None
            ):
                raise ValueError(
                    "synthetic fixtures cannot claim raw TEP preprocessing authority"
                )
        elif self.sample_domain == "tep_xmeas_7_fixed_affine_scaled":
            _validate_sha256(self.raw_sample_sha256, "raw_sample_sha256")  # type: ignore[arg-type]
            if self.preprocessing_configuration_sha256 != (
                FROZEN_TEP_AFFINE_CONFIGURATION_SHA256
            ):
                raise ValueError(
                    "scientific TEP input must bind the frozen affine configuration"
                )
        else:
            raise ValueError("unknown authority-trajectory sample domain")

    @classmethod
    def from_raw_xmeas_7(
        cls,
        fault_number: int,
        simulation_run: int,
        trajectory_identifier: str,
        raw_samples: Sequence[float],
    ) -> "AuthorityTrajectoryInput":
        raw = np.asarray(raw_samples, dtype=np.float64)
        scaled = apply_tep_affine_scale(raw)
        return cls(
            fault_number=fault_number,
            simulation_run=simulation_run,
            trajectory_identifier=trajectory_identifier,
            samples=tuple(float(value) for value in scaled),
            sample_domain="tep_xmeas_7_fixed_affine_scaled",
            raw_sample_sha256=_raw_sample_sha256(raw),
            preprocessing_configuration_sha256=(
                FROZEN_TEP_AFFINE_CONFIGURATION_SHA256
            ),
        )

    @property
    def sample_sha256(self) -> str:
        return _sample_sha256(self.samples)

    @property
    def frozen_tep_preprocessing_verified(self) -> bool:
        return (
            self.sample_domain == "tep_xmeas_7_fixed_affine_scaled"
            and self.raw_sample_sha256 is not None
            and self.preprocessing_configuration_sha256
            == FROZEN_TEP_AFFINE_CONFIGURATION_SHA256
        )


@dataclass(frozen=True)
class DualBoundaryBindings:
    input_sha256: str
    protocol_sha256: str
    dual_boundary_contract_sha256: str
    runner_sha256: str
    source_commit: str

    def __post_init__(self) -> None:
        for name in (
            "input_sha256",
            "protocol_sha256",
            "dual_boundary_contract_sha256",
            "runner_sha256",
        ):
            _validate_sha256(getattr(self, name), name)
        _validate_source_commit(self.source_commit)


@dataclass(frozen=True)
class OnsetIndependentAuthority:
    sample_count: int
    configuration_sha256: str
    preprocessing_trace_sha256: str
    representation_trace_sha256: str | None
    score_trace_sha256: str
    event_gate_trace_sha256: str
    state_evolution_sha256: str | None
    authoritative_event_indices: tuple[int, ...]

    def __post_init__(self) -> None:
        if isinstance(self.sample_count, bool) or not isinstance(self.sample_count, int):
            raise TypeError("sample_count must be an integer")
        if self.sample_count <= 160:
            raise ValueError("sample_count must contain both frozen onset indices")
        for name in (
            "configuration_sha256",
            "preprocessing_trace_sha256",
            "score_trace_sha256",
            "event_gate_trace_sha256",
        ):
            _validate_sha256(getattr(self, name), name)
        for name in ("representation_trace_sha256", "state_evolution_sha256"):
            value = getattr(self, name)
            if value is not None:
                _validate_sha256(value, name)
        classify_dual_boundary_authority(
            self.authoritative_event_indices,
            trace_length=self.sample_count,
        )

    @property
    def onset_independent_artifact_sha256(self) -> str:
        return canonical_sha256(
            {
                "schema_version": "2.0.0",
                "sample_count": self.sample_count,
                "configuration_sha256": self.configuration_sha256,
                "preprocessing_trace_sha256": self.preprocessing_trace_sha256,
                "representation_trace_sha256": self.representation_trace_sha256,
                "score_trace_sha256": self.score_trace_sha256,
                "event_gate_trace_sha256": self.event_gate_trace_sha256,
                "state_evolution_sha256": self.state_evolution_sha256,
                "authoritative_event_indices": list(self.authoritative_event_indices),
            }
        )


def generate_onset_independent_authority(
    samples: Sequence[float], detector: DetectorSpec
) -> OnsetIndependentAuthority:
    """Generate evidence/events from an already-scaled signal without an onset.

    Scientific TEP callers must construct :class:`AuthorityTrajectoryInput`
    through ``from_raw_xmeas_7`` and use ``evaluate_dual_boundary_records``;
    this low-level function remains available for isolated synthetic tests.
    """

    if "onset" in inspect.signature(generate_onset_independent_authority).parameters:
        raise AssertionError("onset-independent generator unexpectedly accepts onset")
    signal = np.asarray(samples, dtype=np.float64)
    preprocessing_hash = _sample_sha256(signal)
    configuration_hash = detector.detector_sha256

    if detector.kind == "dmreda_core":
        core_kwargs = build_tep_core_kwargs()
        assert detector.dmreda_mode is not None
        core_kwargs["mode"] = detector.dmreda_mode
        result = compute_dmreda_reference(signal, **core_kwargs)
        representation_hash = _hash_named_arrays(
            "dmreda-stage3-representation-traces-v2",
            tuple(
                (name, getattr(result, name))
                for name in (
                    "mu",
                    "e",
                    "e1",
                    "e_baseline",
                    "e_baseline_safe",
                    "d",
                    "g_raw",
                    "g",
                    "r",
                    "a",
                    "a_slow",
                )
            ),
        )
        score_hash = _hash_named_arrays(
            "dmreda-stage3-d-g-score-traces-v2",
            (("d", result.d), ("g", result.g)),
        )
        event_gate_hash = _hash_named_arrays(
            "dmreda-stage3-native-event-gate-traces-v2",
            (
                ("pending", result.pending),
                ("confirmed", result.confirmed),
                ("event_active", result.event_active),
            ),
        )
        state_hash = _hash_named_arrays(
            "dmreda-stage3-state-evolution-v2",
            (
                ("state", result.state),
                ("m_eff", result.m_eff),
                ("confirm_len_eff", result.confirm_len_eff),
            ),
        )
        events = tuple(result.event_times)
    else:
        parameters = detector.parameter_mapping()
        if detector.kind == "rms":
            scores = trailing_rms_score(signal, window=int(parameters["window"]))
        elif detector.kind == "cusum":
            scores = two_sided_cusum_score(
                signal,
                center=float(parameters["center"]),
                allowance=float(parameters["allowance"]),
            )
        else:
            scores = ewma_mean_score(
                signal,
                center=float(parameters["center"]),
                scale=float(parameters["scale"]),
                alpha=float(parameters["alpha"]),
            )
        assert detector.gate is not None and detector.threshold is not None
        events = tuple(
            confirmed_alarm_times(scores, detector.threshold, detector.gate)
        )
        confirmed_trace = np.zeros(signal.size, dtype=bool)
        confirmed_trace[list(events)] = True
        representation_hash = None
        score_hash = _hash_named_arrays(
            "dmreda-stage3-scalar-reference-score-trace-v2",
            (("score", scores),),
        )
        event_gate_hash = _hash_named_arrays(
            "dmreda-stage3-scalar-reference-event-output-v2",
            (("confirmed", confirmed_trace),),
        )
        state_hash = None

    return OnsetIndependentAuthority(
        sample_count=int(signal.size),
        configuration_sha256=configuration_hash,
        preprocessing_trace_sha256=preprocessing_hash,
        representation_trace_sha256=representation_hash,
        score_trace_sha256=score_hash,
        event_gate_trace_sha256=event_gate_hash,
        state_evolution_sha256=state_hash,
        authoritative_event_indices=events,
    )


def _ordered_jobs(
    trajectories: Sequence[AuthorityTrajectoryInput],
    detectors: Sequence[DetectorSpec],
) -> tuple[tuple[AuthorityTrajectoryInput, DetectorSpec], ...]:
    if not trajectories or not detectors:
        raise ValueError("at least one trajectory and evidence channel are required")
    trajectory_ids = [item.trajectory_identifier for item in trajectories]
    if len(trajectory_ids) != len(set(trajectory_ids)):
        raise ValueError("trajectory identifiers must be unique")
    recording_ids = [(item.fault_number, item.simulation_run) for item in trajectories]
    if len(recording_ids) != len(set(recording_ids)):
        raise ValueError("faultNumber/simulationRun identities must be unique")
    channel_ids = [item.name for item in detectors]
    if len(channel_ids) != len(set(channel_ids)):
        raise ValueError("evidence-channel identifiers must be unique")
    return tuple(
        sorted(
            ((trajectory, detector) for trajectory in trajectories for detector in detectors),
            key=lambda pair: (
                pair[0].fault_number,
                pair[0].simulation_run,
                pair[1].name,
            ),
        )
    )


def authority_trajectory_set_sha256(
    trajectories: Sequence[AuthorityTrajectoryInput],
) -> str:
    return canonical_sha256(
        [
            {
                "faultNumber": item.fault_number,
                "simulationRun": item.simulation_run,
                "trajectory_identifier": item.trajectory_identifier,
                "sample_count": len(item.samples),
                "sample_sha256": item.sample_sha256,
                "sample_domain": item.sample_domain,
                "raw_sample_sha256": item.raw_sample_sha256,
                "preprocessing_configuration_sha256": (
                    item.preprocessing_configuration_sha256
                ),
            }
            for item in sorted(
                trajectories,
                key=lambda child: (
                    child.fault_number,
                    child.simulation_run,
                    child.trajectory_identifier,
                ),
            )
        ]
    )


def _evaluate_authority_job(
    job: tuple[AuthorityTrajectoryInput, DetectorSpec]
) -> tuple[AuthorityTrajectoryInput, DetectorSpec, OnsetIndependentAuthority]:
    trajectory, detector = job
    authority = generate_onset_independent_authority(trajectory.samples, detector)
    return trajectory, detector, authority


def _build_row(
    trajectory: AuthorityTrajectoryInput,
    detector: DetectorSpec,
    authority: OnsetIndependentAuthority,
    *,
    bindings: DualBoundaryBindings,
    trajectory_set_sha256: str,
) -> dict[str, object]:
    classification = classify_dual_boundary_authority(
        authority.authoritative_event_indices,
        trace_length=authority.sample_count,
    )
    binding_payload = {
        "faultNumber": trajectory.fault_number,
        "simulationRun": trajectory.simulation_run,
        "trajectory_identifier": trajectory.trajectory_identifier,
        "evidence_channel_identifier": detector.name,
        "input_sha256": bindings.input_sha256,
        "sample_domain": trajectory.sample_domain,
        "raw_sample_sha256": trajectory.raw_sample_sha256,
        "preprocessing_configuration_sha256": (
            trajectory.preprocessing_configuration_sha256
        ),
        "configuration_sha256": authority.configuration_sha256,
        "onset_independent_artifact_sha256": (
            authority.onset_independent_artifact_sha256
        ),
        "protocol_sha256": bindings.protocol_sha256,
        "dual_boundary_contract_sha256": bindings.dual_boundary_contract_sha256,
        "runner_sha256": bindings.runner_sha256,
        "source_commit": bindings.source_commit,
        "trajectory_set_sha256": trajectory_set_sha256,
    }
    row: dict[str, object] = {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3_3.dual_boundary_trajectory_result",
        "faultNumber": trajectory.fault_number,
        "simulationRun": trajectory.simulation_run,
        "trajectory_identifier": trajectory.trajectory_identifier,
        "evidence_channel_identifier": detector.name,
        "sample_count": authority.sample_count,
        "sample_sha256": trajectory.sample_sha256,
        "sample_domain": trajectory.sample_domain,
        "raw_sample_sha256": trajectory.raw_sample_sha256,
        "preprocessing_configuration_sha256": (
            trajectory.preprocessing_configuration_sha256
        ),
        "input_sha256": bindings.input_sha256,
        "configuration_sha256": authority.configuration_sha256,
        "preprocessing_trace_sha256": authority.preprocessing_trace_sha256,
        "representation_trace_sha256": authority.representation_trace_sha256,
        "score_trace_sha256": authority.score_trace_sha256,
        "event_gate_trace_sha256": authority.event_gate_trace_sha256,
        "state_evolution_sha256": authority.state_evolution_sha256,
        "onset_independent_artifact_sha256": (
            authority.onset_independent_artifact_sha256
        ),
        **classification.to_dict(),
        "protocol_sha256": bindings.protocol_sha256,
        "dual_boundary_contract_sha256": bindings.dual_boundary_contract_sha256,
        "runner_sha256": bindings.runner_sha256,
        "source_commit": bindings.source_commit,
        "trajectory_set_sha256": trajectory_set_sha256,
        "binding_sha256": canonical_sha256(binding_payload),
    }
    validate_dual_boundary_result_row(row)
    return row


def validate_dual_boundary_result_row(row: Mapping[str, object]) -> None:
    if set(row) != _ROW_KEYS:
        raise CheckpointValidationError("dual-boundary row field set is invalid")
    if row.get("schema_version") != "2.0.0" or row.get("document_type") != (
        "dmreda.stage3_3.dual_boundary_trajectory_result"
    ):
        raise CheckpointValidationError("dual-boundary row schema is invalid")
    for name in (
        "sample_sha256",
        "input_sha256",
        "configuration_sha256",
        "preprocessing_trace_sha256",
        "score_trace_sha256",
        "event_gate_trace_sha256",
        "onset_independent_artifact_sha256",
        "authoritative_events_sha256",
        "protocol_sha256",
        "dual_boundary_contract_sha256",
        "runner_sha256",
        "trajectory_set_sha256",
        "binding_sha256",
    ):
        try:
            _validate_sha256(row[name], name)  # type: ignore[arg-type]
        except (KeyError, ValueError) as error:
            raise CheckpointValidationError(str(error)) from error
    for name in ("representation_trace_sha256", "state_evolution_sha256"):
        value = row[name]
        if value is not None:
            try:
                _validate_sha256(value, name)  # type: ignore[arg-type]
            except ValueError as error:
                raise CheckpointValidationError(str(error)) from error
    sample_domain = row["sample_domain"]
    if row["preprocessing_trace_sha256"] != row["sample_sha256"]:
        raise CheckpointValidationError(
            "preprocessing trace must equal the bound scaled-sample trace"
        )
    if sample_domain == "tep_xmeas_7_fixed_affine_scaled":
        try:
            _validate_sha256(row["raw_sample_sha256"], "raw_sample_sha256")  # type: ignore[arg-type]
        except ValueError as error:
            raise CheckpointValidationError(str(error)) from error
        if row["preprocessing_configuration_sha256"] != (
            FROZEN_TEP_AFFINE_CONFIGURATION_SHA256
        ):
            raise CheckpointValidationError("frozen preprocessing binding is invalid")
    elif sample_domain == "synthetic_pre_scaled_fixture":
        if (
            row["raw_sample_sha256"] is not None
            or row["preprocessing_configuration_sha256"] is not None
        ):
            raise CheckpointValidationError("synthetic row claims scientific preprocessing")
    else:
        raise CheckpointValidationError("unknown sample domain")
    try:
        _validate_source_commit(row["source_commit"])  # type: ignore[arg-type]
        validate_dual_boundary_row(row)
    except (TypeError, ValueError) as error:
        raise CheckpointValidationError(str(error)) from error
    onset_independent_payload = {
        "schema_version": "2.0.0",
        "sample_count": row["sample_count"],
        "configuration_sha256": row["configuration_sha256"],
        "preprocessing_trace_sha256": row["preprocessing_trace_sha256"],
        "representation_trace_sha256": row["representation_trace_sha256"],
        "score_trace_sha256": row["score_trace_sha256"],
        "event_gate_trace_sha256": row["event_gate_trace_sha256"],
        "state_evolution_sha256": row["state_evolution_sha256"],
        "authoritative_event_indices": row["authoritative_event_indices"],
    }
    if row["onset_independent_artifact_sha256"] != canonical_sha256(
        onset_independent_payload
    ):
        raise CheckpointValidationError(
            "onset-independent trace/event artifact binding is invalid"
        )
    binding_payload = {
        name: row[name]
        for name in (
            "faultNumber",
            "simulationRun",
            "trajectory_identifier",
            "evidence_channel_identifier",
            "input_sha256",
            "sample_domain",
            "raw_sample_sha256",
            "preprocessing_configuration_sha256",
            "configuration_sha256",
            "onset_independent_artifact_sha256",
            "protocol_sha256",
            "dual_boundary_contract_sha256",
            "runner_sha256",
            "source_commit",
            "trajectory_set_sha256",
        )
    }
    if row["binding_sha256"] != canonical_sha256(binding_payload):
        raise CheckpointValidationError("dual-boundary row binding is invalid")


def evaluate_dual_boundary_records(
    trajectories: Sequence[AuthorityTrajectoryInput],
    detectors: Sequence[DetectorSpec],
    *,
    bindings: DualBoundaryBindings,
    workers: int = 1,
    require_frozen_tep_preprocessing: bool = True,
) -> tuple[dict[str, object], ...]:
    """Generate one event trace per pair and bind both co-equal onsets."""

    if isinstance(workers, bool) or not isinstance(workers, int):
        raise TypeError("workers must be an integer")
    if not 1 <= workers <= MAX_PROCESS_WORKERS:
        raise ValueError(f"workers must be in [1, {MAX_PROCESS_WORKERS}]")
    if require_frozen_tep_preprocessing and any(
        not trajectory.frozen_tep_preprocessing_verified
        for trajectory in trajectories
    ):
        raise ValueError(
            "scientific evaluation requires exactly-once frozen xmeas_7 affine preprocessing"
        )
    jobs = _ordered_jobs(trajectories, detectors)
    trajectory_hash = authority_trajectory_set_sha256(trajectories)
    if workers == 1:
        generated = tuple(_evaluate_authority_job(job) for job in jobs)
    else:
        with ProcessPoolExecutor(
            max_workers=min(workers, len(jobs), MAX_PROCESS_WORKERS)
        ) as executor:
            generated = tuple(executor.map(_evaluate_authority_job, jobs, chunksize=1))
    rows = tuple(
        _build_row(
            trajectory,
            detector,
            authority,
            bindings=bindings,
            trajectory_set_sha256=trajectory_hash,
        )
        for trajectory, detector, authority in generated
    )
    expected_order = sorted(
        (
            row["faultNumber"],
            row["simulationRun"],
            row["evidence_channel_identifier"],
        )
        for row in rows
    )
    observed_order = [
        (
            row["faultNumber"],
            row["simulationRun"],
            row["evidence_channel_identifier"],
        )
        for row in rows
    ]
    if observed_order != expected_order or len(observed_order) != len(set(observed_order)):
        raise AssertionError("dual-boundary row ordering or identity is invalid")
    return rows


def write_dual_boundary_records_atomic(
    path: Path,
    rows: Sequence[Mapping[str, object]],
    *,
    external_root: Path | None = None,
) -> str:
    """Validate and atomically publish a complete canonical JSONL result."""

    for row in rows:
        validate_dual_boundary_result_row(row)
    return write_canonical_jsonl_atomic(
        Path(path), rows, external_root=external_root
    )


def read_dual_boundary_records_strict(
    path: Path,
) -> tuple[tuple[dict[str, object], ...], str]:
    rows, digest = read_canonical_jsonl_strict(Path(path))
    for row in rows:
        validate_dual_boundary_result_row(row)
    return rows, digest
