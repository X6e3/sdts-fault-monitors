"""Atomic, strict, hash-bound checkpoint I/O for Stage 3.2 evaluation."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Mapping, Sequence

from stage3.admission.serialization import canonical_json_bytes, canonical_sha256
from stage3.tep.output_guard import (
    ExternalArtifactKind,
    atomic_replace_checkpoint_bytes,
    atomic_write_bytes,
)


class CheckpointValidationError(ValueError):
    """A result/checkpoint pair is incomplete, stale, or internally invalid."""


def _reject_nonfinite(token: str) -> None:
    raise CheckpointValidationError(f"non-finite JSON token: {token}")


def _object_without_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, child in pairs:
        if key in value:
            raise CheckpointValidationError(f"duplicate JSON key: {key}")
        value[key] = child
    return value


def _strict_json_loads(text: str) -> Any:
    try:
        return json.loads(
            text,
            parse_constant=_reject_nonfinite,
            object_pairs_hook=_object_without_duplicate_keys,
        )
    except (json.JSONDecodeError, UnicodeError) as error:
        raise CheckpointValidationError(f"invalid JSON: {error}") from error


def _fsync_directory(directory: Path) -> None:
    descriptor = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _atomic_write_bytes(path: Path, payload: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        _fsync_directory(path.parent)
    except BaseException:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def write_canonical_jsonl_atomic(
    path: Path,
    rows: Sequence[Mapping[str, object]],
    *,
    external_root: Path | None = None,
) -> str:
    """Write non-empty canonical JSONL and return its exact byte hash."""

    if not rows:
        raise ValueError("a complete result must contain at least one row")
    payload = b"".join(canonical_json_bytes(dict(row)) + b"\n" for row in rows)
    if external_root is None:
        _atomic_write_bytes(Path(path), payload)
    else:
        atomic_write_bytes(
            Path(path),
            payload,
            external_root=Path(external_root),
            kind=ExternalArtifactKind.IMMUTABLE_JSONL,
        )
    return sha256_bytes(payload)


def read_canonical_jsonl_strict(
    path: Path,
) -> tuple[tuple[dict[str, object], ...], str]:
    """Read canonical JSONL, rejecting truncation, blank lines, and non-objects."""

    raw = Path(path).read_bytes()
    if not raw:
        raise CheckpointValidationError("result JSONL is empty")
    if not raw.endswith(b"\n"):
        raise CheckpointValidationError("result JSONL has a partial final line")

    rows: list[dict[str, object]] = []
    for line_number, raw_line in enumerate(raw.splitlines(), start=1):
        if not raw_line:
            raise CheckpointValidationError(f"blank JSONL line at {line_number}")
        try:
            text = raw_line.decode("utf-8")
        except UnicodeDecodeError as error:
            raise CheckpointValidationError(
                f"invalid UTF-8 on JSONL line {line_number}"
            ) from error
        value = _strict_json_loads(text)
        if not isinstance(value, dict):
            raise CheckpointValidationError(
                f"JSONL line {line_number} must contain an object"
            )
        if canonical_json_bytes(value) != raw_line:
            raise CheckpointValidationError(
                f"JSONL line {line_number} is not canonical"
            )
        rows.append(value)
    return tuple(rows), sha256_bytes(raw)


def write_canonical_checkpoint_atomic(
    path: Path,
    payload: Mapping[str, object],
    *,
    external_root: Path | None = None,
) -> None:
    encoded = canonical_json_bytes(dict(payload)) + b"\n"
    if external_root is None:
        _atomic_write_bytes(Path(path), encoded)
    else:
        atomic_replace_checkpoint_bytes(
            Path(path),
            encoded,
            external_root=Path(external_root),
            kind=ExternalArtifactKind.CHECKPOINT_JSON,
        )


def read_canonical_checkpoint_strict(path: Path) -> dict[str, object]:
    raw = Path(path).read_bytes()
    if not raw.endswith(b"\n"):
        raise CheckpointValidationError("checkpoint has a partial final line")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as error:
        raise CheckpointValidationError("checkpoint is not UTF-8") from error
    value = _strict_json_loads(text)
    if not isinstance(value, dict):
        raise CheckpointValidationError("checkpoint must contain an object")
    if canonical_json_bytes(value) + b"\n" != raw:
        raise CheckpointValidationError("checkpoint is not canonical")
    return value


_CHECKPOINT_KEYS = {
    "schema_version",
    "document_type",
    "status",
    "bindings",
    "binding_sha256",
    "ordered_trajectory_ids",
    "trajectory_count",
    "result_format",
    "result_sha256",
}


def build_complete_checkpoint(
    *,
    bindings: Mapping[str, object],
    ordered_trajectory_ids: Sequence[str],
    result_sha256: str,
) -> dict[str, object]:
    identities = list(ordered_trajectory_ids)
    if not identities or len(identities) != len(set(identities)):
        raise ValueError("checkpoint identities must be non-empty and unique")
    return {
        "schema_version": "1.0.0",
        "document_type": "dmreda.stage3.tep.fault_evaluation_checkpoint",
        "status": "complete",
        "bindings": dict(bindings),
        "binding_sha256": canonical_sha256(dict(bindings)),
        "ordered_trajectory_ids": identities,
        "trajectory_count": len(identities),
        "result_format": "canonical_jsonl",
        "result_sha256": result_sha256,
    }


def validate_complete_checkpoint(
    payload: Mapping[str, object],
    *,
    expected_bindings: Mapping[str, object],
    expected_ordered_trajectory_ids: Sequence[str],
) -> str:
    """Validate a complete checkpoint and return its bound result hash."""

    if set(payload) != _CHECKPOINT_KEYS:
        raise CheckpointValidationError("checkpoint field set is incomplete or unexpected")
    if payload["schema_version"] != "1.0.0":
        raise CheckpointValidationError("unsupported checkpoint schema")
    if payload["document_type"] != "dmreda.stage3.tep.fault_evaluation_checkpoint":
        raise CheckpointValidationError("unexpected checkpoint document type")
    if payload["status"] != "complete":
        raise CheckpointValidationError("checkpoint is not complete")
    if payload["result_format"] != "canonical_jsonl":
        raise CheckpointValidationError("unexpected result format")

    expected_bindings_dict = dict(expected_bindings)
    if payload["bindings"] != expected_bindings_dict:
        raise CheckpointValidationError("checkpoint bindings are stale or mismatched")
    expected_binding_hash = canonical_sha256(expected_bindings_dict)
    if payload["binding_sha256"] != expected_binding_hash:
        raise CheckpointValidationError("checkpoint binding hash is invalid")

    identities = payload["ordered_trajectory_ids"]
    expected_identities = list(expected_ordered_trajectory_ids)
    if identities != expected_identities:
        raise CheckpointValidationError("checkpoint trajectory identity order is stale")
    if not isinstance(identities, list) or any(
        not isinstance(identity, str) or not identity for identity in identities
    ):
        raise CheckpointValidationError("checkpoint identities are invalid")
    if len(identities) != len(set(identities)):
        raise CheckpointValidationError("checkpoint contains duplicate identities")
    if payload["trajectory_count"] != len(identities):
        raise CheckpointValidationError("checkpoint trajectory count is invalid")

    result_hash = payload["result_sha256"]
    if not isinstance(result_hash, str) or len(result_hash) != 64 or any(
        character not in "0123456789abcdef" for character in result_hash
    ):
        raise CheckpointValidationError("checkpoint result hash is invalid")
    return result_hash


_DUAL_BOUNDARY_CHECKPOINT_KEYS = {
    "schema_version",
    "document_type",
    "status",
    "bindings",
    "binding_sha256",
    "ordered_record_ids",
    "record_count",
    "result_format",
    "result_sha256",
    "completed_at_utc",
}


def build_dual_boundary_checkpoint(
    *,
    bindings: Mapping[str, object],
    ordered_record_ids: Sequence[str],
    result_sha256: str,
    completed_at_utc: str,
) -> dict[str, object]:
    """Build a complete V2 checkpoint for one fault-class result."""

    identities = list(ordered_record_ids)
    if not identities or len(identities) != len(set(identities)):
        raise ValueError("checkpoint record identities must be non-empty and unique")
    if identities != sorted(identities):
        raise ValueError("checkpoint record identities must use stable sorted order")
    if not isinstance(completed_at_utc, str) or not completed_at_utc.endswith("Z"):
        raise ValueError("completed_at_utc must be an explicit UTC timestamp")
    if not isinstance(result_sha256, str) or len(result_sha256) != 64 or any(
        character not in "0123456789abcdef" for character in result_sha256
    ):
        raise ValueError("result_sha256 must be a lowercase SHA-256 digest")
    bindings_payload = dict(bindings)
    canonical_json_bytes(bindings_payload)
    return {
        "schema_version": "2.0.0",
        "document_type": "dmreda.stage3.tep.dual_boundary_fault_checkpoint",
        "status": "complete",
        "bindings": bindings_payload,
        "binding_sha256": canonical_sha256(bindings_payload),
        "ordered_record_ids": identities,
        "record_count": len(identities),
        "result_format": "canonical_jsonl",
        "result_sha256": result_sha256,
        "completed_at_utc": completed_at_utc,
    }


def validate_dual_boundary_checkpoint(
    payload: Mapping[str, object],
    *,
    expected_bindings: Mapping[str, object],
    expected_ordered_record_ids: Sequence[str],
) -> str:
    """Validate one V2 checkpoint and return its bound result digest."""

    if set(payload) != _DUAL_BOUNDARY_CHECKPOINT_KEYS:
        raise CheckpointValidationError(
            "dual-boundary checkpoint field set is incomplete or unexpected"
        )
    if payload["schema_version"] != "2.0.0" or payload["document_type"] != (
        "dmreda.stage3.tep.dual_boundary_fault_checkpoint"
    ):
        raise CheckpointValidationError("unsupported dual-boundary checkpoint")
    if payload["status"] != "complete" or payload["result_format"] != (
        "canonical_jsonl"
    ):
        raise CheckpointValidationError("dual-boundary checkpoint is incomplete")
    expected_bindings_payload = dict(expected_bindings)
    if payload["bindings"] != expected_bindings_payload:
        raise CheckpointValidationError("dual-boundary checkpoint bindings are stale")
    if payload["binding_sha256"] != canonical_sha256(expected_bindings_payload):
        raise CheckpointValidationError("dual-boundary checkpoint binding hash is invalid")
    identities = payload["ordered_record_ids"]
    expected_identities = list(expected_ordered_record_ids)
    if identities != expected_identities:
        raise CheckpointValidationError("dual-boundary checkpoint order is stale")
    if not isinstance(identities, list) or identities != sorted(identities) or any(
        not isinstance(identity, str) or not identity for identity in identities
    ):
        raise CheckpointValidationError("dual-boundary checkpoint identities are invalid")
    if len(identities) != len(set(identities)):
        raise CheckpointValidationError("dual-boundary checkpoint identities duplicate")
    if payload["record_count"] != len(identities):
        raise CheckpointValidationError("dual-boundary checkpoint count is invalid")
    completed = payload["completed_at_utc"]
    if not isinstance(completed, str) or not completed.endswith("Z"):
        raise CheckpointValidationError("dual-boundary completion timestamp is invalid")
    result_hash = payload["result_sha256"]
    if not isinstance(result_hash, str) or len(result_hash) != 64 or any(
        character not in "0123456789abcdef" for character in result_hash
    ):
        raise CheckpointValidationError("dual-boundary result hash is invalid")
    return result_hash
