"""Resumable per-fault publication for dual-boundary authority records."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

from stage3.admission.serialization import canonical_sha256
from stage3.tep.authority_runner import (
    AuthorityTrajectoryInput,
    DualBoundaryBindings,
    authority_trajectory_set_sha256,
    evaluate_dual_boundary_records,
    read_dual_boundary_records_strict,
    validate_dual_boundary_result_row,
    write_dual_boundary_records_atomic,
)
from stage3.tep.checkpoints import (
    CheckpointValidationError,
    build_dual_boundary_checkpoint,
    read_canonical_checkpoint_strict,
    validate_dual_boundary_checkpoint,
    write_canonical_checkpoint_atomic,
)
from stage3.tep.runner import DetectorSpec


@dataclass(frozen=True)
class DualBoundaryFaultRun:
    fault_number: int
    record_count: int
    binding_sha256: str
    result_sha256: str
    rows: tuple[Mapping[str, object], ...]
    resumed: bool


def _record_id(row: Mapping[str, object]) -> str:
    return (
        f"fault_{int(row['faultNumber']):02d}/"
        f"run_{int(row['simulationRun']):03d}/"
        f"{row['evidence_channel_identifier']}"
    )


def _validate_one_fault_inputs(
    trajectories: Sequence[AuthorityTrajectoryInput], detectors: Sequence[DetectorSpec]
) -> int:
    if not trajectories or not detectors:
        raise ValueError("one fault run requires trajectories and evidence channels")
    faults = {item.fault_number for item in trajectories}
    if len(faults) != 1:
        raise ValueError("one checkpoint cannot mix faultNumber values")
    return next(iter(faults))


def _checkpoint_bindings(
    trajectories: Sequence[AuthorityTrajectoryInput],
    detectors: Sequence[DetectorSpec],
    bindings: DualBoundaryBindings,
) -> dict[str, object]:
    return {
        "faultNumber": trajectories[0].fault_number,
        "input_sha256": bindings.input_sha256,
        "protocol_sha256": bindings.protocol_sha256,
        "dual_boundary_contract_sha256": bindings.dual_boundary_contract_sha256,
        "runner_sha256": bindings.runner_sha256,
        "source_commit": bindings.source_commit,
        "trajectory_set_sha256": authority_trajectory_set_sha256(trajectories),
        "evidence_channel_configuration_sha256": {
            detector.name: detector.detector_sha256
            for detector in sorted(detectors, key=lambda item: item.name)
        },
    }


def _expected_record_ids(
    trajectories: Sequence[AuthorityTrajectoryInput], detectors: Sequence[DetectorSpec]
) -> list[str]:
    return sorted(
        f"fault_{trajectory.fault_number:02d}/run_{trajectory.simulation_run:03d}/{detector.name}"
        for trajectory in trajectories
        for detector in detectors
    )


def _validate_rows(
    rows: Sequence[Mapping[str, object]],
    *,
    expected_record_ids: Sequence[str],
    expected_bindings: Mapping[str, object],
) -> None:
    observed = [_record_id(row) for row in rows]
    if observed != list(expected_record_ids):
        raise CheckpointValidationError("dual-boundary result identity order is stale")
    if len(observed) != len(set(observed)):
        raise CheckpointValidationError("dual-boundary result identities duplicate")
    configuration_hashes = expected_bindings[
        "evidence_channel_configuration_sha256"
    ]
    if not isinstance(configuration_hashes, Mapping):
        raise AssertionError("configuration hash binding is malformed")
    for row in rows:
        validate_dual_boundary_result_row(row)
        channel = row["evidence_channel_identifier"]
        expected = {
            "input_sha256": expected_bindings["input_sha256"],
            "protocol_sha256": expected_bindings["protocol_sha256"],
            "dual_boundary_contract_sha256": expected_bindings[
                "dual_boundary_contract_sha256"
            ],
            "runner_sha256": expected_bindings["runner_sha256"],
            "source_commit": expected_bindings["source_commit"],
            "trajectory_set_sha256": expected_bindings["trajectory_set_sha256"],
            "configuration_sha256": configuration_hashes.get(channel),
        }
        if any(row.get(name) != value for name, value in expected.items()):
            raise CheckpointValidationError("dual-boundary result binding is stale")


def evaluate_dual_boundary_fault(
    trajectories: Sequence[AuthorityTrajectoryInput],
    detectors: Sequence[DetectorSpec],
    *,
    bindings: DualBoundaryBindings,
    result_path: Path,
    checkpoint_path: Path,
    completed_at_utc: str,
    workers: int = 1,
    resume: bool = True,
    external_root: Path | None = None,
) -> DualBoundaryFaultRun:
    """Evaluate or strictly resume one complete fault-class result."""

    fault_number = _validate_one_fault_inputs(trajectories, detectors)
    expected_bindings = _checkpoint_bindings(trajectories, detectors, bindings)
    binding_hash = canonical_sha256(expected_bindings)
    identities = _expected_record_ids(trajectories, detectors)
    result_path = Path(result_path)
    checkpoint_path = Path(checkpoint_path)
    result_exists = result_path.exists()
    checkpoint_exists = checkpoint_path.exists()

    if result_exists or checkpoint_exists:
        if not resume:
            raise FileExistsError("result/checkpoint already exists and resume is disabled")
        if result_exists and not checkpoint_exists:
            rows, result_hash = read_dual_boundary_records_strict(result_path)
            _validate_rows(
                rows,
                expected_record_ids=identities,
                expected_bindings=expected_bindings,
            )
            checkpoint = build_dual_boundary_checkpoint(
                bindings=expected_bindings,
                ordered_record_ids=identities,
                result_sha256=result_hash,
                completed_at_utc=completed_at_utc,
            )
            write_canonical_checkpoint_atomic(
                checkpoint_path, checkpoint, external_root=external_root
            )
            return DualBoundaryFaultRun(
                fault_number=fault_number,
                record_count=len(rows),
                binding_sha256=binding_hash,
                result_sha256=result_hash,
                rows=rows,
                resumed=True,
            )
        if checkpoint_exists and not result_exists:
            raise CheckpointValidationError(
                "dual-boundary result/checkpoint pair is incomplete"
            )
        checkpoint = read_canonical_checkpoint_strict(checkpoint_path)
        expected_result_hash = validate_dual_boundary_checkpoint(
            checkpoint,
            expected_bindings=expected_bindings,
            expected_ordered_record_ids=identities,
        )
        rows, result_hash = read_dual_boundary_records_strict(result_path)
        _validate_rows(
            rows,
            expected_record_ids=identities,
            expected_bindings=expected_bindings,
        )
        if result_hash != expected_result_hash:
            raise CheckpointValidationError("dual-boundary result hash is stale")
        return DualBoundaryFaultRun(
            fault_number=fault_number,
            record_count=len(rows),
            binding_sha256=binding_hash,
            result_sha256=result_hash,
            rows=rows,
            resumed=True,
        )

    rows = evaluate_dual_boundary_records(
        trajectories, detectors, bindings=bindings, workers=workers
    )
    _validate_rows(
        rows,
        expected_record_ids=identities,
        expected_bindings=expected_bindings,
    )
    result_hash = write_dual_boundary_records_atomic(
        result_path, rows, external_root=external_root
    )
    checkpoint = build_dual_boundary_checkpoint(
        bindings=expected_bindings,
        ordered_record_ids=identities,
        result_sha256=result_hash,
        completed_at_utc=completed_at_utc,
    )
    write_canonical_checkpoint_atomic(
        checkpoint_path, checkpoint, external_root=external_root
    )
    return DualBoundaryFaultRun(
        fault_number=fault_number,
        record_count=len(rows),
        binding_sha256=binding_hash,
        result_sha256=result_hash,
        rows=rows,
        resumed=False,
    )
