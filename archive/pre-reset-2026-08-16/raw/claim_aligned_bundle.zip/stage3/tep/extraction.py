"""Validation and provenance binding for TEP scalar extractions.

This module never interprets detector outcomes.  It validates the narrow CSV
contract produced by the standalone R extractor and binds source, extractor,
and output bytes in a strict manifest.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import gzip
import hashlib
import math
from pathlib import Path
import re
from typing import Any, Final, Mapping

from stage3.admission.serialization import canonical_json_bytes

from .output_guard import (
    ExternalArtifactKind,
    atomic_write_bytes,
)


SCALAR_COLUMNS: Final[tuple[str, ...]] = (
    "faultNumber",
    "simulationRun",
    "sample",
    "xmeas_7",
)
SCALAR_ORDER: Final[tuple[str, ...]] = (
    "faultNumber",
    "simulationRun",
    "sample",
)
EXTRACTION_MANIFEST_SCHEMA_VERSION: Final[str] = (
    "dmreda.stage3.tep.extraction-manifest.v1"
)
_SHA256_PATTERN: Final[re.Pattern[str]] = re.compile(r"[0-9a-f]{64}")
_IDENTIFIER_PATTERN: Final[re.Pattern[str]] = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*")
_OBJECT_NAME_PATTERN: Final[re.Pattern[str]] = re.compile(r"[A-Za-z][A-Za-z0-9_.]*")
_TOP_LEVEL_KEYS: Final[frozenset[str]] = frozenset(
    {
        "dataset_identifier",
        "extractor",
        "output",
        "schema_version",
        "selection",
        "source",
        "validation",
    }
)


@dataclass(frozen=True)
class ScalarExtractionSummary:
    row_count: int
    trajectory_count: int
    first_key: tuple[int, int, int]
    last_key: tuple[int, int, int]


def sha256_file(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    """Hash one file without reading it into memory at once."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _parse_integral_key(value: str, *, field: str, row_number: int) -> int:
    if not value or value != value.strip():
        raise ValueError(f"empty or padded {field} at CSV row {row_number}")
    try:
        number = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError(f"invalid {field} at CSV row {row_number}") from exc
    if not number.is_finite() or number != number.to_integral_value():
        raise ValueError(f"non-integral {field} at CSV row {row_number}")
    parsed = int(number)
    if parsed > 2_147_483_647 or str(parsed) != value:
        raise ValueError(f"non-canonical {field} at CSV row {row_number}")
    if field == "faultNumber" and parsed < 0:
        raise ValueError(f"negative faultNumber at CSV row {row_number}")
    if field != "faultNumber" and parsed < 1:
        raise ValueError(f"non-positive {field} at CSV row {row_number}")
    return parsed


def _parse_finite_channel(value: str, *, row_number: int) -> float:
    if not value or value != value.strip():
        raise ValueError(f"empty or padded xmeas_7 at CSV row {row_number}")
    try:
        parsed = float(value)
    except ValueError as exc:
        raise ValueError(f"invalid xmeas_7 at CSV row {row_number}") from exc
    if not math.isfinite(parsed):
        raise ValueError(f"non-finite xmeas_7 at CSV row {row_number}")
    return parsed


def validate_scalar_trajectory(path: Path) -> ScalarExtractionSummary:
    """Validate the exact gzip CSV schema, identities, order, and finiteness."""

    path = Path(path)
    if not path.name.lower().endswith(".csv.gz"):
        raise ValueError("scalar trajectory must use the .csv.gz suffix")

    previous_key: tuple[int, int, int] | None = None
    first_key: tuple[int, int, int] | None = None
    previous_trajectory: tuple[int, int] | None = None
    row_count = 0
    trajectory_count = 0

    try:
        with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle, strict=True)
            try:
                header = next(reader)
            except StopIteration as exc:
                raise ValueError("scalar trajectory is empty") from exc
            if tuple(header) != SCALAR_COLUMNS:
                raise ValueError("scalar trajectory header or column order is invalid")

            for row_number, row in enumerate(reader, start=2):
                if len(row) != len(SCALAR_COLUMNS):
                    raise ValueError(f"invalid column count at CSV row {row_number}")
                key = (
                    _parse_integral_key(
                        row[0], field="faultNumber", row_number=row_number
                    ),
                    _parse_integral_key(
                        row[1], field="simulationRun", row_number=row_number
                    ),
                    _parse_integral_key(row[2], field="sample", row_number=row_number),
                )
                _parse_finite_channel(row[3], row_number=row_number)

                if previous_key is not None and key <= previous_key:
                    if key == previous_key:
                        raise ValueError(f"duplicate trajectory key at CSV row {row_number}")
                    raise ValueError(f"trajectory keys are not sorted at CSV row {row_number}")
                trajectory = key[:2]
                if trajectory != previous_trajectory:
                    trajectory_count += 1
                    previous_trajectory = trajectory
                if first_key is None:
                    first_key = key
                previous_key = key
                row_count += 1
    except (gzip.BadGzipFile, EOFError) as exc:
        raise ValueError("invalid or truncated gzip scalar trajectory") from exc

    if row_count == 0 or first_key is None or previous_key is None:
        raise ValueError("scalar trajectory contains no data rows")
    return ScalarExtractionSummary(
        row_count=row_count,
        trajectory_count=trajectory_count,
        first_key=first_key,
        last_key=previous_key,
    )


def _logical_name(path: Path) -> str:
    name = Path(path).name
    if not name or name in {".", ".."}:
        raise ValueError("artifact logical name is invalid")
    return name


def build_extraction_manifest(
    *,
    dataset_identifier: str,
    expected_object: str,
    source_path: Path,
    extractor_script_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    """Build a strict manifest binding source, script, and scalar output bytes."""

    summary = validate_scalar_trajectory(output_path)
    manifest: dict[str, Any] = {
        "schema_version": EXTRACTION_MANIFEST_SCHEMA_VERSION,
        "dataset_identifier": dataset_identifier,
        "source": {
            "logical_name": _logical_name(source_path),
            "object_name": expected_object,
            "sha256": sha256_file(source_path),
        },
        "extractor": {
            "logical_name": _logical_name(extractor_script_path),
            "sha256": sha256_file(extractor_script_path),
        },
        "output": {
            "bytes": Path(output_path).stat().st_size,
            "compression": "gzip",
            "format": "csv",
            "logical_name": _logical_name(output_path),
            "sha256": sha256_file(output_path),
        },
        "selection": {
            "channel": "xmeas_7",
            "columns": list(SCALAR_COLUMNS),
            "ordering": list(SCALAR_ORDER),
        },
        "validation": {
            "detector_outcomes_emitted": False,
            "finite": True,
            "first_key": list(summary.first_key),
            "last_key": list(summary.last_key),
            "row_count": summary.row_count,
            "trajectory_count": summary.trajectory_count,
        },
    }
    validate_extraction_manifest(manifest)
    return manifest


def _require_exact_keys(
    value: Any, expected: set[str] | frozenset[str], where: str
) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{where} must be an object")
    if set(value) != set(expected):
        raise ValueError(f"{where} has missing or unexpected keys")
    return value


def _require_string(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{where} must be a non-empty string")
    return value


def _require_logical_name(value: Any, where: str) -> str:
    name = _require_string(value, where)
    if (
        name in {".", ".."}
        or "/" in name
        or "\\" in name
        or Path(name).name != name
        or _IDENTIFIER_PATTERN.fullmatch(name) is None
    ):
        raise ValueError(f"{where} must not contain a path")
    return name


def _require_sha256(value: Any, where: str) -> str:
    digest = _require_string(value, where)
    if _SHA256_PATTERN.fullmatch(digest) is None:
        raise ValueError(f"{where} must be lowercase SHA-256")
    return digest


def _require_positive_int(value: Any, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{where} must be a positive integer")
    return value


def _require_key(value: Any, where: str) -> tuple[int, int, int]:
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError(f"{where} must contain exactly three integers")
    if any(isinstance(item, bool) or not isinstance(item, int) for item in value):
        raise ValueError(f"{where} must contain exactly three integers")
    key = (value[0], value[1], value[2])
    if key[0] < 0 or key[1] < 1 or key[2] < 1:
        raise ValueError(f"{where} contains an invalid identity")
    return key


def validate_extraction_manifest(manifest: Mapping[str, Any]) -> None:
    """Reject loose schemas, path leakage, non-finite data, and outcome fields."""

    # Canonical serialization rejects NaN/Inf and absolute machine paths before
    # the field-specific validation below.
    canonical_json_bytes(manifest)
    top = _require_exact_keys(manifest, _TOP_LEVEL_KEYS, "manifest")
    if top["schema_version"] != EXTRACTION_MANIFEST_SCHEMA_VERSION:
        raise ValueError("unsupported extraction manifest schema")
    dataset_identifier = _require_string(
        top["dataset_identifier"], "dataset_identifier"
    )
    if _IDENTIFIER_PATTERN.fullmatch(dataset_identifier) is None:
        raise ValueError("dataset_identifier must be a portable identifier")

    source = _require_exact_keys(
        top["source"], {"logical_name", "object_name", "sha256"}, "source"
    )
    _require_logical_name(source["logical_name"], "source.logical_name")
    object_name = _require_string(source["object_name"], "source.object_name")
    if _OBJECT_NAME_PATTERN.fullmatch(object_name) is None:
        raise ValueError("source.object_name must be a valid R object name")
    _require_sha256(source["sha256"], "source.sha256")

    extractor = _require_exact_keys(
        top["extractor"], {"logical_name", "sha256"}, "extractor"
    )
    _require_logical_name(extractor["logical_name"], "extractor.logical_name")
    _require_sha256(extractor["sha256"], "extractor.sha256")

    output = _require_exact_keys(
        top["output"],
        {"bytes", "compression", "format", "logical_name", "sha256"},
        "output",
    )
    output_name = _require_logical_name(output["logical_name"], "output.logical_name")
    if not output_name.lower().endswith(".csv.gz"):
        raise ValueError("output logical name must use .csv.gz")
    _require_positive_int(output["bytes"], "output.bytes")
    if output["compression"] != "gzip" or output["format"] != "csv":
        raise ValueError("output encoding contract is invalid")
    _require_sha256(output["sha256"], "output.sha256")

    selection = _require_exact_keys(
        top["selection"], {"channel", "columns", "ordering"}, "selection"
    )
    if selection["channel"] != "xmeas_7":
        raise ValueError("selected channel must be xmeas_7")
    if selection["columns"] != list(SCALAR_COLUMNS):
        raise ValueError("selected columns or column order changed")
    if selection["ordering"] != list(SCALAR_ORDER):
        raise ValueError("trajectory ordering contract changed")

    validation = _require_exact_keys(
        top["validation"],
        {
            "detector_outcomes_emitted",
            "finite",
            "first_key",
            "last_key",
            "row_count",
            "trajectory_count",
        },
        "validation",
    )
    if validation["detector_outcomes_emitted"] is not False:
        raise ValueError("extraction manifest must not contain detector outcomes")
    if validation["finite"] is not True:
        raise ValueError("extraction manifest must assert finite channel values")
    first_key = _require_key(validation["first_key"], "validation.first_key")
    last_key = _require_key(validation["last_key"], "validation.last_key")
    if first_key > last_key:
        raise ValueError("manifest key range is reversed")
    row_count = _require_positive_int(
        validation["row_count"], "validation.row_count"
    )
    trajectory_count = _require_positive_int(
        validation["trajectory_count"], "validation.trajectory_count"
    )
    if trajectory_count > row_count:
        raise ValueError("trajectory_count cannot exceed row_count")


def validate_extraction_bindings(
    manifest: Mapping[str, Any],
    *,
    source_path: Path,
    extractor_script_path: Path,
    output_path: Path,
) -> None:
    """Recompute every bound hash and revalidate output contents."""

    validate_extraction_manifest(manifest)
    source = manifest["source"]
    extractor = manifest["extractor"]
    output = manifest["output"]
    validation = manifest["validation"]

    if source["logical_name"] != _logical_name(source_path):
        raise ValueError("source logical name mismatch")
    if extractor["logical_name"] != _logical_name(extractor_script_path):
        raise ValueError("extractor logical name mismatch")
    if output["logical_name"] != _logical_name(output_path):
        raise ValueError("output logical name mismatch")
    if source["sha256"] != sha256_file(source_path):
        raise ValueError("source hash mismatch")
    if extractor["sha256"] != sha256_file(extractor_script_path):
        raise ValueError("extractor script hash mismatch")
    if output["sha256"] != sha256_file(output_path):
        raise ValueError("output hash mismatch")
    if output["bytes"] != Path(output_path).stat().st_size:
        raise ValueError("output byte count mismatch")

    summary = validate_scalar_trajectory(output_path)
    observed_summary = {
        "first_key": list(summary.first_key),
        "last_key": list(summary.last_key),
        "row_count": summary.row_count,
        "trajectory_count": summary.trajectory_count,
    }
    for key, observed in observed_summary.items():
        if validation[key] != observed:
            raise ValueError(f"output validation summary mismatch for {key}")


def write_extraction_manifest(
    destination: Path,
    manifest: Mapping[str, Any],
    *,
    external_root: Path,
) -> Path:
    """Validate and atomically publish a manifest beside external outputs."""

    validate_extraction_manifest(manifest)
    return atomic_write_bytes(
        destination,
        canonical_json_bytes(manifest) + b"\n",
        external_root=external_root,
        kind=ExternalArtifactKind.EXTRACTION_MANIFEST,
    )
