"""Controlled Layer B validation of DMREDA event-authority arbitration.

Diagnostic profiles isolate FSM boundaries without changing the canonical Core
or the frozen TEP configuration.  The known same-sample timeout/re-arm behavior
is characterized as an unresolved design choice and is not silently altered.
"""

from __future__ import annotations

from dataclasses import asdict, replace
from typing import Mapping, Sequence

import numpy as np

from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    DMREDAProfile,
    RegimeTransition,
    compute_dmreda_reference,
)
from gold_line.evaluation.alarm_metrics import classify_run_outcome
from stage3.admission.serialization import canonical_sha256
from stage3.tep.configuration import (
    FROZEN_TEP_CONFIGURATION_SHA256,
    build_tep_core_kwargs,
)
from stage3.tep.dual_boundary import classify_dual_boundary_authority


ARBITRATION_CONTRACT_VERSION = "1.0.0"
ARBITRATION_EXPECTATIONS_V1: Mapping[str, object] = {
    "hard_contracts": {
        "transient_below_persistence": "no confirmed authority",
        "inclusive_confirmation_boundary": "confirmation is allowed on the final window sample",
        "persistent_evidence": "sufficient evidence confirms deterministically",
        "interrupted_persistence": "area and count accumulate across a low-evidence sample",
        "refractory": "authority reopens at confirmation index plus refractory length",
        "mode_gating": "D_ONLY, G_ONLY, and D_OR_G gate candidate opening by their named predicates",
        "pending_snapshot": "an in-flight candidate retains its opening confirmation contract",
        "warmup": "authority is suppressed before index 92 and representation history is inherited",
        "first_event_ownership": "an early authority cannot be redeemed by a later authority",
        "determinism": "all controlled cases repeat exactly",
    },
    "known_unresolved_semantics": {
        "same_sample_timeout_rearm": {
            "classification": "unresolved_design_choice_preserved",
            "behavior": "a timed-out candidate re-arms on the same sample when the fast trigger remains true",
            "python_c_stage2_status": "exact parity established",
        },
        "pending_trace": (
            "pending[t] records activity at some point during sample t, not necessarily end-of-sample state"
        ),
        "event_active_trace": "one-sample authority impulse, not a refractory-duration level",
    },
    "scientific_interpretation": (
        "Layer B validates arbitration contracts; it does not establish fault-detection superiority"
    ),
}

FROZEN_ARBITRATION_EXPECTATIONS_SHA256 = (
    "30e3fb127867de8210404ad9483297810250ea93f459b1b6ed708edc4371d1ab"
)


def _profile_payload(profile: DMREDAProfile) -> dict[str, object]:
    payload = asdict(profile)
    payload["m_set"] = list(profile.m_set)
    return payload


def _result_observation(result) -> dict[str, object]:
    pending_indices = np.flatnonzero(result.pending)
    confirmation_indices = np.flatnonzero(result.confirmed)
    return {
        "d": [float(value) for value in result.d],
        "g": [float(value) for value in result.g],
        "r": [float(value) for value in result.r],
        "state": [int(value) for value in result.state],
        "confirm_len_eff": [int(value) for value in result.confirm_len_eff],
        "pending": [bool(value) for value in result.pending],
        "confirmed": [bool(value) for value in result.confirmed],
        "event_active": [bool(value) for value in result.event_active],
        "event_indices": [int(value) for value in result.event_times],
        "first_pending_open": int(pending_indices[0]) if pending_indices.size else None,
        "first_confirmation": (
            int(confirmation_indices[0]) if confirmation_indices.size else None
        ),
        "confirmation_latency_from_first_pending": (
            int(confirmation_indices[0] - pending_indices[0])
            if pending_indices.size and confirmation_indices.size
            else None
        ),
    }


def _fixed_run(
    signal: Sequence[float],
    profile: DMREDAProfile,
    *,
    mode: str = "d_only",
    warmup_samples: int = 0,
):
    values = np.asarray(signal, dtype=np.float64)
    return compute_dmreda_reference(
        values,
        profiles={0: profile},
        transitions={0: RegimeTransition()},
        regime_tick=len(values) + 1,
        warmup_samples=warmup_samples,
        mode=mode,
    )


def _core_case(
    *,
    name: str,
    purpose: str,
    signal: Sequence[float],
    profile: DMREDAProfile,
    expected: Mapping[str, object],
    mode: str = "d_only",
) -> dict[str, object]:
    first = _fixed_run(signal, profile, mode=mode)
    second = _fixed_run(signal, profile, mode=mode)
    observed = _result_observation(first)
    deterministic = observed == _result_observation(second)
    checks = {field: observed[field] == value for field, value in expected.items()}
    checks["deterministic"] = deterministic
    return {
        "case_name": name,
        "fixture_role": "controlled_semantic_diagnostic",
        "purpose": purpose,
        "signal": [float(value) for value in signal],
        "mode": mode.upper(),
        "profile": _profile_payload(profile),
        "configuration_sha256": canonical_sha256(
            {
                "profile": _profile_payload(profile),
                "mode": mode.lower(),
                "warmup_samples": 0,
                "regime_tick": len(signal) + 1,
            }
        ),
        "expected": dict(expected),
        "observed": observed,
        "checks": checks,
        "status": "passed" if all(checks.values()) else "failed",
    }


def _boundary_cases() -> list[dict[str, object]]:
    inclusive_profile = replace(
        DEFAULT_PROFILES[0],
        w1=3,
        w2=1,
        confirm_base=3,
        confirm_min=3,
        confirm_max=3,
        th_d2=0.0,
        th_a=1.0,
        n_min=3,
        refractory=3,
    )
    interrupted_profile = replace(
        inclusive_profile,
        th_a=6.0,
        n_min=2,
    )
    timeout_profile = replace(
        DEFAULT_PROFILES[0],
        w1=3,
        w2=1,
        confirm_base=2,
        confirm_min=2,
        confirm_max=2,
        th_d2=99.0,
        th_a=999.0,
        n_min=2,
    )
    refractory_profile = replace(
        DEFAULT_PROFILES[0],
        confirm_base=2,
        confirm_min=2,
        confirm_max=2,
        th_d=-2.0,
        th_d2=-2.0,
        th_a=0.0,
        n_min=1,
        refractory=3,
    )
    zero_refractory_profile = replace(
        DEFAULT_PROFILES[0],
        confirm_base=2,
        confirm_min=2,
        confirm_max=2,
        th_d=-2.0,
        th_d2=-2.0,
        th_a=0.0,
        n_min=2,
        refractory=0,
    )
    return [
        _core_case(
            name="transient_below_persistence",
            purpose="reject insufficient count at the inclusive timeout boundary",
            signal=[0.0, 1.0, 2.0, 2.0],
            profile=inclusive_profile,
            expected={
                "d": [-1.0, 5.0, 5.0, -1.0],
                "pending": [False, True, True, True],
                "confirmed": [False, False, False, False],
                "event_indices": [],
            },
        ),
        _core_case(
            name="transient_at_persistence_boundary",
            purpose="confirm on the final allowed confirmation sample",
            signal=[0.0, 1.0, 2.0, 3.0, 3.0],
            profile=inclusive_profile,
            expected={
                "confirmed": [False, False, False, True, False],
                "event_indices": [3],
                "confirmation_latency_from_first_pending": 2,
            },
        ),
        _core_case(
            name="persistent_evidence",
            purpose="confirm sustained evidence without changing thresholds",
            signal=[0.0, 1.0, 2.0, 3.0, 4.0, 5.0],
            profile=inclusive_profile,
            expected={"event_indices": [3], "first_pending_open": 1},
        ),
        _core_case(
            name="interrupted_persistence",
            purpose="preserve accumulated area and count across a low-evidence sample",
            signal=[0.0, 1.0, 1.0, 2.0],
            profile=interrupted_profile,
            expected={
                "d": [-1.0, 5.0, -1.0, 5.0],
                "pending": [False, True, True, True],
                "event_indices": [3],
            },
        ),
        _core_case(
            name="refractory_during_and_after",
            purpose="suppress repeated authority during refractory and reopen at its boundary",
            signal=[0.0] * 8,
            profile=refractory_profile,
            expected={"event_indices": [0, 3, 6]},
        ),
        _core_case(
            name="zero_refractory_single_sample_authority",
            purpose="prevent duplicate confirmation authority on one sample",
            signal=[0.0, 0.0, 0.0],
            profile=zero_refractory_profile,
            expected={
                "pending": [True, True, True],
                "confirmed": [False, True, False],
                "event_indices": [1],
            },
        ),
        _core_case(
            name="same_sample_timeout_rearm",
            purpose="preserve and expose the Stage 2 unresolved immediate re-arm behavior",
            signal=[0.0, 1.0, 2.0, 2.0, 2.0],
            profile=timeout_profile,
            expected={
                "d": [-1.0, 5.0, 5.0, -1.0, -1.0],
                "pending": [False, True, True, True, False],
                "event_indices": [],
            },
        ),
    ]


def _mode_gating_cases() -> dict[str, object]:
    profile = replace(
        DEFAULT_PROFILES[0],
        w1=3,
        w2=1,
        beta=0.0,
        m_set=(1,),
        m_base=1,
        lam=1.0,
        e_floor=0.02,
        confirm_base=4,
        confirm_min=4,
        confirm_max=4,
        th_d=0.35,
        th_g=0.10,
        th_d2=99.0,
        th_a=999.0,
        n_min=1,
    )
    signal = np.asarray([0.0, 0.04, 0.08, 0.12])
    expectations = {
        1: {"D_ONLY": False, "G_ONLY": True, "D_OR_G": True},
        2: {"D_ONLY": True, "G_ONLY": True, "D_OR_G": True},
        3: {"D_ONLY": True, "G_ONLY": False, "D_OR_G": True},
    }
    rows: list[dict[str, object]] = []
    all_passed = True
    for sample_index, expected in expectations.items():
        observed: dict[str, bool] = {}
        representations: list[tuple[list[float], list[float]]] = []
        for mode in ("D_ONLY", "G_ONLY", "D_OR_G"):
            result = _fixed_run(
                signal[: sample_index + 1],
                profile,
                mode=mode,
                warmup_samples=sample_index,
            )
            observed[mode] = bool(result.pending[sample_index])
            representations.append(
                ([float(value) for value in result.d], [float(value) for value in result.g])
            )
        passed = observed == expected and representations.count(representations[0]) == 3
        all_passed = all_passed and passed
        rows.append(
            {
                "sample_index": sample_index,
                "d": representations[0][0][-1],
                "g": representations[0][1][-1],
                "expected_pending_by_mode": expected,
                "observed_pending_by_mode": observed,
                "representation_equal_across_modes": representations.count(representations[0]) == 3,
                "status": "passed" if passed else "failed",
            }
        )
    return {
        "fixture_role": "controlled_semantic_diagnostic",
        "profile": _profile_payload(profile),
        "rows": rows,
        "status": "passed" if all_passed else "failed",
    }


def _regime_snapshot_case() -> dict[str, object]:
    profile_0 = replace(
        DEFAULT_PROFILES[0],
        w1=3,
        w2=1,
        rho=1.0,
        confirm_base=2,
        confirm_min=2,
        confirm_max=2,
        th_d2=0.0,
        th_a=6.0,
        n_min=2,
        hold_up=1,
    )
    profile_1 = replace(
        profile_0,
        confirm_base=4,
        confirm_min=4,
        confirm_max=4,
        th_d2=99.0,
        th_a=999.0,
        n_min=1,
    )
    kwargs = {
        "profiles": {0: profile_0, 1: profile_1},
        "transitions": {
            0: RegimeTransition(up_threshold=0.1),
            1: RegimeTransition(),
        },
        "regime_tick": 1,
        "warmup_samples": 0,
        "mode": "d_only",
    }
    first = compute_dmreda_reference([0.0, 1.0, 2.0], **kwargs)
    second = compute_dmreda_reference([0.0, 1.0, 2.0], **kwargs)
    observed = _result_observation(first)
    expected = {
        "d": [-1.0, 5.0, 5.0],
        "r": [0.0, 0.5, 1.0],
        "state": [0, 1, 1],
        "confirm_len_eff": [2, 4, 4],
        "pending": [False, True, True],
        "confirmed": [False, False, True],
        "event_indices": [2],
    }
    checks = {field: observed[field] == value for field, value in expected.items()}
    checks["deterministic"] = observed == _result_observation(second)
    return {
        "fixture_role": "controlled_semantic_diagnostic",
        "purpose": "prove an in-flight candidate retains its opening profile contract",
        "profiles": {"0": _profile_payload(profile_0), "1": _profile_payload(profile_1)},
        "expected": expected,
        "observed": observed,
        "checks": checks,
        "status": "passed" if all(checks.values()) else "failed",
    }


def _warmup_cases() -> dict[str, object]:
    length = 220
    cases: list[tuple[str, np.ndarray, list[int], int | None, str]] = []
    signal = np.zeros(length)
    signal[20:35] = 1.0
    cases.append(("entirely_inside_warmup", signal, [], None, "ignored"))
    signal = np.zeros(length)
    signal[88:] = 1.0
    cases.append(("starts_during_and_persists", signal, [97], 92, "inherits_representation"))
    signal = np.zeros(length)
    signal[92:] = 1.0
    cases.append(("starts_at_boundary", signal, [97], 92, "starts_at_authority_boundary"))
    signal = np.zeros(length)
    signal[120:] = 1.0
    cases.append(("starts_after_warmup", signal, [125], 120, "ordinary_post_warmup"))
    signal = np.zeros(length)
    signal[88:90] = 1.0
    cases.append(("residual_structural_evidence", signal, [97], 92, "inherits_representation"))

    rows: list[dict[str, object]] = []
    all_passed = True
    for name, values, expected_events, expected_pending, interpretation in cases:
        first = compute_dmreda_reference(values, **build_tep_core_kwargs())
        second = compute_dmreda_reference(values, **build_tep_core_kwargs())
        pending = np.flatnonzero(first.pending)
        first_pending = int(pending[0]) if pending.size else None
        no_early_authority = bool(
            not np.any(first.pending[:92])
            and not np.any(first.confirmed[:92])
            and not np.any(first.event_active[:92])
        )
        passed = (
            first.event_times == expected_events
            and first_pending == expected_pending
            and no_early_authority
            and _result_observation(first) == _result_observation(second)
        )
        all_passed = all_passed and passed
        rows.append(
            {
                "case_name": name,
                "interpretation": interpretation,
                "expected_event_indices": expected_events,
                "observed_event_indices": [int(value) for value in first.event_times],
                "expected_first_pending": expected_pending,
                "observed_first_pending": first_pending,
                "no_authority_before_warmup": no_early_authority,
                "status": "passed" if passed else "failed",
            }
        )
    return {
        "fixture_role": "frozen_tep_configuration_characterization",
        "configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "rows": rows,
        "status": "passed" if all_passed else "failed",
    }


def _ownership_cases() -> dict[str, object]:
    first = classify_run_outcome(
        [3, 11], onset=8, trace_length=16, warmup_samples=0
    ).to_dict()
    dual = classify_dual_boundary_authority([158, 200], trace_length=960).to_dict()
    first_passed = (
        first["outcome"] == "false_positive"
        and first["first_alarm"] == 3
        and first["valid_detection_delay_samples"] is None
    )
    dual_passed = (
        dual["boundary_sensitivity_category"] == "false_authority_under_both"
        and dual["outcome_onset_159"] == "false_authority"
        and dual["outcome_onset_160"] == "false_authority"
        and dual["latency_onset_159"] is None
        and dual["latency_onset_160"] is None
    )
    return {
        "single_onset_pre_authority_then_later_post_authority": first,
        "dual_boundary_pre_authority_then_later_post_authority": dual,
        "later_authority_receives_detection_credit": False,
        "status": "passed" if first_passed and dual_passed else "failed",
    }


def run_arbitration_validation() -> dict[str, object]:
    """Execute the frozen controlled Layer B suite."""

    boundary_cases = _boundary_cases()
    mode_gating = _mode_gating_cases()
    regime_snapshot = _regime_snapshot_case()
    warmup = _warmup_cases()
    ownership = _ownership_cases()
    component_status = {
        "boundary_cases": all(row["status"] == "passed" for row in boundary_cases),
        "mode_gating": mode_gating["status"] == "passed",
        "regime_pending_snapshot": regime_snapshot["status"] == "passed",
        "warmup_authority": warmup["status"] == "passed",
        "first_event_ownership": ownership["status"] == "passed",
    }
    expectations_sha256 = canonical_sha256(ARBITRATION_EXPECTATIONS_V1)
    component_status["frozen_expectations_hash_matches"] = (
        expectations_sha256 == FROZEN_ARBITRATION_EXPECTATIONS_SHA256
    )
    payload: dict[str, object] = {
        "schema_version": "1.0.0",
        "document_type": "dmreda.tep.stage3_3.arbitration_validation",
        "contract_version": ARBITRATION_CONTRACT_VERSION,
        "expectations": dict(ARBITRATION_EXPECTATIONS_V1),
        "expectations_sha256": expectations_sha256,
        "frozen_tep_configuration_sha256": FROZEN_TEP_CONFIGURATION_SHA256,
        "boundary_cases": boundary_cases,
        "mode_gating": mode_gating,
        "regime_pending_snapshot": regime_snapshot,
        "warmup_authority": warmup,
        "first_event_ownership": ownership,
        "component_status": component_status,
        "known_unresolved_semantics": {
            "same_sample_timeout_rearm": "unresolved_design_choice_preserved",
            "policy_changed": False,
        },
        "status": "passed" if all(component_status.values()) else "failed",
    }
    payload["result_sha256"] = canonical_sha256(payload)
    return payload


def render_arbitration_report(payload: Mapping[str, object]) -> str:
    lines = [
        "# DMREDA Stage 3.3 Layer B Arbitration Validation",
        "",
        f"Status: `{payload['status']}`",
        "",
        "This controlled suite validates native pending, confirmation, refractory, warm-up, regime-snapshot, and first-authority ownership semantics.",
        "",
        "## Contract results",
        "",
    ]
    for name, value in sorted(payload["component_status"].items()):
        lines.append(f"- `{name}`: `{'passed' if value else 'failed'}`")
    lines.extend(
        [
            "",
            "## Preserved ambiguity",
            "",
            "A timed-out candidate immediately re-arms on the same sample when its fast trigger remains true. This is preserved as `unresolved_design_choice_preserved`; it was not changed in Stage 3.3.",
            "",
            "Interrupted low evidence does not reset accumulated area/count inside the bounded confirmation window.",
            "",
            "The first authority owns the complete trace; a later post-onset authority cannot redeem an earlier false authority.",
            "",
            f"Result SHA-256: `{payload['result_sha256']}`",
            "",
        ]
    )
    return "\n".join(lines)
