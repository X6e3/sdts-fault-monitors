"""Deterministic whole-recording split construction and leakage checks."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
from typing import Mapping, Sequence

from .contracts import SHA256_PATTERN
from .serialization import canonical_sha256


BANK_NAMES = ("A", "B", "C", "D")


@dataclass(frozen=True)
class RecordingIdentity:
    dataset_identifier: str
    recording_id: str
    lineage_id: str
    content_sha256: str
    sample_count: int
    anomaly_interval_count: int
    eligible_banks: tuple[str, ...]

    def __post_init__(self) -> None:
        for name in ("dataset_identifier", "recording_id", "lineage_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        if not SHA256_PATTERN.fullmatch(self.content_sha256):
            raise ValueError("content_sha256 must be a lowercase SHA-256 digest")
        if self.sample_count <= 0 or self.anomaly_interval_count < 0:
            raise ValueError("recording counts are invalid")
        if not self.eligible_banks or any(
            bank not in BANK_NAMES for bank in self.eligible_banks
        ):
            raise ValueError("eligible_banks must contain only A, B, C, or D")
        if len(set(self.eligible_banks)) != len(self.eligible_banks):
            raise ValueError("eligible_banks must be unique")

    @property
    def independent_key(self) -> str:
        return f"{self.dataset_identifier}:{self.recording_id}"


@dataclass(frozen=True)
class SplitManifest:
    schema_version: str
    dataset_identifier: str
    seed: int
    banks: Mapping[str, tuple[RecordingIdentity, ...]]
    excluded_recording_ids: tuple[str, ...]
    exclusion_reasons: Mapping[str, str]
    split_sha256: str

    def to_dict(self, *, include_hash: bool = True) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema_version": self.schema_version,
            "dataset_identifier": self.dataset_identifier,
            "seed": self.seed,
            "banks": {
                bank: [asdict(record) for record in self.banks[bank]]
                for bank in BANK_NAMES
            },
            "excluded_recording_ids": list(self.excluded_recording_ids),
            "exclusion_reasons": dict(sorted(self.exclusion_reasons.items())),
        }
        if include_hash:
            payload["split_sha256"] = self.split_sha256
        return payload


def _assignment_key(seed: int, record: RecordingIdentity) -> bytes:
    return hashlib.sha256(
        f"dmreda-stage3-split-v1\0{seed}\0{record.independent_key}".encode("utf-8")
    ).digest()


def _validate_source_records(records: Sequence[RecordingIdentity]) -> None:
    if not records:
        raise ValueError("at least one recording is required")
    datasets = {record.dataset_identifier for record in records}
    if len(datasets) != 1:
        raise ValueError("one split manifest cannot mix datasets")
    keys = [record.independent_key for record in records]
    if len(keys) != len(set(keys)):
        raise ValueError("recording identities must be unique")
    hashes = [record.content_sha256 for record in records]
    if len(hashes) != len(set(hashes)):
        raise ValueError("content-hash duplicates are forbidden")
    lineages = [record.lineage_id for record in records]
    if len(lineages) != len(set(lineages)):
        raise ValueError(
            "multiple windows from one parent lineage are forbidden; assign the whole recording"
        )


def validate_split_manifest(manifest: SplitManifest) -> None:
    if manifest.schema_version != "1.0.0":
        raise ValueError("unsupported split schema")
    if tuple(manifest.banks) != BANK_NAMES:
        raise ValueError("banks must be ordered A, B, C, D")
    all_records = [record for bank in BANK_NAMES for record in manifest.banks[bank]]
    _validate_source_records(all_records)
    for bank in BANK_NAMES:
        for record in manifest.banks[bank]:
            if bank not in record.eligible_banks:
                raise ValueError(f"recording {record.recording_id} is ineligible for Bank {bank}")
    expected = canonical_sha256(manifest.to_dict(include_hash=False))
    if manifest.split_sha256 != expected:
        raise ValueError("split hash does not bind the manifest")


def build_recording_disjoint_split(
    records: Sequence[RecordingIdentity],
    *,
    bank_counts: Mapping[str, int],
    seed: int,
    exclusions: Mapping[str, str] | None = None,
) -> SplitManifest:
    """Assign complete independent recordings using a stable seeded order."""

    _validate_source_records(records)
    if set(bank_counts) != set(BANK_NAMES):
        raise ValueError("bank_counts must define A, B, C, and D")
    if any(not isinstance(value, int) or value < 0 for value in bank_counts.values()):
        raise ValueError("bank counts must be non-negative integers")
    if not isinstance(seed, int):
        raise ValueError("seed must be an integer")
    exclusions = dict(exclusions or {})
    known_ids = {record.recording_id for record in records}
    unknown_exclusions = set(exclusions) - known_ids
    if unknown_exclusions:
        raise ValueError(f"exclusions reference unknown recordings: {unknown_exclusions}")
    if any(not reason.strip() for reason in exclusions.values()):
        raise ValueError("every exclusion requires a reason")

    available = sorted(
        (record for record in records if record.recording_id not in exclusions),
        key=lambda record: (_assignment_key(seed, record), record.independent_key),
    )
    assigned: dict[str, tuple[RecordingIdentity, ...]] = {}
    consumed: set[str] = set()
    for bank in BANK_NAMES:
        eligible = [
            record
            for record in available
            if record.recording_id not in consumed and bank in record.eligible_banks
        ]
        count = bank_counts[bank]
        if len(eligible) < count:
            raise ValueError(f"insufficient eligible independent recordings for Bank {bank}")
        selected = tuple(eligible[:count])
        assigned[bank] = selected
        consumed.update(record.recording_id for record in selected)

    if len(consumed) != len(available):
        raise ValueError(
            "every non-excluded recording must be assigned; add an explicit exclusion reason"
        )

    payload = {
        "schema_version": "1.0.0",
        "dataset_identifier": records[0].dataset_identifier,
        "seed": seed,
        "banks": {
            bank: [asdict(record) for record in assigned[bank]] for bank in BANK_NAMES
        },
        "excluded_recording_ids": sorted(exclusions),
        "exclusion_reasons": dict(sorted(exclusions.items())),
    }
    manifest = SplitManifest(
        schema_version="1.0.0",
        dataset_identifier=records[0].dataset_identifier,
        seed=seed,
        banks=assigned,
        excluded_recording_ids=tuple(sorted(exclusions)),
        exclusion_reasons=dict(sorted(exclusions.items())),
        split_sha256=canonical_sha256(payload),
    )
    validate_split_manifest(manifest)
    return manifest
