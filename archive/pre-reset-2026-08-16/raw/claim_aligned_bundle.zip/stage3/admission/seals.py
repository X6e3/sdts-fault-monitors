"""Fail-closed Bank D seal and immutable opening audit event."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Mapping

from .contracts import AdmissionLevel, SHA256_PATTERN
from .serialization import canonical_sha256


@dataclass(frozen=True)
class FreezeBindings:
    dataset_manifest_sha256: str
    split_manifest_sha256: str
    channel_configuration_sha256: str
    scaling_configuration_sha256: str
    detector_configuration_sha256: str
    protocol_sha256: str
    risk_result_sha256: str
    source_commit: str

    def __post_init__(self) -> None:
        for name in (
            "dataset_manifest_sha256",
            "split_manifest_sha256",
            "channel_configuration_sha256",
            "scaling_configuration_sha256",
            "detector_configuration_sha256",
            "protocol_sha256",
            "risk_result_sha256",
        ):
            if not SHA256_PATTERN.fullmatch(getattr(self, name)):
                raise ValueError(f"{name} must be a lowercase SHA-256 digest")
        if not (
            len(self.source_commit) in {40, 64}
            and all(character in "0123456789abcdef" for character in self.source_commit)
        ):
            raise ValueError("source_commit must be a lowercase Git object identity")

    @property
    def binding_sha256(self) -> str:
        return canonical_sha256(asdict(self))


@dataclass(frozen=True)
class BankDSeal:
    schema_version: str = "1.0.0"
    opened: bool = False
    audit_events: tuple[Mapping[str, object], ...] = ()

    def __post_init__(self) -> None:
        if self.schema_version != "1.0.0":
            raise ValueError("unsupported bank-seal schema")
        if self.opened != bool(self.audit_events):
            raise ValueError("opened state and audit-event presence must agree")
        if len(self.audit_events) > 1:
            raise ValueError("Bank D may be opened at most once")


def open_bank_d(
    seal: BankDSeal,
    *,
    admission_level: AdmissionLevel,
    bindings: FreezeBindings,
    protocol_frozen: bool,
    detector_configuration_frozen: bool,
    channel_frozen: bool,
    scaling_frozen: bool,
    risk_target_frozen: bool,
    risk_match_passed: bool,
    opened_at_utc: str,
) -> BankDSeal:
    """Open Bank D exactly once after all scientific prerequisites pass."""

    if seal.opened or seal.audit_events:
        raise PermissionError("Bank D cannot be reopened")
    if admission_level is not AdmissionLevel.CLAIM_GRADE_ADMITTED:
        raise PermissionError("Bank D requires a claim-grade admitted dataset")
    prerequisites = {
        "protocol_frozen": protocol_frozen,
        "detector_configuration_frozen": detector_configuration_frozen,
        "channel_frozen": channel_frozen,
        "scaling_frozen": scaling_frozen,
        "risk_target_frozen": risk_target_frozen,
        "risk_match_passed": risk_match_passed,
    }
    failed = sorted(name for name, passed in prerequisites.items() if not passed)
    if failed:
        raise PermissionError(f"Bank D prerequisites failed: {', '.join(failed)}")
    if not opened_at_utc.endswith("Z"):
        raise ValueError("opened_at_utc must be an explicit UTC timestamp")
    event_without_hash: dict[str, object] = {
        "schema_version": "1.0.0",
        "action": "open_bank_d",
        "opened_at_utc": opened_at_utc,
        "source_commit": bindings.source_commit,
        "binding_sha256": bindings.binding_sha256,
        "bindings": asdict(bindings),
    }
    event = dict(event_without_hash)
    event["audit_event_sha256"] = canonical_sha256(event_without_hash)
    return BankDSeal(opened=True, audit_events=(event,))
