"""Scientific-output and repository-payload authorization guards."""

from __future__ import annotations

from pathlib import PurePosixPath
from typing import Iterable, Mapping, Sequence

from gold_line.evaluation.alarm_metrics import RunOutcome

from .contracts import AdmissionLevel, SHA256_PATTERN


_FORBIDDEN_PARTS = {
    ".cache",
    ".venv",
    "__pycache__",
    "dataset-audit",
    "downloads",
    "raw-data",
    "raw_datasets",
    "venv",
    "venvs",
}
_FORBIDDEN_NAMES = {
    ".env",
    "credentials.json",
    "id_rsa",
    "id_ed25519",
    "kaggle.json",
}
_FORBIDDEN_SUFFIXES = {
    ".7z",
    ".bundle",
    ".h5",
    ".hdf5",
    ".key",
    ".mat",
    ".npy",
    ".npz",
    ".parquet",
    ".pem",
    ".rdata",
    ".tar",
    ".tgz",
    ".wav",
    ".zip",
}


def forbidden_stage3_tracked_paths(paths: Iterable[str]) -> tuple[str, ...]:
    """Return forbidden Stage 3 payload paths from a tracked-path inventory."""

    forbidden: list[str] = []
    for raw in paths:
        path = PurePosixPath(raw)
        lowered_parts = {part.lower() for part in path.parts}
        lowered_name = path.name.lower()
        suffixes = {suffix.lower() for suffix in path.suffixes}
        if (
            lowered_parts.intersection(_FORBIDDEN_PARTS)
            or lowered_name in _FORBIDDEN_NAMES
            or suffixes.intersection(_FORBIDDEN_SUFFIXES)
            or lowered_name.endswith(".tar.gz")
        ):
            forbidden.append(raw)
    return tuple(sorted(forbidden))


def validate_hash_bindings(
    observed: Mapping[str, str], expected: Mapping[str, str]
) -> None:
    """Require exact, complete SHA-256 output/config/protocol/dataset binding."""

    if set(observed) != set(expected):
        raise ValueError("hash-binding key set is incomplete or unexpected")
    for name, expected_digest in expected.items():
        observed_digest = observed[name]
        if not SHA256_PATTERN.fullmatch(expected_digest):
            raise ValueError(f"expected binding {name} is not SHA-256")
        if observed_digest != expected_digest:
            raise ValueError(f"hash binding mismatch for {name}")


def authorize_detector_ranking(
    *, admission_level: AdmissionLevel, achieved_risk_matched: bool
) -> None:
    if admission_level is not AdmissionLevel.CLAIM_GRADE_ADMITTED:
        raise PermissionError("detector ranking requires a claim-grade admitted dataset")
    if not achieved_risk_matched:
        raise PermissionError("detector ranking is forbidden when achieved risk is unmatched")


def authorize_scientific_output(
    *,
    admission_level: AdmissionLevel,
    protocol_frozen: bool,
    bank_d_opened: bool,
) -> None:
    if admission_level is not AdmissionLevel.CLAIM_GRADE_ADMITTED:
        raise PermissionError("scientific output requires a claim-grade admitted dataset")
    if not protocol_frozen or not bank_d_opened:
        raise PermissionError("scientific output requires frozen protocol and opened Bank D")


def conditional_valid_detection_delays(
    outcomes: Sequence[RunOutcome],
) -> tuple[int, ...]:
    """Return delays for valid detections only; FP and miss never contribute."""

    delays: list[int] = []
    for outcome in outcomes:
        if outcome.detected:
            if outcome.delay_samples is None:
                raise ValueError("valid detection is missing delay")
            delays.append(outcome.delay_samples)
        elif outcome.delay_samples is not None:
            raise ValueError("false-positive/miss outcome carries a delay")
    return tuple(delays)
