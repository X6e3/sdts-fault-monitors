"""Fail-closed contracts for DMREDA Stage 3 dataset admission."""

from .adapters import DatasetAdapter, RecordingDescriptor, ScalarTrace
from .contracts import (
    AdmissionLevel,
    AuthorityStatus,
    DatasetAuthority,
    DataAccessPolicy,
    FrozenPreprocessing,
    LicenseStatus,
    apply_fixed_affine,
)
from .guards import (
    authorize_detector_ranking,
    authorize_scientific_output,
    conditional_valid_detection_delays,
    forbidden_stage3_tracked_paths,
    validate_hash_bindings,
)
from .seals import BankDSeal, FreezeBindings, open_bank_d
from .serialization import (
    atomic_write_json,
    canonical_json_bytes,
    canonical_sha256,
    load_strict_json,
    validate_no_machine_paths,
)
from .splits import (
    RecordingIdentity,
    SplitManifest,
    build_recording_disjoint_split,
)

__all__ = [
    "AdmissionLevel",
    "AuthorityStatus",
    "BankDSeal",
    "DataAccessPolicy",
    "DatasetAdapter",
    "DatasetAuthority",
    "FreezeBindings",
    "FrozenPreprocessing",
    "LicenseStatus",
    "RecordingDescriptor",
    "RecordingIdentity",
    "ScalarTrace",
    "SplitManifest",
    "apply_fixed_affine",
    "atomic_write_json",
    "authorize_detector_ranking",
    "authorize_scientific_output",
    "build_recording_disjoint_split",
    "canonical_json_bytes",
    "canonical_sha256",
    "conditional_valid_detection_delays",
    "forbidden_stage3_tracked_paths",
    "load_strict_json",
    "open_bank_d",
    "validate_hash_bindings",
    "validate_no_machine_paths",
]
