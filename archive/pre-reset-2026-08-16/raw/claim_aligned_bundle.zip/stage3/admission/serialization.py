"""Canonical, finite, path-safe JSON serialization for Stage 3 artifacts."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Mapping


FORBIDDEN_MACHINE_PATH_MARKERS = (
    "/" + "Users" + "/",
    "/" + "home" + "/",
    "file" + "://",
)


def _reject_nonfinite(token: str) -> None:
    raise ValueError(f"non-finite JSON token: {token}")


def validate_no_machine_paths(value: Any, *, location: str = "$") -> None:
    """Reject absolute user paths in nested public-facing data."""

    if isinstance(value, str):
        if any(marker in value for marker in FORBIDDEN_MACHINE_PATH_MARKERS):
            raise ValueError(f"machine-specific path at {location}")
        return
    if isinstance(value, Mapping):
        for key, child in value.items():
            validate_no_machine_paths(child, location=f"{location}.{key}")
        return
    if isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            validate_no_machine_paths(child, location=f"{location}[{index}]")


def canonical_json_bytes(value: Any) -> bytes:
    """Return deterministic UTF-8 JSON bytes and reject non-finite values."""

    validate_no_machine_paths(value)
    encoded = json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )
    return encoded.encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def load_strict_json(path: Path) -> Any:
    """Load JSON while rejecting the non-standard NaN/Infinity tokens."""

    return json.loads(
        path.read_text(encoding="utf-8"),
        parse_constant=_reject_nonfinite,
    )


def atomic_write_json(path: Path, value: Any) -> None:
    """Atomically write canonical JSON with a trailing newline."""

    path = Path(path)
    payload = canonical_json_bytes(value) + b"\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise
