"""Dataset-neutral adapter metadata interface.

The interface deliberately does not prescribe normalization or event logic.
Adapters expose immutable observations and authority metadata; the frozen
preprocessing contract remains external and common to every detector.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Protocol, Sequence, runtime_checkable

from .contracts import DataAccessPolicy, SHA256_PATTERN


@dataclass(frozen=True)
class RecordingDescriptor:
    dataset_identifier: str
    recording_id: str
    lineage_id: str
    device_id: str | None
    session_id: str | None
    sample_count: int
    sample_rate_hz: float | None
    timestamp_authority: str
    channel_name: str
    units: str
    source_member: str
    source_sha256: str
    anomaly_interval_count: int
    missing_sample_count: int

    def __post_init__(self) -> None:
        for name in (
            "dataset_identifier",
            "recording_id",
            "lineage_id",
            "timestamp_authority",
            "channel_name",
            "units",
            "source_member",
        ):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a non-empty string")
        if self.sample_count <= 0:
            raise ValueError("sample_count must be positive")
        if self.sample_rate_hz is not None and (
            not math.isfinite(self.sample_rate_hz) or self.sample_rate_hz <= 0.0
        ):
            raise ValueError("sample_rate_hz must be finite and positive")
        if not SHA256_PATTERN.fullmatch(self.source_sha256):
            raise ValueError("source_sha256 must be a lowercase SHA-256 digest")
        if self.anomaly_interval_count < 0 or self.missing_sample_count < 0:
            raise ValueError("counts must be non-negative")


@dataclass(frozen=True)
class ScalarTrace:
    samples: tuple[float, ...]
    sample_indices: tuple[int, ...]
    timestamps: tuple[str | None, ...]
    missing_sample_indicators: tuple[bool, ...]
    anomaly_intervals: tuple[tuple[int, int], ...]

    def __post_init__(self) -> None:
        size = len(self.samples)
        if size == 0:
            raise ValueError("trace must not be empty")
        if not (
            len(self.sample_indices)
            == len(self.timestamps)
            == len(self.missing_sample_indicators)
            == size
        ):
            raise ValueError("trace fields must align")
        if tuple(self.sample_indices) != tuple(range(size)):
            raise ValueError("sample_indices must be contiguous and zero-based")
        if any(not math.isfinite(float(value)) for value in self.samples):
            raise ValueError("samples must be finite")
        for start, stop in self.anomaly_intervals:
            if not (0 <= start < stop <= size):
                raise ValueError("anomaly interval must be half-open and in range")


@runtime_checkable
class DatasetAdapter(Protocol):
    """Required read-only interface for an admitted dataset adapter."""

    @property
    def dataset_identifier(self) -> str: ...

    @property
    def adapter_configuration_sha256(self) -> str: ...

    def recordings(self) -> Sequence[RecordingDescriptor]: ...

    def load_scalar_trace(
        self, recording_id: str, *, access: DataAccessPolicy
    ) -> ScalarTrace: ...
