"""Dataset-authority, preprocessing, and access contracts."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
import math
import re
from typing import Mapping, Sequence

from .serialization import canonical_sha256


SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")


class AdmissionLevel(str, Enum):
    REJECTED = "rejected"
    PROVENANCE_ONLY = "provenance_only"
    EXPLORATORY = "exploratory"
    CLAIM_GRADE_CANDIDATE = "claim_grade_candidate"
    CLAIM_GRADE_ADMITTED = "claim_grade_admitted"


class AuthorityStatus(str, Enum):
    VERIFIED_PRIMARY_SOURCE = "verified_primary_source"
    VERIFIED_AUTHORITATIVE_MIRROR = "verified_authoritative_mirror"
    UNRESOLVED = "unresolved"
    FAILED = "failed"


class LicenseStatus(str, Enum):
    VERIFIED_OPEN = "verified_open"
    VERIFIED_RESEARCH_ONLY = "verified_research_only"
    HUMAN_ACCESS_REQUIRED = "human_access_required"
    UNRESOLVED = "unresolved"
    PROHIBITED = "prohibited"


_RAW_STATUSES = {"raw", "minimally_processed", "derived", "simulation"}
_LABEL_AUTHORITIES = {
    "dataset_supplied_onset",
    "dataset_supplied_interval",
    "recording_condition_only",
    "locally_inferred",
    "none",
    "unresolved",
}
_SAMPLE_RATE_AUTHORITIES = {
    "exact",
    "timestamped_irregular",
    "sample_index_only",
    "unresolved",
}


def _require_text(value: str, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a non-empty string")


def _validate_sha256(value: str, name: str) -> None:
    if not SHA256_PATTERN.fullmatch(value):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest")


@dataclass(frozen=True)
class DatasetAuthority:
    schema_version: str
    dataset_identifier: str
    admission_level: AdmissionLevel
    authority_status: AuthorityStatus
    source_organization: str
    source_locator: str
    citation: str
    version: str
    license_status: LicenseStatus
    license_locator: str | None
    archive_sha256: str | None
    member_sha256: Mapping[str, str]
    raw_or_derived_status: str
    preprocessing_history: tuple[str, ...]
    recording_identity_fields: tuple[str, ...]
    label_authority: str
    sample_rate_authority: str
    channel_authority: str
    normal_data_suitable: bool
    bank_suitability: Mapping[str, bool]
    blocker_reasons: tuple[str, ...]
    human_access_requirements: tuple[str, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.admission_level, AdmissionLevel):
            raise TypeError("admission_level must be an AdmissionLevel")
        if not isinstance(self.authority_status, AuthorityStatus):
            raise TypeError("authority_status must be an AuthorityStatus")
        if not isinstance(self.license_status, LicenseStatus):
            raise TypeError("license_status must be a LicenseStatus")
        if self.schema_version != "1.0.0":
            raise ValueError("unsupported dataset-authority schema version")
        for name in (
            "dataset_identifier",
            "source_organization",
            "source_locator",
            "citation",
            "version",
            "channel_authority",
        ):
            _require_text(getattr(self, name), name)
        if not self.source_locator.startswith(("https://", "doi:")):
            raise ValueError("source_locator must be an authoritative HTTPS or DOI locator")
        if self.raw_or_derived_status not in _RAW_STATUSES:
            raise ValueError("invalid raw_or_derived_status")
        if self.label_authority not in _LABEL_AUTHORITIES:
            raise ValueError("invalid label_authority")
        if self.sample_rate_authority not in _SAMPLE_RATE_AUTHORITIES:
            raise ValueError("invalid sample_rate_authority")
        if set(self.bank_suitability) != {"A", "B", "C", "D"}:
            raise ValueError("bank_suitability must define A, B, C, and D")
        if self.archive_sha256 is not None:
            _validate_sha256(self.archive_sha256, "archive_sha256")
        for member, digest in self.member_sha256.items():
            _require_text(member, "member path")
            _validate_sha256(digest, f"member_sha256[{member!r}]")
        if self.license_status is LicenseStatus.HUMAN_ACCESS_REQUIRED:
            if not self.human_access_requirements:
                raise ValueError("human access requirements must be recorded")
        elif self.human_access_requirements:
            raise ValueError("human access requirements conflict with license status")
        if self.admission_level is AdmissionLevel.CLAIM_GRADE_ADMITTED:
            if self.authority_status not in {
                AuthorityStatus.VERIFIED_PRIMARY_SOURCE,
                AuthorityStatus.VERIFIED_AUTHORITATIVE_MIRROR,
            }:
                raise ValueError("admission requires verified authority")
            if self.license_status not in {
                LicenseStatus.VERIFIED_OPEN,
                LicenseStatus.VERIFIED_RESEARCH_ONLY,
            }:
                raise ValueError("admission requires verified usable terms")
            if self.archive_sha256 is None or not self.member_sha256:
                raise ValueError("admission requires immutable source hashes")
            if not self.recording_identity_fields:
                raise ValueError("admission requires independent recording identities")
            if self.label_authority not in {
                "dataset_supplied_onset",
                "dataset_supplied_interval",
            }:
                raise ValueError("admission requires authoritative event timing")
            if not self.normal_data_suitable or not all(self.bank_suitability.values()):
                raise ValueError("admission requires suitable A/B/C/D data")
            if self.blocker_reasons:
                raise ValueError("admitted datasets cannot retain blockers")

    def to_dict(self) -> dict[str, object]:
        value = asdict(self)
        value["admission_level"] = self.admission_level.value
        value["authority_status"] = self.authority_status.value
        value["license_status"] = self.license_status.value
        value["preprocessing_history"] = list(self.preprocessing_history)
        value["recording_identity_fields"] = list(self.recording_identity_fields)
        value["blocker_reasons"] = list(self.blocker_reasons)
        value["human_access_requirements"] = list(self.human_access_requirements)
        value["member_sha256"] = dict(sorted(self.member_sha256.items()))
        value["bank_suitability"] = dict(sorted(self.bank_suitability.items()))
        return value

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "DatasetAuthority":
        """Construct a validated record from strict JSON-compatible values."""

        values = dict(payload)
        values["admission_level"] = AdmissionLevel(str(values["admission_level"]))
        values["authority_status"] = AuthorityStatus(str(values["authority_status"]))
        values["license_status"] = LicenseStatus(str(values["license_status"]))
        for name in (
            "preprocessing_history",
            "recording_identity_fields",
            "blocker_reasons",
            "human_access_requirements",
        ):
            raw = values[name]
            if not isinstance(raw, (list, tuple)):
                raise TypeError(f"{name} must be an array")
            values[name] = tuple(str(item) for item in raw)
        for name in ("member_sha256", "bank_suitability"):
            if not isinstance(values[name], Mapping):
                raise TypeError(f"{name} must be an object")
            values[name] = dict(values[name])
        return cls(**values)  # type: ignore[arg-type]

    @property
    def authority_record_sha256(self) -> str:
        return canonical_sha256(self.to_dict())


@dataclass(frozen=True)
class FrozenPreprocessing:
    channel_name: str
    units: str
    offset_fixed: float
    scale_fixed: float
    fitted_bank: str
    full_trace_normalization: bool = False
    label_dependent_selection: bool = False

    def __post_init__(self) -> None:
        _require_text(self.channel_name, "channel_name")
        _require_text(self.units, "units")
        if not math.isfinite(self.offset_fixed):
            raise ValueError("offset_fixed must be finite")
        if not math.isfinite(self.scale_fixed) or self.scale_fixed <= 0.0:
            raise ValueError("scale_fixed must be finite and positive")
        if self.fitted_bank != "A":
            raise ValueError("fixed affine scaling must be fitted from Bank A")
        if self.full_trace_normalization:
            raise ValueError("full-trace normalization is forbidden")
        if self.label_dependent_selection:
            raise ValueError("label-dependent channel selection is forbidden")

    def to_dict(self) -> dict[str, object]:
        return asdict(self)

    @property
    def configuration_sha256(self) -> str:
        return canonical_sha256(self.to_dict())


def apply_fixed_affine(
    samples: Sequence[float], preprocessing: FrozenPreprocessing
) -> tuple[float, ...]:
    """Apply the frozen causal affine equation independently per sample."""

    transformed: list[float] = []
    for sample in samples:
        numeric = float(sample)
        if not math.isfinite(numeric):
            raise ValueError("raw samples must be finite")
        transformed.append(
            (numeric - preprocessing.offset_fixed) / preprocessing.scale_fixed
        )
    return tuple(transformed)


@dataclass(frozen=True)
class DataAccessPolicy:
    """Prevent calibration code from requesting evaluation labels."""

    bank: str
    include_labels: bool
    purpose: str

    def __post_init__(self) -> None:
        if self.bank not in {"A", "B", "C", "D"}:
            raise ValueError("bank must be A, B, C, or D")
        _require_text(self.purpose, "purpose")
        if self.bank in {"A", "B", "C"} and self.include_labels:
            raise PermissionError("calibration/risk banks may not expose labels")
