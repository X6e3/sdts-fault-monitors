# Resume Stage 3.3 V2

From the scientific output root, run `shasum -a 256 -c manifests/SHA256SUMS_BLOCKED_V2.txt`. Then follow `recovery/GIT_BUNDLE_RECEIPT_V2.json` with the private recovery root to verify the Git bundle. Check out the recorded branch and HEAD, validate the clean worktree, then inspect the denial seal and stop report. Do not open Bank D under this frozen protocol. A new scientific campaign requires an explicit new protocol; do not retune this result.
