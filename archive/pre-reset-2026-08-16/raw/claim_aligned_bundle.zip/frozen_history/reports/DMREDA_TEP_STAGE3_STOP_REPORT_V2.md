# DMREDA TEP Stage 3.3 Stop Report V2

The campaign stopped at the machine-derived Bank D admission gate.

- Scientific stop status: `unstable_normal_authority`.
- Seal reasons: dmreda_normal_false_authority_gate_failed, normal_summary_and_admission_disagree.
- DMREDA normal false authority: 42/500.
- Frozen maximum allowed count: 25.
- Bank D: sealed and unopened.
- Faulty Testing values: not accessed by this campaign.
- Disturbed outcome rows or rankings: none.
- Scientific status: unstable_normal_authority; no claim-grade Layer C result.

The representation and arbitration artifacts remain engineering evidence only. The denial is preserved; thresholds, native event semantics, and the co-equal onset contract were not changed to obtain admission.
