# DMREDA TEP xmeas_7 Stage 3.3 Frozen Protocol V2

Status: **frozen**

## Scientific identity

DMREDA is a causal, deterministic, bounded-state temporal evidence representation and arbitration core.

- Layer A: representation validation
- Layer B: arbitration and external event-authority validation
- Layer C: TEP xmeas_7 assurance-channel application

RMS, CUSUM, and EWMA are classical scalar evidence references. Their independent admission cannot veto the primary DMREDA application.

## Co-equal onset contract

- Candidate 1: final normal label 159, first affected label 160, Python onset index 159
- Candidate 2: final normal label 160, first affected label 161, Python onset index 160
- Neither mapping is uniquely primary.
- Events and evidence are generated once without an onset, then classified under both mappings.
- Selecting the more favorable boundary after outcomes is prohibited.

## Frozen numerical contract

- Channel: `xmeas_7`
- Scaling: `(raw_x - 2705.0) / 7.561259999999865`, exactly once
- Primary mode: `D_OR_G`
- Warm-up: `92` samples
- Sensitivity multiplier: `2.5` on `th_d`, `th_g`, `th_d2`, and `th_a` only

## Scalar-reference configurations

- `cusum`: `fa2d5e0acd005129429c86c1425f461efe11fbae6b25993f4ee9322c4da072c1`
- `ewma`: `817a26eab34d1fc08a991579aaaaccf1997f5cbdb2b9bc52867603eb4f70b3f2`
- `rms`: `01ed156913d0b73a1f9d5b876ec90218291c693dc01aeaab984ec588f7029ec1`

## Authority and stop rules

The first authority owns the complete trajectory. False authority and no authority have no valid latency. Comparator admission failure only excludes that comparator; it does not deny primary Bank D admission.

Source commit: `7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc`
