# Frozen DMREDA Stage 3.3 history

This directory is an immutable forensic copy of the claim-bearing Stage 3.3
baseline at source commit `7fb1fe26e7a24831c28bd3d64ef56831b2ab54bc`.

The historical result is negative and must not be retuned, rewritten, or
reclassified:

- 42 of 500 fault-free testing trajectories produced authority;
- the mission horizon was 960 samples;
- the frozen admission limit was 25 of 500 trajectories;
- Bank D was denied and Faulty Testing remained sealed by the campaign.

`source/` contains the verified Git bundle. `protocol/`, `results/`,
`environment/`, `golden/`, and `reports/` are byte-for-byte copies from the
recovered external Stage 3.3 package or source commit. Raw RData is deliberately
not copied here; its frozen hashes are recorded in the protocol and raw-integrity
record.

`SHA256SUMS` binds every copied forensic artifact. New experiments must write
only under `current_claim/` or `experimental/` and must refer to this directory
as historical evidence, never as current validation.
