#!/usr/bin/env python3
"""Run the frozen, non-claim-grade DMREDA finalization ablation.

This program intentionally refuses to read FaultyTesting.  It accepts only the
two value-bearing DEVELOPMENT extracts named in protocol_v3_development.json.
The complete threshold-search results and selected trajectory outcomes are
written as audit artifacts; no locked evaluation is performed here.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, replace
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
from typing import Callable, Iterable, Mapping, Sequence

import numpy as np

from gold_line.benchmarks.fair_baseline_scaffold import (
    EventGateConfig,
    confirmed_alarm_times,
    ewma_mean_score,
    two_sided_cusum_score,
)
from gold_line.core.dmreda_reference_clean import (
    DEFAULT_PROFILES,
    DEFAULT_TRANSITIONS,
    DMREDAProfile,
    RegimeTransition,
    compute_dmreda_reference,
)
from stage3.tep.configuration import apply_tep_affine_scale


PROTOCOL_PATH = Path(__file__).with_name("protocol_v3_development.json")
EXPECTED_NORMAL_SHA256 = (
    "f48e6735bc80d0ab0ab4b7aad4957a7203ed346ea1556ef7e1f37693fc686b4d"
)
EXPECTED_FAULT_SHA256 = (
    "c8c6990730c23be501260235417d2c8347653cf11faae056ac09e39b6288261d"
)
HORIZON = 500
WARMUP = 92
FAULT_ONSET = 20
TARGET_FALSE_COUNT = 10
TARGET_RESTRICTED_SUM = 97_500
KAPPA_GRID = np.array([integer / 20.0 for integer in range(10, 321)], dtype=np.float64)
REPORTING_HORIZONS = (120, 160, 240, 320, 400, 500)
BOOTSTRAP_SEED = 20_260_814
BOOTSTRAP_REPLICATES = 10_000
VARIANT_LABELS = tuple("ABCDEFGHIJKL")


@dataclass(frozen=True)
class SignalRecord:
    fault: int
    simulation_run: int
    raw: np.ndarray
    scaled: np.ndarray

    @property
    def key(self) -> tuple[int, int]:
        return self.fault, self.simulation_run


@dataclass(frozen=True)
class RepresentationTrace:
    d: np.ndarray
    g: np.ndarray
    th_d: np.ndarray
    th_g: np.ndarray
    th_d2: np.ndarray
    th_a: np.ndarray
    n_min: np.ndarray
    confirm_len: np.ndarray


@dataclass(frozen=True)
class SelectedDetector:
    label: str
    parameter_name: str
    parameter_value: float
    candidate_index: int
    candidate_count: int
    candidate_grid_sha256: str
    calibration_first_times: np.ndarray
    normal_first_times: np.ndarray
    fault_first_times: np.ndarray


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_sha256(payload: object) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def float_grid_sha256(values: np.ndarray, domain: bytes) -> str:
    canonical = np.ascontiguousarray(values, dtype=np.dtype("<f8"))
    digest = hashlib.sha256()
    digest.update(domain)
    digest.update(len(canonical).to_bytes(8, "big"))
    digest.update(canonical.tobytes())
    return digest.hexdigest()


def load_extract(path: Path, *, expected_sha256: str) -> list[SignalRecord]:
    observed = sha256_file(path)
    if observed != expected_sha256:
        raise RuntimeError(
            f"input hash mismatch for {path}: expected {expected_sha256}, got {observed}"
        )

    grouped: dict[tuple[int, int], list[tuple[int, float]]] = {}
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"faultNumber", "simulationRun", "sample", "xmeas_7"}
        if set(reader.fieldnames or ()) != required:
            raise RuntimeError(
                f"unexpected extract columns for {path}: {reader.fieldnames!r}"
            )
        for row in reader:
            key = (int(row["faultNumber"]), int(row["simulationRun"]))
            grouped.setdefault(key, []).append(
                (int(row["sample"]), float(row["xmeas_7"]))
            )

    records: list[SignalRecord] = []
    for (fault, simulation_run), pairs in sorted(grouped.items()):
        pairs.sort()
        indices = [pair[0] for pair in pairs]
        if len(pairs) != HORIZON:
            raise RuntimeError(
                f"trajectory {(fault, simulation_run)} has {len(pairs)} samples"
            )
        first = indices[0]
        expected = list(range(first, first + HORIZON))
        if indices != expected:
            raise RuntimeError(
                f"trajectory {(fault, simulation_run)} sample indices are not contiguous"
            )
        raw = np.array([pair[1] for pair in pairs], dtype=np.float64)
        if not np.all(np.isfinite(raw)):
            raise RuntimeError(f"trajectory {(fault, simulation_run)} is non-finite")
        records.append(
            SignalRecord(
                fault=fault,
                simulation_run=simulation_run,
                raw=raw,
                scaled=apply_tep_affine_scale(raw),
            )
        )
    return records


def validate_inventory(
    normal: Sequence[SignalRecord], fault: Sequence[SignalRecord]
) -> None:
    normal_keys = [record.key for record in normal]
    expected_normal = [(0, run) for run in range(1, 501)]
    if normal_keys != expected_normal:
        raise RuntimeError("normal extract does not contain exactly fault 0, runs 1-500")
    fault_keys = [record.key for record in fault]
    expected_fault = [
        (fault_number, run)
        for fault_number in range(1, 21)
        for run in range(301, 321)
    ]
    if fault_keys != expected_fault:
        raise RuntimeError(
            "fault extract does not contain exactly faults 1-20, runs 301-320"
        )


def full_profiles() -> dict[int, DMREDAProfile]:
    return {state: replace(profile) for state, profile in DEFAULT_PROFILES.items()}


def full_transitions() -> dict[int, RegimeTransition]:
    return {
        state: replace(transition)
        for state, transition in DEFAULT_TRANSITIONS.items()
    }


def no_regime_profiles() -> dict[int, DMREDAProfile]:
    return {0: replace(DEFAULT_PROFILES[0])}


def fixed_profiles() -> dict[int, DMREDAProfile]:
    profile = DEFAULT_PROFILES[0]
    return {
        0: replace(
            profile,
            m_set=(4,),
            m_base=4,
            confirm_base=20,
            confirm_min=20,
            confirm_max=20,
            alpha=0.0,
        )
    }


def fixed_confirmation_profiles() -> dict[int, DMREDAProfile]:
    return {
        state: replace(
            profile,
            confirm_min=profile.confirm_base,
            confirm_max=profile.confirm_base,
            alpha=0.0,
        )
        for state, profile in DEFAULT_PROFILES.items()
    }


def compute_representation(
    signal: np.ndarray,
    *,
    profiles: Mapping[int, DMREDAProfile],
    transitions: Mapping[int, RegimeTransition],
) -> RepresentationTrace:
    result = compute_dmreda_reference(
        signal,
        profiles=profiles,
        transitions=transitions,
        mode="D_or_G",
        warmup_samples=WARMUP,
    )
    n = signal.size
    used_state = np.empty(n, dtype=np.int64)
    used_state[0] = 0
    used_state[1:] = result.state[:-1]
    used_confirm_len = np.empty(n, dtype=np.int64)
    used_confirm_len[0] = profiles[0].confirm_base
    used_confirm_len[1:] = result.confirm_len_eff[:-1]

    def profile_trace(field: str, dtype: np.dtype) -> np.ndarray:
        return np.array(
            [getattr(profiles[int(state)], field) for state in used_state],
            dtype=dtype,
        )

    return RepresentationTrace(
        d=np.array(result.d, copy=True),
        g=np.array(result.g, copy=True),
        th_d=profile_trace("th_d", np.float64),
        th_g=profile_trace("th_g", np.float64),
        th_d2=profile_trace("th_d2", np.float64),
        th_a=profile_trace("th_a", np.float64),
        n_min=profile_trace("n_min", np.int64),
        confirm_len=used_confirm_len,
    )


def native_authority_grid(
    trace: RepresentationTrace,
    kappas: np.ndarray,
    *,
    opening: str,
    require_area: bool,
    require_count: bool,
) -> np.ndarray:
    """Return first-authority times for every kappa with exact pending ordering."""

    candidate_count = kappas.size
    first = np.full(candidate_count, -1, dtype=np.int64)
    active = np.zeros(candidate_count, dtype=bool)
    ell = np.zeros(candidate_count, dtype=np.int64)
    area = np.zeros(candidate_count, dtype=np.float64)
    count = np.zeros(candidate_count, dtype=np.int64)
    snap_l = np.ones(candidate_count, dtype=np.int64)
    snap_th_d2 = np.zeros(candidate_count, dtype=np.float64)
    snap_th_a = np.zeros(candidate_count, dtype=np.float64)
    snap_n_min = np.ones(candidate_count, dtype=np.int64)

    for t in range(WARMUP, trace.d.size):
        live = first < 0
        continuing = active & live
        if np.any(continuing):
            ell[continuing] += 1
            area[continuing] += np.maximum(
                0.0, trace.d[t] - snap_th_d2[continuing]
            )
            count[continuing] += trace.d[t] > snap_th_d2[continuing]
            area_ok = area > snap_th_a if require_area else np.ones_like(active)
            count_ok = count >= snap_n_min if require_count else np.ones_like(active)
            confirmed = continuing & area_ok & count_ok
            first[confirmed] = t
            active[confirmed] = False
            timed_out = continuing & ~confirmed & (ell >= snap_l)
            active[timed_out] = False
            ell[timed_out] = 0
            area[timed_out] = 0.0
            count[timed_out] = 0

        if opening == "d_only":
            trigger = trace.d[t] > kappas * trace.th_d[t]
        elif opening == "g_only":
            trigger = trace.g[t] > kappas * trace.th_g[t]
        elif opening == "d_or_g":
            trigger = (trace.d[t] > kappas * trace.th_d[t]) | (
                trace.g[t] > kappas * trace.th_g[t]
            )
        else:
            raise ValueError(f"unknown opening mode {opening!r}")

        opened = (~active) & (first < 0) & trigger
        if not np.any(opened):
            continue
        active[opened] = True
        ell[opened] = 1
        area[opened] = np.maximum(
            0.0, trace.d[t] - kappas[opened] * trace.th_d2[t]
        )
        count[opened] = trace.d[t] > kappas[opened] * trace.th_d2[t]
        snap_l[opened] = trace.confirm_len[t]
        snap_th_d2[opened] = kappas[opened] * trace.th_d2[t]
        snap_th_a[opened] = kappas[opened] * trace.th_a[t]
        snap_n_min[opened] = trace.n_min[t]
        area_ok = area > snap_th_a if require_area else np.ones_like(active)
        count_ok = count >= snap_n_min if require_count else np.ones_like(active)
        immediate = opened & area_ok & count_ok
        first[immediate] = t
        active[immediate] = False

    return first


def consecutive_run_grid(trace: RepresentationTrace, kappas: np.ndarray) -> np.ndarray:
    first = np.full(kappas.size, -1, dtype=np.int64)
    run_length = np.zeros(kappas.size, dtype=np.int64)
    threshold_base = float(DEFAULT_PROFILES[0].th_d2)
    required = int(DEFAULT_PROFILES[0].n_min)
    for t in range(WARMUP, trace.d.size):
        live = first < 0
        above = trace.d[t] > kappas * threshold_base
        run_length = np.where(live & above, run_length + 1, 0)
        confirmed = live & (run_length >= required)
        first[confirmed] = t
    return first


def rolling_area_grid(trace: RepresentationTrace, kappas: np.ndarray) -> np.ndarray:
    first = np.full(kappas.size, -1, dtype=np.int64)
    window = int(DEFAULT_PROFILES[0].confirm_base)
    ring = np.zeros((window, kappas.size), dtype=np.float64)
    area = np.zeros(kappas.size, dtype=np.float64)
    threshold_base = float(DEFAULT_PROFILES[0].th_d2)
    area_base = float(DEFAULT_PROFILES[0].th_a)
    for authority_offset, t in enumerate(range(WARMUP, trace.d.size)):
        slot = authority_offset % window
        excess = np.maximum(0.0, trace.d[t] - kappas * threshold_base)
        area += excess - ring[slot]
        ring[slot] = excess
        live = first < 0
        confirmed = live & (area > kappas * area_base)
        first[confirmed] = t
    return first


def hysteretic_grid(trace: RepresentationTrace, kappas: np.ndarray) -> np.ndarray:
    first = np.full(kappas.size, -1, dtype=np.int64)
    latched = np.zeros(kappas.size, dtype=bool)
    high = kappas * float(DEFAULT_PROFILES[0].th_d)
    low = 0.5 * high
    for t in range(WARMUP, trace.d.size):
        latched &= trace.d[t] >= low
        trigger = (~latched) & (first < 0) & (trace.d[t] > high)
        first[trigger] = t
        latched[trigger] = True
    return first


def candidate_metrics(first_times: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    alarmed = first_times >= 0
    false_counts = np.count_nonzero(alarmed, axis=0).astype(np.int64)
    restricted_sums = np.where(alarmed, first_times, HORIZON).sum(axis=0)
    return false_counts, restricted_sums.astype(np.int64)


def choose_candidate(
    candidate_values: np.ndarray,
    false_counts: np.ndarray,
    restricted_sums: np.ndarray,
) -> int:
    objectives = [
        (
            abs(int(false_counts[index]) - TARGET_FALSE_COUNT),
            abs(int(restricted_sums[index]) - TARGET_RESTRICTED_SUM),
            -float(candidate_values[index]),
        )
        for index in range(candidate_values.size)
    ]
    return min(range(candidate_values.size), key=objectives.__getitem__)


def persistence_window_minima(scores: np.ndarray, persistence: int) -> np.ndarray:
    eligible = scores[WARMUP:]
    count = eligible.size - persistence + 1
    if count <= 0:
        return np.empty(0, dtype=np.float64)
    minima = np.full(count, np.inf, dtype=np.float64)
    for offset in range(persistence):
        np.minimum(minima, eligible[offset : offset + count], out=minima)
    return minima


def exact_score_candidates(
    score_runs: Sequence[np.ndarray],
    *,
    persistence: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    minima_by_run = [persistence_window_minima(run, persistence) for run in score_runs]
    unique = np.unique(np.concatenate(minima_by_run)).astype(np.float64, copy=False)
    lower = float(np.nextafter(unique[0], -np.inf))
    candidates = np.concatenate((np.array([lower]), unique))
    counts = np.zeros(candidates.size, dtype=np.int64)
    sums = np.zeros(candidates.size, dtype=np.int64)
    first_eligible = WARMUP + persistence - 1
    for minima in minima_by_run:
        prefix = np.maximum.accumulate(minima)
        positions = np.searchsorted(prefix, candidates, side="right")
        alarmed = positions < prefix.size
        counts += alarmed
        sums += np.where(alarmed, first_eligible + positions, HORIZON)
    return candidates, counts, sums


def first_score_alarm(scores: np.ndarray, threshold: float) -> int:
    gate = EventGateConfig(warmup_samples=WARMUP, persistence=20, refractory=80)
    alarms = confirmed_alarm_times(scores, threshold, gate)
    return int(alarms[0]) if alarms else -1


def wilson_interval(successes: int, total: int) -> tuple[float, float]:
    if total <= 0:
        raise ValueError("Wilson interval requires a positive total")
    z = 1.959963984540054
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denominator
    half = (
        z
        * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total))
        / denominator
    )
    return center - half, center + half


def normal_statistics(first_times: np.ndarray) -> dict[str, object]:
    alarmed = first_times >= 0
    count = int(np.count_nonzero(alarmed))
    total = int(first_times.size)
    observed = first_times[alarmed]
    horizon_rows: list[dict[str, object]] = []
    for horizon in REPORTING_HORIZONS:
        horizon_count = int(np.count_nonzero(alarmed & (first_times < horizon)))
        low, high = wilson_interval(horizon_count, total)
        horizon_rows.append(
            {
                "H": horizon,
                "authority_count": horizon_count,
                "risk": horizon_count / total,
                "risk_wilson_95": [low, high],
                "survival": 1.0 - horizon_count / total,
            }
        )
    low, high = wilson_interval(count, total)
    return {
        "trajectory_count": total,
        "false_authority_count": count,
        "P_tau_le_H": count / total,
        "P_tau_le_H_wilson_95": [low, high],
        "censoring_count": total - count,
        "censoring_rate": 1.0 - count / total,
        "restricted_mean_time_to_authority": float(
            np.mean(np.where(alarmed, first_times, HORIZON))
        ),
        "classical_uncensored_ARL_claimed": False,
        "first_authority_time": {
            "minimum": int(np.min(observed)) if observed.size else None,
            "median": float(np.median(observed)) if observed.size else None,
            "maximum": int(np.max(observed)) if observed.size else None,
            "values": [int(value) for value in observed],
        },
        "horizon_curve": horizon_rows,
    }


def percentile_interval(values: np.ndarray) -> list[float]:
    return [float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))]


def fault_statistics(
    records: Sequence[SignalRecord], first_times: np.ndarray
) -> dict[str, object]:
    detected = first_times >= FAULT_ONSET
    false_pre_onset = (first_times >= 0) & (first_times < FAULT_ONSET)
    delays = first_times[detected] - FAULT_ONSET
    total = len(records)
    count = int(np.count_nonzero(detected))
    low, high = wilson_interval(count, total)
    restricted_delays = np.where(detected, first_times - FAULT_ONSET, HORIZON - FAULT_ONSET)
    by_fault: list[dict[str, object]] = []
    for fault_number in range(1, 21):
        mask = np.array([record.fault == fault_number for record in records])
        fault_detected = detected[mask]
        fault_delays = first_times[mask][fault_detected] - FAULT_ONSET
        fault_count = int(np.count_nonzero(fault_detected))
        fault_low, fault_high = wilson_interval(fault_count, int(np.count_nonzero(mask)))
        by_fault.append(
            {
                "fault": fault_number,
                "trajectory_count": int(np.count_nonzero(mask)),
                "detection_count": fault_count,
                "detection_probability": fault_count / int(np.count_nonzero(mask)),
                "detection_probability_wilson_95": [fault_low, fault_high],
                "median_delay": float(np.median(fault_delays)) if fault_delays.size else None,
            }
        )
    return {
        "trajectory_count": total,
        "detection_count": count,
        "detection_probability": count / total,
        "detection_probability_wilson_95": [low, high],
        "miss_count": total - count,
        "pre_onset_false_authority_count": int(np.count_nonzero(false_pre_onset)),
        "pre_onset_metric_interpretation": (
            "Structurally uninformative here because onset 20 precedes warm-up 92."
        ),
        "mean_delay_detected_only": float(np.mean(delays)) if delays.size else None,
        "median_delay_detected_only": float(np.median(delays)) if delays.size else None,
        "p90_delay_detected_only": float(np.quantile(delays, 0.9)) if delays.size else None,
        "restricted_mean_detection_delay": float(np.mean(restricted_delays)),
        "censoring_count": total - count,
        "by_fault": by_fault,
    }


def cluster_bootstrap_deltas(
    fault_records: Sequence[SignalRecord],
    candidate_first: np.ndarray,
    reference_first: np.ndarray,
    *,
    rng_indices: np.ndarray,
) -> dict[str, object]:
    runs = list(range(301, 321))
    detection_cluster_delta = np.empty(len(runs), dtype=np.float64)
    delay_cluster_delta = np.empty(len(runs), dtype=np.float64)
    for cluster_index, simulation_run in enumerate(runs):
        mask = np.array(
            [record.simulation_run == simulation_run for record in fault_records]
        )
        candidate_detected = candidate_first[mask] >= FAULT_ONSET
        reference_detected = reference_first[mask] >= FAULT_ONSET
        detection_cluster_delta[cluster_index] = float(
            np.mean(candidate_detected.astype(np.float64) - reference_detected)
        )
        candidate_delay = np.where(
            candidate_detected,
            candidate_first[mask] - FAULT_ONSET,
            HORIZON - FAULT_ONSET,
        )
        reference_delay = np.where(
            reference_detected,
            reference_first[mask] - FAULT_ONSET,
            HORIZON - FAULT_ONSET,
        )
        delay_cluster_delta[cluster_index] = float(
            np.mean(candidate_delay - reference_delay)
        )
    detection_bootstrap = detection_cluster_delta[rng_indices].mean(axis=1)
    delay_bootstrap = delay_cluster_delta[rng_indices].mean(axis=1)
    return {
        "paired_detection_probability_delta": float(
            np.mean(detection_cluster_delta)
        ),
        "paired_detection_probability_delta_cluster_bootstrap_95": percentile_interval(
            detection_bootstrap
        ),
        "paired_restricted_mean_delay_delta_samples": float(
            np.mean(delay_cluster_delta)
        ),
        "paired_restricted_mean_delay_delta_cluster_bootstrap_95": percentile_interval(
            delay_bootstrap
        ),
        "bootstrap_cluster_count": 20,
        "bootstrap_replicates": BOOTSTRAP_REPLICATES,
    }


def representation_families(
    all_records: Sequence[SignalRecord],
) -> dict[str, dict[tuple[int, int], RepresentationTrace]]:
    definitions: dict[
        str, tuple[Mapping[int, DMREDAProfile], Mapping[int, RegimeTransition]]
    ] = {
        "full": (full_profiles(), full_transitions()),
        "no_regime": (no_regime_profiles(), {}),
        "fixed": (fixed_profiles(), {}),
        "fixed_confirmation": (fixed_confirmation_profiles(), full_transitions()),
    }
    families: dict[str, dict[tuple[int, int], RepresentationTrace]] = {}
    for name, (profiles, transitions) in definitions.items():
        families[name] = {
            record.key: compute_representation(
                record.scaled,
                profiles=profiles,
                transitions=transitions,
            )
            for record in all_records
        }
    return families


def variant_grid_function(
    label: str,
) -> tuple[str, Callable[[RepresentationTrace, np.ndarray], np.ndarray]]:
    if label == "A":
        return "full", lambda trace, grid: native_authority_grid(
            trace, grid, opening="d_or_g", require_area=True, require_count=True
        )
    if label == "B":
        return "full", lambda trace, grid: native_authority_grid(
            trace, grid, opening="d_only", require_area=True, require_count=True
        )
    if label == "C":
        return "full", lambda trace, grid: native_authority_grid(
            trace, grid, opening="g_only", require_area=True, require_count=True
        )
    if label == "D":
        return "no_regime", lambda trace, grid: native_authority_grid(
            trace, grid, opening="d_or_g", require_area=True, require_count=True
        )
    if label == "E":
        return "fixed", lambda trace, grid: native_authority_grid(
            trace, grid, opening="d_or_g", require_area=True, require_count=True
        )
    if label == "F":
        return "fixed_confirmation", lambda trace, grid: native_authority_grid(
            trace, grid, opening="d_or_g", require_area=True, require_count=True
        )
    if label == "G":
        return "full", lambda trace, grid: native_authority_grid(
            trace, grid, opening="d_or_g", require_area=False, require_count=True
        )
    if label == "H":
        return "fixed", consecutive_run_grid
    if label == "I":
        return "fixed", rolling_area_grid
    if label == "L":
        return "fixed", hysteretic_grid
    raise ValueError(f"variant {label} is not a kappa-grid detector")


def evaluate_kappa_variant(
    label: str,
    *,
    families: Mapping[str, Mapping[tuple[int, int], RepresentationTrace]],
    normal_calibration: Sequence[SignalRecord],
    normal_evaluation: Sequence[SignalRecord],
    fault_evaluation: Sequence[SignalRecord],
    candidate_writer: Callable[[Mapping[str, object]], None],
) -> SelectedDetector:
    family_name, grid_function = variant_grid_function(label)
    family = families[family_name]
    calibration_matrix = np.vstack(
        [grid_function(family[record.key], KAPPA_GRID) for record in normal_calibration]
    )
    false_counts, restricted_sums = candidate_metrics(calibration_matrix)
    selected_index = choose_candidate(KAPPA_GRID, false_counts, restricted_sums)
    grid_hash = float_grid_sha256(
        KAPPA_GRID, b"dmreda-finalization-kappa-grid-v1\0"
    )
    for index, kappa in enumerate(KAPPA_GRID):
        candidate_writer(
            {
                "variant": label,
                "candidate_index": index,
                "parameter": "kappa",
                "value": float(kappa),
                "calibration_false_authority_count": int(false_counts[index]),
                "calibration_false_authority_risk": float(
                    false_counts[index] / len(normal_calibration)
                ),
                "calibration_restricted_time_sum": int(restricted_sums[index]),
                "selected": index == selected_index,
                "candidate_grid_sha256": grid_hash,
            }
        )
    normal_first = np.array(
        [
            grid_function(family[record.key], KAPPA_GRID[[selected_index]])[0]
            for record in normal_evaluation
        ],
        dtype=np.int64,
    )
    fault_first = np.array(
        [
            grid_function(family[record.key], KAPPA_GRID[[selected_index]])[0]
            for record in fault_evaluation
        ],
        dtype=np.int64,
    )
    return SelectedDetector(
        label=label,
        parameter_name="kappa",
        parameter_value=float(KAPPA_GRID[selected_index]),
        candidate_index=selected_index,
        candidate_count=KAPPA_GRID.size,
        candidate_grid_sha256=grid_hash,
        calibration_first_times=calibration_matrix[:, selected_index],
        normal_first_times=normal_first,
        fault_first_times=fault_first,
    )


def evaluate_score_variant(
    label: str,
    score_function: Callable[[np.ndarray], np.ndarray],
    *,
    normal_calibration: Sequence[SignalRecord],
    normal_evaluation: Sequence[SignalRecord],
    fault_evaluation: Sequence[SignalRecord],
    candidate_writer: Callable[[Mapping[str, object]], None],
) -> SelectedDetector:
    calibration_scores = [score_function(record.scaled) for record in normal_calibration]
    candidates, false_counts, restricted_sums = exact_score_candidates(
        calibration_scores, persistence=20
    )
    selected_index = choose_candidate(candidates, false_counts, restricted_sums)
    grid_hash = float_grid_sha256(
        candidates,
        f"dmreda-finalization-{label}-score-grid-v1\0".encode("ascii"),
    )
    for index, threshold in enumerate(candidates):
        candidate_writer(
            {
                "variant": label,
                "candidate_index": index,
                "parameter": "score_threshold",
                "value": float(threshold),
                "calibration_false_authority_count": int(false_counts[index]),
                "calibration_false_authority_risk": float(
                    false_counts[index] / len(normal_calibration)
                ),
                "calibration_restricted_time_sum": int(restricted_sums[index]),
                "selected": index == selected_index,
                "candidate_grid_sha256": grid_hash,
            }
        )
    threshold = float(candidates[selected_index])
    calibration_first = np.array(
        [first_score_alarm(scores, threshold) for scores in calibration_scores],
        dtype=np.int64,
    )
    replay_counts, replay_sums = candidate_metrics(calibration_first[:, None])
    if replay_counts[0] != false_counts[selected_index]:
        raise AssertionError(f"{label} candidate count failed exact gate replay")
    if replay_sums[0] != restricted_sums[selected_index]:
        raise AssertionError(f"{label} restricted sum failed exact gate replay")
    normal_first = np.array(
        [
            first_score_alarm(score_function(record.scaled), threshold)
            for record in normal_evaluation
        ],
        dtype=np.int64,
    )
    fault_first = np.array(
        [
            first_score_alarm(score_function(record.scaled), threshold)
            for record in fault_evaluation
        ],
        dtype=np.int64,
    )
    return SelectedDetector(
        label=label,
        parameter_name="score_threshold",
        parameter_value=threshold,
        candidate_index=selected_index,
        candidate_count=candidates.size,
        candidate_grid_sha256=grid_hash,
        calibration_first_times=calibration_first,
        normal_first_times=normal_first,
        fault_first_times=fault_first,
    )


def write_json(path: Path, payload: object) -> None:
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--normal-extract", required=True, type=Path)
    parser.add_argument("--fault-extract", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    arguments = parser.parse_args()

    protocol = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
    if protocol["status"] != "frozen_before_development_execution":
        raise RuntimeError("development protocol is not in its frozen pre-run state")
    if protocol["evidence_scope"]["faulty_testing_access_permitted"] is not False:
        raise RuntimeError("protocol unexpectedly permits FaultyTesting access")
    for supplied in (arguments.normal_extract, arguments.fault_extract):
        lowered = str(supplied).lower().replace("_", "").replace("-", "")
        if "faultytesting" in lowered:
            raise RuntimeError("FaultyTesting paths are forbidden in development runner")

    normal_records = load_extract(
        arguments.normal_extract, expected_sha256=EXPECTED_NORMAL_SHA256
    )
    fault_records = load_extract(
        arguments.fault_extract, expected_sha256=EXPECTED_FAULT_SHA256
    )
    validate_inventory(normal_records, fault_records)
    normal_calibration = [
        record for record in normal_records if 1 <= record.simulation_run <= 200
    ]
    normal_evaluation = [
        record for record in normal_records if 201 <= record.simulation_run <= 500
    ]

    arguments.output_dir.mkdir(parents=True, exist_ok=False)
    candidate_path = arguments.output_dir / "candidate_results.jsonl"
    trajectory_path = arguments.output_dir / "selected_trajectory_results.jsonl"
    candidate_handle = candidate_path.open("w", encoding="utf-8")

    def emit_candidate(payload: Mapping[str, object]) -> None:
        candidate_handle.write(
            json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)
            + "\n"
        )

    all_records = [*normal_records, *fault_records]
    families = representation_families(all_records)
    selected: dict[str, SelectedDetector] = {}
    for label in ("A", "B", "C", "D", "E", "F", "G", "H", "I", "L"):
        selected[label] = evaluate_kappa_variant(
            label,
            families=families,
            normal_calibration=normal_calibration,
            normal_evaluation=normal_evaluation,
            fault_evaluation=fault_records,
            candidate_writer=emit_candidate,
        )
    selected["J"] = evaluate_score_variant(
        "J",
        lambda signal: two_sided_cusum_score(
            signal, center=0.0, allowance=0.5
        ),
        normal_calibration=normal_calibration,
        normal_evaluation=normal_evaluation,
        fault_evaluation=fault_records,
        candidate_writer=emit_candidate,
    )
    selected["K"] = evaluate_score_variant(
        "K",
        lambda signal: ewma_mean_score(
            signal, center=0.0, scale=1.0, alpha=2.0 / 33.0
        ),
        normal_calibration=normal_calibration,
        normal_evaluation=normal_evaluation,
        fault_evaluation=fault_records,
        candidate_writer=emit_candidate,
    )
    candidate_handle.close()

    rng = np.random.default_rng(BOOTSTRAP_SEED)
    bootstrap_indices = rng.integers(
        0, 20, size=(BOOTSTRAP_REPLICATES, 20), endpoint=False
    )
    variant_results: dict[str, object] = {}
    reference_fault = selected["A"].fault_first_times
    for label in VARIANT_LABELS:
        detector = selected[label]
        cal_counts, cal_sums = candidate_metrics(
            detector.calibration_first_times[:, None]
        )
        variant_results[label] = {
            "selected_parameter": {
                "name": detector.parameter_name,
                "value": detector.parameter_value,
                "candidate_index": detector.candidate_index,
                "candidate_count": detector.candidate_count,
                "candidate_grid_sha256": detector.candidate_grid_sha256,
            },
            "normal_calibration": {
                **normal_statistics(detector.calibration_first_times),
                "restricted_time_sum": int(cal_sums[0]),
                "target_false_authority_count": TARGET_FALSE_COUNT,
                "target_restricted_time_sum": TARGET_RESTRICTED_SUM,
            },
            "normal_development_evaluation": normal_statistics(
                detector.normal_first_times
            ),
            "fault_development_evaluation": fault_statistics(
                fault_records, detector.fault_first_times
            ),
            "paired_vs_A": cluster_bootstrap_deltas(
                fault_records,
                detector.fault_first_times,
                reference_fault,
                rng_indices=bootstrap_indices,
            ),
        }

    simplicity_order = ["L", "H", "I", "G", "E", "D", "F", "B", "C", "A"]
    eligibility: dict[str, dict[str, object]] = {}
    chosen = "A"
    for label in simplicity_order:
        result = variant_results[label]
        paired = result["paired_vs_A"]
        normal_risk = result["normal_development_evaluation"]["P_tau_le_H"]
        detection_lower = paired[
            "paired_detection_probability_delta_cluster_bootstrap_95"
        ][0]
        delay_upper = paired[
            "paired_restricted_mean_delay_delta_cluster_bootstrap_95"
        ][1]
        passed = (
            normal_risk <= 0.075
            and detection_lower >= -0.05
            and delay_upper <= 10.0
        )
        eligibility[label] = {
            "normal_risk_le_0_075": bool(normal_risk <= 0.075),
            "detection_delta_lower_ge_minus_0_05": bool(detection_lower >= -0.05),
            "delay_delta_upper_le_10": bool(delay_upper <= 10.0),
            "eligible": bool(passed),
        }
        if passed:
            chosen = label
            break

    with trajectory_path.open("w", encoding="utf-8") as handle:
        for label in VARIANT_LABELS:
            detector = selected[label]
            for role, records, first_values, onset in (
                (
                    "normal_development_evaluation",
                    normal_evaluation,
                    detector.normal_first_times,
                    None,
                ),
                (
                    "fault_development_evaluation",
                    fault_records,
                    detector.fault_first_times,
                    FAULT_ONSET,
                ),
            ):
                for record, first in zip(records, first_values):
                    if role.startswith("normal"):
                        outcome = "false_authority" if first >= 0 else "censored"
                        delay = None
                    elif first < 0:
                        outcome = "missed_censored"
                        delay = None
                    elif first < FAULT_ONSET:
                        outcome = "pre_onset_false_authority"
                        delay = None
                    else:
                        outcome = "detected"
                        delay = int(first - FAULT_ONSET)
                    row = {
                        "variant": label,
                        "role": role,
                        "faultNumber": record.fault,
                        "simulationRun": record.simulation_run,
                        "horizon": HORIZON,
                        "onset": onset,
                        "first_authority_index": int(first) if first >= 0 else None,
                        "outcome": outcome,
                        "delay": delay,
                    }
                    handle.write(
                        json.dumps(
                            row,
                            sort_keys=True,
                            separators=(",", ":"),
                            allow_nan=False,
                        )
                        + "\n"
                    )

    source_path = Path(__file__).resolve()
    result_payload = {
        "schema": "dmreda.finalization.development-ablation-results.v1",
        "evidence_classification": "DEVELOPMENT_NON_CLAIM_GRADE",
        "protocol": {
            "path": str(PROTOCOL_PATH.relative_to(PROTOCOL_PATH.parents[2])),
            "sha256": sha256_file(PROTOCOL_PATH),
        },
        "runner": {
            "path": str(source_path.relative_to(source_path.parents[2])),
            "sha256": sha256_file(source_path),
        },
        "environment": {
            "python": sys.version,
            "numpy": np.__version__,
            "platform": platform.platform(),
            "machine": platform.machine(),
        },
        "inputs": {
            "normal_extract_sha256": sha256_file(arguments.normal_extract),
            "fault_extract_sha256": sha256_file(arguments.fault_extract),
            "normal_trajectory_count": len(normal_records),
            "fault_trajectory_count": len(fault_records),
            "faulty_testing_opened": False,
        },
        "mission": {
            "horizon": HORIZON,
            "warmup": WARMUP,
            "fault_onset": FAULT_ONSET,
            "normal_target_risk": 0.05,
        },
        "variants": variant_results,
        "architecture_selection": {
            "rule_source": "protocol_v3_development.json",
            "simplicity_order": simplicity_order,
            "eligibility_audit_until_first_pass": eligibility,
            "selected_dmreda_derived_variant": chosen,
            "claim_status": (
                "Engineering candidate only; requires a genuinely untouched normal gate "
                "and, if that passes, untouched fault evaluation."
            ),
        },
        "artifact_hashes": {},
    }
    write_json(arguments.output_dir / "ablation_summary.json", result_payload)
    result_payload["artifact_hashes"] = {
        "candidate_results.jsonl": sha256_file(candidate_path),
        "selected_trajectory_results.jsonl": sha256_file(trajectory_path),
    }
    write_json(arguments.output_dir / "ablation_summary.json", result_payload)
    result_payload["artifact_hashes"]["ablation_summary.json"] = sha256_file(
        arguments.output_dir / "ablation_summary.json"
    )
    # The self-hash is recorded in a detached manifest to avoid recursive hashing.
    manifest = {
        "schema": "dmreda.finalization.development-output-manifest.v1",
        "files": {
            "ablation_summary.json": sha256_file(
                arguments.output_dir / "ablation_summary.json"
            ),
            "candidate_results.jsonl": sha256_file(candidate_path),
            "selected_trajectory_results.jsonl": sha256_file(trajectory_path),
        },
    }
    write_json(arguments.output_dir / "manifest.json", manifest)
    print(json.dumps({"output_dir": str(arguments.output_dir), "selected": chosen}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
