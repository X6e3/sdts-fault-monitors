"""Reduced authority-state model for the historical full Core semantics.

This module reduces implementation fields; it does not assert a global
mathematical minimum.  The signal representation state is intentionally out of
scope here.  ``ell == 0`` encodes inactivity and ``ell > 0`` is the pending age.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class OpenContract:
    confirm_len: int
    th_d2: float
    th_a: float
    n_min: int
    refractory: int

    def validate(self) -> None:
        if self.confirm_len <= 0:
            raise ValueError("confirm_len must be positive")
        if self.n_min <= 0 or self.n_min > self.confirm_len:
            raise ValueError("n_min must be in [1, confirm_len]")
        if self.refractory < 0:
            raise ValueError("refractory must be non-negative")
        if not math.isfinite(self.th_d2) or not math.isfinite(self.th_a):
            raise ValueError("contract thresholds must be finite")


@dataclass
class MinimalAuthorityState:
    ell: int = 0
    area: float = 0.0
    count: int = 0
    open_contract: OpenContract | None = None
    refractory_remaining: int = 0

    @property
    def pending_active(self) -> bool:
        return self.ell > 0

    def pending_start(self, current_index: int) -> int | None:
        return current_index - self.ell + 1 if self.ell > 0 else None

    def validate(self) -> None:
        if self.ell < 0 or self.count < 0 or self.refractory_remaining < 0:
            raise ValueError("integer state fields must be non-negative")
        if not math.isfinite(self.area) or self.area < 0.0:
            raise ValueError("area must be finite and non-negative")
        if (self.ell == 0) != (self.open_contract is None):
            raise ValueError("open_contract is present exactly while ell > 0")
        if self.open_contract is not None:
            self.open_contract.validate()


@dataclass(frozen=True)
class AuthorityOutput:
    pending: bool
    confirmed: bool


def _clear_pending(state: MinimalAuthorityState) -> None:
    state.ell = 0
    state.area = 0.0
    state.count = 0
    state.open_contract = None


def _accumulate(
    state: MinimalAuthorityState,
    d_value: float,
) -> bool:
    contract = state.open_contract
    if contract is None:
        raise AssertionError("cannot accumulate without an open contract")
    state.area += max(0.0, d_value - contract.th_d2)
    state.count += int(d_value > contract.th_d2)
    return (state.area > contract.th_a) and (state.count >= contract.n_min)


def step_authority(
    state: MinimalAuthorityState,
    *,
    d_value: float,
    g_value: float,
    th_d: float,
    th_g: float,
    current_contract: OpenContract,
    mode: str,
    authority_enabled: bool,
) -> AuthorityOutput:
    """Advance one sample with the historical ordering and strict inequalities."""

    state.validate()
    current_contract.validate()
    numeric = (d_value, g_value, th_d, th_g)
    if not all(math.isfinite(value) for value in numeric):
        raise ValueError("sample features and opening thresholds must be finite")
    normalized_mode = mode.lower()
    if normalized_mode not in {"d_only", "g_only", "d_or_g"}:
        raise ValueError("mode must be d_only, g_only, or d_or_g")

    if state.refractory_remaining > 0:
        state.refractory_remaining -= 1

    pending_output = False
    confirmed = False
    if authority_enabled:
        if state.ell > 0:
            pending_output = True
            state.ell += 1
            if _accumulate(state, d_value):
                contract = state.open_contract
                assert contract is not None
                state.refractory_remaining = contract.refractory
                _clear_pending(state)
                confirmed = True
            else:
                contract = state.open_contract
                assert contract is not None
                if state.ell >= contract.confirm_len:
                    _clear_pending(state)

        if normalized_mode == "d_only":
            fast_trigger = d_value > th_d
        elif normalized_mode == "g_only":
            fast_trigger = g_value > th_g
        else:
            fast_trigger = (d_value > th_d) or (g_value > th_g)

        if (
            state.ell == 0
            and not confirmed
            and state.refractory_remaining == 0
            and fast_trigger
        ):
            state.ell = 1
            state.area = 0.0
            state.count = 0
            state.open_contract = current_contract
            pending_output = True
            if _accumulate(state, d_value):
                state.refractory_remaining = current_contract.refractory
                _clear_pending(state)
                confirmed = True

    state.validate()
    return AuthorityOutput(pending=pending_output, confirmed=confirmed)


def state_collision_witnesses() -> dict[str, object]:
    """Return explicit sufficient-state collision witnesses used in the report."""

    return {
        "count_is_necessary_given_ell_and_area": {
            "contract": {
                "confirm_len": 4,
                "th_d2": 1.0,
                "th_a": 1.0,
                "n_min": 3,
            },
            "history_1_d": [1.6, 0.5],
            "history_2_d": [1.3, 1.3],
            "collision_before_common_sample": {
                "ell": 2,
                "area": 0.6,
                "count_history_1": 1,
                "count_history_2": 2,
            },
            "common_next_d": 1.5,
            "outcome": "history_2 confirms with C=3; history_1 remains pending with C=2",
        },
        "ell_is_necessary_given_area_and_count": {
            "contract": {
                "confirm_len": 3,
                "th_d2": 1.0,
                "th_a": 1.0,
                "n_min": 2,
            },
            "collision": {
                "state_1": {"ell": 2, "area": 0.2, "count": 1},
                "state_2": {"ell": 1, "area": 0.2, "count": 1},
            },
            "common_suffix_d": [0.5, 2.0],
            "opening_trigger_on_first_suffix_sample": False,
            "outcome": "state_1 times out before the final sample and only reopens; state_2 confirms on the final sample",
        },
        "open_contract_is_necessary": {
            "state_0_contract": {
                "confirm_len": 20,
                "th_d2": 0.20,
                "th_a": 1.8,
                "n_min": 6,
            },
            "state_1_contract": {
                "confirm_len": 28,
                "th_d2": 0.28,
                "th_a": 2.6,
                "n_min": 8,
            },
            "collision_before_common_sample": {"ell": 5, "area": 1.7, "count": 5},
            "reachable_prefixes": {
                "state_0_d": [0.54, 0.54, 0.54, 0.54, 0.54],
                "state_1_d": [0.62, 0.62, 0.62, 0.62, 0.62],
            },
            "common_next_d": 0.5,
            "outcome": "state-0 contract confirms; state-1 contract remains pending",
        },
        "refractory_is_additional_multi_event_state": {
            "collision": {
                "ell": 0,
                "area": 0.0,
                "count": 0,
                "refractory_state_1": 0,
                "refractory_state_2": 2,
            },
            "common_next_sample": "opening threshold exceeded",
            "outcome": "only refractory_state_1 may open a new candidate",
        },
    }
