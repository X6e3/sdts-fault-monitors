# Experimental path

Development-only ablations, spent-data diagnostics, synthetic fixtures, and
model-selection records belong here. Nothing in this directory is independent
claim-grade evidence.
