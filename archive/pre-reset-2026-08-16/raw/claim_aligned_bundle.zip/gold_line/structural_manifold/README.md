# Structural Manifold Detector

This package contains the heavy structural-feature research family that was
previously labeled simply `dmreda` inside the PQD benchmark.

Its runtime path includes:

```text
sliding window
→ multivariate temporal features
→ calibration-bank standardization
→ centroid and covariance model
→ pseudo-inverse
→ Mahalanobis distance
→ sequential accumulation
→ detector-family persistence/refractory event gate
```

`pqd16c_benchmark.py` is the canonical benchmark source. Full dataset and
covariance-shift benchmark output use schema v3; bounded synthetic/small
engineering output uses its separately identified schema v1. Both use the
`structural_manifold` detector key. A legacy `dmreda` key is recognized only as
a migration marker for historical Structural Manifold output; it is never an
alias for the Core FSM.

The benchmark owns complete-trace first-event outcomes. An early first event is
a false positive and receives no detection delay or later detection credit; a
post-onset first event is a valid detection; no event is a miss with explicit
right-censoring metadata. Conditional delay fields contain valid detections
only. Calibration reports restricted finite-horizon time-to-alarm and censoring
rather than silently treating censored runs as an uncensored ARL estimate.

`separability_harness.c` is a deterministic laboratory experiment that stores
large feature sets and measures centroid separation. It is preserved, but it
is not the DMREDA Core FSM C port. The historical
`gold_line/support/dmreda_core_test.c` path includes this source only for build
compatibility.

The package may be useful as an offline detector or as evidence for structural
separability. Portability requires a separately justified frozen or reduced
feature/whitening design.

## Reproducibility boundary

Optional Kaggle download support is imported only when requested. `--offline`
is fail-closed, `--dataset-archive` owns input discovery, and `--output-dir`
owns generated files. `--synthetic-smoke` is dataset-free engineering
validation; `--small-benchmark` is bounded execution, not scientific
validation. Runtime, dataset, bank, source, and behavior-affecting configuration
identities are recorded in active output.

The pinned clean-environment instructions and observed Stage 2 validation
record are under `repro/structural_manifold/`. The complete licensed PQD-16c
dataset was unavailable during Stage 2. The only local archive contained one
`dummy.csv` member, so its bounded run is preserved only as a negative/internal
smoke result and cannot support a detector ranking.
