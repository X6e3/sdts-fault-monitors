"""Structural Manifold Detector research family.

This package is deliberately separate from :mod:`gold_line.core`, which owns
the canonical DMREDA Core FSM.
"""
