"""
Research-grade Structural Manifold Detector benchmark on PQD-16c.

Key points:
- Causal feature path (no deep learning); the full covariance detector remains heavy.
- Streaming reconstruction: PQD snippets are embedded into long synthetic traces
  with realistic colored noise, drift, and harmonics.
- Primary detector: a structural manifold + sequential Mahalanobis CUSUM.
- This detector is a separate algorithmic family from DMREDA Core FSM.
- Metrics: detection delay, early margin, false alarms, misses, latency
  distribution. Plots are optional.

Prerequisites:
- Python and NumPy for import and synthetic smoke validation.
- SciPy only when waveform resampling is required.
- Matplotlib only with ``--plots``.
- Kaggle plus authorized credentials only when an explicit download is allowed.

Usage (example):
  python3 -m gold_line.structural_manifold.pqd16c_benchmark \
      --runs 50 --target-restricted-mean-time-to-alarm 10000 \
      --offline --dataset-archive /path/to/pqd16c.zip \
      --output-json pqd_report.json --output-csv pqd_runs.csv --plots
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import math
import os
import platform
import random
import subprocess
import tarfile
import tempfile
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Deque, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import hashlib

from gold_line.evaluation import (
    FiniteHorizonAlarmStatistics,
    ThresholdCalibrationResult,
    summarize_finite_horizon_alarms,
)


def _load_pyplot():
    try:
        import matplotlib.pyplot as pyplot
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "matplotlib is required only when --plots is requested"
        ) from exc
    return pyplot


def _load_kaggle_api():
    try:
        from kaggle.api.kaggle_api_extended import KaggleApi
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "kaggle is required only for an authorized dataset download"
        ) from exc
    return KaggleApi


def _load_resample_poly():
    try:
        from scipy.signal import resample_poly
    except ModuleNotFoundError as exc:
        raise RuntimeError("scipy is required only when waveform resampling is needed") from exc
    return resample_poly

# ---- Required constants ----
EPS = 1e-12
LOW_FREQ_RATIO = 0.1
REG_COV = 1e-3
DEFAULT_RUNS = 100
NUM_SAMPLES = 100_000
SLOPE = 2e-5
HARMONIC_AMP = 0.03
HARMONIC_FREQ_HZ = 150.0
K_EFFECTIVE = 3.0

# Determinism
GLOBAL_SEED = 42
np.random.seed(GLOBAL_SEED)
random.seed(GLOBAL_SEED)

# Paths
BASE_DIR = Path(__file__).resolve().parents[2]
CACHE_DIR = BASE_DIR / "pqd16c_cache"
DATASET_ZIP = CACHE_DIR / "pqd16c.zip"

# Streaming / signal parameters
FS_TARGET = 10_000  # Hz after resampling
STREAM_LEN_RANGE = (50_000, 200_000)  # samples
BACKGROUND_RHO = 0.9
BACKGROUND_STD = 0.05
DRIFT_STD = 0.00005
HARMONIC_AMPL = HARMONIC_AMP
HARMONIC_FREQ = HARMONIC_FREQ_HZ
HARMONIC_JITTER = 0.5  # Hz deviation
IMPULSE_RATE = 0.00005  # per sample
IMPULSE_SCALE = 0.1
RMS_TOL = 0.005  # 0.5% window RMS tolerance
MEAN_PRESERVE_TOL = 2e-3
VAR_PRESERVE_TOL = 0.02
ARL_TOL = 0.10
CALIBRATION_RUNS = 40
GLR_WINDOW = 64
EWMA_ALPHA = 2.0 / (32 + 1.0)
HP_ALPHA = 0.1
STATIONARY_DRIFT_TOL = 1e-3

# Structural-manifold feature windows (causal)
FEATURE_WINDOW = 64
RMS_WINDOW = 32
PERSISTENCE = 3

# Historical internal names retain ``ARL`` for compatibility.  Active output
# schemas explicitly report finite-horizon restricted time-to-alarm statistics.
TARGET_ARL = 10_000.0
ARL_BINSEARCH_ITERS = 40

# Output defaults
DEFAULT_JSON = BASE_DIR / "structural_manifold_pqd16c_results.json"
DEFAULT_CSV = BASE_DIR / "structural_manifold_pqd16c_runs.csv"
STRUCTURAL_COV_JSON = BASE_DIR / "results" / "structural_covariance_shift_results.json"

# ROC sweep multipliers
ROC_MULTIPLIERS = np.linspace(0.5, 2.5, 9)

# Structural covariance-shift benchmark constants
STRUCTURAL_MIN_RUNS = 200
STRUCTURAL_STREAM_LEN_RANGE = (20_000, 30_000)
STRUCTURAL_BASE_RHO = 0.9
STRUCTURAL_SHIFT_RHO = 0.4
STRUCTURAL_SIGMA = BACKGROUND_STD
STRUCTURAL_LOW_PASS_ALPHA = 0.02
STRUCTURAL_LOW_FREQ_WEIGHT = 0.25
STRUCTURAL_BLEND_LEN = 512
STRUCTURAL_RMS_TARGET_REL = 0.02
STRUCTURAL_RMS_ABORT_REL = 0.03
STRUCTURAL_MISS_FAIL_PCT = 80.0
STRUCTURAL_CALIBRATION_RUNS = 40
STRUCTURAL_EMPIRICAL_ARL_RUNS = 40


# -----------------------------------------------------------------------------#
# Data classes
# -----------------------------------------------------------------------------#
@dataclass
class RunStats:
    scenario: str
    config_id: str
    strict_delay: float
    effective_delay: float
    detector: str
    fp: bool
    miss: bool
    onset: int
    detect_time: float
    seed: int


@dataclass
class DetectorMetrics:
    conditional_valid_detection_delay_mean_samples: float
    conditional_valid_detection_delay_median_samples: float
    conditional_valid_detection_delay_p10_samples: float
    conditional_valid_detection_delay_p90_samples: float
    detection_rate_pct: float
    miss_rate: float
    fp_rate: float
    achieved_restricted_mean_time_to_alarm: float


# -----------------------------------------------------------------------------#
# Dataset acquisition
# -----------------------------------------------------------------------------#
def download_pqd16c(cache_dir: Path = CACHE_DIR) -> Path:
    """Download PQD-16c from Kaggle if not already cached."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    archive_path = cache_dir / "pqd16c.zip"
    if archive_path.exists():
        return archive_path
    KaggleApi = _load_kaggle_api()
    api = KaggleApi()
    api.authenticate()
    api.dataset_download_files("datamunge/pqd-16c", path=cache_dir, unzip=False)
    if not archive_path.is_file():
        raise RuntimeError("Kaggle download completed without the expected archive")
    return archive_path


def extract_first_waveforms(archive_path: Path, cache_dir: Path = CACHE_DIR, limit: int = 50) -> List[np.ndarray]:
    """Extract a subset of PQD waveforms; assumes archive is a zip or tar of CSV files."""
    waveforms: List[np.ndarray] = []
    if archive_path.suffix == ".zip":
        import zipfile

        with zipfile.ZipFile(archive_path, "r") as zf:
            for name in zf.namelist():
                if not name.lower().endswith(".csv"):
                    continue
                with zf.open(name) as f:
                    data = np.loadtxt(f, delimiter=",", dtype=np.float64)
                    waveforms.append(data)
                if len(waveforms) >= limit:
                    break
    elif archive_path.suffix in {".tar", ".gz", ".tgz"}:
        with tarfile.open(archive_path, "r:*") as tf:
            for member in tf:
                if not member.name.lower().endswith(".csv"):
                    continue
                f = tf.extractfile(member)
                if f is None:
                    continue
                data = np.loadtxt(f, delimiter=",", dtype=np.float64)
                waveforms.append(data)
                if len(waveforms) >= limit:
                    break
    else:
        raise ValueError(f"Unsupported archive format: {archive_path}")
    if not waveforms:
        raise RuntimeError("No waveforms extracted; check dataset archive.")
    return waveforms


# -----------------------------------------------------------------------------#
# Streaming synthesis
# -----------------------------------------------------------------------------#
def colored_noise(rng: np.random.Generator, length: int, rho: float, sigma: float) -> np.ndarray:
    eps_std = sigma * math.sqrt(max(1.0 - rho * rho, 1e-12))
    x = np.empty(length, dtype=np.float64)
    x[0] = rng.normal(0.0, sigma)
    for i in range(1, length):
        x[i] = rho * x[i - 1] + rng.normal(0.0, eps_std)
    return x


def slow_drift(rng: np.random.Generator, length: int, std: float) -> np.ndarray:
    t = np.arange(length, dtype=np.float64)
    drift = rng.normal(0.0, std, size=length).astype(np.float64)
    drift = np.cumsum(drift)
    drift -= drift.mean()
    return drift


def harmonic_contamination_stream(rng: np.random.Generator, length: int, base_ampl: float) -> np.ndarray:
    t = np.arange(length, dtype=np.float64) / FS_TARGET
    freq = HARMONIC_FREQ + rng.uniform(-HARMONIC_JITTER, HARMONIC_JITTER)
    ampl = base_ampl * rng.uniform(0.6, 1.4)
    return (ampl * np.sin(2.0 * math.pi * freq * t)).astype(np.float64)


def impulse_noise(rng: np.random.Generator, length: int, rate: float, scale: float) -> np.ndarray:
    mask = rng.uniform(0.0, 1.0, size=length) < rate
    impulses = rng.normal(0.0, scale, size=length).astype(np.float64)
    return impulses * mask


def resample_to_10k(signal: np.ndarray, orig_fs: float) -> np.ndarray:
    if math.isclose(orig_fs, FS_TARGET):
        return signal.astype(np.float64, copy=False)
    resample_poly = _load_resample_poly()
    up = int(FS_TARGET)
    down = int(orig_fs)
    return resample_poly(signal, up, down).astype(np.float64, copy=False)


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def config_hash(config: Dict[str, object]) -> str:
    payload = json.dumps(
        _canonical_value(config),
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _canonical_value(value: Any) -> Any:
    """Convert configuration/output values into deterministic JSON data.

    Array contents are represented by dtype, shape, and a content hash.  This
    keeps configuration hashes stable without embedding large fitted models in
    metadata.  Non-finite values are explicit nulls in outputs; they are never
    emitted as non-standard JSON ``NaN``/``Infinity`` tokens.
    """

    if isinstance(value, np.ndarray):
        contiguous = np.ascontiguousarray(value)
        return {
            "dtype": contiguous.dtype.str,
            "shape": list(contiguous.shape),
            "sha256": hashlib.sha256(contiguous.tobytes(order="C")).hexdigest(),
        }
    if isinstance(value, np.generic):
        return _canonical_value(value.item())
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {
            str(key): _canonical_value(item)
            for key, item in sorted(
                value.items(), key=lambda pair: str(pair[0])
            )
        }
    if isinstance(value, (list, tuple)):
        return [_canonical_value(item) for item in value]
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if callable(value):
        module = getattr(value, "__module__", "")
        qualname = getattr(
            value,
            "__qualname__",
            getattr(value, "__name__", type(value).__name__),
        )
        return {"callable": f"{module}.{qualname}".strip(".")}
    if value is None or isinstance(value, (str, int, bool)):
        return value
    return {"type": f"{type(value).__module__}.{type(value).__qualname__}"}


def strict_json_dumps(value: Any, *, indent: int = 2) -> str:
    """Serialize standards-compliant JSON after normalizing NumPy values."""

    return (
        json.dumps(
            _canonical_value(value),
            indent=indent,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n"
    )


def atomic_write_text(path: Path, text: str) -> None:
    """Atomically replace a text artifact in its destination directory."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=path.parent,
            delete=False,
        ) as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def signal_bank_hash(signals: Sequence[np.ndarray]) -> str:
    """Hash an ordered signal bank including each array's dtype and shape."""

    digest = hashlib.sha256()
    for index, signal in enumerate(signals):
        contiguous = np.ascontiguousarray(signal)
        digest.update(index.to_bytes(8, "little", signed=False))
        digest.update(contiguous.dtype.str.encode("ascii"))
        digest.update(np.asarray(contiguous.shape, dtype="<u8").tobytes())
        digest.update(contiguous.tobytes(order="C"))
    return digest.hexdigest()


def resolve_dataset_archive(
    *,
    explicit_archive: Path | None,
    cache_dir: Path,
    offline: bool,
) -> Path:
    """Resolve the dataset without silently crossing the network boundary."""

    if explicit_archive is not None:
        archive = explicit_archive.expanduser().resolve()
        if not archive.is_file():
            raise FileNotFoundError(f"dataset archive does not exist: {archive}")
        return archive
    cached = cache_dir.expanduser().resolve() / "pqd16c.zip"
    if cached.is_file():
        return cached
    if offline:
        raise FileNotFoundError(
            f"offline mode requires --dataset-archive or cached archive at {cached}"
        )
    return download_pqd16c(cache_dir.expanduser().resolve())


def dataset_archive_manifest(archive: Path) -> Dict[str, object]:
    """Return content identity and member inventory without extracting data."""

    members: List[str] = []
    if archive.suffix.lower() == ".zip":
        import zipfile

        with zipfile.ZipFile(archive, "r") as handle:
            members = sorted(
                item.filename for item in handle.infolist() if not item.is_dir()
            )
    elif archive.suffix.lower() in {".tar", ".gz", ".tgz"}:
        with tarfile.open(archive, "r:*") as handle:
            members = sorted(item.name for item in handle.getmembers() if item.isfile())
    return {
        "sha256": file_sha256(archive),
        "size_bytes": archive.stat().st_size,
        "member_count": len(members),
        "member_names_sha256": hashlib.sha256(
            "\n".join(members).encode("utf-8")
        ).hexdigest(),
    }


def runtime_manifest() -> Dict[str, object]:
    """Capture the executing runtime without importing optional Kaggle auth."""

    packages: Dict[str, str | None] = {}
    for distribution in ("numpy", "scipy", "matplotlib", "kaggle"):
        try:
            packages[distribution] = importlib.metadata.version(distribution)
        except importlib.metadata.PackageNotFoundError:
            packages[distribution] = None

    git: Dict[str, object] = {"commit": None, "dirty": None}
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=BASE_DIR,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        dirty = bool(
            subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=BASE_DIR,
                check=True,
                capture_output=True,
                text=True,
            ).stdout.strip()
        )
        git = {"commit": commit, "dirty": dirty}
    except (OSError, subprocess.CalledProcessError):
        pass

    return {
        "python": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "operating_system": platform.platform(),
        "machine": platform.machine(),
        "packages": packages,
        "numpy_build_dependencies": _canonical_value(
            np.__config__.CONFIG.get("Build Dependencies", {})
        ),
        "source_sha256": file_sha256(Path(__file__)),
        "git": git,
    }


def detector_event_contract(detector_name: str) -> Dict[str, object]:
    """Describe the native score/reset path and external authority gate.

    This benchmark contains the Structural Manifold family and scalar
    comparators; it does not execute the DMREDA Core FSM.  The persistence gate
    here therefore must not be described as canonical DMREDA event authority.
    """

    native_mechanisms = {
        "structural_manifold": "Mahalanobis distance then nonnegative sequential accumulation",
        "rms": "trailing RMS squared then nonnegative sequential accumulation",
        "page_hinkley": "native Page-Hinkley accumulator",
        "cusum_mean": "native two-sided mean CUSUM accumulator",
        "cusum_variance": "native high-pass energy CUSUM accumulator",
        "ewma_mean_var": "native EWMA mean/variance score",
        "glr_mean": "native causal windowed mean-shift GLR score",
    }
    return {
        "warmup_samples": 0,
        "native_score_mechanism": native_mechanisms.get(
            detector_name, "detector-native causal score"
        ),
        "external_event_mechanism": (
            f"score > threshold for {PERSISTENCE} consecutive samples"
        ),
        "reset_policy": "all detector and gate state resets at each trace start",
        "refractory_samples": 0,
        "first_alarm_ownership": "first confirmed alarm on the complete trace",
    }


def detector_configuration_hash(
    detector_name: str, model: Mapping[str, object]
) -> str:
    """Hash the complete fitted detector configuration used for evaluation."""

    return config_hash(
        {
            "schema": "structural-manifold-detector-config-v1",
            "detector": detector_name,
            "model": dict(model),
            "event_contract": detector_event_contract(detector_name),
        }
    )


def smooth_blend(base: np.ndarray, insert: np.ndarray, start: int) -> None:
    n = insert.size
    end = start + n
    if end > base.size:
        raise ValueError("Insertion exceeds base length")
    window = np.hanning(min(64, n))
    half = window.size // 2
    # fade-in
    base[start : start + half] += insert[:half] * window[:half]
    # middle
    base[start + half : end - half] += insert[half : n - half]
    # fade-out
    base[end - half : end] += insert[n - half :] * window[half:]


def background_stream(rng: np.random.Generator, length: int) -> np.ndarray:
    """Generate streaming background with the same components as main streams."""
    stream = colored_noise(rng, length, BACKGROUND_RHO, BACKGROUND_STD)
    stream += slow_drift(rng, length, DRIFT_STD)
    stream += harmonic_contamination_stream(rng, length, HARMONIC_AMPL)
    stream += impulse_noise(rng, length, IMPULSE_RATE, IMPULSE_SCALE)
    return stream


def structural_noise_stream(rng: np.random.Generator, length: int) -> np.ndarray:
    """Stationary AR(1) baseline used for the structural covariance-shift benchmark."""
    return colored_noise(rng, length, STRUCTURAL_BASE_RHO, STRUCTURAL_SIGMA)


def iir_lowpass(signal: np.ndarray, alpha: float) -> np.ndarray:
    out = np.empty_like(signal, dtype=np.float64)
    out[0] = float(signal[0])
    for idx in range(1, signal.size):
        out[idx] = alpha * signal[idx] + (1.0 - alpha) * out[idx - 1]
    return out


def lag1_autocorr(signal: np.ndarray) -> float:
    if signal.size < 2:
        return math.nan
    x0 = signal[:-1] - float(np.mean(signal[:-1]))
    x1 = signal[1:] - float(np.mean(signal[1:]))
    denom = math.sqrt(float(np.sum(x0 * x0) * np.sum(x1 * x1))) + EPS
    return float(np.sum(x0 * x1) / denom)


def low_frequency_ratio_iir(signal: np.ndarray, alpha: float = STRUCTURAL_LOW_PASS_ALPHA) -> float:
    lp = iir_lowpass(signal, alpha)
    energy_total = float(np.sum(signal * signal)) + EPS
    energy_lp = float(np.sum(lp * lp))
    return energy_lp / energy_total


def structural_window_stats(signal: np.ndarray, onset: int, span: int) -> np.ndarray:
    start = max(0, onset - span)
    end = min(signal.size, onset + span)
    if end - onset < span:
        start = max(0, end - 2 * span)
    return signal[start : start + span]


def structural_covariance_shift_diagnostics(
    baseline_window: np.ndarray,
    shifted_window: np.ndarray,
) -> Dict[str, float]:
    base_mean = float(np.mean(baseline_window))
    shift_mean = float(np.mean(shifted_window))
    base_var = float(np.var(baseline_window) + EPS)
    shift_var = float(np.var(shifted_window) + EPS)
    base_rms = math.sqrt(float(np.mean(baseline_window**2)) + EPS)
    shift_rms = math.sqrt(float(np.mean(shifted_window**2)) + EPS)
    return {
        "baseline_mean": base_mean,
        "shifted_mean": shift_mean,
        "baseline_var": base_var,
        "shifted_var": shift_var,
        "baseline_rms": base_rms,
        "shifted_rms": shift_rms,
        "mean_gap_abs": abs(shift_mean - base_mean),
        "var_gap_rel": abs(shift_var - base_var) / base_var,
        "rms_gap_rel": abs(shift_rms - base_rms) / base_rms,
        "baseline_lag1": lag1_autocorr(baseline_window),
        "shifted_lag1": lag1_autocorr(shifted_window),
        "baseline_low_freq_ratio": low_frequency_ratio_iir(baseline_window),
        "shifted_low_freq_ratio": low_frequency_ratio_iir(shifted_window),
    }


def build_structural_covariance_shift_run(
    rng: np.random.Generator,
) -> Tuple[np.ndarray, int, Dict[str, float]]:
    length = int(rng.integers(STRUCTURAL_STREAM_LEN_RANGE[0], STRUCTURAL_STREAM_LEN_RANGE[1] + 1))
    signal = structural_noise_stream(rng, length)
    onset_low = max(int(0.10 * length), 8 * FEATURE_WINDOW)
    onset_high = min(int(0.70 * length), length - 10 * FEATURE_WINDOW - 1)
    if onset_high <= onset_low:
        onset_high = onset_low + 1
    onset = int(rng.integers(onset_low, onset_high))
    pre_signal = signal.copy()

    span = min(8_192, onset, signal.size - onset)
    if span <= FEATURE_WINDOW:
        raise RuntimeError("Structural covariance shift span too short")

    baseline_window = signal[onset - span : onset].copy()
    target_mean = float(np.mean(baseline_window))
    target_std = float(np.std(baseline_window) + EPS)
    target_rms = math.sqrt(float(np.mean(baseline_window**2)) + EPS)

    shifted = colored_noise(rng, signal.size - onset, STRUCTURAL_SHIFT_RHO, target_std)
    low_band = iir_lowpass(rng.normal(0.0, target_std, size=shifted.size).astype(np.float64), STRUCTURAL_LOW_PASS_ALPHA)
    low_band -= float(np.mean(low_band))
    low_band /= float(np.std(low_band) + EPS)
    low_band *= target_std

    mix_scale = math.sqrt(max(1.0 - STRUCTURAL_LOW_FREQ_WEIGHT**2, EPS))
    shifted = mix_scale * shifted + STRUCTURAL_LOW_FREQ_WEIGHT * low_band
    shifted -= float(np.mean(shifted))
    shifted /= float(np.std(shifted) + EPS)
    shifted *= target_std
    shifted += target_mean

    blend_len = min(STRUCTURAL_BLEND_LEN, shifted.size)
    if blend_len > 1:
        fade = np.linspace(0.0, 1.0, blend_len, dtype=np.float64)
        original = signal[onset : onset + blend_len]
        shifted[:blend_len] = (1.0 - fade) * original + fade * shifted[:blend_len]
    for _ in range(3):
        span_view = shifted[:span]
        shifted += target_mean - float(np.mean(span_view))
        span_std = float(np.std(shifted[:span]) + EPS)
        shifted = target_mean + (shifted - target_mean) * (target_std / span_std)
        span_rms = math.sqrt(float(np.mean(shifted[:span] ** 2)) + EPS)
        shifted *= target_rms / span_rms
        shifted += target_mean - float(np.mean(shifted[:span]))

    signal[onset:] = shifted
    shifted_window = signal[onset : onset + span]
    diag = structural_covariance_shift_diagnostics(baseline_window, shifted_window)
    diag["mean_preserved"] = float(diag["mean_gap_abs"] <= MEAN_PRESERVE_TOL)
    diag["variance_preserved"] = float(diag["var_gap_rel"] <= VAR_PRESERVE_TOL)
    diag["rms_preserved"] = float(diag["rms_gap_rel"] <= STRUCTURAL_RMS_TARGET_REL)

    # Defensive correction: exact RMS match if drift window is still slightly off.
    if diag["rms_gap_rel"] > STRUCTURAL_RMS_TARGET_REL:
        segment = signal[onset:]
        renormalize_rms(segment, target_rms)
        segment += target_mean - float(np.mean(segment[:span]))
        shifted_window = signal[onset : onset + span]
        diag = structural_covariance_shift_diagnostics(baseline_window, shifted_window)
        diag["mean_preserved"] = float(diag["mean_gap_abs"] <= MEAN_PRESERVE_TOL)
        diag["variance_preserved"] = float(diag["var_gap_rel"] <= VAR_PRESERVE_TOL)
        diag["rms_preserved"] = float(diag["rms_gap_rel"] <= STRUCTURAL_RMS_TARGET_REL)

    # Preserve a copy of the unperturbed stream only for deterministic sanity if needed.
    _ = pre_signal
    return signal, onset, diag


def apply_drift(signal: np.ndarray, onset: int, slope: float) -> None:
    t = np.arange(signal.size - onset, dtype=np.float64)
    signal[onset:] += slope * t


def apply_harmonic(signal: np.ndarray, onset: int, amplitude: float, freq_hz: float) -> None:
    t = np.arange(signal.size - onset, dtype=np.float64) / FS_TARGET
    signal[onset:] += amplitude * np.sin(2.0 * math.pi * freq_hz * t)


def renormalize_rms(segment: np.ndarray, target_rms: float) -> None:
    current = math.sqrt(float(np.mean(segment**2)) + EPS)
    if current == 0:
        return
    segment *= target_rms / current


def perturb_energy_preserved(rng: np.random.Generator, signal: np.ndarray, onset: int) -> Tuple[float, float]:
    """
    Apply structural perturbations post-onset while keeping RMS within 0.5%.
    Returns (rms_before, rms_after).
    """
    pre_rms = math.sqrt(float(np.mean(signal[:onset] ** 2)) + EPS)
    seg = signal[onset:].copy()
    n = seg.size

    # A) Harmonic redistribution
    spectrum = np.fft.rfft(seg)
    freqs = np.fft.rfftfreq(n, d=1.0 / FS_TARGET)
    fundamental = 50.0
    def nearest_bin(h):
        return int(np.argmin(np.abs(freqs - h * fundamental)))
    b3, b5 = nearest_bin(3), nearest_bin(5)
    if b3 < spectrum.size and b5 < spectrum.size:
        energy3 = np.abs(spectrum[b3])
        transfer = 0.3 * energy3
        spectrum[b3] *= 0.7
        spectrum[b5] += transfer * np.exp(1j * np.angle(spectrum[b3]))
    seg = np.fft.irfft(spectrum, n=n)

    # B) Slow phase walk using Hilbert transform
    analytic = np.fft.ifft(np.fft.fft(seg) * 2)
    hilbert = np.imag(analytic)
    phase_walk = rng.normal(0.0, 1e-4, size=n).cumsum()
    seg = seg * np.cos(phase_walk) - hilbert * np.sin(phase_walk)

    # C) Low-frequency envelope modulation
    eps_env = rng.uniform(0.01, 0.03)
    f_env = rng.uniform(1.0, 3.0)
    t = np.arange(n, dtype=np.float64) / FS_TARGET
    seg *= (1.0 + eps_env * np.sin(2.0 * math.pi * f_env * t))

    # D) Half-cycle asymmetry
    delta = rng.uniform(0.02, 0.06)
    pos_mask = seg >= 0
    seg[pos_mask] *= (1.0 + delta)
    seg[~pos_mask] *= (1.0 - delta)

    # Renormalize RMS
    renormalize_rms(seg, pre_rms)
    post_rms = math.sqrt(float(np.mean(seg**2)) + EPS)
    if abs(post_rms - pre_rms) / max(pre_rms, EPS) > 0.005:
        # final corrective scaling
        renormalize_rms(seg, pre_rms)
        post_rms = math.sqrt(float(np.mean(seg**2)) + EPS)

    signal[onset:] = seg
    return pre_rms, post_rms


def _smooth_gain(gain: np.ndarray, width: int = 33) -> np.ndarray:
    width = max(3, width | 1)  # ensure odd
    kernel = np.ones(width, dtype=np.float64)
    kernel /= kernel.sum()
    padded = np.pad(gain, (width // 2,), mode="edge")
    smoothed = np.convolve(padded, kernel, mode="valid")
    return smoothed


def perturb_phase_scramble_window_rms_preserved(
    rng: np.random.Generator, signal: np.ndarray, onset: int
) -> Tuple[float, float, float, float, np.ndarray]:
    """
    Phase scramble a post-onset segment while preserving trailing RMS locally.
    Returns (global_pre_rms, global_post_rms, max_rel_err, mean_rel_err, feature_delta).
    """
    n_total = signal.size
    seg_len = int(rng.integers(20_000, 50_000))
    seg_len = min(seg_len, n_total - onset)
    if seg_len <= RMS_WINDOW + 2:
        return 0.0, 0.0, 0.0, 0.0, np.zeros(10)

    pre_signal = signal.copy()
    pre_rms_global = math.sqrt(float(np.mean(pre_signal**2)) + EPS)

    seg = signal[onset : onset + seg_len]
    orig_seg = seg.copy()

    # phase scramble with smooth phase warp
    spectrum = np.fft.rfft(seg)
    mag = np.abs(spectrum)
    phase = np.angle(spectrum)
    warp = rng.normal(0.0, 0.02, size=phase.shape)
    warp = np.cumsum(warp)
    warp = _smooth_gain(warp, width=51)
    new_phase = phase + warp
    spectrum_scrambled = mag * np.exp(1j * new_phase)
    seg_scrambled = np.fft.irfft(spectrum_scrambled, n=seg_len)

    rms_pre = trailing_rms(pre_signal, RMS_WINDOW)
    # Sequential exact window enforcement using running sum of squares
    corr = pre_signal.copy()
    corr[onset : onset + seg_len] = seg_scrambled
    sum_sq = 0.0
    window_vals: List[float] = []
    for t in range(corr.size):
        val = corr[t]
        val_sq = float(val * val)
        sum_sq += val_sq
        window_vals.append(val_sq)
        if len(window_vals) > RMS_WINDOW:
            sum_sq -= window_vals.pop(0)
        if t < onset:
            continue
        target_len = len(window_vals)
        target_sum = (rms_pre[t] ** 2) * target_len
        temp_sum = sum_sq - window_vals[-1]
        new_val_sq = max(target_sum - temp_sum, 0.0)
        gain = math.sqrt(new_val_sq / (window_vals[-1] + EPS))
        corr[t] *= gain
        new_sq = corr[t] * corr[t]
        window_vals[-1] = new_sq
        sum_sq = temp_sum + new_sq

    temp_signal = corr
    rms_post2 = trailing_rms(temp_signal, RMS_WINDOW)
    rel_err = np.abs(rms_post2[onset : onset + seg_len] - rms_pre[onset : onset + seg_len]) / (
        rms_pre[onset : onset + seg_len] + EPS
    )
    max_rel_err = float(np.max(rel_err))
    mean_rel_err = float(np.mean(rel_err))

    # commit
    signal[onset : onset + seg_len] = corr[onset : onset + seg_len]
    post_rms_global = math.sqrt(float(np.mean(signal**2)) + EPS)

    # feature deltas
    _, feat_before = augmented_features(pre_signal[onset : onset + seg_len + FEATURE_WINDOW - 1], FEATURE_WINDOW)
    _, feat_after = augmented_features(signal[onset : onset + seg_len + FEATURE_WINDOW - 1], FEATURE_WINDOW)
    feat_delta = np.mean(np.abs(feat_after - feat_before), axis=0)

    return pre_rms_global, post_rms_global, max_rel_err, mean_rel_err, feat_delta


def apply_phase_scramble_scenario(
    rng: np.random.Generator, signal: np.ndarray, onset: int
) -> Tuple[Dict[str, object], np.ndarray]:
    pre_signal = signal.copy()
    pre_rms, post_rms, max_err, mean_err, feat_delta = perturb_phase_scramble_window_rms_preserved(rng, signal, onset)
    diag = scenario_preservation_flags(pre_signal, signal, onset)
    diag["global_rms_pre"] = pre_rms
    diag["global_rms_post"] = post_rms
    diag["window_rms_max_rel_err"] = max_err
    diag["window_rms_mean_rel_err"] = mean_err
    diag["feature_delta"] = feat_delta.tolist()
    return diag, pre_signal


# -----------------------------------------------------------------------------#
# Low-level utilities
# -----------------------------------------------------------------------------#
def trailing_median(signal: np.ndarray, window: int) -> np.ndarray:
    """Causal trailing median used only for effective-onset reporting."""

    if window <= 0:
        raise ValueError("window must be positive")
    result = np.empty(signal.size, dtype=np.float64)
    for idx in range(signal.size):
        start = max(0, idx - window + 1)
        result[idx] = float(np.median(signal[start : idx + 1]))
    return result


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=np.float64)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=np.float64)))
    rms = np.empty(signal.size, dtype=np.float64)
    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)
    return rms


def persistent_mask(trigger: np.ndarray, persistence: int) -> np.ndarray:
    out = np.zeros_like(trigger, dtype=bool)
    count = 0
    for i, flag in enumerate(trigger):
        if flag:
            count += 1
            if count >= persistence:
                out[i] = True
        else:
            count = 0
    return out


def first_trigger_at_or_after(trigger: np.ndarray, onset: int) -> int | None:
    idx = np.flatnonzero(trigger[onset:])
    if idx.size == 0:
        return None
    return int(onset + idx[0])


def mahalanobis_series(features: np.ndarray, centroid: np.ndarray, inv_cov: np.ndarray) -> np.ndarray:
    delta = features - centroid
    quad = np.einsum("ij,jk,ik->i", delta, inv_cov, delta)
    return np.clip(quad, 0.0, None)


def sequential_statistic(distance_series: np.ndarray, bias: float) -> np.ndarray:
    s = np.zeros_like(distance_series, dtype=np.float64)
    accum = 0.0
    for i, d in enumerate(distance_series):
        accum = max(0.0, accum + (float(d) - bias))
        s[i] = accum
    return s


def rms_detect(signal: np.ndarray, onset: int, persistence: int, bias: float, threshold: float) -> int | None:
    """Return the first complete-trace RMS alarm.

    ``onset`` remains in the compatibility signature but must not constrain the
    search; callers need the pre-onset alarm to perform correct FP accounting.
    """

    _ = onset
    rms = trailing_rms(signal, RMS_WINDOW)
    seq = sequential_statistic(np.square(rms), bias)
    trig = persistent_mask(seq > threshold, persistence)
    pos = np.flatnonzero(trig)
    return None if pos.size == 0 else int(pos[0])


def effective_onset(signal: np.ndarray, baseline_mu: np.ndarray, onset: int, k_sigma: float) -> int | None:
    sigma = float(np.std(signal[:onset])) + EPS
    thresh = k_sigma * sigma
    for t in range(onset, signal.size):
        if abs(signal[t] - baseline_mu[t]) > thresh:
            return t
    return None


def robust_location_scale(signal: np.ndarray) -> Tuple[float, float]:
    mu0 = float(np.median(signal))
    mad = float(np.median(np.abs(signal - mu0)) + EPS)
    sigma0 = 1.4826 * mad + EPS
    return mu0, sigma0


def robust_variance(signal: np.ndarray, mu0: float) -> float:
    return float(np.median((signal - mu0) ** 2) + EPS)


class StreamingDetector:
    def reset(self) -> None:
        raise NotImplementedError

    def update(self, x_t: float) -> float:
        raise NotImplementedError


class PageHinkleyDetector(StreamingDetector):
    def __init__(self, mu0: float, delta: float) -> None:
        self.mu0 = mu0
        self.delta = delta
        self.reset()

    def reset(self) -> None:
        self.mean = self.mu0
        self.count = 0
        self.ph = 0.0

    def update(self, x_t: float) -> float:
        deviation = x_t - self.mean - self.delta
        self.ph = max(0.0, self.ph + deviation)
        self.count += 1
        self.mean += (x_t - self.mean) / self.count
        return self.ph


class TwoSidedCUSUMDetector(StreamingDetector):
    def __init__(self, mu0: float, k: float) -> None:
        self.mu0 = mu0
        self.k = k
        self.reset()

    def reset(self) -> None:
        self.c_plus = 0.0
        self.c_minus = 0.0

    def update(self, x_t: float) -> float:
        centered = x_t - self.mu0
        self.c_plus = max(0.0, self.c_plus + centered - self.k)
        self.c_minus = max(0.0, self.c_minus - centered - self.k)
        return max(self.c_plus, self.c_minus)


class VarianceCUSUMDetector(StreamingDetector):
    def __init__(self, mu0: float, alpha_hp: float, k: float) -> None:
        self.mu0 = mu0
        self.alpha_hp = alpha_hp
        self.k = k
        self.reset()

    def reset(self) -> None:
        self.ewma_mean = self.mu0
        self.score = 0.0

    def update(self, x_t: float) -> float:
        self.ewma_mean = (1.0 - self.alpha_hp) * self.ewma_mean + self.alpha_hp * x_t
        hp_t = x_t - self.ewma_mean
        z_t = hp_t * hp_t
        self.score = max(0.0, self.score + (z_t - self.k))
        return self.score


class EWMAMeanVarianceDetector(StreamingDetector):
    def __init__(self, mu0: float, sigma0: float, var0: float, alpha: float, var_scale: float) -> None:
        self.mu0 = mu0
        self.sigma0 = sigma0
        self.var0 = var0
        self.alpha = alpha
        self.var_scale = var_scale
        self.reset()

    def reset(self) -> None:
        self.ewma_mean = self.mu0
        self.ewma_var = self.var0

    def update(self, x_t: float) -> float:
        self.ewma_mean = (1.0 - self.alpha) * self.ewma_mean + self.alpha * x_t
        residual = x_t - self.ewma_mean
        self.ewma_var = (1.0 - self.alpha) * self.ewma_var + self.alpha * (residual * residual)
        score_mean = abs(self.ewma_mean - self.mu0) / (self.sigma0 + EPS)
        score_var = abs(self.ewma_var - self.var0) / (self.var_scale + EPS)
        return max(score_mean, score_var)


class GLRMeanShiftDetector(StreamingDetector):
    def __init__(self, mu0: float, sigma0: float, window: int) -> None:
        self.mu0 = mu0
        self.sigma0 = sigma0
        self.window = window
        self.reset()

    def reset(self) -> None:
        self.buffer: Deque[float] = deque(maxlen=self.window)

    def update(self, x_t: float) -> float:
        self.buffer.append(x_t)
        running = 0.0
        best = 0.0
        values = list(self.buffer)
        for width, value in enumerate(reversed(values), start=1):
            running += value - self.mu0
            score = (running * running) / ((self.sigma0 * self.sigma0 * width) + EPS)
            if score > best:
                best = score
        return best


def run_streaming_detector(detector: StreamingDetector, signal: np.ndarray) -> np.ndarray:
    detector.reset()
    scores = np.empty(signal.size, dtype=np.float64)
    for idx, sample in enumerate(signal):
        scores[idx] = detector.update(float(sample))
    return scores


def gate_score_series(
    scores: np.ndarray,
    threshold: float,
    persistence: int,
    sig_len: int,
    indices: Optional[np.ndarray] = None,
) -> np.ndarray:
    trigger = np.zeros(sig_len, dtype=bool)
    if indices is None:
        trigger[: scores.size] = scores > threshold
    else:
        trigger[indices] = scores > threshold
    return persistent_mask(trigger, persistence)


def detector_drift_rate(scores: np.ndarray) -> float:
    if scores.size <= 1:
        return 0.0
    return float(np.mean(np.diff(scores)))


def is_stationary_score(scores: np.ndarray) -> bool:
    if scores.size < 16:
        return True
    span = max(8, scores.size // 4)
    head = scores[:span]
    tail = scores[-span:]
    delta = abs(float(np.mean(tail) - np.mean(head)))
    scale = float(np.std(scores) + EPS)
    return delta <= 0.5 * scale


def noise_stream_generator(rng: np.random.Generator, max_samples: int) -> np.ndarray:
    upper = min(STREAM_LEN_RANGE[1], max_samples)
    length = int(rng.integers(STREAM_LEN_RANGE[0], upper + 1))
    return background_stream(rng, length)


def structural_noise_stream_generator(rng: np.random.Generator, max_samples: int) -> np.ndarray:
    upper = min(STRUCTURAL_STREAM_LEN_RANGE[1], max_samples)
    length = int(rng.integers(STRUCTURAL_STREAM_LEN_RANGE[0], upper + 1))
    return structural_noise_stream(rng, length)


def calibrate_threshold(
    detector_factory: Callable[[], StreamingDetector],
    noise_stream_generator_fn: Callable[[np.random.Generator, int], np.ndarray],
    target_arl: float,
    persistence_params: Dict[str, int],
    seed: int,
    n_runs: int,
    max_samples: int,
) -> Tuple[float, float, List[np.ndarray], List[int]]:
    rng = np.random.default_rng(seed)
    score_runs: List[np.ndarray] = []
    signal_lengths: List[int] = []
    indices_runs: List[np.ndarray] = []
    for _ in range(n_runs):
        signal = noise_stream_generator_fn(rng, max_samples)
        score = run_streaming_detector(detector_factory(), signal)
        score_runs.append(score)
        signal_lengths.append(signal.size)
        indices_runs.append(np.arange(signal.size, dtype=np.int64))
    threshold, arl = calibrate_threshold_noise(
        score_runs,
        indices_runs,
        target_arl,
        persistence_params["persistence"],
        signal_lengths,
    )
    return threshold, arl, score_runs, signal_lengths


def build_scalar_detector_model(
    name: str,
    params: Dict[str, float],
    detector_factory: Callable[[Dict[str, float]], StreamingDetector],
    target_arl: float,
    seed: int,
    noise_generator_fn: Callable[[np.random.Generator, int], np.ndarray] = noise_stream_generator,
    max_samples: int = STREAM_LEN_RANGE[1],
    calibration_runs: int = CALIBRATION_RUNS,
) -> Dict[str, object]:
    factory = lambda: detector_factory(params)
    threshold, arl, score_runs, signal_lengths = calibrate_threshold(
        factory,
        noise_generator_fn,
        target_arl,
        {"persistence": PERSISTENCE},
        seed,
        calibration_runs,
        max_samples,
    )
    drift = float(np.mean([detector_drift_rate(score) for score in score_runs]))
    if abs(arl - target_arl) / target_arl > ARL_TOL:
        raise RuntimeError(
            f"{name} restricted-mean calibration failed: {arl} vs {target_arl}"
        )
    if abs(drift) > STATIONARY_DRIFT_TOL:
        raise RuntimeError(f"{name} score drift too high under noise: {drift}")
    return {
        "name": name,
        "params": params,
        "threshold": threshold,
        # Compatibility key: this is the achieved finite-horizon restricted
        # mean, not an uncensored classical ARL estimate.
        "arl": arl,
        "stationary_drift": drift,
        "factory": detector_factory,
    }


def compute_seq_cache(
    signals: List[np.ndarray],
    onsets: List[int],
    detector: str,
    model: Dict[str, object],
) -> List[Dict[str, object]]:
    cache: List[Dict[str, object]] = []
    for sig, onset in zip(signals, onsets):
        if detector == "structural_manifold":
            idx, feats = augmented_features(sig, FEATURE_WINDOW)
            feats_std = (feats - model["mean"]) / model["std"]  # type: ignore[index]
            d_values = mahalanobis_series(feats_std, model["centroid"], model["inv_cov"])  # type: ignore[index]
            seq = sequential_statistic(d_values, float(model["bias"]))
            cache.append({"idx": idx, "seq": seq, "onset": onset, "sig_len": sig.size})
        elif detector == "rms":
            rms = trailing_rms(sig, RMS_WINDOW)
            seq = sequential_statistic(np.square(rms, dtype=np.float64), float(model["bias"]))
            cache.append({"idx": np.arange(sig.size, dtype=np.int64), "seq": seq, "onset": onset, "sig_len": sig.size})
        else:
            factory = model["factory"]  # type: ignore[index]
            if factory is None:
                raise ValueError(f"Missing factory for detector {detector}")
            score = run_streaming_detector(factory(model["params"]), sig)  # type: ignore[index]
            cache.append({"idx": np.arange(sig.size, dtype=np.int64), "seq": score, "onset": onset, "sig_len": sig.size})
    return cache


def detect_from_seq(entry: Dict[str, object], threshold: float) -> int | None:
    """Return the first confirmed alarm on the complete trace.

    Evaluation must see pre-onset alarms.  Searching from ``onset`` would
    discard exactly the observations that must be charged as false positives.
    """

    idx = entry["idx"]  # type: ignore[index]
    seq = entry["seq"]  # type: ignore[index]
    sig_len = int(entry["sig_len"])
    trig = gate_score_series(seq, threshold, PERSISTENCE, sig_len, idx)
    pos = np.flatnonzero(trig)
    return None if pos.size == 0 else int(pos[0])


def first_confirmed_alarm(entry: Dict[str, object], threshold: float) -> int | None:
    """Compatibility name for complete-trace first-alarm accounting."""

    return detect_from_seq(entry, threshold)


def finite_horizon_operating_statistics_for_detector(
    noise_signals: List[np.ndarray],
    detector_name: str,
    model: Dict[str, object],
) -> FiniteHorizonAlarmStatistics:
    cache = compute_seq_cache(noise_signals, [0] * len(noise_signals), detector_name, model)
    first_hits: List[int | None] = []
    horizons: List[int] = []
    for signal, entry in zip(noise_signals, cache):
        hit = first_confirmed_alarm(entry, float(model["threshold"]))
        first_hits.append(hit)
        horizons.append(int(signal.size))
    return summarize_finite_horizon_alarms(first_hits, horizons)


def empirical_arl_for_detector(
    noise_signals: List[np.ndarray],
    detector_name: str,
    model: Dict[str, object],
) -> float:
    """Compatibility alias for the finite-horizon restricted mean.

    This is not an uncensored classical ARL estimator.  New output schemas use
    ``restricted_mean_time_to_alarm`` and carry censoring metadata.
    """

    return finite_horizon_operating_statistics_for_detector(
        noise_signals, detector_name, model
    ).restricted_mean_time_to_alarm


def recalibrate_threshold_on_noise_bank(
    detector_name: str,
    model: Dict[str, object],
    noise_signals: List[np.ndarray],
    target_arl: float,
) -> Dict[str, object]:
    cache = compute_seq_cache(noise_signals, [0] * len(noise_signals), detector_name, model)
    series_runs = [np.asarray(entry["seq"], dtype=np.float64) for entry in cache]
    indices_runs = [np.asarray(entry["idx"], dtype=np.int64) for entry in cache]
    signal_lengths = [int(entry["sig_len"]) for entry in cache]
    calibration = calibrate_threshold_noise(
        series_runs, indices_runs, target_arl, PERSISTENCE, signal_lengths
    )
    threshold, arl = calibration
    updated = dict(model)
    updated["threshold"] = float(threshold)
    # Compatibility key; the full censoring record is stored immediately below.
    updated["arl"] = float(arl)
    updated["threshold_calibration"] = calibration.to_dict()
    return updated


def bootstrap_median_delta_ci(
    left: np.ndarray,
    right: np.ndarray,
    seed: int,
    n_boot: int = 2_000,
) -> Tuple[float, float]:
    valid = np.isfinite(left) & np.isfinite(right)
    if not np.any(valid):
        return math.nan, math.nan
    deltas = right[valid] - left[valid]
    rng = np.random.default_rng(seed)
    medians = np.empty(n_boot, dtype=np.float64)
    for idx in range(n_boot):
        sample_idx = rng.integers(0, deltas.size, size=deltas.size)
        medians[idx] = float(np.median(deltas[sample_idx]))
    lo, hi = np.percentile(medians, [2.5, 97.5])
    return float(lo), float(hi)


def json_scalar(value: float | None) -> float | None:
    if value is None:
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return float(value)


def run_outcome_label(*, miss: bool, false_positive: bool) -> str:
    """Return the mutually exclusive first-alarm outcome label for one run."""

    if miss and false_positive:
        raise ValueError("a run cannot be both missed and false-positive")
    if false_positive:
        return "false_positive"
    if miss:
        return "miss"
    return "valid_detection"


def joint_valid_conditional_delay_deltas(
    structural_delays: np.ndarray,
    comparator_delays: np.ndarray,
) -> np.ndarray:
    """Return delay deltas only where both detectors validly detected.

    False-positive and missed runs are represented by non-finite delays and are
    intentionally excluded. Callers must report the joint-valid count and the
    marginal/paired outcome populations alongside this secondary diagnostic.
    """

    valid = np.isfinite(structural_delays) & np.isfinite(comparator_delays)
    if not np.any(valid):
        return np.array([], dtype=np.float64)
    return comparator_delays[valid] - structural_delays[valid]


def paired_outcome_contingency(
    left_miss: List[bool],
    left_fp: List[bool],
    right_miss: List[bool],
    right_fp: List[bool],
) -> Dict[str, Dict[str, int]]:
    """Count all paired first-alarm outcomes without inventing a utility."""

    lengths = {len(left_miss), len(left_fp), len(right_miss), len(right_fp)}
    if len(lengths) != 1:
        raise ValueError("paired outcome vectors must have equal lengths")
    labels = ("false_positive", "valid_detection", "miss")
    table = {left: {right: 0 for right in labels} for left in labels}
    for lm, lf, rm, rf in zip(left_miss, left_fp, right_miss, right_fp):
        left = run_outcome_label(miss=lm, false_positive=lf)
        right = run_outcome_label(miss=rm, false_positive=rf)
        table[left][right] += 1
    return table


def bootstrap_median_ci_from_deltas(
    deltas: np.ndarray,
    seed: int,
    n_boot: int = 2_000,
) -> Tuple[float, float]:
    if deltas.size == 0:
        return math.nan, math.nan
    rng = np.random.default_rng(seed)
    medians = np.empty(n_boot, dtype=np.float64)
    for idx in range(n_boot):
        sample_idx = rng.integers(0, deltas.size, size=deltas.size)
        medians[idx] = float(np.median(deltas[sample_idx]))
    lo, hi = np.percentile(medians, [2.5, 97.5])
    return float(lo), float(hi)


def compute_local_mean_gap_stats(
    signals: List[np.ndarray],
    onsets: List[int],
    half_window: int = 300,
) -> Tuple[np.ndarray, np.ndarray]:
    local_mean_gaps = np.empty(len(signals), dtype=np.float64)
    baseline_stds = np.empty(len(signals), dtype=np.float64)
    for idx, (signal, onset) in enumerate(zip(signals, onsets)):
        pre_start = max(0, onset - half_window)
        pre_window = signal[pre_start:onset]
        post_end = min(signal.size, onset + half_window)
        post_window = signal[onset:post_end]
        if pre_window.size == 0 or post_window.size == 0:
            local_mean_gaps[idx] = math.nan
            baseline_stds[idx] = math.nan
            continue
        local_mean_gaps[idx] = abs(float(np.mean(post_window) - np.mean(pre_window)))
        baseline_stds[idx] = float(np.std(pre_window) + EPS)
    return local_mean_gaps, baseline_stds


def build_stream(
    rng: np.random.Generator,
    wave: np.ndarray,
    orig_fs: float,
) -> Tuple[np.ndarray, int]:
    length = int(rng.integers(STREAM_LEN_RANGE[0], STREAM_LEN_RANGE[1] + 1))
    background = background_stream(rng, length)

    wave_rs = resample_to_10k(wave, orig_fs)
    wave_rs = wave_rs - wave_rs.mean()  # preserve relative amplitude but zero DC
    # scale waveform to background RMS to avoid amplitude-driven cues
    wave_rms = math.sqrt(float(np.mean(wave_rs**2)) + EPS)
    if wave_rms > 0:
        wave_rs *= BACKGROUND_STD / wave_rms

    max_start = length - wave_rs.size - 1
    if max_start <= 0:
        raise ValueError("Waveform too long for stream length")
    # onset sampling with stress cases
    mode = rng.uniform()
    if mode < 0.2:
        onset = int(rng.integers(int(0.02 * length), int(0.10 * length)))
    elif mode < 0.4:
        onset = int(rng.integers(int(0.90 * length), int(0.98 * length)))
    else:
        onset = int(rng.integers(int(0.10 * length), int(0.90 * length)))
    onset = min(onset, max_start)
    tgt_rms = math.sqrt(float(np.mean(background[onset : onset + wave_rs.size] ** 2)) + EPS)
    wave_rms = math.sqrt(float(np.mean(wave_rs**2)) + EPS)
    if wave_rms > 0:
        wave_rs *= tgt_rms / wave_rms
    background[onset : onset + wave_rs.size] = wave_rs
    return background, onset


# -----------------------------------------------------------------------------#
# Feature extraction (causal, vectorized)
# -----------------------------------------------------------------------------#
def sliding_windows(signal: np.ndarray, window: int) -> Tuple[np.ndarray, np.ndarray]:
    windows = np.lib.stride_tricks.sliding_window_view(signal, window)
    indices = np.arange(window - 1, signal.size, dtype=np.int64)
    return indices, windows


def augmented_features(signal: np.ndarray, window: int) -> Tuple[np.ndarray, np.ndarray]:
    idx, win = sliding_windows(signal, window)
    dx = np.diff(win, axis=1)
    dx_signs = np.sign(dx).astype(np.float64, copy=False)
    dx_signs[dx_signs == 0.0] = 1.0

    changes = dx_signs[:, 1:] != dx_signs[:, :-1]
    run_length = dx_signs.shape[1] / (1.0 + np.sum(changes, axis=1, dtype=np.float64))
    x_prev = dx_signs[:, :-1]
    x_next = dx_signs[:, 1:]
    x_prev_c = x_prev - np.mean(x_prev, axis=1, keepdims=True)
    x_next_c = x_next - np.mean(x_next, axis=1, keepdims=True)
    denom = np.sqrt(np.sum(x_prev_c**2, axis=1) * np.sum(x_next_c**2, axis=1)) + EPS
    sign_autocorr = np.sum(x_prev_c * x_next_c, axis=1) / denom

    zero_cross = np.mean(changes, axis=1, dtype=np.float64)
    monotonicity = np.abs(np.sum(dx, axis=1)) / (np.sum(np.abs(dx), axis=1) + EPS)
    sign_var = np.var(dx_signs, axis=1)

    p_pos = np.mean(dx_signs > 0.0, axis=1, dtype=np.float64)
    p_neg = 1.0 - p_pos
    trend_entropy = -(p_pos * np.log2(p_pos + EPS) + p_neg * np.log2(p_neg + EPS))

    win_rms = np.sqrt(np.mean(win**2, axis=1)) + EPS
    win_energy = np.sum(win**2, axis=1) + EPS

    t = np.arange(window, dtype=np.float64)
    t_c = t - t.mean()
    y_c = win - np.mean(win, axis=1, keepdims=True)
    slope = np.sum(y_c * t_c, axis=1) / (np.sum(t_c**2) + EPS)

    cumsum = np.cumsum(win, axis=1, dtype=np.float64)
    norm_cumsum = np.max(np.abs(cumsum), axis=1) / win_energy

    centered = win - np.mean(win, axis=1, keepdims=True)
    spectrum = np.fft.rfft(centered, axis=1)
    energy = np.abs(spectrum) ** 2
    cutoff = max(1, int(math.floor(LOW_FREQ_RATIO * energy.shape[1])))
    low_freq_ratio = np.sum(energy[:, :cutoff], axis=1) / (np.sum(energy, axis=1) + EPS)

    mean_drift = np.abs(np.mean(win, axis=1)) / win_rms

    features = np.column_stack(
        (
            run_length,
            sign_autocorr,
            zero_cross,
            monotonicity,
            sign_var,
            trend_entropy,
            np.abs(slope) / win_rms,
            norm_cumsum,
            low_freq_ratio,
            mean_drift,
        )
    ).astype(np.float64, copy=False)
    return idx, features


def generate_noise_signals(cal_runs: int, seed_offset: int = 1234) -> List[np.ndarray]:
    """Generate noise-only streams matching length distribution for calibration."""
    signals = []
    for i in range(cal_runs):
        rng = np.random.default_rng(seed_offset + i)
        length = int(rng.integers(STREAM_LEN_RANGE[0], STREAM_LEN_RANGE[1] + 1))
        sig = background_stream(rng, length)
        signals.append(sig)
    return signals


def tune_positive_drift_param(
    base_params: Dict[str, float],
    key: str,
    step: float,
    detector_factory: Callable[[Dict[str, float]], StreamingDetector],
    noise_signals: List[np.ndarray],
) -> Dict[str, float]:
    params = dict(base_params)
    for _ in range(10):
        scores = [run_streaming_detector(detector_factory(params), signal) for signal in noise_signals[:8]]
        drift = float(np.mean([detector_drift_rate(score) for score in scores]))
        if abs(drift) <= STATIONARY_DRIFT_TOL:
            break
        if drift > 0.0:
            params[key] += step
        else:
            params[key] = max(params[key] - step, EPS)
    return params


def build_baseline_models(noise_signals: List[np.ndarray], target_arl: float, include_rms: bool) -> Dict[str, Dict[str, object]]:
    all_noise = np.concatenate(noise_signals)
    mu0, sigma0 = robust_location_scale(all_noise)
    var0 = robust_variance(all_noise, mu0)

    # Residual statistics for variance-sensitive baselines.
    ewma_mean = mu0
    hp_energy = []
    ewma_var = var0
    ewma_var_series = []
    for sample in all_noise:
        ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
        residual = sample - ewma_mean
        hp_energy.append(residual * residual)
        ewma_var = (1.0 - EWMA_ALPHA) * ewma_var + EWMA_ALPHA * (residual * residual)
        ewma_var_series.append(ewma_var)
    hp_energy_arr = np.asarray(hp_energy, dtype=np.float64)
    ewma_var_arr = np.asarray(ewma_var_series, dtype=np.float64)
    var_scale = 1.4826 * np.median(np.abs(ewma_var_arr - np.median(ewma_var_arr))) + EPS

    models: Dict[str, Dict[str, object]] = {}

    ph_params = tune_positive_drift_param(
        {"mu0": mu0, "delta": 0.25 * sigma0},
        "delta",
        0.1 * sigma0,
        lambda p: PageHinkleyDetector(p["mu0"], p["delta"]),
        noise_signals,
    )
    models["page_hinkley"] = build_scalar_detector_model(
        "page_hinkley",
        ph_params,
        lambda p: PageHinkleyDetector(p["mu0"], p["delta"]),
        target_arl,
        GLOBAL_SEED + 101,
    )

    cusum_mean_params = tune_positive_drift_param(
        {"mu0": mu0, "k": 0.5 * sigma0},
        "k",
        0.1 * sigma0,
        lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
        noise_signals,
    )
    models["cusum_mean"] = build_scalar_detector_model(
        "cusum_mean",
        cusum_mean_params,
        lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
        target_arl,
        GLOBAL_SEED + 102,
    )

    var_cusum_params = tune_positive_drift_param(
        {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp_energy_arr, 60.0))},
        "k",
        float(np.median(np.abs(hp_energy_arr - np.median(hp_energy_arr))) + EPS),
        lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
        noise_signals,
    )
    models["cusum_variance"] = build_scalar_detector_model(
        "cusum_variance",
        var_cusum_params,
        lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
        target_arl,
        GLOBAL_SEED + 103,
    )

    ewma_params = {
        "mu0": mu0,
        "sigma0": sigma0,
        "var0": var0,
        "alpha": EWMA_ALPHA,
        "var_scale": var_scale,
    }
    models["ewma_mean_var"] = build_scalar_detector_model(
        "ewma_mean_var",
        ewma_params,
        lambda p: EWMAMeanVarianceDetector(p["mu0"], p["sigma0"], p["var0"], p["alpha"], p["var_scale"]),
        target_arl,
        GLOBAL_SEED + 104,
    )

    glr_params = {"mu0": mu0, "sigma0": sigma0, "window": float(GLR_WINDOW)}
    models["glr_mean"] = build_scalar_detector_model(
        "glr_mean",
        glr_params,
        lambda p: GLRMeanShiftDetector(p["mu0"], p["sigma0"], int(p["window"])),
        target_arl,
        GLOBAL_SEED + 105,
    )

    if include_rms:
        rms_model = build_rms_model(noise_signals, target_arl)
        models["rms"] = {
            "name": "rms",
            "params": {"bias": float(rms_model["bias"]), "window": float(RMS_WINDOW)},
            "threshold": float(rms_model["threshold"]),
            "arl": float(rms_model["arl"]),
            "factory": None,
            "stationary_drift": 0.0,
            "bias": float(rms_model["bias"]),
        }

    return models


def build_structural_cusum_models(noise_signals: List[np.ndarray], target_arl: float) -> Dict[str, Dict[str, object]]:
    all_noise = np.concatenate(noise_signals)
    mu0, sigma0 = robust_location_scale(all_noise)

    ewma_mean = mu0
    hp_energy = []
    for sample in all_noise:
        ewma_mean = (1.0 - HP_ALPHA) * ewma_mean + HP_ALPHA * sample
        residual = sample - ewma_mean
        hp_energy.append(residual * residual)
    hp_energy_arr = np.asarray(hp_energy, dtype=np.float64)

    cusum_mean_params = tune_positive_drift_param(
        {"mu0": mu0, "k": 0.5 * sigma0},
        "k",
        0.1 * sigma0,
        lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
        noise_signals,
    )
    cusum_variance_params = tune_positive_drift_param(
        {"mu0": mu0, "alpha_hp": HP_ALPHA, "k": float(np.percentile(hp_energy_arr, 60.0))},
        "k",
        float(np.median(np.abs(hp_energy_arr - np.median(hp_energy_arr))) + EPS),
        lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
        noise_signals,
    )

    return {
        "cusum_mean": build_scalar_detector_model(
            "cusum_mean",
            cusum_mean_params,
            lambda p: TwoSidedCUSUMDetector(p["mu0"], p["k"]),
            target_arl,
            GLOBAL_SEED + 302,
            noise_generator_fn=structural_noise_stream_generator,
            max_samples=STRUCTURAL_STREAM_LEN_RANGE[1],
            calibration_runs=STRUCTURAL_CALIBRATION_RUNS,
        ),
        "cusum_variance": build_scalar_detector_model(
            "cusum_variance",
            cusum_variance_params,
            lambda p: VarianceCUSUMDetector(p["mu0"], p["alpha_hp"], p["k"]),
            target_arl,
            GLOBAL_SEED + 303,
            noise_generator_fn=structural_noise_stream_generator,
            max_samples=STRUCTURAL_STREAM_LEN_RANGE[1],
            calibration_runs=STRUCTURAL_CALIBRATION_RUNS,
        ),
    }


def scenario_preservation_flags(
    pre_signal: np.ndarray,
    post_signal: np.ndarray,
    onset: int,
) -> Dict[str, object]:
    span = min(max(10 * FEATURE_WINDOW, 2_000), onset, post_signal.size - onset)
    if span <= 0:
        return {
            "mean_preserved": False,
            "variance_preserved": False,
            "rms_preserved": False,
            "delta_mean": math.nan,
            "delta_var_rel": math.nan,
            "delta_rms_rel": math.nan,
        }
    pre_seg = pre_signal[onset : onset + span]
    post_seg = post_signal[onset : onset + span]
    pre_mean = float(np.mean(pre_seg))
    post_mean = float(np.mean(post_seg))
    pre_var = float(np.var(pre_seg) + EPS)
    post_var = float(np.var(post_seg) + EPS)
    pre_rms = math.sqrt(float(np.mean(pre_seg**2)) + EPS)
    post_rms = math.sqrt(float(np.mean(post_seg**2)) + EPS)
    delta_mean = abs(post_mean - pre_mean)
    delta_var_rel = abs(post_var - pre_var) / pre_var
    delta_rms_rel = abs(post_rms - pre_rms) / pre_rms
    return {
        "mean_preserved": delta_mean <= MEAN_PRESERVE_TOL,
        "variance_preserved": delta_var_rel <= VAR_PRESERVE_TOL,
        "rms_preserved": delta_rms_rel <= RMS_TOL,
        "delta_mean": delta_mean,
        "delta_var_rel": delta_var_rel,
        "delta_rms_rel": delta_rms_rel,
    }


def perturb_runlength_structure(
    rng: np.random.Generator, signal: np.ndarray, onset: int
) -> Tuple[Dict[str, object], np.ndarray]:
    pre_signal = signal.copy()
    seg_len = min(int(rng.integers(10_000, 20_000)), signal.size - onset)
    seg = signal[onset : onset + seg_len].copy()
    block = 64
    out = seg.copy()
    for start in range(0, seg_len, block):
        block_view = seg[start : start + block]
        pos = np.sort(block_view[block_view >= 0.0])
        neg = np.sort(block_view[block_view < 0.0])
        if (start // block) % 2 == 0:
            arranged = np.concatenate((pos, neg))
        else:
            arranged = np.concatenate((neg, pos))
        out[start : start + block_view.size] = arranged[: block_view.size]
    signal[onset : onset + seg_len] = out
    _, feat_before = augmented_features(pre_signal[onset : onset + seg_len + FEATURE_WINDOW - 1], FEATURE_WINDOW)
    _, feat_after = augmented_features(signal[onset : onset + seg_len + FEATURE_WINDOW - 1], FEATURE_WINDOW)
    diag = scenario_preservation_flags(pre_signal, signal, onset)
    diag["feature_delta"] = np.mean(np.abs(feat_after - feat_before), axis=0).tolist()
    return diag, pre_signal


def sanity_validation(
    manifold_model: Dict[str, object],
    baseline_models: Dict[str, Dict[str, object]],
) -> None:
    """Run dataset-independent deterministic checks before heavy Monte Carlo."""
    dummy_scores = np.array([0.0, 1.0, 2.0, 2.0, 0.0], dtype=np.float64)
    dummy_gate = gate_score_series(dummy_scores, 1.5, PERSISTENCE, dummy_scores.size)
    direct_gate = persistent_mask(dummy_scores > 1.5, PERSISTENCE)
    assert np.array_equal(dummy_gate, direct_gate), "Persistence gate mismatch"

    # Noise-only: expect no detection
    rng = np.random.default_rng(999)
    noise_sig = background_stream(rng, 2_000)
    signals = [noise_sig]
    onsets = [1_500]  # far end of this short stream
    manifold_res = evaluate_detector(signals, onsets, "structural_manifold", manifold_model)
    assert manifold_res[2] == 1 and manifold_res[3] == 0, (
        "manifold detector should have no authority-bearing alarm on clean noise"
    )
    for name, model in baseline_models.items():
        res = evaluate_detector(signals, onsets, name, model)
        assert abs(float(model.get("stationary_drift", 0.0))) <= max(STATIONARY_DRIFT_TOL, 1e-2), f"{name} drifted under noise"
        assert res[2] == 1 and res[3] == 0, (
            f"{name} should have no authority-bearing alarm on clean noise"
        )

    # Structured scenario: the manifold detector should respond.
    rng2 = np.random.default_rng(1001)
    synthetic_wave = np.sin(np.linspace(0.0, 8.0 * math.pi, 512))
    stream, base_onset = build_stream(rng2, synthetic_wave, FS_TARGET)
    onset = min(base_onset + 4 * FEATURE_WINDOW, stream.size - 1_000)
    perturb_phase_scramble_window_rms_preserved(rng2, stream, onset)
    signals = [stream]
    onsets = [onset]
    manifold_res2 = evaluate_detector(signals, onsets, "structural_manifold", manifold_model)
    assert (
        manifold_res2[2] == 0
        and manifold_res2[3] == 0
        and np.isfinite(manifold_res2[0][0])
    ), "manifold detector failed to produce a valid post-onset detection"
# -----------------------------------------------------------------------------#
# Calibration
# -----------------------------------------------------------------------------#
def calibrate_threshold_noise(
    series_runs: List[np.ndarray],
    indices_runs: List[np.ndarray],
    target_arl: float,
    persistence: int,
    signal_lengths: List[int] | None = None,
) -> ThresholdCalibrationResult:
    """Match a finite-horizon restricted time-to-alarm target.

    No-alarm traces are explicitly right-censored at their individual
    horizons.  The returned object retains all censoring observations.  The
    historical two-value unpacking contract remains available through
    :class:`ThresholdCalibrationResult`.
    """

    if not series_runs or len(series_runs) != len(indices_runs):
        raise ValueError("score and index run lists must be non-empty and aligned")
    if not math.isfinite(target_arl) or target_arl <= 0.0:
        raise ValueError("target finite-horizon operating value must be positive and finite")
    if persistence <= 0:
        raise ValueError("persistence must be positive")
    if signal_lengths is None:
        signal_lengths = [int(idx[-1]) + 1 for idx in indices_runs]
    if len(signal_lengths) != len(series_runs):
        raise ValueError("signal lengths must align with score runs")

    def observations(threshold: float) -> FiniteHorizonAlarmStatistics:
        first_alarms: List[int | None] = []
        horizons: List[int] = []
        for series, idx, sig_len in zip(series_runs, indices_runs, signal_lengths):
            if series.ndim != 1 or idx.ndim != 1 or series.size != idx.size:
                raise ValueError("each score run and index run must be aligned 1-D arrays")
            if sig_len <= 0 or idx.size == 0:
                raise ValueError("calibration runs must have a positive observable horizon")
            trig = np.zeros(int(sig_len), dtype=bool)
            trig[idx] = series > threshold
            confirmed = persistent_mask(trig, persistence)
            positions = np.flatnonzero(confirmed)
            first_alarms.append(None if positions.size == 0 else int(positions[0]))
            horizons.append(int(sig_len))
        return summarize_finite_horizon_alarms(first_alarms, horizons)

    low = min(float(np.min(s)) for s in series_runs)
    high = max(float(np.max(s)) for s in series_runs) + 1.0
    best_h = high
    best_statistics = observations(high)

    for _ in range(ARL_BINSEARCH_ITERS):
        mid = 0.5 * (low + high)
        statistics = observations(mid)
        if statistics.restricted_mean_time_to_alarm >= target_arl:
            best_h = mid
            best_statistics = statistics
            high = mid
        else:
            low = mid

    return ThresholdCalibrationResult(
        threshold=float(best_h),
        target_restricted_mean_time_to_alarm=float(target_arl),
        achieved_statistics=best_statistics,
        iterations=ARL_BINSEARCH_ITERS,
    )


def build_structural_manifold_model(noise_signals: List[np.ndarray], target_arl: float) -> Dict[str, object]:
    idx_runs = []
    feat_runs = []
    sig_lengths: List[int] = []
    for sig in noise_signals:
        idx, feats = augmented_features(sig, FEATURE_WINDOW)
        idx_runs.append(idx)
        feat_runs.append(feats)
        sig_lengths.append(sig.size)

    all_feats = np.vstack(feat_runs)
    mean = np.mean(all_feats, axis=0)
    std = np.std(all_feats, axis=0)
    std_safe = np.where(std < 1e-6, 1.0, std)
    feats_std = [(f - mean) / std_safe for f in feat_runs]

    centroid = np.mean(np.vstack(feats_std), axis=0)
    centered = np.vstack([f - centroid for f in feats_std])
    cov = np.cov(centered, rowvar=False) + REG_COV * np.eye(centered.shape[1], dtype=np.float64)
    inv_cov = np.linalg.pinv(cov)

    dist_runs = [mahalanobis_series(f, centroid, inv_cov) for f in feats_std]
    dist_all = np.concatenate(dist_runs)
    dist_median = float(np.median(dist_all))
    mad = float(np.median(np.abs(dist_all - dist_median)) + EPS)
    bias = dist_median

    # Zero-drift validation
    def drift_for_bias(b: float) -> float:
        seq = sequential_statistic(dist_all, b)
        return float(np.mean(np.diff(seq))) if seq.size > 1 else 0.0

    drift_rate = drift_for_bias(bias)
    if abs(drift_rate) >= 1e-3:
        # trimmed median 40-60 percentile
        lo = np.percentile(dist_all, 40.0)
        hi = np.percentile(dist_all, 60.0)
        trimmed = dist_all[(dist_all >= lo) & (dist_all <= hi)]
        if trimmed.size:
            bias = float(np.median(trimmed))
            drift_rate = drift_for_bias(bias)

    # final robust nudging using MAD, no means
    steps = 0
    while abs(drift_rate) >= 1e-3 and steps < 10:
        bias += math.copysign(mad, drift_rate)
        drift_rate = drift_for_bias(bias)
        steps += 1

    iqr = float(np.percentile(dist_all, 75.0) - np.percentile(dist_all, 25.0))

    if abs(drift_rate) > 0.01:
        raise RuntimeError(f"Sequential drift too high after centering: {drift_rate}")

    seq_runs = [sequential_statistic(d, bias) for d in dist_runs]
    calibration = calibrate_threshold_noise(
        seq_runs, idx_runs, target_arl, PERSISTENCE, sig_lengths
    )
    h, arl = calibration

    print(
        f"[MANIFOLD CAL] distance_median={dist_median:.4f} "
        f"IQR={iqr:.4f} MAD={mad:.4f} "
        f"seq_drift_rate={drift_rate:.6f} "
        f"restricted_mean_time_to_alarm={arl:.1f}"
    )

    return {
        "mean": mean,
        "std": std_safe,
        "centroid": centroid,
        "inv_cov": inv_cov,
        "bias": bias,
        "threshold": h,
        "arl": arl,
        "threshold_calibration": calibration.to_dict(),
    }


def build_rms_model(noise_signals: List[np.ndarray], target_arl: float) -> Dict[str, float]:
    rms_sq_runs = []
    idx_runs = []
    sig_lengths: List[int] = []
    for sig in noise_signals:
        rms = trailing_rms(sig, RMS_WINDOW)
        rms_sq = np.square(rms, dtype=np.float64)
        rms_sq_runs.append(rms_sq)
        idx_runs.append(np.arange(sig.size, dtype=np.int64))
        sig_lengths.append(sig.size)
    rms_sq_all = np.concatenate(rms_sq_runs)
    bias = float(np.percentile(rms_sq_all, 60.0))

    def drift_for_bias(b: float) -> float:
        seq = sequential_statistic(rms_sq_all, b)
        return float(np.mean(np.diff(seq))) if seq.size > 1 else 0.0

    drift_rate = drift_for_bias(bias)
    if abs(drift_rate) >= 1e-3:
        lo = np.percentile(rms_sq_all, 40.0)
        hi = np.percentile(rms_sq_all, 60.0)
        trimmed = rms_sq_all[(rms_sq_all >= lo) & (rms_sq_all <= hi)]
        if trimmed.size:
            bias = float(np.median(trimmed))
            drift_rate = drift_for_bias(bias)
    steps = 0
    mad = float(np.median(np.abs(rms_sq_all - bias)) + EPS)
    while abs(drift_rate) >= 1e-3 and steps < 10:
        bias += math.copysign(mad, drift_rate)
        drift_rate = drift_for_bias(bias)
        steps += 1
    if drift_rate > 1e-4:
        bias += mad
        drift_rate = drift_for_bias(bias)

    seq_runs = [sequential_statistic(r, bias) for r in rms_sq_runs]
    calibration = calibrate_threshold_noise(
        seq_runs, idx_runs, target_arl, PERSISTENCE, sig_lengths
    )
    h, arl = calibration
    print(
        f"[RMS CAL] rms_median={bias:.6f} "
        f"seq_drift_rate={drift_rate:.6f} "
        f"restricted_mean_time_to_alarm={arl:.1f}"
    )
    return {
        "bias": bias,
        "threshold": h,
        "arl": arl,
        "threshold_calibration": calibration.to_dict(),
    }


# -----------------------------------------------------------------------------#
# Evaluation
# -----------------------------------------------------------------------------#
def evaluate_detector(
    signals: List[np.ndarray],
    onsets: List[int],
    detector: str,
    model: Dict[str, object],
) -> Tuple[List[float], List[float], int, int, List[bool], List[bool], List[int | None]]:
    cache = compute_seq_cache(signals, onsets, detector, model)
    strict_delays: List[float] = []
    eff_delays: List[float] = []
    miss = 0
    fp = 0
    miss_flags: List[bool] = []
    fp_flags: List[bool] = []
    detect_times: List[int | None] = []
    for sig, onset, entry in zip(signals, onsets, cache):
        detect = detect_from_seq(entry, float(model["threshold"]))

        if detect is not None and detect < onset:
            fp += 1
            fp_flags.append(True)
            miss_flags.append(False)
            strict_delays.append(math.nan)
            eff_delays.append(math.nan)
            detect_times.append(detect)
            continue

        if detect is None:
            miss += 1
            miss_flags.append(True)
            fp_flags.append(False)
            strict_delays.append(math.nan)
            eff_delays.append(math.nan)
            detect_times.append(None)
            continue

        miss_flags.append(False)
        fp_flags.append(False)
        detect_times.append(detect)
        # strict delay
        strict_delays.append(float(detect - onset))
        # effective onset
        baseline_mu = trailing_median(sig, 7)
        t_eff = effective_onset(sig, baseline_mu, onset, K_EFFECTIVE)
        if t_eff is None:
            eff_delays.append(float(detect - onset))
        else:
            eff_delays.append(float(detect - t_eff))

    return strict_delays, eff_delays, miss, fp, miss_flags, fp_flags, detect_times


def evaluate_detector_strict_only(
    signals: List[np.ndarray],
    onsets: List[int],
    detector: str,
    model: Dict[str, object],
) -> Tuple[List[float], int, int, List[bool], List[bool], List[int | None]]:
    cache = compute_seq_cache(signals, onsets, detector, model)
    strict_delays: List[float] = []
    miss = 0
    fp = 0
    miss_flags: List[bool] = []
    fp_flags: List[bool] = []
    detect_times: List[int | None] = []
    for onset, entry in zip(onsets, cache):
        detect = detect_from_seq(entry, float(model["threshold"]))
        if detect is not None and detect < onset:
            fp += 1
            fp_flags.append(True)
            miss_flags.append(False)
            strict_delays.append(math.nan)
            detect_times.append(detect)
            continue
        if detect is None:
            miss += 1
            miss_flags.append(True)
            fp_flags.append(False)
            strict_delays.append(math.nan)
            detect_times.append(None)
            continue
        miss_flags.append(False)
        fp_flags.append(False)
        strict_delays.append(float(detect - onset))
        detect_times.append(detect)
    return strict_delays, miss, fp, miss_flags, fp_flags, detect_times


def roc_sweep(
    cache: List[Dict[str, object]],
    base_threshold: float,
    multipliers: Iterable[float],
) -> List[Dict[str, float]]:
    roc_entries: List[Dict[str, float]] = []
    for mult in multipliers:
        thr = base_threshold * mult
        detections = 0
        fps = 0
        for entry in cache:
            onset = int(entry["onset"])
            det = detect_from_seq(entry, thr)
            if det is None:
                continue
            if det < onset:
                fps += 1
            else:
                detections += 1
        runs = len(cache)
        roc_entries.append(
            {
                "multiplier": float(mult),
                "detection_rate": detections / runs if runs else 0.0,
                "fp_rate": fps / runs if runs else 0.0,
            }
        )
    return roc_entries


def summarize(
    delays: List[float],
    eff_delays: List[float],
    miss: int,
    fp: int,
    runs: int,
    achieved_restricted_mean_time_to_alarm: float,
) -> DetectorMetrics:
    d = np.array(delays, dtype=np.float64)
    e = np.array(eff_delays, dtype=np.float64)
    miss_rate = 100.0 * miss / max(runs, 1)
    fp_rate = 100.0 * fp / max(runs, 1)
    finite_d = d[np.isfinite(d)]
    finite_e = e[np.isfinite(e)]
    mean_delay = float(np.nanmean(finite_d)) if finite_d.size else math.nan
    median_delay = float(np.nanmedian(finite_d)) if finite_d.size else math.nan
    p10 = float(np.nanpercentile(finite_d, 10)) if finite_d.size else math.nan
    p90 = float(np.nanpercentile(finite_d, 90)) if finite_d.size else math.nan
    return DetectorMetrics(
        conditional_valid_detection_delay_mean_samples=mean_delay,
        conditional_valid_detection_delay_median_samples=median_delay,
        conditional_valid_detection_delay_p10_samples=p10,
        conditional_valid_detection_delay_p90_samples=p90,
        detection_rate_pct=100.0 * finite_d.size / max(runs, 1),
        miss_rate=miss_rate,
        fp_rate=fp_rate,
        achieved_restricted_mean_time_to_alarm=(
            achieved_restricted_mean_time_to_alarm
        ),
    )


def detector_metric_payload(
    delays: List[float],
    eff_delays: List[float],
    miss: int,
    fp: int,
    runs: int,
    arl: float,
) -> Dict[str, float]:
    """Build metrics; ``arl`` is a compatibility parameter name only.

    The value is emitted under the technically explicit finite-horizon name.
    """

    achieved_restricted_mean_time_to_alarm = arl
    strict = np.asarray(delays, dtype=np.float64)
    effective = np.asarray(eff_delays, dtype=np.float64)
    strict_valid = strict[np.isfinite(strict)]
    effective_valid = effective[np.isfinite(effective)]
    detection_rate = 100.0 * strict_valid.size / max(runs, 1)
    return {
        "conditional_valid_detection_delay_mean_samples": float(np.nanmean(strict_valid)) if strict_valid.size else math.nan,
        "conditional_valid_detection_delay_median_samples": float(np.nanmedian(strict_valid)) if strict_valid.size else math.nan,
        "conditional_valid_effective_delay_mean_samples": float(np.nanmean(effective_valid)) if effective_valid.size else math.nan,
        "conditional_valid_effective_delay_median_samples": float(np.nanmedian(effective_valid)) if effective_valid.size else math.nan,
        "valid_detection_count": int(strict_valid.size),
        "false_positive_count": int(fp),
        "miss_count": int(miss),
        "miss_rate_per_run": 100.0 * miss / max(runs, 1),
        "fp_rate_per_run": 100.0 * fp / max(runs, 1),
        "valid_detection_rate_per_run": detection_rate,
        "conditional_valid_detection_delay_p10_samples": float(np.nanpercentile(strict_valid, 10)) if strict_valid.size else math.nan,
        "conditional_valid_detection_delay_p50_samples": float(np.nanpercentile(strict_valid, 50)) if strict_valid.size else math.nan,
        "conditional_valid_detection_delay_p90_samples": float(np.nanpercentile(strict_valid, 90)) if strict_valid.size else math.nan,
        "achieved_restricted_mean_time_to_alarm": (
            achieved_restricted_mean_time_to_alarm
        ),
    }


def run_structural_covariance_shift_benchmark(args: argparse.Namespace) -> None:
    runs = max(int(args.runs), STRUCTURAL_MIN_RUNS)
    target_arl = float(args.target_arl)
    output_path = Path(args.output_json)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    noise_signals = []
    for idx in range(STRUCTURAL_CALIBRATION_RUNS):
        rng = np.random.default_rng(GLOBAL_SEED + 50_000 + idx)
        length = int(rng.integers(STRUCTURAL_STREAM_LEN_RANGE[0], STRUCTURAL_STREAM_LEN_RANGE[1] + 1))
        noise_signals.append(structural_noise_stream(rng, length))

    manifold_model = build_structural_manifold_model(noise_signals, target_arl)
    cusum_models = build_structural_cusum_models(noise_signals, target_arl)

    detector_models: Dict[str, Dict[str, object]] = {
        "structural_manifold": manifold_model,
        "cusum_mean": cusum_models["cusum_mean"],
        "cusum_variance": cusum_models["cusum_variance"],
    }

    refine_noise_signals = []
    for idx in range(STRUCTURAL_EMPIRICAL_ARL_RUNS):
        rng = np.random.default_rng(GLOBAL_SEED + 55_000 + idx)
        length = int(rng.integers(STRUCTURAL_STREAM_LEN_RANGE[0], STRUCTURAL_STREAM_LEN_RANGE[1] + 1))
        refine_noise_signals.append(structural_noise_stream(rng, length))
    detector_models = {
        name: recalibrate_threshold_on_noise_bank(name, model, refine_noise_signals, target_arl)
        for name, model in detector_models.items()
    }

    signals: List[np.ndarray] = []
    onsets: List[int] = []
    seeds: List[int] = []
    diagnostics: List[Dict[str, float]] = []
    for run_idx in range(runs):
        seed = GLOBAL_SEED + 100_000 + run_idx
        rng = np.random.default_rng(seed)
        signal, onset, diag = build_structural_covariance_shift_run(rng)
        signals.append(signal)
        onsets.append(onset)
        seeds.append(seed)
        diagnostics.append(diag)

    local_mean_gaps, baseline_stds = compute_local_mean_gap_stats(signals, onsets)
    median_local_mean_gap = float(np.nanmedian(local_mean_gaps))
    max_local_mean_gap = float(np.nanmax(local_mean_gaps))
    median_baseline_std = float(np.nanmedian(baseline_stds))
    local_mean_shift_present = bool(median_local_mean_gap > 0.001 * median_baseline_std)

    rms_gaps = np.asarray([diag["rms_gap_rel"] for diag in diagnostics], dtype=np.float64)
    mean_gaps = np.asarray([diag["mean_gap_abs"] for diag in diagnostics], dtype=np.float64)
    var_gaps = np.asarray([diag["var_gap_rel"] for diag in diagnostics], dtype=np.float64)
    max_rms_gap = float(np.max(rms_gaps))
    median_rms_gap = float(np.median(rms_gaps))

    # A third, common noise bank reports achieved operating risk.  It is not
    # reused for fitting model parameters or refining thresholds.
    operating_noise_signals = []
    for idx in range(STRUCTURAL_EMPIRICAL_ARL_RUNS):
        rng = np.random.default_rng(GLOBAL_SEED + 60_000 + idx)
        length = int(rng.integers(STRUCTURAL_STREAM_LEN_RANGE[0], STRUCTURAL_STREAM_LEN_RANGE[1] + 1))
        operating_noise_signals.append(structural_noise_stream(rng, length))

    achieved_operating_statistics = {
        name: finite_horizon_operating_statistics_for_detector(
            operating_noise_signals, name, model
        )
        for name, model in detector_models.items()
    }

    eval_results = {
        name: evaluate_detector_strict_only(signals, onsets, name, model)
        for name, model in detector_models.items()
    }

    summary: Dict[str, Dict[str, object]] = {}
    raw_delays: Dict[str, List[float | None]] = {}
    raw_effective_delays: Dict[str, List[float | None]] = {}
    raw_detect_times: Dict[str, List[int | None]] = {}
    raw_outcomes: Dict[str, List[str]] = {}
    invalid = False

    arl_values = [
        item.restricted_mean_time_to_alarm
        for item in achieved_operating_statistics.values()
    ]
    if max(arl_values) - min(arl_values) > 0.10 * target_arl:
        invalid = True
    if any(abs(value - target_arl) > 0.10 * target_arl for value in arl_values):
        invalid = True
    if max_rms_gap > STRUCTURAL_RMS_ABORT_REL:
        invalid = True

    miss_rates_pct: Dict[str, float] = {}
    for name, result in eval_results.items():
        strict_delays, miss, fp, miss_flags, fp_flags, detect_times = result
        strict_arr = np.asarray(strict_delays, dtype=np.float64)
        valid = strict_arr[np.isfinite(strict_arr)]
        miss_rate = 100.0 * miss / runs
        miss_rates_pct[name] = miss_rate
        summary[name] = {
            "conditional_valid_detection_delay_median_samples": float(np.nanmedian(valid)) if valid.size else math.nan,
            "conditional_valid_detection_delay_p10_samples": float(np.nanpercentile(valid, 10)) if valid.size else math.nan,
            "conditional_valid_detection_delay_p90_samples": float(np.nanpercentile(valid, 90)) if valid.size else math.nan,
            "conditional_valid_effective_delay_median_samples": None,
            "valid_detection_count": int(valid.size),
            "valid_detection_rate_pct": 100.0 * valid.size / runs,
            "miss_count": int(miss),
            "miss_rate": miss_rate,
            "false_positive_count": int(fp),
            "false_alarm_rate": 100.0 * fp / runs,
            "achieved_finite_horizon_operating_statistics": (
                achieved_operating_statistics[name].to_dict()
            ),
            "achieved_operating_target_deviation_samples": (
                achieved_operating_statistics[
                    name
                ].restricted_mean_time_to_alarm
                - target_arl
            ),
            "raw_miss_flags": miss_flags,
            "raw_fp_flags": fp_flags,
        }
        raw_delays[name] = [float(x) if np.isfinite(x) else None for x in strict_arr]
        raw_effective_delays[name] = [None] * runs
        raw_detect_times[name] = detect_times
        raw_outcomes[name] = [
            run_outcome_label(miss=miss_flag, false_positive=fp_flag)
            for miss_flag, fp_flag in zip(miss_flags, fp_flags)
        ]

    if miss_rates_pct.get("structural_manifold", 100.0) >= STRUCTURAL_MISS_FAIL_PCT:
        invalid = True

    manifold_delays = np.asarray(raw_delays["structural_manifold"], dtype=np.float64)
    cusum_mean_delays = np.asarray(raw_delays["cusum_mean"], dtype=np.float64)
    cusum_var_delays = np.asarray(raw_delays["cusum_variance"], dtype=np.float64)

    pairwise_deltas_mean = joint_valid_conditional_delay_deltas(manifold_delays, cusum_mean_delays)
    pairwise_deltas_var = joint_valid_conditional_delay_deltas(manifold_delays, cusum_var_delays)
    delta_mean = float(np.median(pairwise_deltas_mean)) if pairwise_deltas_mean.size else math.nan
    delta_var = float(np.median(pairwise_deltas_var)) if pairwise_deltas_var.size else math.nan
    ci_mean = bootstrap_median_ci_from_deltas(pairwise_deltas_mean, GLOBAL_SEED + 71_001)
    ci_var = bootstrap_median_ci_from_deltas(pairwise_deltas_var, GLOBAL_SEED + 71_002)

    valid_mean = np.isfinite(manifold_delays) & np.isfinite(cusum_mean_delays)
    valid_var = np.isfinite(manifold_delays) & np.isfinite(cusum_var_delays)
    earlier_rate_mean = float(np.mean(manifold_delays[valid_mean] < cusum_mean_delays[valid_mean])) if np.any(valid_mean) else math.nan
    earlier_rate_var = float(np.mean(manifold_delays[valid_var] < cusum_var_delays[valid_var])) if np.any(valid_var) else math.nan

    cusum_mean_median = float(summary["cusum_mean"]["conditional_valid_detection_delay_median_samples"])
    cusum_var_median = float(summary["cusum_variance"]["conditional_valid_detection_delay_median_samples"])
    manifold_median = float(summary["structural_manifold"]["conditional_valid_detection_delay_median_samples"])
    rel_improve_mean = (
        100.0 * delta_mean / cusum_mean_median
        if np.isfinite(delta_mean) and np.isfinite(cusum_mean_median) and abs(cusum_mean_median) > EPS
        else math.nan
    )
    rel_improve_var = (
        100.0 * delta_var / cusum_var_median
        if np.isfinite(delta_var) and np.isfinite(cusum_var_median) and abs(cusum_var_median) > EPS
        else math.nan
    )

    mean_contingency = paired_outcome_contingency(
        eval_results["structural_manifold"][3],
        eval_results["structural_manifold"][4],
        eval_results["cusum_mean"][3],
        eval_results["cusum_mean"][4],
    )
    var_contingency = paired_outcome_contingency(
        eval_results["structural_manifold"][3],
        eval_results["structural_manifold"][4],
        eval_results["cusum_variance"][3],
        eval_results["cusum_variance"][4],
    )

    structural_bank_hashes = {
        "parameter_calibration": signal_bank_hash(noise_signals),
        "threshold_refinement": signal_bank_hash(refine_noise_signals),
        "operating_risk_holdout": signal_bank_hash(operating_noise_signals),
        "disturbed_evaluation": signal_bank_hash(signals),
    }
    structural_detector_hashes = {
        name: detector_configuration_hash(name, model)
        for name, model in detector_models.items()
    }
    structural_frozen_configuration = {
        "scenario": "structural_covariance_shift",
        "runs": runs,
        "target_restricted_mean_time_to_alarm": target_arl,
        "persistence": PERSISTENCE,
        "stream_len_range": STRUCTURAL_STREAM_LEN_RANGE,
        "seed_ranges": {
            "parameter_calibration": [
                GLOBAL_SEED + 50_000,
                GLOBAL_SEED + 50_000 + STRUCTURAL_CALIBRATION_RUNS - 1,
            ],
            "threshold_refinement": [
                GLOBAL_SEED + 55_000,
                GLOBAL_SEED + 55_000 + STRUCTURAL_EMPIRICAL_ARL_RUNS - 1,
            ],
            "operating_risk_holdout": [
                GLOBAL_SEED + 60_000,
                GLOBAL_SEED + 60_000 + STRUCTURAL_EMPIRICAL_ARL_RUNS - 1,
            ],
            "disturbed_evaluation": [
                GLOBAL_SEED + 100_000,
                GLOBAL_SEED + 100_000 + runs - 1,
            ],
        },
        "detector_configuration_hashes": structural_detector_hashes,
    }

    result_payload = {
        "schema_version": 3,
        "result_classification": "synthetic_benchmark_not_universal_validation",
        "scenario": "structural_covariance_shift",
        "seed": GLOBAL_SEED,
        "runs": runs,
        "target_restricted_mean_time_to_alarm": target_arl,
        "persistence": PERSISTENCE,
        "stream_len_range": STRUCTURAL_STREAM_LEN_RANGE,
        "configuration_hash": config_hash(structural_frozen_configuration),
        "frozen_configuration": structural_frozen_configuration,
        "detector_key_migration": {
            "canonical": "structural_manifold",
            "legacy_historical_only": "dmreda",
        },
        "provenance": {
            "runtime": runtime_manifest(),
            "bank_hashes": structural_bank_hashes,
            "banks_are_role_disjoint_by_seed_and_content": len(
                set(structural_bank_hashes.values())
            ) == len(structural_bank_hashes),
        },
        "detectors": {
            "structural_manifold": {
                "threshold": float(detector_models["structural_manifold"]["threshold"]),
                "bias": float(detector_models["structural_manifold"]["bias"]),
                "configuration_hash": structural_detector_hashes[
                    "structural_manifold"
                ],
                "event_contract": detector_event_contract("structural_manifold"),
                "summary": summary["structural_manifold"],
            },
            "cusum_mean": {
                "threshold": float(detector_models["cusum_mean"]["threshold"]),
                "params": detector_models["cusum_mean"]["params"],
                "configuration_hash": structural_detector_hashes["cusum_mean"],
                "event_contract": detector_event_contract("cusum_mean"),
                "summary": summary["cusum_mean"],
            },
            "cusum_variance": {
                "threshold": float(detector_models["cusum_variance"]["threshold"]),
                "params": detector_models["cusum_variance"]["params"],
                "configuration_hash": structural_detector_hashes[
                    "cusum_variance"
                ],
                "event_contract": detector_event_contract("cusum_variance"),
                "summary": summary["cusum_variance"],
            },
        },
        "rms_equivalence": {
            "median_gap_pct": 100.0 * median_rms_gap,
            "max_gap_pct": 100.0 * max_rms_gap,
            "mean_gap_pct": 100.0 * float(np.mean(rms_gaps)),
            "mean_gap_abs": float(np.mean(mean_gaps)),
            "mean_var_gap_pct": 100.0 * float(np.mean(var_gaps)),
            "all_runs_within_2pct": bool(np.all(rms_gaps <= STRUCTURAL_RMS_TARGET_REL)),
            "abort_threshold_pct": 100.0 * STRUCTURAL_RMS_ABORT_REL,
            "per_run_gap_pct": (100.0 * rms_gaps).tolist(),
        },
        "summary": {
            "primary_comparison": "marginal first-alarm outcomes at matched achieved finite-horizon operating risk",
            "secondary_joint_valid_delay_diagnostics": {
                "cusum_mean_minus_structural_manifold_median_samples": json_scalar(delta_mean),
                "cusum_variance_minus_structural_manifold_median_samples": json_scalar(delta_var),
                "relative_difference_vs_cusum_mean_pct": json_scalar(rel_improve_mean),
                "relative_difference_vs_cusum_variance_pct": json_scalar(rel_improve_var),
                "cusum_mean_minus_structural_manifold_bootstrap_median_ci": [json_scalar(ci_mean[0]), json_scalar(ci_mean[1])],
                "cusum_variance_minus_structural_manifold_bootstrap_median_ci": [json_scalar(ci_var[0]), json_scalar(ci_var[1])],
                "structural_manifold_earlier_than_cusum_mean_rate": json_scalar(earlier_rate_mean),
                "structural_manifold_earlier_than_cusum_variance_rate": json_scalar(earlier_rate_var),
                "joint_valid_count_vs_cusum_mean": int(pairwise_deltas_mean.size),
                "joint_valid_count_vs_cusum_variance": int(pairwise_deltas_var.size),
                "outcome_contingency_vs_cusum_mean": mean_contingency,
                "outcome_contingency_vs_cusum_variance": var_contingency,
            },
            "median_local_mean_gap": json_scalar(median_local_mean_gap),
            "max_local_mean_gap": json_scalar(max_local_mean_gap),
            "median_baseline_std": json_scalar(median_baseline_std),
            "local_mean_shift_present": local_mean_shift_present,
            "invalid_under_constraints": invalid,
        },
        "raw_runs": {
            "seeds": seeds,
            "onsets": onsets,
            "valid_detection_delays_samples": raw_delays,
            "conditional_valid_effective_delays_samples": raw_effective_delays,
            "first_alarm_indices": raw_detect_times,
            "outcomes": raw_outcomes,
            "local_mean_gap": [json_scalar(x) for x in local_mean_gaps],
            "baseline_std": [json_scalar(x) for x in baseline_stds],
            "joint_valid_conditional_pairwise_delay_deltas": {
                "cusum_mean_minus_structural_manifold": [json_scalar(x) for x in pairwise_deltas_mean.tolist()],
                "cusum_variance_minus_structural_manifold": [json_scalar(x) for x in pairwise_deltas_var.tolist()],
            },
            "diagnostics": diagnostics,
        },
    }

    atomic_write_text(output_path, strict_json_dumps(result_payload))

    print("STRUCTURAL-ONLY DRIFT BENCHMARK")
    print()
    print(f"Target restricted mean time to alarm: {target_arl:.1f} samples")
    print(
        "Achieved restricted mean time to alarm on common holdout: "
        f"manifold={achieved_operating_statistics['structural_manifold'].restricted_mean_time_to_alarm:.1f}, "
        f"CUSUM mean={achieved_operating_statistics['cusum_mean'].restricted_mean_time_to_alarm:.1f}, "
        f"CUSUM var={achieved_operating_statistics['cusum_variance'].restricted_mean_time_to_alarm:.1f}"
    )
    print(
        "Censoring rate on common holdout: "
        f"manifold={achieved_operating_statistics['structural_manifold'].censoring_rate:.1%}, "
        f"CUSUM mean={achieved_operating_statistics['cusum_mean'].censoring_rate:.1%}, "
        f"CUSUM var={achieved_operating_statistics['cusum_variance'].censoring_rate:.1%}"
    )
    print(
        "RMS equivalence check: "
        f"median gap={100.0 * median_rms_gap:.3f}%, "
        f"max gap={100.0 * max_rms_gap:.3f}%"
    )
    print()
    print("Conditional valid-detection median delay:")
    print(
        f"manifold: {summary['structural_manifold']['conditional_valid_detection_delay_median_samples']:.1f}"
    )
    print(
        f"CUSUM mean: {summary['cusum_mean']['conditional_valid_detection_delay_median_samples']:.1f}"
    )
    print(
        f"CUSUM var: {summary['cusum_variance']['conditional_valid_detection_delay_median_samples']:.1f}"
    )
    print()
    print("Conditional valid-detection delay p10 / p90:")
    print(
        f"manifold: {summary['structural_manifold']['conditional_valid_detection_delay_p10_samples']:.1f} / {summary['structural_manifold']['conditional_valid_detection_delay_p90_samples']:.1f}"
    )
    print(
        f"CUSUM mean: {summary['cusum_mean']['conditional_valid_detection_delay_p10_samples']:.1f} / {summary['cusum_mean']['conditional_valid_detection_delay_p90_samples']:.1f}"
    )
    print(
        f"CUSUM var: {summary['cusum_variance']['conditional_valid_detection_delay_p10_samples']:.1f} / {summary['cusum_variance']['conditional_valid_detection_delay_p90_samples']:.1f}"
    )
    print()
    print("Secondary joint-valid median delay delta (CUSUM - structural manifold):")
    print(f"mean-based: {delta_mean:.1f} (n={pairwise_deltas_mean.size})")
    print(f"var-based: {delta_var:.1f} (n={pairwise_deltas_var.size})")
    print()
    print("Secondary joint-valid relative delay difference (%):")
    print(f"mean-based: {rel_improve_mean:.2f}%")
    print(f"var-based: {rel_improve_var:.2f}%")
    print()
    print("Bootstrap 95% CI:")
    print(f"mean-based: [{ci_mean[0]:.1f}, {ci_mean[1]:.1f}]")
    print(f"var-based: [{ci_var[0]:.1f}, {ci_var[1]:.1f}]")
    print()
    print("Earlier-than-CUSUM rate:")
    print(f"vs mean-based: {100.0 * earlier_rate_mean:.1f}%")
    print(f"vs var-based: {100.0 * earlier_rate_var:.1f}%")
    print()
    print("Local mean gap stats:")
    print(f"median_local_mean_gap: {median_local_mean_gap:.6f}")
    print(f"max_local_mean_gap: {max_local_mean_gap:.6f}")
    print(f"median_baseline_std: {median_baseline_std:.6f}")
    print(f"local_mean_shift_present: {local_mean_shift_present}")
    print()
    print("Miss / false-alarm rate:")
    print(
        f"manifold miss={summary['structural_manifold']['miss_rate']:.1f}% "
        f"fp={summary['structural_manifold']['false_alarm_rate']:.1f}%"
    )
    print(
        f"CUSUM mean miss={summary['cusum_mean']['miss_rate']:.1f}% fp={summary['cusum_mean']['false_alarm_rate']:.1f}%"
    )
    print(
        f"CUSUM var miss={summary['cusum_variance']['miss_rate']:.1f}% fp={summary['cusum_variance']['false_alarm_rate']:.1f}%"
    )
    if invalid:
        print()
        print("Benchmark invalid under constraints.")


# -----------------------------------------------------------------------------#
# Main driver
# -----------------------------------------------------------------------------#
def run_synthetic_smoke(
    args: argparse.Namespace,
    *,
    dataset_wave: np.ndarray | None = None,
    dataset_manifest: Mapping[str, object] | None = None,
) -> None:
    """Run a small deterministic end-to-end plumbing validation.

    This exercises model fitting, threshold refinement, disjoint operating-risk
    measurement, first-alarm outcome ownership, and atomic schema export.  It
    is intentionally too small and synthetic to support a scientific claim.
    """

    calibration_signals = [
        colored_noise(np.random.default_rng(81_000 + index), 1_024, 0.85, 0.05)
        for index in range(6)
    ]
    refinement_signals = [
        colored_noise(np.random.default_rng(81_200 + index), 1_024, 0.85, 0.05)
        for index in range(6)
    ]
    operating_signals = [
        colored_noise(np.random.default_rng(81_500 + index), 1_024, 0.85, 0.05)
        for index in range(6)
    ]
    target = min(float(args.target_arl), 800.0)

    manifold_model = build_structural_manifold_model(calibration_signals, target)
    rms_raw = build_rms_model(calibration_signals, target)
    rms_model: Dict[str, object] = {
        "name": "rms",
        "params": {"bias": float(rms_raw["bias"]), "window": RMS_WINDOW},
        "bias": float(rms_raw["bias"]),
        "threshold": float(rms_raw["threshold"]),
        "arl": float(rms_raw["arl"]),
        "threshold_calibration": rms_raw["threshold_calibration"],
        "factory": None,
    }
    models = {
        "structural_manifold": recalibrate_threshold_on_noise_bank(
            "structural_manifold", manifold_model, refinement_signals, target
        ),
        "rms": recalibrate_threshold_on_noise_bank(
            "rms", rms_model, refinement_signals, target
        ),
    }

    run_count = min(max(int(args.runs), 1), 8)
    evaluation_signals: List[np.ndarray] = []
    onsets: List[int] = []
    evaluation_seeds: List[int] = []
    for index in range(run_count):
        seed = 82_000 + index
        rng = np.random.default_rng(seed)
        if dataset_wave is None:
            signal = colored_noise(rng, 1_536, 0.85, 0.05)
            onset = 768
            disturbance = 0.08 * np.sign(
                np.sin(np.arange(signal.size - onset, dtype=np.float64) * 0.3)
            )
            signal[onset:] += disturbance
        else:
            wave = np.asarray(dataset_wave, dtype=np.float64).reshape(-1)
            wave = resample_to_10k(wave, 12_800.0)
            wave = wave - float(np.mean(wave))
            wave_rms = math.sqrt(float(np.mean(wave * wave)) + EPS)
            wave = 0.08 * wave / wave_rms
            onset = 1_536
            signal_length = max(4_096, onset + int(wave.size) + 256)
            signal = colored_noise(rng, signal_length, 0.85, 0.05)
            signal[onset : onset + wave.size] += wave
        evaluation_signals.append(signal)
        onsets.append(onset)
        evaluation_seeds.append(seed)

    detector_payloads: Dict[str, Dict[str, object]] = {}
    csv_rows: List[str] = []
    for detector_name, model in models.items():
        operating = finite_horizon_operating_statistics_for_detector(
            operating_signals, detector_name, model
        )
        result = evaluate_detector(
            evaluation_signals, onsets, detector_name, model
        )
        delays, _, miss_count, fp_count, miss_flags, fp_flags, first_alarms = result
        outcomes: List[Dict[str, object]] = []
        for run_index, (
            seed,
            onset,
            signal,
            delay,
            miss_flag,
            fp_flag,
            first_alarm,
        ) in enumerate(
            zip(
                evaluation_seeds,
                onsets,
                evaluation_signals,
                delays,
                miss_flags,
                fp_flags,
                first_alarms,
            )
        ):
            outcome = run_outcome_label(
                miss=miss_flag, false_positive=fp_flag
            )
            valid_delay = None if not np.isfinite(delay) else float(delay)
            outcomes.append(
                {
                    "run_index": run_index,
                    "seed": seed,
                    "onset": onset,
                    "trace_length": int(signal.size),
                    "first_alarm_index": first_alarm,
                    "outcome": outcome,
                    "valid_detection_delay_samples": valid_delay,
                }
            )
            csv_rows.append(
                f"{run_index},{seed},{detector_name},{onset},{signal.size},"
                f"{'' if first_alarm is None else first_alarm},{outcome},"
                f"{'' if valid_delay is None else valid_delay}"
            )

        valid_delays = np.asarray(delays, dtype=np.float64)
        valid_delays = valid_delays[np.isfinite(valid_delays)]
        detector_payloads[detector_name] = {
            "configuration_hash": detector_configuration_hash(
                detector_name, model
            ),
            "event_contract": detector_event_contract(detector_name),
            "threshold": float(model["threshold"]),
            "threshold_calibration": model.get("threshold_calibration"),
            "achieved_operating_statistics": operating.to_dict(),
            "achieved_operating_target_deviation_samples": (
                operating.restricted_mean_time_to_alarm - target
            ),
            "evaluation": {
                "run_count": run_count,
                "valid_detection_count": int(valid_delays.size),
                "false_positive_count": int(fp_count),
                "miss_count": int(miss_count),
                "conditional_valid_detection_delay_mean_samples": (
                    float(np.mean(valid_delays)) if valid_delays.size else None
                ),
                "outcomes": outcomes,
            },
        }

    bank_hashes = {
        "parameter_calibration": signal_bank_hash(calibration_signals),
        "threshold_refinement": signal_bank_hash(refinement_signals),
        "operating_risk_holdout": signal_bank_hash(operating_signals),
        "disturbed_evaluation": signal_bank_hash(evaluation_signals),
    }
    detector_config_hashes = {
        name: str(detector["configuration_hash"])
        for name, detector in detector_payloads.items()
    }
    validation_level = (
        "deterministic_synthetic_smoke_only"
        if dataset_wave is None
        else "deterministic_dataset_backed_small_benchmark"
    )
    evaluation_input_contract: Dict[str, object]
    if dataset_wave is None:
        evaluation_input_contract = {
            "kind": "synthetic_alternating_sign_disturbance",
            "trace_length": 1_536,
            "onset": 768,
            "amplitude": 0.08,
            "angular_increment_radians_per_sample": 0.3,
        }
    else:
        evaluation_input_contract = {
            "kind": "dataset_archive_first_waveform",
            "dataset_archive_sha256": (
                None
                if dataset_manifest is None
                else dataset_manifest.get("sha256")
            ),
            "source_sampling_rate_hz": 12_800.0,
            "target_sampling_rate_hz": FS_TARGET,
            "normalized_rms": 0.08,
            "onset": 1_536,
        }
    frozen_configuration = {
        "validation_level": validation_level,
        "evaluation_input_contract": evaluation_input_contract,
        "target_restricted_mean_time_to_alarm": target,
        "persistence": PERSISTENCE,
        "feature_window": FEATURE_WINDOW,
        "rms_window": RMS_WINDOW,
        "parameter_calibration_seeds": [81_000, 81_005],
        "threshold_refinement_seeds": [81_200, 81_205],
        "operating_risk_seeds": [81_500, 81_505],
        "evaluation_seeds": evaluation_seeds,
        "detector_configuration_hashes": detector_config_hashes,
    }
    payload = {
        "schema_version": 1,
        "validation_level": validation_level,
        "scientific_validation": False,
        "claim_boundary": (
            "validates local execution and output contracts only; this small "
            "run does not validate PQD-16c performance or detector superiority"
        ),
        "dataset": None if dataset_manifest is None else dict(dataset_manifest),
        "canonical_detector_key": "structural_manifold",
        "legacy_detector_key_note": (
            "historical dmreda keys are preserved in historical outputs only"
        ),
        "target_restricted_mean_time_to_alarm": target,
        "configuration_hash": config_hash(frozen_configuration),
        "frozen_configuration": frozen_configuration,
        "runtime": runtime_manifest(),
        "bank_hashes": bank_hashes,
        "banks_are_content_disjoint": len(set(bank_hashes.values())) == len(
            bank_hashes
        ),
        "evaluation_seeds": evaluation_seeds,
        "detectors": detector_payloads,
    }
    atomic_write_text(Path(args.output_json), strict_json_dumps(payload))
    atomic_write_text(
        Path(args.output_csv),
        "run_index,seed,detector,onset,trace_length,first_alarm_index,outcome,"
        "valid_detection_delay_samples\n"
        + "\n".join(csv_rows)
        + "\n",
    )
    label = "SYNTHETIC SMOKE" if dataset_wave is None else "SMALL DATASET-BACKED BENCHMARK"
    print(f"{label} COMPLETE (not scientific validation)")
    print(f"Config hash: {payload['configuration_hash']}")


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PQD-16c streaming structural benchmark")
    parser.add_argument("--runs", type=int, default=DEFAULT_RUNS, help="Monte Carlo runs per scenario")
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-csv", type=Path)
    parser.add_argument("--output-dir", type=Path, help="directory for default outputs and plots")
    parser.add_argument("--plots", action="store_true", help="generate diagnostic plots")
    parser.add_argument("--dataset-archive", type=Path, help="explicit cached PQD archive")
    parser.add_argument("--cache-dir", type=Path, default=CACHE_DIR)
    parser.add_argument(
        "--offline",
        "--skip-download",
        dest="offline",
        action="store_true",
        help="forbid network access and require an explicit or cached archive",
    )
    parser.add_argument(
        "--target-restricted-mean-time-to-alarm",
        "--target-arl",
        dest="target_arl",
        type=float,
        default=TARGET_ARL,
        help=(
            "finite-horizon restricted mean time-to-first-alarm target in samples; "
            "--target-arl is a compatibility alias"
        ),
    )
    parser.add_argument("--roc-sweep", action="store_true", help="enable ROC threshold sweep output")
    parser.add_argument("--include-rms", action="store_true", help="include RMS as an optional baseline")
    parser.add_argument(
        "--synthetic-smoke",
        action="store_true",
        help="run a small deterministic plumbing validation without a dataset",
    )
    parser.add_argument(
        "--small-benchmark",
        action="store_true",
        help="run a deterministic dataset-backed small engineering benchmark",
    )
    parser.add_argument(
        "--structural-covariance-shift-only",
        action="store_true",
        help="run only the structural covariance-shift equal-ARL benchmark",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = build_argument_parser()
    args = parser.parse_args(argv)

    selected_modes = sum(
        bool(value)
        for value in (
            args.synthetic_smoke,
            args.small_benchmark,
            args.structural_covariance_shift_only,
        )
    )
    if selected_modes > 1:
        parser.error("select at most one benchmark mode")

    if args.runs <= 0:
        parser.error("--runs must be positive")
    if not math.isfinite(args.target_arl) or args.target_arl <= 0.0:
        parser.error("target restricted mean time to alarm must be positive and finite")

    output_dir = Path(args.output_dir) if args.output_dir is not None else None
    if args.output_json is None:
        if args.structural_covariance_shift_only:
            args.output_json = (output_dir / STRUCTURAL_COV_JSON.name) if output_dir else STRUCTURAL_COV_JSON
        elif args.synthetic_smoke:
            args.output_json = (output_dir / "structural_manifold_synthetic_smoke.json") if output_dir else (BASE_DIR / "structural_manifold_synthetic_smoke.json")
        elif args.small_benchmark:
            args.output_json = (output_dir / "structural_manifold_small_benchmark.json") if output_dir else (BASE_DIR / "structural_manifold_small_benchmark.json")
        else:
            args.output_json = (output_dir / DEFAULT_JSON.name) if output_dir else DEFAULT_JSON
    if args.output_csv is None:
        if args.synthetic_smoke:
            args.output_csv = (output_dir / "structural_manifold_synthetic_smoke.csv") if output_dir else (BASE_DIR / "structural_manifold_synthetic_smoke.csv")
        elif args.small_benchmark:
            args.output_csv = (output_dir / "structural_manifold_small_benchmark.csv") if output_dir else (BASE_DIR / "structural_manifold_small_benchmark.csv")
        else:
            args.output_csv = (output_dir / DEFAULT_CSV.name) if output_dir else DEFAULT_CSV
    artifact_dir = output_dir if output_dir is not None else Path(args.output_json).parent

    plt = _load_pyplot() if args.plots else None

    if args.synthetic_smoke:
        run_synthetic_smoke(args)
        return

    if args.small_benchmark:
        small_archive = resolve_dataset_archive(
            explicit_archive=args.dataset_archive,
            cache_dir=args.cache_dir,
            offline=bool(args.offline),
        )
        small_wave = extract_first_waveforms(
            small_archive, args.cache_dir, limit=1
        )[0]
        run_synthetic_smoke(
            args,
            dataset_wave=small_wave,
            dataset_manifest=dataset_archive_manifest(small_archive),
        )
        return

    if args.structural_covariance_shift_only:
        run_structural_covariance_shift_benchmark(args)
        return

    # Step 1: data
    archive = resolve_dataset_archive(
        explicit_archive=args.dataset_archive,
        cache_dir=args.cache_dir,
        offline=bool(args.offline),
    )
    waves = extract_first_waveforms(archive, args.cache_dir, limit=30)
    orig_fs = 12_800.0  # PQD is 12.8 kHz; adjust if differs

    # Step 2: role-separated noise banks.  Parameter fitting, threshold
    # refinement, and achieved-risk reporting never reuse signal content.
    noise_sigs = generate_noise_signals(40, seed_offset=1_234)
    threshold_refinement_sigs = generate_noise_signals(40, seed_offset=5_000)
    operating_risk_sigs = generate_noise_signals(40, seed_offset=8_000)
    bank_hashes = {
        "parameter_calibration": signal_bank_hash(noise_sigs),
        "threshold_refinement": signal_bank_hash(threshold_refinement_sigs),
        "operating_risk_holdout": signal_bank_hash(operating_risk_sigs),
    }
    if len(set(bank_hashes.values())) != len(bank_hashes):
        raise RuntimeError("calibration and operating-risk banks overlap by content")

    manifold_model = build_structural_manifold_model(noise_sigs, args.target_arl)
    if abs(float(manifold_model["arl"]) - args.target_arl) / args.target_arl > ARL_TOL:
        raise RuntimeError(
            "structural-manifold restricted-mean calibration drifted outside tolerance"
        )
    baseline_models = build_baseline_models(noise_sigs, args.target_arl, args.include_rms)

    models_to_refine: Dict[str, Dict[str, object]] = {
        "structural_manifold": manifold_model,
        **baseline_models,
    }
    models_to_refine = {
        name: recalibrate_threshold_on_noise_bank(
            name, model, threshold_refinement_sigs, args.target_arl
        )
        for name, model in models_to_refine.items()
    }
    manifold_model = models_to_refine.pop("structural_manifold")
    baseline_models = models_to_refine
    operating_statistics = {
        name: finite_horizon_operating_statistics_for_detector(
            operating_risk_sigs, name, model
        )
        for name, model in {
            "structural_manifold": manifold_model,
            **baseline_models,
        }.items()
    }

    # Quick deterministic sanity checks
    sanity_validation(manifold_model, baseline_models)

    dataset_manifest = dataset_archive_manifest(archive)

    detector_models = {
        "structural_manifold": manifold_model,
        **baseline_models,
    }
    detector_config_hashes = {
        name: detector_configuration_hash(name, model)
        for name, model in detector_models.items()
    }
    frozen_experiment_configuration = {
        "target_restricted_mean_time_to_alarm": args.target_arl,
        "persistence": PERSISTENCE,
        "feature_window": FEATURE_WINDOW,
        "rms_window": RMS_WINDOW,
        "stream_len_range": STREAM_LEN_RANGE,
        "slope": SLOPE,
        "harmonic_amp": HARMONIC_AMP,
        "harmonic_freq_hz": HARMONIC_FREQ_HZ,
        "runs": args.runs,
        "global_seed": GLOBAL_SEED,
        "noise_bank_seed_ranges": {
            "parameter_calibration": [1_234, 1_273],
            "threshold_refinement": [5_000, 5_039],
            "operating_risk_holdout": [8_000, 8_039],
            "disturbed_evaluation": [10_000, 10_000 + args.runs - 1],
        },
        "detector_configuration_hashes": detector_config_hashes,
    }
    config_meta = {
        **frozen_experiment_configuration,
        "configuration_hash": config_hash(frozen_experiment_configuration),
        "dataset": dataset_manifest,
        "bank_hashes": bank_hashes,
        "runtime": runtime_manifest(),
        "detector_key_migration": {
            "canonical": "structural_manifold",
            "legacy_historical_only": "dmreda",
        },
        "operating_risk_match": {
            "comparison_bank": "operating_risk_holdout",
            "target_restricted_mean_time_to_alarm": args.target_arl,
            "relative_tolerance": ARL_TOL,
            "detectors": {
                name: {
                    "achieved_restricted_mean_time_to_alarm": (
                        statistics.restricted_mean_time_to_alarm
                    ),
                    "target_deviation_samples": (
                        statistics.restricted_mean_time_to_alarm - args.target_arl
                    ),
                    "within_tolerance": abs(
                        statistics.restricted_mean_time_to_alarm - args.target_arl
                    )
                    <= ARL_TOL * args.target_arl,
                }
                for name, statistics in operating_statistics.items()
            },
        },
    }

    all_results: Dict[str, Dict[str, object]] = {
        "schema_version": 3,
        "result_classification": "dataset_benchmark_not_universal_validation",
        "fairness_contract": (
            "detectors retain native causal score/reset semantics and are "
            "compared on a common disjoint finite-horizon operating-risk bank"
        ),
        "meta": config_meta,
    }
    all_results["detectors"] = {
        "structural_manifold": {
            "threshold": float(manifold_model["threshold"]),
            "params": {
                "bias": float(manifold_model["bias"]),
                "feature_window": FEATURE_WINDOW,
                "persistence": PERSISTENCE,
            },
            "configuration_hash": detector_config_hashes["structural_manifold"],
            "event_contract": detector_event_contract("structural_manifold"),
            "threshold_calibration": manifold_model.get("threshold_calibration"),
            "achieved_operating_statistics": operating_statistics[
                "structural_manifold"
            ].to_dict(),
            "achieved_operating_target_deviation_samples": (
                operating_statistics[
                    "structural_manifold"
                ].restricted_mean_time_to_alarm
                - args.target_arl
            ),
            "metrics_by_scenario": {},
        }
    }
    for name, model in baseline_models.items():
        all_results["detectors"][name] = {
            "threshold": float(model["threshold"]),
            "params": model["params"],
            "configuration_hash": detector_config_hashes[name],
            "event_contract": detector_event_contract(name),
            "threshold_calibration": model.get("threshold_calibration"),
            "achieved_operating_statistics": operating_statistics[name].to_dict(),
            "achieved_operating_target_deviation_samples": (
                operating_statistics[name].restricted_mean_time_to_alarm
                - args.target_arl
            ),
            "metrics_by_scenario": {},
        }
    csv_rows: List[str] = []

    scenario_handlers: Dict[str, Callable[[np.random.Generator, np.ndarray, int], Tuple[Dict[str, object], np.ndarray]]] = {
        "window_rms_preserved_phase_scramble": apply_phase_scramble_scenario,
        "mean_variance_preserved_runlength_scramble": perturb_runlength_structure,
    }
    diagnostic_samples: Dict[str, List[Dict[str, object]]] = {name: [] for name in scenario_handlers}
    detector_order = ["structural_manifold", *baseline_models.keys()]

    for scenario, handler in scenario_handlers.items():
        signals: List[np.ndarray] = []
        onsets: List[int] = []
        seeds: List[int] = []
        scenario_diags: List[Dict[str, object]] = []
        for run_idx in range(args.runs):
            rng = np.random.default_rng(10_000 + run_idx)
            wave = waves[run_idx % len(waves)]
            for _ in range(8):
                stream, base_onset = build_stream(rng, wave, orig_fs)
                if base_onset < stream.size - 25_000:
                    break
            onset = min(base_onset + 4 * FEATURE_WINDOW, stream.size - 20_000)
            diag, _ = handler(rng, stream, onset)
            scenario_diags.append(diag)
            if len(diagnostic_samples[scenario]) < 5:
                diagnostic_samples[scenario].append(diag)
            signals.append(stream)
            onsets.append(onset)
            seeds.append(10_000 + run_idx)

        scenario_result: Dict[str, object] = {
            "seeds": seeds,
            "detectors": {},
            "preservation": {
                "tolerances": {
                    "mean": MEAN_PRESERVE_TOL,
                    "variance_rel": VAR_PRESERVE_TOL,
                    "rms_rel": RMS_TOL,
                },
                "mean_preserved_rate_pct": 100.0 * np.mean([diag["mean_preserved"] for diag in scenario_diags]),
                "variance_preserved_rate_pct": 100.0 * np.mean([diag["variance_preserved"] for diag in scenario_diags]),
                "rms_preserved_rate_pct": 100.0 * np.mean([diag["rms_preserved"] for diag in scenario_diags]),
            },
        }

        detector_results: Dict[str, Tuple[List[float], List[float], int, int, List[bool], List[bool], List[int | None]]] = {}
        detector_caches: Dict[str, List[Dict[str, object]]] = {}
        for detector_name in detector_order:
            model = manifold_model if detector_name == "structural_manifold" else baseline_models[detector_name]
            result = evaluate_detector(signals, onsets, detector_name, model)
            detector_results[detector_name] = result
            delays, eff, miss, fp, miss_flags, fp_flags, detect_times = result
            achieved_restricted_mean = operating_statistics[
                detector_name
            ].restricted_mean_time_to_alarm
            metrics = summarize(
                delays,
                eff,
                miss,
                fp,
                args.runs,
                achieved_restricted_mean,
            )
            payload = detector_metric_payload(
                delays,
                eff,
                miss,
                fp,
                args.runs,
                achieved_restricted_mean,
            )
            scenario_result["detectors"][detector_name] = payload
            if detector_name == "structural_manifold":
                scenario_result["structural_manifold"] = asdict(metrics)
            if detector_name == "rms":
                scenario_result["rms"] = asdict(metrics)
            all_results["detectors"][detector_name]["metrics_by_scenario"][scenario] = payload
            detector_caches[detector_name] = compute_seq_cache(signals, onsets, detector_name, model)

            for signal, onset, delay, eff_delay, miss_flag, fp_flag, detect_time, seed in zip(
                signals,
                onsets,
                delays,
                eff,
                miss_flags,
                fp_flags,
                detect_times,
                seeds,
            ):
                outcome = run_outcome_label(miss=miss_flag, false_positive=fp_flag)
                delay_text = "" if not np.isfinite(delay) else str(float(delay))
                effective_text = "" if not np.isfinite(eff_delay) else str(float(eff_delay))
                first_alarm_text = "" if detect_time is None else str(int(detect_time))
                csv_rows.append(
                    f"{scenario},{detector_name},{onset},{signal.size},{first_alarm_text},{outcome},"
                    f"{delay_text},{effective_text},{int(miss_flag)},{int(fp_flag)},{seed}"
                )

            if args.roc_sweep:
                roc = roc_sweep(detector_caches[detector_name], float(model["threshold"]), ROC_MULTIPLIERS)
                all_results["detectors"][detector_name].setdefault("roc", {})[scenario] = roc
                scenario_result.setdefault("roc", {})[detector_name] = roc

        manifold_detects = np.array(
            [
                detect is not None and (not miss_flag) and (not fp_flag)
                for detect, miss_flag, fp_flag in zip(
                    detector_results["structural_manifold"][6],
                    detector_results["structural_manifold"][4],
                    detector_results["structural_manifold"][5],
                )
            ]
        )
        for detector_name in detector_order:
            if detector_name == "structural_manifold":
                continue
            baseline_detects = np.array(
                [
                    detect is not None and (not miss_flag) and (not fp_flag)
                    for detect, miss_flag, fp_flag in zip(
                        detector_results[detector_name][6],
                        detector_results[detector_name][4],
                        detector_results[detector_name][5],
                    )
                ]
            )
            manifold_only = 100.0 * np.mean(np.logical_and(manifold_detects, ~baseline_detects))
            baseline_only = 100.0 * np.mean(np.logical_and(baseline_detects, ~manifold_detects))
            scenario_result["detectors"][detector_name]["structural_manifold_only_detect_pct"] = manifold_only
            scenario_result["detectors"][detector_name]["baseline_only_detect_pct"] = baseline_only
            all_results["detectors"][detector_name]["metrics_by_scenario"][scenario]["structural_manifold_only_detect_pct"] = manifold_only
            all_results["detectors"][detector_name]["metrics_by_scenario"][scenario]["baseline_only_detect_pct"] = baseline_only

        all_results[scenario] = scenario_result

        if args.plots:
            rep_sig = signals[0]
            rep_onset = onsets[0]
            rep_manifold_cache = compute_seq_cache([rep_sig], [rep_onset], "structural_manifold", manifold_model)[0]
            plt.figure(figsize=(10, 4))
            t = np.arange(rep_sig.size)
            rms_trace = trailing_rms(rep_sig, RMS_WINDOW)
            plt.subplot(2, 1, 1)
            plt.plot(t, rms_trace, label="RMS")
            plt.axvline(rep_onset, color="k", linestyle="--", label="onset")
            plt.ylabel("RMS")
            plt.legend()
            plt.subplot(2, 1, 2)
            plt.plot(rep_manifold_cache["idx"], rep_manifold_cache["seq"], label="structural manifold seq")
            plt.axhline(
                manifold_model["threshold"],
                color="r",
                linestyle="--",
                label="structural-manifold threshold",
            )
            plt.axvline(rep_onset, color="k", linestyle="--", label="onset")
            plt.ylabel("Seq stat")
            plt.xlabel("Sample")
            plt.legend()
            plt.tight_layout()
            artifact_dir.mkdir(parents=True, exist_ok=True)
            plt.savefig(artifact_dir / f"trace_{scenario}.png", dpi=150)
            plt.close()

            plt.figure(figsize=(6, 4))
            plt.hist(
                [
                    d - b
                    for d, b in zip(detector_results["structural_manifold"][0], detector_results[detector_order[1]][0])
                    if np.isfinite(d) and np.isfinite(b)
                ],
                bins=30,
                alpha=0.7,
            )
            plt.axvline(0, color="k", linestyle="--")
            plt.xlabel(f"Delay difference (structural manifold - {detector_order[1]}) samples")
            plt.ylabel("Count")
            plt.title(f"Delay diff histogram - {scenario}")
            plt.tight_layout()
            plt.savefig(artifact_dir / f"delay_diff_{scenario}.png", dpi=150)
            plt.close()

    # ROC export if enabled
    if args.roc_sweep:
        roc_entries = []
        for detector_name, detector_payload in all_results["detectors"].items():
            if "roc" not in detector_payload:
                continue
            for scenario, entries in detector_payload["roc"].items():  # type: ignore[index]
                for entry in entries:
                    roc_entries.append({"scenario": scenario, "detector": detector_name, **entry})
        atomic_write_text(
            artifact_dir / "roc_curve.json", strict_json_dumps(roc_entries)
        )

    # Save outputs
    atomic_write_text(Path(args.output_json), strict_json_dumps(all_results))
    atomic_write_text(
        Path(args.output_csv),
        "scenario,detector,onset,trace_length,first_alarm_index,outcome,"
        "valid_detection_delay_samples,conditional_valid_effective_delay_samples,miss,false_positive,seed\n"
        + "\n".join(csv_rows)
        + "\n",
    )

    print("\nBenchmark summary (det_rate/fp_rate/p50 samples):")
    header = ["scenario", *detector_order]
    print(" | ".join(f"{item:>20}" for item in header))
    for scenario in scenario_handlers:
        row = [f"{scenario:>20}"]
        for detector_name in detector_order:
            metrics = all_results[scenario]["detectors"][detector_name]
            row.append(
                f"{metrics['valid_detection_rate_per_run']:.1f}/{metrics['fp_rate_per_run']:.1f}/"
                f"{metrics['conditional_valid_detection_delay_p50_samples']:.1f}"
            )
        print(" | ".join(f"{item:>20}" for item in row))

    for scenario, samples in diagnostic_samples.items():
        if not samples:
            continue
        print(f"\n{scenario} diagnostics:")
        for idx, sample in enumerate(samples):
            print(
                f"run{idx}: mean_ok={sample['mean_preserved']} var_ok={sample['variance_preserved']} "
                f"rms_ok={sample['rms_preserved']} dmean={sample['delta_mean']:.4e} "
                f"dvar={sample['delta_var_rel']:.4%} drms={sample['delta_rms_rel']:.4%}"
            )
            if "window_rms_max_rel_err" in sample:
                print(
                    f"window_rms_err max={sample['window_rms_max_rel_err']:.4%} "
                    f"mean={sample['window_rms_mean_rel_err']:.4%}"
                )

    meta = all_results.get("meta", {})
    if meta:
        print(
            f"\nConfig hash: {meta.get('configuration_hash')}"
        )
        dataset_meta = meta.get("dataset", {})
        if isinstance(dataset_meta, dict):
            print(f"Dataset checksum: {dataset_meta.get('sha256')}")

    print("\nFAIR BENCHMARK COMPLETE")


if __name__ == "__main__":
    main()
