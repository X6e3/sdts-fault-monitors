#include <math.h>
#include <stdio.h>

#define NUM_SAMPLES 10000
#define FEATURE_WINDOW 64
#define RMS_WINDOW 32
#define N_RUNS 20

#define NOISE_STD 0.5
#define EVENT_NOISE_STD 0.25

#define BURST_START 4300
#define BURST_WIDTH 192
#define BURST_AMPLITUDE 1.2

#define DRIFT_START 3200
#define DRIFT_END 4800

#define SHOCK_INDEX 5000
#define SHOCK_AMPLITUDE 2.5
#define SHOCK_ANALYSIS_WIDTH 256

#define EPS 1e-12
#define LP_ALPHA 0.05
#define FEATURE_COUNT 5
#define NOISE_SAMPLES_PER_RUN 1600
#define BURST_SAMPLES_PER_RUN BURST_WIDTH
#define DRIFT_SAMPLES_PER_RUN (DRIFT_END - DRIFT_START)
#define SHOCK_SAMPLES_PER_RUN SHOCK_ANALYSIS_WIDTH
#define MAX_CLASS_SAMPLES (N_RUNS * NOISE_SAMPLES_PER_RUN)

enum SignalClass {
    CLASS_NOISE = 0,
    CLASS_BURST = 1,
    CLASS_DRIFT = 2,
    CLASS_SHOCK = 3,
    CLASS_COUNT = 4
};

typedef struct {
    double slope_mag;
    double norm_cumsum_mag;
    double mean_drift_mag;
    double monotonicity_ratio;
    double low_freq_energy_ratio;
} FeatureVector;

typedef struct {
    double sum_slope_mag;
    double sum_norm_cumsum_mag;
    double sum_mean_drift_mag;
    double sum_monotonicity_ratio;
    double sum_low_freq_energy_ratio;
    int count;
} FeatureAccumulator;

static unsigned int rng_state = 0x12345678u;
static int box_muller_has_spare = 0;
static double box_muller_spare = 0.0;

static double signal_noise[NUM_SAMPLES];
static double signal_burst[NUM_SAMPLES];
static double signal_drift[NUM_SAMPLES];
static double signal_shock[NUM_SAMPLES];
static double burst_template_buffer[NUM_SAMPLES];
static double drift_template_buffer[NUM_SAMPLES];
static double lp_buffer[FEATURE_WINDOW];
static double hf_buffer[FEATURE_WINDOW];
static double centered_buffer[FEATURE_COUNT];
static double diff_buffer[FEATURE_COUNT];
static double product_buffer[FEATURE_COUNT];
static double feature_storage[CLASS_COUNT][MAX_CLASS_SAMPLES][FEATURE_COUNT];
static int feature_counts[CLASS_COUNT];
static int class_capacities[CLASS_COUNT] = {
    N_RUNS * NOISE_SAMPLES_PER_RUN,
    N_RUNS * BURST_SAMPLES_PER_RUN,
    N_RUNS * DRIFT_SAMPLES_PER_RUN,
    N_RUNS * SHOCK_SAMPLES_PER_RUN
};
static double global_feature_mean[FEATURE_COUNT];
static double global_feature_std[FEATURE_COUNT];
static double standardized_centroids[CLASS_COUNT][FEATURE_COUNT];
static double pooled_covariance[FEATURE_COUNT][FEATURE_COUNT];
static double inverse_covariance[FEATURE_COUNT][FEATURE_COUNT];
static double gauss_jordan_aug[FEATURE_COUNT][2 * FEATURE_COUNT];
static const char *class_names[CLASS_COUNT] = {
    "noise",
    "burst",
    "drift",
    "shock"
};
static const char *feature_names[FEATURE_COUNT] = {
    "slope_mag",
    "norm_cumsum_mag",
    "mean_drift_mag",
    "monotonicity_ratio",
    "low_freq_energy_ratio"
};

static int is_noise_region(int index) {
    return index >= 3000 && index < 4600;
}

static int is_burst_region(int index) {
    return index >= BURST_START && index < BURST_START + BURST_WIDTH;
}

static int is_drift_region(int index) {
    return index >= DRIFT_START && index < DRIFT_END;
}

static int is_shock_region(int index) {
    return index >= SHOCK_INDEX && index < SHOCK_INDEX + SHOCK_ANALYSIS_WIDTH;
}

static void set_seed(unsigned int seed) {
    rng_state = seed;
    box_muller_has_spare = 0;
    box_muller_spare = 0.0;
}

static unsigned int lcg_next_u32(void) {
    rng_state = 1664525u * rng_state + 1013904223u;
    return rng_state;
}

static double uniform_unit(void) {
    return ((double)lcg_next_u32() + 1.0) / 4294967297.0;
}

static double gaussian_box_muller(double stddev) {
    double u1;
    double u2;
    double radius;
    double theta;

    if (box_muller_has_spare) {
        box_muller_has_spare = 0;
        return box_muller_spare * stddev;
    }

    u1 = uniform_unit();
    u2 = uniform_unit();
    radius = sqrt(-2.0 * log(u1 + EPS));
    theta = 2.0 * 3.14159265358979323846 * u2;

    box_muller_spare = radius * sin(theta);
    box_muller_has_spare = 1;
    return radius * cos(theta) * stddev;
}

static void fill_noise(double *signal, double stddev) {
    int i;
    for (i = 0; i < NUM_SAMPLES; ++i) {
        signal[i] = gaussian_box_muller(stddev);
    }
}

static void store_feature_vector(enum SignalClass class_id, const FeatureVector *features) {
    int index = feature_counts[class_id];
    if (index >= class_capacities[class_id]) {
        return;
    }

    feature_storage[class_id][index][0] = features->slope_mag;
    feature_storage[class_id][index][1] = features->norm_cumsum_mag;
    feature_storage[class_id][index][2] = features->mean_drift_mag;
    feature_storage[class_id][index][3] = features->monotonicity_ratio;
    feature_storage[class_id][index][4] = features->low_freq_energy_ratio;
    feature_counts[class_id] += 1;
}

static double trailing_rms_mean(const double *signal, int start_index, int end_index) {
    int i;
    double sum_rms = 0.0;
    int count = 0;

    for (i = start_index; i < end_index; ++i) {
        int w;
        int window_start = i - RMS_WINDOW + 1;
        double energy = 0.0;
        int samples = 0;

        if (window_start < 0) {
            window_start = 0;
        }

        for (w = window_start; w <= i; ++w) {
            energy += signal[w] * signal[w];
            ++samples;
        }

        if (samples > 0) {
            sum_rms += sqrt(energy / (double)samples);
            ++count;
        }
    }

    if (count == 0) {
        return 0.0;
    }
    return sum_rms / (double)count;
}

static void build_burst_template(double *signal) {
    int i;
    int half_width = BURST_WIDTH / 2;
    for (i = BURST_START; i < BURST_START + half_width; ++i) {
        signal[i] += BURST_AMPLITUDE;
    }
    for (i = BURST_START + half_width; i < BURST_START + BURST_WIDTH; ++i) {
        signal[i] -= BURST_AMPLITUDE;
    }
}

static void build_drift_template(double *signal, double slope) {
    int i;
    for (i = DRIFT_START; i < DRIFT_END; ++i) {
        signal[i] += slope * (double)(i - DRIFT_START);
    }
}

static void build_shock_template(double *signal) {
    int i;
    for (i = SHOCK_INDEX; i < NUM_SAMPLES; ++i) {
        signal[i] += SHOCK_AMPLITUDE;
    }
}

static double calibrate_drift_slope(void) {
    double low = 0.0;
    double high = 0.01;
    double target;
    int iter;
    int i;

    for (i = 0; i < NUM_SAMPLES; ++i) {
        burst_template_buffer[i] = 0.0;
        drift_template_buffer[i] = 0.0;
    }

    build_burst_template(burst_template_buffer);
    target = trailing_rms_mean(burst_template_buffer, BURST_START, BURST_START + BURST_WIDTH);

    for (iter = 0; iter < 60; ++iter) {
        double mid = 0.5 * (low + high);
        double rms;
        for (i = 0; i < NUM_SAMPLES; ++i) {
            drift_template_buffer[i] = 0.0;
        }
        build_drift_template(drift_template_buffer, mid);
        rms = trailing_rms_mean(drift_template_buffer, DRIFT_START, DRIFT_END);
        if (rms < target) {
            low = mid;
        } else {
            high = mid;
        }
    }

    return 0.5 * (low + high);
}

static void compute_window_features(const double *signal, int end_index, FeatureVector *out_features) {
    int i;
    int start_index = end_index - FEATURE_WINDOW + 1;
    double sum_x = 0.0;
    double sum_x2 = 0.0;
    double sum_dx = 0.0;
    double sum_abs_dx = 0.0;
    double max_abs_cumsum = 0.0;
    double cumsum = 0.0;
    double t_mean = 0.5 * (FEATURE_WINDOW - 1);
    double numerator = 0.0;
    double denominator = 0.0;
    double energy_lp = 0.0;

    for (i = 0; i < FEATURE_WINDOW; ++i) {
        double sample = signal[start_index + i];
        double centered_t = (double)i - t_mean;
        sum_x += sample;
        sum_x2 += sample * sample;
        cumsum += sample;
        if (fabs(cumsum) > max_abs_cumsum) {
            max_abs_cumsum = fabs(cumsum);
        }
        denominator += centered_t * centered_t;
    }

    {
        double mean_x = sum_x / (double)FEATURE_WINDOW;
        for (i = 0; i < FEATURE_WINDOW; ++i) {
            double centered_t = (double)i - t_mean;
            double centered_x = signal[start_index + i] - mean_x;
            numerator += centered_t * centered_x;
        }
    }

    for (i = 1; i < FEATURE_WINDOW; ++i) {
        double dx = signal[start_index + i] - signal[start_index + i - 1];
        sum_dx += dx;
        sum_abs_dx += fabs(dx);
    }

    lp_buffer[0] = signal[start_index];
    hf_buffer[0] = signal[start_index] - lp_buffer[0];
    energy_lp += lp_buffer[0] * lp_buffer[0];
    for (i = 1; i < FEATURE_WINDOW; ++i) {
        double sample = signal[start_index + i];
        lp_buffer[i] = LP_ALPHA * sample + (1.0 - LP_ALPHA) * lp_buffer[i - 1];
        hf_buffer[i] = sample - lp_buffer[i];
        energy_lp += lp_buffer[i] * lp_buffer[i];
    }

    {
        double rms = sqrt(sum_x2 / (double)FEATURE_WINDOW) + EPS;
        double slope = numerator / (denominator + EPS);
        out_features->slope_mag = fabs(slope) / rms;
        out_features->norm_cumsum_mag = max_abs_cumsum / (sum_x2 + EPS);
        out_features->mean_drift_mag = fabs(sum_x / (double)FEATURE_WINDOW) / rms;
        out_features->monotonicity_ratio = fabs(sum_dx) / (sum_abs_dx + EPS);
        out_features->low_freq_energy_ratio = energy_lp / (sum_x2 + EPS);
    }
}

static void accumulate_and_store_features(
    const double *signal,
    int (*region_fn)(int),
    enum SignalClass class_id
) {
    int i;
    for (i = FEATURE_WINDOW - 1; i < NUM_SAMPLES; ++i) {
        FeatureVector features;
        if (!region_fn(i)) {
            continue;
        }
        compute_window_features(signal, i, &features);
        store_feature_vector(class_id, &features);
    }
}

static void compute_global_feature_stats(void) {
    int class_id;
    int sample_index;
    int feature_index;
    double total_count = 0.0;

    for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
        global_feature_mean[feature_index] = 0.0;
        global_feature_std[feature_index] = 0.0;
    }

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        for (sample_index = 0; sample_index < feature_counts[class_id]; ++sample_index) {
            for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
                global_feature_mean[feature_index] += feature_storage[class_id][sample_index][feature_index];
            }
            total_count += 1.0;
        }
    }

    if (total_count <= 0.0) {
        return;
    }

    for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
        global_feature_mean[feature_index] /= total_count;
    }

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        for (sample_index = 0; sample_index < feature_counts[class_id]; ++sample_index) {
            for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
                double delta = feature_storage[class_id][sample_index][feature_index] - global_feature_mean[feature_index];
                global_feature_std[feature_index] += delta * delta;
            }
        }
    }

    for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
        global_feature_std[feature_index] = sqrt(global_feature_std[feature_index] / total_count);
        if (global_feature_std[feature_index] < EPS) {
            global_feature_std[feature_index] = 1.0;
        }
    }
}

static void standardize_features_in_place(void) {
    int class_id;
    int sample_index;
    int feature_index;

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        for (sample_index = 0; sample_index < feature_counts[class_id]; ++sample_index) {
            for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
                feature_storage[class_id][sample_index][feature_index] =
                    (feature_storage[class_id][sample_index][feature_index] - global_feature_mean[feature_index]) /
                    global_feature_std[feature_index];
            }
        }
    }
}

static void compute_standardized_centroids(void) {
    int class_id;
    int sample_index;
    int feature_index;

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
            standardized_centroids[class_id][feature_index] = 0.0;
        }
    }

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        if (feature_counts[class_id] <= 0) {
            continue;
        }
        for (sample_index = 0; sample_index < feature_counts[class_id]; ++sample_index) {
            for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
                standardized_centroids[class_id][feature_index] += feature_storage[class_id][sample_index][feature_index];
            }
        }
        for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
            standardized_centroids[class_id][feature_index] /= (double)feature_counts[class_id];
        }
    }
}

static void compute_pooled_covariance(void) {
    int class_id;
    int sample_index;
    int row;
    int col;
    double normalizer = 0.0;

    for (row = 0; row < FEATURE_COUNT; ++row) {
        for (col = 0; col < FEATURE_COUNT; ++col) {
            pooled_covariance[row][col] = 0.0;
        }
    }

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        for (sample_index = 0; sample_index < feature_counts[class_id]; ++sample_index) {
            for (row = 0; row < FEATURE_COUNT; ++row) {
                centered_buffer[row] = feature_storage[class_id][sample_index][row] - standardized_centroids[class_id][row];
            }
            for (row = 0; row < FEATURE_COUNT; ++row) {
                for (col = 0; col < FEATURE_COUNT; ++col) {
                    pooled_covariance[row][col] += centered_buffer[row] * centered_buffer[col];
                }
            }
            normalizer += 1.0;
        }
    }

    if (normalizer <= 1.0) {
        normalizer = 1.0;
    }

    for (row = 0; row < FEATURE_COUNT; ++row) {
        for (col = 0; col < FEATURE_COUNT; ++col) {
            pooled_covariance[row][col] /= normalizer;
        }
        pooled_covariance[row][row] += 1e-6;
    }
}

static int invert_matrix_5x5(void) {
    int row;
    int col;
    int pivot_row;

    for (row = 0; row < FEATURE_COUNT; ++row) {
        for (col = 0; col < FEATURE_COUNT; ++col) {
            gauss_jordan_aug[row][col] = pooled_covariance[row][col];
            gauss_jordan_aug[row][FEATURE_COUNT + col] = (row == col) ? 1.0 : 0.0;
        }
    }

    for (row = 0; row < FEATURE_COUNT; ++row) {
        double max_abs = fabs(gauss_jordan_aug[row][row]);
        pivot_row = row;
        for (col = row + 1; col < FEATURE_COUNT; ++col) {
            double candidate = fabs(gauss_jordan_aug[col][row]);
            if (candidate > max_abs) {
                max_abs = candidate;
                pivot_row = col;
            }
        }

        if (max_abs < 1e-12) {
            return 0;
        }

        if (pivot_row != row) {
            int k;
            for (k = 0; k < 2 * FEATURE_COUNT; ++k) {
                double temp = gauss_jordan_aug[row][k];
                gauss_jordan_aug[row][k] = gauss_jordan_aug[pivot_row][k];
                gauss_jordan_aug[pivot_row][k] = temp;
            }
        }

        {
            double pivot = gauss_jordan_aug[row][row];
            int k;
            for (k = 0; k < 2 * FEATURE_COUNT; ++k) {
                gauss_jordan_aug[row][k] /= pivot;
            }
        }

        for (pivot_row = 0; pivot_row < FEATURE_COUNT; ++pivot_row) {
            if (pivot_row == row) {
                continue;
            }
            {
                double factor = gauss_jordan_aug[pivot_row][row];
                int k;
                for (k = 0; k < 2 * FEATURE_COUNT; ++k) {
                    gauss_jordan_aug[pivot_row][k] -= factor * gauss_jordan_aug[row][k];
                }
            }
        }
    }

    for (row = 0; row < FEATURE_COUNT; ++row) {
        for (col = 0; col < FEATURE_COUNT; ++col) {
            inverse_covariance[row][col] = gauss_jordan_aug[row][FEATURE_COUNT + col];
        }
    }

    return 1;
}

static double mahalanobis_distance(int class_a, int class_b) {
    int row;
    int col;
    double quadratic = 0.0;

    for (row = 0; row < FEATURE_COUNT; ++row) {
        diff_buffer[row] = standardized_centroids[class_a][row] - standardized_centroids[class_b][row];
        product_buffer[row] = 0.0;
    }

    for (row = 0; row < FEATURE_COUNT; ++row) {
        for (col = 0; col < FEATURE_COUNT; ++col) {
            product_buffer[row] += inverse_covariance[row][col] * diff_buffer[col];
        }
    }

    for (row = 0; row < FEATURE_COUNT; ++row) {
        quadratic += diff_buffer[row] * product_buffer[row];
    }

    if (quadratic < 0.0) {
        quadratic = 0.0;
    }

    return sqrt(quadratic);
}

static void print_feature_stats(void) {
    int feature_index;
    printf("Global feature statistics\n");
    printf("-------------------------\n");
    printf("%-24s | %12s | %12s\n", "Feature", "mean", "std");
    printf("--------------------------------------------------------\n");
    for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
        printf("%-24s | %12.6f | %12.6f\n",
               feature_names[feature_index],
               global_feature_mean[feature_index],
               global_feature_std[feature_index]);
    }
    printf("\n");
}

static void print_standardized_centroids(void) {
    int class_id;
    int feature_index;
    printf("Standardized centroids\n");
    printf("----------------------\n");
    printf("%-10s", "Class");
    for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
        printf(" | %12s", feature_names[feature_index]);
    }
    printf(" | %6s\n", "count");
    printf("---------------------------------------------------------------------------------------------------------------\n");

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        printf("%-10s", class_names[class_id]);
        for (feature_index = 0; feature_index < FEATURE_COUNT; ++feature_index) {
            printf(" | %12.6f", standardized_centroids[class_id][feature_index]);
        }
        printf(" | %6d\n", feature_counts[class_id]);
    }
    printf("\n");
}

int main(void) {
    double drift_slope = calibrate_drift_slope();
    double burst_rms_sum = 0.0;
    double drift_rms_sum = 0.0;
    int run_index;
    int class_id;

    printf("Structural Manifold Separability Harness (C99)\n");
    printf("======================\n\n");

    printf("Configuration\n");
    printf("-------------\n");
    printf("N_RUNS         : %d\n", N_RUNS);
    printf("NUM_SAMPLES    : %d\n", NUM_SAMPLES);
    printf("FEATURE_WINDOW : %d\n", FEATURE_WINDOW);
    printf("RMS_WINDOW     : %d\n", RMS_WINDOW);
    printf("Drift slope    : %.10f\n", drift_slope);
    printf("\n");

    for (class_id = 0; class_id < CLASS_COUNT; ++class_id) {
        feature_counts[class_id] = 0;
    }

    for (run_index = 0; run_index < N_RUNS; ++run_index) {
        set_seed(0x12345678u + (unsigned int)(747796405u * (unsigned int)(run_index + 1)));

        fill_noise(signal_noise, NOISE_STD);
        fill_noise(signal_burst, EVENT_NOISE_STD);
        fill_noise(signal_drift, EVENT_NOISE_STD);
        fill_noise(signal_shock, EVENT_NOISE_STD);

        build_burst_template(signal_burst);
        build_drift_template(signal_drift, drift_slope);
        build_shock_template(signal_shock);

        accumulate_and_store_features(signal_noise, is_noise_region, CLASS_NOISE);
        accumulate_and_store_features(signal_burst, is_burst_region, CLASS_BURST);
        accumulate_and_store_features(signal_drift, is_drift_region, CLASS_DRIFT);
        accumulate_and_store_features(signal_shock, is_shock_region, CLASS_SHOCK);

        burst_rms_sum += trailing_rms_mean(signal_burst, BURST_START, BURST_START + BURST_WIDTH);
        drift_rms_sum += trailing_rms_mean(signal_drift, DRIFT_START, DRIFT_END);
    }

    printf("Average Burst RMS : %.6f\n", burst_rms_sum / (double)N_RUNS);
    printf("Average Drift RMS : %.6f\n\n", drift_rms_sum / (double)N_RUNS);

    compute_global_feature_stats();
    print_feature_stats();

    standardize_features_in_place();
    compute_standardized_centroids();
    print_standardized_centroids();

    compute_pooled_covariance();
    if (!invert_matrix_5x5()) {
        printf("Matrix inversion failed.\n");
        return 1;
    }

    printf("Mahalanobis distances\n");
    printf("---------------------\n");
    printf("noise vs drift : %.6f\n", mahalanobis_distance(CLASS_NOISE, CLASS_DRIFT));
    printf("noise vs burst : %.6f\n", mahalanobis_distance(CLASS_NOISE, CLASS_BURST));
    printf("drift vs burst : %.6f\n", mahalanobis_distance(CLASS_DRIFT, CLASS_BURST));

    return 0;
}
