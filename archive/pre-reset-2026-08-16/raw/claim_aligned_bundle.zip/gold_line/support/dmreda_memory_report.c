#include "../core/dmreda_streaming_fixed.h"

#include <stdio.h>

int main(void) {
    /* Keep this list explicit: sizeof(state) does not include local scratch. */
    const size_t trailing_median_sorted_bytes =
        sizeof(double) * (size_t)DMREDA_FIXED_MAX_W1;

    printf("{\n");
    printf("  \"schema_version\": 1,\n");
    printf("  \"sizeof_dmreda_fixed_config\": %zu,\n", sizeof(DmredaFixedConfig));
    printf("  \"sizeof_dmreda_fixed_state\": %zu,\n", sizeof(DmredaFixedState));
    printf("  \"sizeof_dmreda_fixed_output\": %zu,\n", sizeof(DmredaFixedOutput));
    printf("  \"known_local_scratch_arrays\": {\n");
    printf("    \"trailing_median_sorted_double_count\": %d,\n", DMREDA_FIXED_MAX_W1);
    printf("    \"trailing_median_sorted_bytes\": %zu\n", trailing_median_sorted_bytes);
    printf("  }\n");
    printf("}\n");
    return 0;
}
