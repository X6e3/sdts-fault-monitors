# Framework v0 Design

## Title

Temporal-Structural Deviation Framework (TSDF)

## 1. Objective

This document defines a modular architectural framework that generalizes the current Growth x Signed-Area discriminator without changing the DMREDA signal core.

The framework goal is to support early deviation detection under bounded noise using a small set of physically interpretable decision axes and a structurally constrained decision geometry.

This is not a detector rewrite.
It is an analysis and extension framework around an unchanged DMREDA core.

## 2. Non-Negotiable Constraints

The following constraints are fixed:

1. DMREDA core signal path remains unchanged.
2. Existing baseline, energy deviation, growth, confirmation, regime FSM, and bounded adaptation remain unchanged.
3. New features are evaluation-layer or decision-layer quantities derived from the same signal stream.
4. New features must be physically interpretable, bounded, and MCU-feasible.
5. No heavy transforms, no learned embeddings, no uncontrolled adaptive feature generation.

## 3. Architectural Position

DMREDA remains the temporal core.

The new framework wraps DMREDA inside a broader multi-axis deviation interpretation layer:

- Axis 1: temporal growth
- Axis 2: structural bias
- Axis 3: optional frequency bias

The framework does not ask whether energy increased only.
It asks whether the deviation evolves in a temporally meaningful and structurally consistent way.

## 4. Problem Definition

The framework is defined as a unified deviation framework.

It must cover three related but distinct operating modes:

1. Early transient detection
2. Drift-sensitive deviation detection
3. Unified low-latency deviation characterization

This means the framework should not be tied only to ramp onset or only to burst detection.
Instead, it should express a general language for describing how a deviation departs from baseline over time and structure.

Operationally:

- Early transient detection emphasizes temporal growth.
- Drift detection emphasizes structural bias persistence.
- Unified deviation detection combines both under one bounded geometry.

## 5. Core Axes

### 5.1 Temporal Growth Axis

Purpose:
Measure how quickly normalized deviation is increasing.

Source:
Directly inherited from DMREDA growth quantities such as `G_raw`, `G`, or bounded summaries of recent growth.

Interpretation:

- High temporal growth indicates rapid departure from local baseline.
- Low temporal growth indicates weak or static deviation.

Role in framework:
This remains the primary early-warning axis.

### 5.2 Structural Bias Axis

Purpose:
Measure whether the recent signal segment has a directional or geometric bias that is unlikely to be explained by symmetric fluctuation.

Candidate realizations:

- Signed-area bias
- Curvature consistency
- Zero-crossing asymmetry
- Local trend coherence

Current preferred realization:
Signed-area coupling because it is cheap, causal-compatible, and physically interpretable.

Interpretation:

- A true ramp or structured drift should accumulate directional bias.
- A noise-driven slope excursion may show temporary growth without stable structural bias.

Role in framework:
This is the first structural discriminator that complements growth.

### 5.3 Optional Frequency Bias Axis

Purpose:
Measure whether the recent deviation has a low-frequency or high-frequency tendency without using heavy spectral transforms.

Allowed realizations must remain MCU-feasible.
Examples:

- Zero-crossing density
- Sign-change rate of first difference
- Short-lag autocorrelation proxy
- Low-pass versus raw deviation ratio

Interpretation:

- High-frequency fluctuation may produce growth spikes without structural consistency.
- Lower-frequency persistent deformation should show different frequency bias.

Role in framework:
Optional third axis for later versions.
Not required for framework validity in v0.

## 6. Feature Admission Rule

Features are not added because they improve one benchmark.
They are admitted only if they satisfy all of the following:

1. Physical meaning:
The feature must correspond to a recognizable signal property.

2. Causal computability:
The feature must be computable from present and past samples only.

3. Bounded complexity:
The feature must fit fixed-window MCU evaluation.

4. Orthogonality:
The feature must add a distinct decision direction rather than duplicate growth.

5. Robustness relevance:
The feature must help separate structured deviations from noise-induced excursions.

This rule prevents random feature accretion.

## 7. Decision Geometry

### 7.1 Why Scalar Thresholding Is Not Enough

A scalar threshold assumes one score is sufficient.
That collapses distinct physical causes into a single number.

In this framework, a deviation is described as a point in a low-dimensional axis space:

- temporal growth
- structural bias
- optional frequency bias

The decision is therefore region-based rather than score-only.

### 7.2 Multi-Axis Region Definition

The framework should define acceptance regions in axis space.

Examples of valid region logic:

- growth must exceed minimum level
- structural bias must exceed consistency floor
- frequency bias must remain inside admissible band

This can be expressed as:

- axis-aligned inequalities
- piecewise linear guards
- low-cost polygonal or wedge regions

The region should be deterministic and finite.

### 7.3 MCU-Feasible Boundary

The boundary must remain cheap to evaluate.

Recommended forms:

1. Axis-aligned box:
`A1 > T1 and A2 > T2`

2. Two-stage guard:
`A1 > T1`, then validate `A2 > T2`

3. Piecewise linear coupling:
`A2 > m*A1 + b` over bounded interval

4. Small finite lookup table:
state-conditioned admissible regions

Not allowed:

- kernel methods
- high-order surfaces
- iterative optimization at runtime
- probabilistic latent decision boundaries

## 8. Modular Stack

The framework is organized into layers.

### Layer 1: Signal Core

Unchanged DMREDA quantities:

- adaptive baseline
- energy deviation
- normalized deviation
- growth
- confirmation
- regime FSM

### Layer 2: Structural Descriptors

Derived low-cost descriptors computed on fixed trailing windows.

Examples:

- signed-area bias
- curvature descriptor
- zero-cross asymmetry
- trend consistency

### Layer 3: Axis Mapping

Descriptors are mapped into bounded axes:

- temporal growth axis
- structural bias axis
- optional frequency bias axis

This layer standardizes feature interpretation.

### Layer 4: Decision Geometry

A deterministic region test decides whether the axis point is consistent with a structured deviation.

### Layer 5: Policy Layer

Application policy decides what the framework is asked to detect:

- transient-first policy
- drift-aware policy
- unified policy

This separation avoids entangling detector identity with application tuning.

## 9. Complexity Budget

The framework must satisfy:

- O(N) streaming operation over time
- fixed window memory only
- fixed-size state
- no transform larger than tiny local algebra
- no heavy frequency-domain processing

Operational budget requirements:

1. Memory:
Ring buffers and fixed counters only.

2. Arithmetic:
Add, multiply, divide, comparisons, and very small linear solves only.

3. Windowing:
All descriptors must use fixed trailing windows.

4. State:
Finite decision state, no unbounded history accumulation.

This preserves deployability on MCU-class systems.

## 10. Decision Philosophy

The framework is structural-first, not threshold-first.

Meaning:

- A deviation is not accepted merely because it is large.
- A deviation is accepted because it has coherent temporal and structural evidence.

This is the central design identity.

The DMREDA core tells us that something is changing.
The framework asks whether the change has interpretable structure.

## 11. Publish Angle

The publication angle should emphasize five points.

### 11.1 Energy-Agnostic Detection

The framework is not limited to raw energy growth.
Energy-derived growth is only one axis.
Structured bias can come from other low-cost physical descriptors.

### 11.2 MCU-Constrained Intelligence

The contribution is not heavy modeling.
It is disciplined, analyzable, low-cost multi-axis reasoning under embedded constraints.

### 11.3 Structural-First Decision

The core novelty is the shift from scalar alarm logic to structured deviation geometry.

### 11.4 Unified Deviation Interpretation

The framework can speak to ramps, drifts, and transient departures under one bounded language.

### 11.5 Deterministic Deployability

The framework stays compatible with bounded analysis, fixed windows, finite states, and worst-case timing analysis.

## 12. Recommended v0 Scope

Framework v0 should include:

1. Temporal growth axis
2. Structural bias axis using signed-area bias
3. Region-based analysis layer for post-core discrimination
4. Fixed-window causal descriptors only

Framework v0 should exclude:

1. Learned feature weights
2. Non-causal descriptors
3. FFT-like processing
4. High-dimensional feature banks
5. Runtime boundary adaptation

## 13. Research Questions for v1+

Once v0 is stable, the next questions are:

1. Which structural bias descriptor is most orthogonal to growth?
2. Does a third frequency-bias axis materially improve separability?
3. What is the best bounded region geometry under MCU constraints?
4. Can regime state condition the admissible region without changing detector identity?
5. Can the framework support policy-specific operating modes without feature proliferation?

## 14. Final Definition

Temporal-Structural Deviation Framework is defined as:

A deterministic, modular, low-complexity decision architecture built on top of an unchanged deviation-growth core, where detection is expressed as membership in a bounded multi-axis structural region rather than by a single scalar threshold.

That is the framework identity.
