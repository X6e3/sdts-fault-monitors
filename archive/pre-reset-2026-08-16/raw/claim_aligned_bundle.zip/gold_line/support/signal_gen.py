from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass(frozen=True)
class SignalMetadata:
    disturbance_type: str
    start: int
    end: int
    amplitude: float
    noise_std: float
    seed: int


def generate_signal(
    n: int,
    disturbance_type: str = "burst",
    amplitude: float = 0.8,
    noise_std: float = 0.3,
    seed: int = 0,
    disturb_idx: int = None,
    burst_len: int = 80,
    ramp_len: int = 200,
    return_metadata: bool = False,
) -> Tuple[np.ndarray, int]:
    """Generate a simple disturbance signal for detector experiments.

    Disturbance definitions:
    - ``step``: constant offset from ``disturb_idx`` onward
    - ``ramp``: ramp to ``amplitude`` over ``ramp_len`` samples, then hold
    - ``burst``: finite-duration offset with length ``burst_len``
    - ``drift``: slow linear drift that keeps increasing until the end
    """

    if n <= 0:
        raise ValueError("n must be positive")
    if noise_std < 0:
        raise ValueError("noise_std must be non-negative")

    disturbance_type = disturbance_type.lower()
    if disturbance_type not in {"step", "ramp", "burst", "drift"}:
        raise ValueError(f"unsupported disturbance_type: {disturbance_type}")

    if disturb_idx is None:
        disturb_idx = n // 2
    if not 0 <= disturb_idx < n:
        raise ValueError("disturb_idx must be within signal bounds")

    rng = np.random.default_rng(seed)
    signal = rng.normal(0.0, noise_std, n)

    if disturbance_type == "step":
        signal[disturb_idx:] += amplitude
        disturb_end = n
    elif disturbance_type == "ramp":
        end = min(n, disturb_idx + max(1, ramp_len))
        signal[disturb_idx:end] += np.linspace(0.0, amplitude, end - disturb_idx)
        if end < n:
            signal[end:] += amplitude
        disturb_end = n
    elif disturbance_type == "burst":
        end = min(n, disturb_idx + max(1, burst_len))
        signal[disturb_idx:end] += amplitude
        disturb_end = end
    else:  # drift
        tail = n - disturb_idx
        signal[disturb_idx:] += np.linspace(0.0, amplitude, tail)
        disturb_end = n

    if return_metadata:
        meta = SignalMetadata(
            disturbance_type=disturbance_type,
            start=disturb_idx,
            end=disturb_end,
            amplitude=amplitude,
            noise_std=noise_std,
            seed=seed,
        )
        return signal, meta

    return signal, disturb_idx


__all__ = ["SignalMetadata", "generate_signal"]
