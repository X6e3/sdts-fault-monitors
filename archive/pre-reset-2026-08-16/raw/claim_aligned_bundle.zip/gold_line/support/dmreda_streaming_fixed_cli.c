#include "../core/dmreda_streaming_fixed.h"

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>

static int parse_warmup(const char *text, size_t *value) {
    const unsigned char *cursor = (const unsigned char *)text;
    size_t parsed = 0U;

    if (text == NULL || value == NULL || *cursor == '\0') {
        return -1;
    }
    while (*cursor != '\0') {
        size_t digit;
        if (!isdigit(*cursor)) {
            return -1;
        }
        digit = (size_t)(*cursor - (unsigned char)'0');
        if (parsed > (SIZE_MAX - digit) / 10U) {
            return -1;
        }
        parsed = parsed * 10U + digit;
        cursor += 1;
    }
    *value = parsed;
    return 0;
}

static int ascii_equal_ignore_case(const char *left, const char *right) {
    while (*left != '\0' && *right != '\0') {
        if (tolower((unsigned char)*left) != tolower((unsigned char)*right)) {
            return 0;
        }
        left += 1;
        right += 1;
    }
    return *left == '\0' && *right == '\0';
}

static int parse_mode(const char *text, DmredaFixedMode *mode) {
    if (text == NULL || mode == NULL) {
        return -1;
    }
    if (ascii_equal_ignore_case(text, "D_ONLY")) {
        *mode = DMREDA_MODE_D_ONLY;
        return 0;
    }
    if (ascii_equal_ignore_case(text, "G_ONLY")) {
        *mode = DMREDA_MODE_G_ONLY;
        return 0;
    }
    if (ascii_equal_ignore_case(text, "D_OR_G")) {
        *mode = DMREDA_MODE_D_OR_G;
        return 0;
    }
    return -1;
}

int main(int argc, char **argv) {
    DmredaFixedConfig config = dmreda_fixed_default_config();
    DmredaFixedState state;
    DmredaFixedOutput output;
    double sample;
    int scan_result;

    if (argc > 3) {
        fprintf(stderr, "usage: %s [warmup_samples] [mode]\n", argv[0]);
        return 2;
    }
    if (argc >= 2 && parse_warmup(argv[1], &config.warmup_samples) != 0) {
        fprintf(stderr, "invalid warmup_samples: %s\n", argv[1]);
        return 2;
    }
    if (argc == 3 && parse_mode(argv[2], &config.mode) != 0) {
        fprintf(stderr, "invalid mode: %s\n", argv[2]);
        return 2;
    }
    if (dmreda_fixed_init(&state, &config) != 0) {
        fprintf(stderr, "invalid fixed-state DMREDA configuration\n");
        return 2;
    }

    puts("sample,mu,e,e1,e_baseline,e_baseline_safe,d,g_raw,g,r,a,state,m_eff,confirm_len_eff,pending,confirmed,event_active");
    for (;;) {
        scan_result = scanf("%lf", &sample);
        if (scan_result == EOF) {
            break;
        }
        if (scan_result != 1) {
            fprintf(stderr, "invalid input at sample %zu\n", state.sample_count);
            return 3;
        }
        if (dmreda_fixed_step(&state, sample, &output) != 0) {
            fprintf(stderr, "invalid input at sample %zu\n", state.sample_count);
            return 3;
        }
        printf(
            "%zu,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%d,%d,%d,%d,%d,%d\n",
            output.sample_index,
            output.mu,
            output.e,
            output.e1,
            output.e_baseline,
            output.e_baseline_safe,
            output.d,
            output.g_raw,
            output.g,
            output.r,
            output.a,
            output.state,
            output.m_eff,
            output.confirm_len_eff,
            output.pending,
            output.confirmed,
            output.event_active
        );
    }
    if (ferror(stdin)) {
        perror("stdin");
        return 4;
    }
    return 0;
}
