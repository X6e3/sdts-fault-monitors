/*
 * Historical compatibility entry point.
 *
 * This file was previously described as a DMREDA core port.  It is actually a
 * deterministic structural-feature separability experiment.  The canonical
 * source now lives in ../structural_manifold/separability_harness.c.
 */
#include "../structural_manifold/separability_harness.c"
