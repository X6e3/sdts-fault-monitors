"""Gold-line support artifacts."""
