from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, List, Sequence, Tuple
import sys

import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from deprecated.detectors import rms_detector_causal
from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference
from gold_line.support.signal_gen import SignalMetadata, generate_signal


@dataclass
class Trial:
    signal: np.ndarray
    meta: SignalMetadata


def threshold_crossing_events(
    score: np.ndarray,
    threshold: float,
    *,
    refractory: int,
    min_consecutive: int = 1,
) -> List[int]:
    event_times: List[int] = []
    lockout = 0
    run_len = 0

    for t, value in enumerate(score):
        if lockout > 0:
            lockout -= 1
            run_len = 0
            continue

        if value > threshold:
            run_len += 1
            if run_len >= min_consecutive:
                event_time = t - min_consecutive + 1
                event_times.append(event_time)
                lockout = refractory
                run_len = 0
        else:
            run_len = 0

    return event_times


def evaluate_events(
    event_times: Sequence[int],
    meta: SignalMetadata,
    signal_len: int,
    *,
    detection_horizon: int = 200,
    warmup: int = 128,
) -> Tuple[bool, bool, float]:
    false_alarm = any(warmup <= t < meta.start for t in event_times)
    detection_end = min(signal_len, max(meta.end, meta.start + detection_horizon))
    post_events = [t for t in event_times if meta.start <= t < detection_end]

    detected = len(post_events) > 0
    latency = float(post_events[0] - meta.start) if detected else np.nan
    return detected, false_alarm, latency


def build_trials(
    disturbance: str,
    noise_std: float,
    amplitude: float,
    seeds: Sequence[int],
    *,
    n: int = 5000,
) -> List[Trial]:
    trials: List[Trial] = []

    for seed in seeds:
        signal, meta = generate_signal(
            n,
            disturbance_type=disturbance,
            amplitude=amplitude,
            noise_std=noise_std,
            seed=int(seed),
            return_metadata=True,
        )
        trials.append(Trial(signal=signal, meta=meta))

    return trials


def calibrate_threshold_to_fa_rate(
    scores: Sequence[np.ndarray],
    metas: Sequence[SignalMetadata],
    *,
    target_fa_rate: float,
    refractory: int,
    min_consecutive: int = 1,
    warmup: int = 128,
) -> Tuple[float, float]:
    pooled_pre = np.concatenate(
        [score[warmup : meta.start] for score, meta in zip(scores, metas)]
    )
    if pooled_pre.size == 0:
        raise ValueError("pooled pre-disturbance segment is empty")

    quantiles = np.linspace(0.80, 0.9995, 96)
    candidates = np.unique(np.quantile(pooled_pre, quantiles))
    candidates = np.append(candidates, np.max(pooled_pre) + 1e-9)

    best_threshold = float(candidates[-1])
    best_fa_rate = 0.0

    for threshold in candidates:
        fa_flags = []
        for score, meta in zip(scores, metas):
            event_times = threshold_crossing_events(
                score,
                float(threshold),
                refractory=refractory,
                min_consecutive=min_consecutive,
            )
            _, false_alarm, _ = evaluate_events(
                event_times,
                meta,
                len(score),
                warmup=warmup,
            )
            fa_flags.append(false_alarm)

        fa_rate = float(np.mean(fa_flags))
        best_threshold = float(threshold)
        best_fa_rate = fa_rate
        if fa_rate <= target_fa_rate:
            break

    return best_threshold, best_fa_rate


def summarize_metrics(metric_rows: Sequence[Tuple[bool, bool, float]]) -> Dict[str, float]:
    detections = np.array([row[0] for row in metric_rows], dtype=float)
    false_alarms = np.array([row[1] for row in metric_rows], dtype=float)
    latencies = np.array([row[2] for row in metric_rows], dtype=float)

    valid = latencies[~np.isnan(latencies)]
    return {
        "detection_rate": float(np.mean(detections)),
        "false_alarm_rate": float(np.mean(false_alarms)),
        "latency_mean": float(np.mean(valid)) if valid.size else np.nan,
        "latency_median": float(np.median(valid)) if valid.size else np.nan,
        "latency_std": float(np.std(valid)) if valid.size else np.nan,
    }


def scaled_profiles(scale: float):
    return {
        state: replace(
            profile,
            th_d=profile.th_d * scale,
            th_g=profile.th_g * scale,
            th_d2=profile.th_d2 * scale,
            th_a=profile.th_a * scale,
        )
        for state, profile in DEFAULT_PROFILES.items()
    }


def calibrate_dmreda_scale(
    trials: Sequence[Trial],
    *,
    target_fa_rate: float,
    warmup: int = 128,
) -> Tuple[float, float]:
    scale_grid = np.concatenate(
        (
            np.linspace(1.0, 2.0, 9),
            np.linspace(2.25, 5.0, 12),
        )
    )
    best_scale = float(scale_grid[-1])
    best_fa_rate = 1.0

    for scale in scale_grid:
        profiles = scaled_profiles(float(scale))
        fa_flags = []

        for trial in trials:
            result = compute_dmreda_reference(trial.signal, profiles=profiles)
            _, false_alarm, _ = evaluate_events(
                result.event_times,
                trial.meta,
                len(trial.signal),
                warmup=warmup,
            )
            fa_flags.append(false_alarm)

        fa_rate = float(np.mean(fa_flags))
        best_scale = float(scale)
        best_fa_rate = fa_rate
        if fa_rate <= target_fa_rate:
            break

    return best_scale, best_fa_rate


def evaluate_condition(
    disturbance: str,
    noise_std: float,
    amplitude: float,
    seeds: Sequence[int],
    *,
    target_fa_rate: float = 0.10,
) -> Dict[str, Dict[str, float]]:
    trials = build_trials(disturbance, noise_std, amplitude, seeds)

    dmr_scale, dmr_fa_cal = calibrate_dmreda_scale(
        trials,
        target_fa_rate=target_fa_rate,
        warmup=128,
    )
    dmr_profiles = scaled_profiles(dmr_scale)
    dmr_results = [
        compute_dmreda_reference(trial.signal, profiles=dmr_profiles) for trial in trials
    ]
    dmr_metrics = [
        evaluate_events(
            result.event_times,
            trial.meta,
            len(trial.signal),
            warmup=128,
        )
        for result, trial in zip(dmr_results, trials)
    ]
    dmr_summary = summarize_metrics(dmr_metrics)
    dmr_summary["scale"] = dmr_scale
    dmr_summary["matched_false_alarm_rate"] = dmr_fa_cal

    rms_scores = [rms_detector_causal(trial.signal, window=32)[1] for trial in trials]
    rms_threshold, rms_fa_cal = calibrate_threshold_to_fa_rate(
        rms_scores,
        [trial.meta for trial in trials],
        target_fa_rate=dmr_summary["false_alarm_rate"],
        refractory=80,
        min_consecutive=3,
        warmup=128,
    )
    rms_metrics = [
        evaluate_events(
            threshold_crossing_events(
                score,
                rms_threshold,
                refractory=80,
                min_consecutive=3,
            ),
            trial.meta,
            len(trial.signal),
            warmup=128,
        )
        for score, trial in zip(rms_scores, trials)
    ]
    rms_summary = summarize_metrics(rms_metrics)
    rms_summary["threshold"] = rms_threshold
    rms_summary["matched_false_alarm_rate"] = rms_fa_cal

    dmr_summary["threshold"] = np.nan

    return {
        "DMREDA_REF": dmr_summary,
        "RMS_CAUSAL": rms_summary,
    }


def run_benchmark() -> None:
    disturbances = ("step", "ramp", "burst", "drift")
    noise_levels = (0.2, 0.3, 0.5)
    amplitudes = (0.5, 0.8, 1.2, 1.5)
    seeds = tuple(range(20))

    print("============== CAUSAL DMREDA REFERENCE BENCHMARK ==============")

    for disturbance in disturbances:
        print(f"\n=== {disturbance.upper()} ===")
        for noise_std in noise_levels:
            print(f"\nNoise STD: {noise_std}")
            for amplitude in amplitudes:
                summary = evaluate_condition(
                    disturbance,
                    noise_std,
                    amplitude,
                    seeds,
                    target_fa_rate=0.10,
                )
                dmr = summary["DMREDA_REF"]
                rms = summary["RMS_CAUSAL"]

                print(f"\nAmplitude {amplitude}")
                print(
                    "DMREDA_REF "
                    f"det={dmr['detection_rate']:.2f} "
                    f"fa={dmr['false_alarm_rate']:.2f} "
                    f"lat_mean={dmr['latency_mean']:.1f} "
                    f"lat_med={dmr['latency_median']:.1f} "
                    f"scale={dmr['scale']:.2f}"
                )
                print(
                    "RMS_CAUSAL "
                    f"det={rms['detection_rate']:.2f} "
                    f"fa={rms['false_alarm_rate']:.2f} "
                    f"lat_mean={rms['latency_mean']:.1f} "
                    f"lat_med={rms['latency_median']:.1f} "
                    f"th={rms['threshold']:.4f}"
                )


if __name__ == "__main__":
    run_benchmark()
