from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, dataclass, replace
import csv
import math
import os
from pathlib import Path
import sys
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from deprecated.detectors import rms_detector_causal, rms_event_detector_causal
from gold_line.core.dmreda_reference import DEFAULT_PROFILES, compute_dmreda_reference, compute_warmup_samples
from gold_line.support.signal_gen import SignalMetadata, generate_signal


N_SAMPLES = 5000
AMPLITUDE = 0.8
NOISE_LEVELS = (0.2, 0.3, 0.5)
SEED_COUNT = int(os.environ.get("DMREDA_NUM_SEEDS", "20"))
SEEDS = tuple(range(SEED_COUNT))
RAMP_LENGTHS = (5, 10, 20, 40, 80)
TARGET_FALSE_ALARM_RATE = 0.05
RESULT_CSV = "validation_sweep_results.csv"

STATE0_PROFILE = DEFAULT_PROFILES[0]
RMS_WINDOW = max(profile.w2 for profile in DEFAULT_PROFILES.values())
RMS_CONFIRM_WINDOW = STATE0_PROFILE.confirm_base
RMS_N_PERSIST = STATE0_PROFILE.n_min
RMS_REFRACTORY = STATE0_PROFILE.refractory


@dataclass(frozen=True)
class EvalConfig:
    config_id: str
    warmup_samples: int
    mode: str
    w1_override: Optional[int] = None
    th_scale: Optional[Dict[str, float]] = None


@dataclass(frozen=True)
class Condition:
    disturbance: str
    noise_std: float
    amplitude: float
    ramp_len: Optional[int] = None

    @property
    def label(self) -> str:
        if self.ramp_len is None:
            return self.disturbance
        return f"{self.disturbance}(ramp_len={self.ramp_len})"


@dataclass
class Trial:
    signal: np.ndarray
    meta: SignalMetadata


def build_eval_profiles(eval_config: EvalConfig):
    scales = eval_config.th_scale or {}
    theta_d_scale = scales.get("thetaD", 1.0)
    theta_g_scale = scales.get("thetaG", 1.0)
    theta_a_scale = scales.get("thetaA", 1.0)

    profiles = {}
    for state, profile in DEFAULT_PROFILES.items():
        updated = replace(
            profile,
            th_d=profile.th_d * theta_d_scale,
            th_g=profile.th_g * theta_g_scale,
            th_a=profile.th_a * theta_a_scale,
        )
        if eval_config.w1_override is not None:
            updated = replace(updated, w1=eval_config.w1_override)
        profiles[state] = updated

    return profiles


def make_eval_config_grid() -> List[EvalConfig]:
    configs: List[EvalConfig] = []
    config_idx = 1

    for w1 in (3, 5, 7, 9, 11):
        for theta_a_scale in (0.6, 0.8, 1.0, 1.2, 1.4):
            for theta_d_scale in (0.8, 1.0, 1.2):
                for theta_g_scale in (0.8, 1.0, 1.2):
                    for mode in ("D_or_G", "G_only"):
                        provisional = EvalConfig(
                            config_id=f"CFG_{config_idx:04d}",
                            warmup_samples=0,
                            mode=mode,
                            w1_override=w1,
                            th_scale={
                                "thetaA": theta_a_scale,
                                "thetaD": theta_d_scale,
                                "thetaG": theta_g_scale,
                            },
                        )
                        profiles = build_eval_profiles(provisional)
                        warmup = compute_warmup_samples(profiles)
                        configs.append(
                            replace(
                                provisional,
                                warmup_samples=warmup,
                            )
                        )
                        config_idx += 1

    return configs


def build_trials(condition: Condition) -> List[Trial]:
    trials: List[Trial] = []
    for seed in SEEDS:
        signal, meta = generate_signal(
            N_SAMPLES,
            disturbance_type=condition.disturbance,
            amplitude=condition.amplitude,
            noise_std=condition.noise_std,
            seed=seed,
            ramp_len=condition.ramp_len if condition.ramp_len is not None else 200,
            return_metadata=True,
        )
        trials.append(Trial(signal=signal, meta=meta))
    return trials


def evaluate_event_times(
    event_times: Sequence[int],
    meta: SignalMetadata,
    signal_len: int,
    *,
    detection_horizon: int = 200,
) -> Tuple[bool, bool, float]:
    false_alarm = any(t < meta.start for t in event_times)
    detection_end = min(signal_len, max(meta.end, meta.start + detection_horizon))
    post_events = [t for t in event_times if meta.start <= t < detection_end]
    detected = len(post_events) > 0
    latency = float(post_events[0] - meta.start) if detected else math.nan
    return detected, false_alarm, latency


def summarize_metrics(metric_rows: Sequence[Tuple[bool, bool, float]]) -> Dict[str, float]:
    detections = np.array([row[0] for row in metric_rows], dtype=float)
    false_alarms = np.array([row[1] for row in metric_rows], dtype=float)
    latencies = np.array([row[2] for row in metric_rows], dtype=float)
    valid_latencies = latencies[~np.isnan(latencies)]

    return {
        "latency_mean": float(np.mean(valid_latencies)) if valid_latencies.size else math.nan,
        "latency_std": float(np.std(valid_latencies)) if valid_latencies.size else math.nan,
        "detection_rate": float(np.mean(detections)),
        "false_alarm_rate": float(np.mean(false_alarms)),
    }


def calibrate_rms_threshold(
    trials: Sequence[Trial],
    *,
    warmup_samples: int,
) -> float:
    scores = [rms_detector_causal(trial.signal, window=RMS_WINDOW)[1] for trial in trials]
    pooled_pre = np.concatenate([score[warmup_samples : trial.meta.start] for score, trial in zip(scores, trials)])
    candidates = np.unique(np.quantile(pooled_pre, np.linspace(0.80, 0.9995, 96)))
    candidates = np.append(candidates, np.max(pooled_pre) + 1e-9)

    selected_threshold = float(candidates[-1])
    for threshold in candidates:
        fa_flags = []
        for trial in trials:
            rms_result = rms_event_detector_causal(
                trial.signal,
                threshold=float(threshold),
                window=RMS_WINDOW,
                confirm_window=RMS_CONFIRM_WINDOW,
                n_persist=RMS_N_PERSIST,
                refractory=RMS_REFRACTORY,
                warmup_samples=warmup_samples,
            )
            _, false_alarm, _ = evaluate_event_times(
                rms_result.event_times,
                trial.meta,
                len(trial.signal),
            )
            fa_flags.append(false_alarm)

        if float(np.mean(fa_flags)) <= TARGET_FALSE_ALARM_RATE:
            selected_threshold = float(threshold)
            break

    return selected_threshold


def evaluate_rms_condition(
    trials: Sequence[Trial],
    *,
    warmup_samples: int,
) -> Dict[str, float]:
    threshold = calibrate_rms_threshold(trials, warmup_samples=warmup_samples)
    metrics = []
    for trial in trials:
        rms_result = rms_event_detector_causal(
            trial.signal,
            threshold=threshold,
            window=RMS_WINDOW,
            confirm_window=RMS_CONFIRM_WINDOW,
            n_persist=RMS_N_PERSIST,
            refractory=RMS_REFRACTORY,
            warmup_samples=warmup_samples,
        )
        metrics.append(
            evaluate_event_times(
                rms_result.event_times,
                trial.meta,
                len(trial.signal),
            )
        )

    summary = summarize_metrics(metrics)
    summary["threshold"] = threshold
    return summary


def evaluate_dmreda_config(
    condition: Condition,
    trials: Sequence[Trial],
    eval_config: EvalConfig,
    rms_summary: Dict[str, float],
) -> Dict[str, float]:
    profiles = build_eval_profiles(eval_config)
    metrics = []

    for trial in trials:
        result = compute_dmreda_reference(
            trial.signal,
            profiles=profiles,
            mode=eval_config.mode,
        )
        filtered_event_times = [t for t in result.event_times if t >= eval_config.warmup_samples]
        metrics.append(
            evaluate_event_times(
                filtered_event_times,
                trial.meta,
                len(trial.signal),
            )
        )

    summary = summarize_metrics(metrics)
    latency_delta = summary["latency_mean"] - rms_summary["latency_mean"]

    row = {
        "disturbance": condition.disturbance,
        "noise_std": condition.noise_std,
        "amplitude": condition.amplitude,
        "ramp_len": condition.ramp_len if condition.ramp_len is not None else "",
        "configuration_id": eval_config.config_id,
        "mode": eval_config.mode,
        "w1": eval_config.w1_override,
        "thetaA_scale": (eval_config.th_scale or {}).get("thetaA", 1.0),
        "thetaD_scale": (eval_config.th_scale or {}).get("thetaD", 1.0),
        "thetaG_scale": (eval_config.th_scale or {}).get("thetaG", 1.0),
        "warmup_samples": eval_config.warmup_samples,
        "latency_mean": summary["latency_mean"],
        "latency_std": summary["latency_std"],
        "detection_rate": summary["detection_rate"],
        "false_alarm_rate": summary["false_alarm_rate"],
        "rms_latency_mean": rms_summary["latency_mean"],
        "rms_latency_std": rms_summary["latency_std"],
        "rms_detection_rate": rms_summary["detection_rate"],
        "rms_false_alarm_rate": rms_summary["false_alarm_rate"],
        "rms_threshold": rms_summary["threshold"],
        "latency_delta_vs_rms": latency_delta,
    }
    return row


def sweep_condition(condition: Condition, configs: Sequence[EvalConfig]) -> Dict[str, object]:
    trials = build_trials(condition)
    warmup_samples = configs[0].warmup_samples
    rms_summary = evaluate_rms_condition(trials, warmup_samples=warmup_samples)
    rows = [
        evaluate_dmreda_config(
            condition,
            trials,
            eval_config,
            rms_summary,
        )
        for eval_config in configs
    ]
    return {
        "condition": asdict(condition),
        "rms_summary": rms_summary,
        "rows": rows,
    }


def build_conditions() -> List[Condition]:
    conditions: List[Condition] = []
    for noise_std in NOISE_LEVELS:
        for disturbance in ("step", "burst", "drift"):
            conditions.append(
                Condition(
                    disturbance=disturbance,
                    noise_std=noise_std,
                    amplitude=AMPLITUDE,
                )
            )
        for ramp_len in RAMP_LENGTHS:
            conditions.append(
                Condition(
                    disturbance="ramp",
                    noise_std=noise_std,
                    amplitude=AMPLITUDE,
                    ramp_len=ramp_len,
                )
            )
    return conditions


def format_value(value) -> str:
    if isinstance(value, float):
        if math.isnan(value):
            return "nan"
        return f"{value:.4f}"
    return str(value)


def print_condition_table(condition: Condition, rms_summary: Dict[str, float], rows: Sequence[Dict[str, float]]) -> None:
    print()
    print(f"Condition: disturbance={condition.label} noise_std={condition.noise_std:.2f}")
    print(
        "RMS_BASELINE "
        f"latency_mean={format_value(rms_summary['latency_mean'])} "
        f"latency_std={format_value(rms_summary['latency_std'])} "
        f"detection_rate={format_value(rms_summary['detection_rate'])} "
        f"false_alarm_rate={format_value(rms_summary['false_alarm_rate'])} "
        f"threshold={format_value(rms_summary['threshold'])}"
    )
    print("Configuration ID,Mode,Latency_mean,Detection_rate,FA_rate,Latency_delta_vs_RMS")
    for row in rows:
        print(
            f"{row['configuration_id']},"
            f"{row['mode']},"
            f"{format_value(row['latency_mean'])},"
            f"{format_value(row['detection_rate'])},"
            f"{format_value(row['false_alarm_rate'])},"
            f"{format_value(row['latency_delta_vs_rms'])}"
        )


def save_rows_to_csv(rows: Sequence[Dict[str, float]], csv_path: str) -> None:
    if not rows:
        return

    fieldnames = list(rows[0].keys())
    with open(csv_path, "w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def select_best_row(rows: Sequence[Dict[str, float]]) -> Dict[str, float]:
    valid_rows = [
        row
        for row in rows
        if not math.isnan(row["latency_mean"])
        and row["false_alarm_rate"] <= row["rms_false_alarm_rate"]
    ]
    if not valid_rows:
        return {
            "configuration_id": "NONE",
            "disturbance": "NONE",
            "noise_std": math.nan,
            "ramp_len": "",
            "mode": "NONE",
            "w1": math.nan,
            "thetaA_scale": math.nan,
            "thetaD_scale": math.nan,
            "thetaG_scale": math.nan,
            "warmup_samples": math.nan,
            "latency_mean": math.nan,
            "latency_std": math.nan,
            "detection_rate": math.nan,
            "false_alarm_rate": math.nan,
            "rms_latency_mean": math.nan,
            "rms_false_alarm_rate": math.nan,
            "latency_delta_vs_rms": math.nan,
            "feasible_count": 0,
        }

    valid_rows.sort(
        key=lambda row: (
            row["latency_mean"],
            row["false_alarm_rate"],
            row["latency_std"],
            row["configuration_id"],
        )
    )
    best = dict(valid_rows[0])
    best["feasible_count"] = len(valid_rows)
    return best


def log_ramp_crossovers(rows: Sequence[Dict[str, float]]) -> None:
    for noise_std in NOISE_LEVELS:
        crossover_row = None
        for ramp_len in RAMP_LENGTHS:
            candidates = [
                row
                for row in rows
                if row["disturbance"] == "ramp"
                and row["noise_std"] == noise_std
                and row["ramp_len"] == ramp_len
                and not math.isnan(row["latency_mean"])
                and row["false_alarm_rate"] <= row["rms_false_alarm_rate"]
                and row["latency_mean"] < row["rms_latency_mean"]
            ]
            if not candidates:
                continue

            candidates.sort(key=lambda row: (row["latency_mean"], row["false_alarm_rate"], row["configuration_id"]))
            crossover_row = candidates[0]
            break

        if crossover_row is None:
            print(f"CROSSOVER noise_std={noise_std:.2f} ramp_len=None")
        else:
            print(
                f"CROSSOVER noise_std={noise_std:.2f} "
                f"ramp_len={crossover_row['ramp_len']} "
                f"configuration_id={crossover_row['configuration_id']} "
                f"mode={crossover_row['mode']} "
                f"latency_mean={format_value(crossover_row['latency_mean'])} "
                f"rms_latency_mean={format_value(crossover_row['rms_latency_mean'])}"
            )


def run_validation_sweep() -> Dict[str, float]:
    configs = make_eval_config_grid()
    conditions = build_conditions()

    condition_results: List[Dict[str, object]] = []
    max_workers = min(10, os.cpu_count() or 1)

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(sweep_condition, condition, configs): condition for condition in conditions
        }
        for future in as_completed(future_map):
            condition_results.append(future.result())

    order = {
        ("step", None): 0,
        ("burst", None): 1,
        ("drift", None): 2,
    }
    condition_results.sort(
        key=lambda item: (
            item["condition"]["noise_std"],
            order.get((item["condition"]["disturbance"], item["condition"]["ramp_len"]), 3),
            item["condition"]["ramp_len"] if item["condition"]["ramp_len"] is not None else -1,
        )
    )

    all_rows: List[Dict[str, float]] = []
    for item in condition_results:
        condition = Condition(**item["condition"])
        rows = item["rows"]
        rows.sort(key=lambda row: row["configuration_id"])
        print_condition_table(condition, item["rms_summary"], rows)
        all_rows.extend(rows)

    save_rows_to_csv(all_rows, RESULT_CSV)
    log_ramp_crossovers(all_rows)
    best_row = select_best_row(all_rows)
    return best_row


if __name__ == "__main__":
    best = run_validation_sweep()
    print("BEST_CONFIGURATION_SUMMARY")
    for key in (
        "configuration_id",
        "disturbance",
        "noise_std",
        "ramp_len",
        "mode",
        "w1",
        "thetaA_scale",
        "thetaD_scale",
        "thetaG_scale",
        "warmup_samples",
        "latency_mean",
        "latency_std",
        "detection_rate",
        "false_alarm_rate",
        "rms_latency_mean",
        "rms_false_alarm_rate",
        "latency_delta_vs_rms",
    ):
        print(f"{key}={best[key]}")
