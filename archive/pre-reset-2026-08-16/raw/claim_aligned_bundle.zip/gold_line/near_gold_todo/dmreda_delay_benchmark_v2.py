"""
DMREDA delay benchmark v2 (fair, deterministic).

Runs synthetic scenarios using the cleaned reference implementation in
`dmreda_reference_clean.py` and reports detection delays (strict and effective)
plus false positives / misses. RMS baseline is optional and off by default.

Usage:
    python3 dmreda_delay_benchmark_v2.py
    python3 dmreda_delay_benchmark_v2.py --runs 50 --rms
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple
import sys

import numpy as np

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from gold_line.core.dmreda_reference_clean import (
    DMREDAResult,
    compute_dmreda_reference,
    compute_warmup_samples,
    DEFAULT_PROFILES,
)


# ----------------------------
# Configuration (defaults)
# ----------------------------
FS = 1000  # Hz
DURATION_SEC = 10
NUM_SAMPLES = FS * DURATION_SEC
ONSET_RANGE = (2_000, 4_000)  # samples
DEFAULT_RUNS = 200
BASE_NOISE_STD = 0.5
RHO_VALUES = (0.9,)
NOISE_SCALES = (1.5,)
FEATURE_WINDOWS = (64,)  # kept for completeness; DMREDA profiles fix W1/W2
PERSISTENCE = 3
SLOPE = 0.002
HARMONIC_AMP = 0.3
HARMONIC_FREQ_HZ = 5.0
K_EFFECTIVE = 2.0
RESULT_PATH = Path("/Users/x6e3/vscode/dmreda_delay_benchmark_v2_results.json")


# ----------------------------
# Data structures
# ----------------------------
@dataclass
class ScenarioMetrics:
    mean_strict: float
    median_strict: float
    mean_effective: float
    median_effective: float
    miss_rate: float
    fp_rate: float
    mean_delay_ms: float


@dataclass
class ScenarioResult:
    scenario: str
    metrics: ScenarioMetrics
    strict_delays: List[float]
    effective_delays: List[float]


# ----------------------------
# Signal generation
# ----------------------------
def generate_ar1_noise(rng: np.random.Generator, rho: float, sigma: float) -> np.ndarray:
    signal = np.empty(NUM_SAMPLES, dtype=np.float64)
    signal[0] = rng.normal(0.0, sigma)
    eps_std = sigma * math.sqrt(max(1.0 - rho * rho, 1e-12))
    for i in range(1, NUM_SAMPLES):
        signal[i] = rho * signal[i - 1] + rng.normal(0.0, eps_std)
    return signal


def apply_drift(signal: np.ndarray, onset: int, slope: float) -> None:
    t = np.arange(NUM_SAMPLES - onset, dtype=np.float64)
    signal[onset:] += slope * t


def apply_harmonic(signal: np.ndarray, onset: int, amplitude: float, freq_hz: float) -> None:
    t = np.arange(NUM_SAMPLES - onset, dtype=np.float64)
    phase = 2.0 * math.pi * freq_hz * (t / FS)
    signal[onset:] += amplitude * np.sin(phase)


# ----------------------------
# Detection helpers
# ----------------------------
def first_confirm_after_onset(result: DMREDAResult, onset: int) -> int | None:
    for t in result.event_times:
        if t >= onset:
            return t
    return None


def effective_onset(signal: np.ndarray, mu: np.ndarray, onset: int, k: float) -> int | None:
    sigma_noise = float(np.std(signal[:onset])) + 1e-12
    thresh = k * sigma_noise
    for t in range(onset, len(signal)):
        if abs(signal[t] - mu[t]) > thresh:
            return t
    return None


def trailing_rms(signal: np.ndarray, window: int) -> np.ndarray:
    sq = np.square(signal, dtype=np.float64)
    prefix = np.concatenate(([0.0], np.cumsum(sq, dtype=np.float64)))
    rms = np.empty(signal.size, dtype=np.float64)
    for i in range(signal.size):
        start = max(0, i - window + 1)
        total = prefix[i + 1] - prefix[start]
        count = i - start + 1
        rms[i] = math.sqrt(total / count)
    return rms


def rms_detect(signal: np.ndarray, onset: int, persistence: int) -> int | None:
    rms = trailing_rms(signal, RMS_WINDOW)
    noise_rms = rms[:onset]
    thresh = float(np.mean(noise_rms) + 3.0 * np.std(noise_rms))
    trigger = np.zeros_like(signal, dtype=bool)
    count = 0
    for i, val in enumerate(rms):
        if val > thresh:
            count += 1
            if count >= persistence:
                trigger[i] = True
        else:
            count = 0
    idx = np.flatnonzero(trigger[onset:])
    if idx.size == 0:
        return None
    return int(onset + idx[0])


# ----------------------------
# Benchmark core
# ----------------------------
def run_single(
    rng: np.random.Generator,
    scenario: str,
    rho: float,
    noise_scale: float,
    slope: float,
    harmonic_amp: float,
    harmonic_freq: float,
    persistence: int,
    use_rms: bool,
) -> Tuple[float, float, bool, bool]:
    """Return (strict_delay, effective_delay, is_miss, is_fp)."""
    onset = int(rng.integers(ONSET_RANGE[0], ONSET_RANGE[1]))
    sigma = noise_scale * BASE_NOISE_STD
    x = generate_ar1_noise(rng, rho, sigma)
    if scenario == "drift":
        apply_drift(x, onset, slope)
    elif scenario == "harmonic_drift":
        apply_drift(x, onset, slope)
        apply_harmonic(x, onset, harmonic_amp, harmonic_freq)
    else:
        raise ValueError(f"unknown scenario: {scenario}")

    dm_result = compute_dmreda_reference(x, mode="D_or_G", warmup_samples=None)
    t_detect = first_confirm_after_onset(dm_result, onset)

    if t_detect is not None and t_detect < onset:
        return math.nan, math.nan, True, True  # FP run

    t_eff = effective_onset(x, dm_result.mu, onset, K_EFFECTIVE)
    if t_eff is None:
        t_eff = onset

    if t_detect is None:
        return math.nan, math.nan, True, False

    strict_delay = float(t_detect - onset)
    effective_delay = float(t_detect - t_eff)

    if use_rms:
        _ = rms_detect(x, onset, persistence)  # baseline only if needed; not returned

    return strict_delay, effective_delay, False, False


def compute_metrics(delays: List[float], eff_delays: List[float], miss_count: int, fp_count: int, runs: int) -> ScenarioMetrics:
    delay_arr = np.array(delays, dtype=np.float64)
    eff_arr = np.array(eff_delays, dtype=np.float64)
    miss_rate = 100.0 * miss_count / max(runs, 1)
    fp_rate = 100.0 * fp_count / max(runs, 1)

    mean_delay = float(np.nanmean(delay_arr))
    median_delay = float(np.nanmedian(delay_arr))
    mean_eff = float(np.nanmean(eff_arr))
    median_eff = float(np.nanmedian(eff_arr))
    mean_delay_ms = mean_delay * 1000.0 / FS

    return ScenarioMetrics(
        mean_strict=mean_delay,
        median_strict=median_delay,
        mean_effective=mean_eff,
        median_effective=median_eff,
        miss_rate=miss_rate,
        fp_rate=fp_rate,
        mean_delay_ms=mean_delay_ms,
    )


def format_table(results: List[ScenarioResult]) -> str:
    header = "| scenario | mean_strict | median_strict | mean_eff | median_eff | miss% | fp% |"
    lines = [header]
    for res in results:
        m = res.metrics
        lines.append(
            f"| {res.scenario:<12} | {m.mean_strict:11.1f} | {m.median_strict:13.1f} | "
            f"{m.mean_effective:8.1f} | {m.median_effective:10.1f} | {m.miss_rate:5.2f} | {m.fp_rate:4.2f} |"
        )
    return "\n".join(lines)


# ----------------------------
# Main
# ----------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="DMREDA delay benchmark v2")
    parser.add_argument("--runs", type=int, default=DEFAULT_RUNS, help="number of Monte Carlo runs")
    parser.add_argument("--use-rms", action="store_true", help="enable RMS baseline (not reported)")
    args = parser.parse_args()

    np.random.seed(42)
    warmup_samples = compute_warmup_samples(DEFAULT_PROFILES)

    results: List[ScenarioResult] = []
    json_payload: Dict[str, object] = {
        "config": {
            "fs": FS,
            "duration_sec": DURATION_SEC,
            "runs": args.runs,
            "rho_values": list(RHO_VALUES),
            "noise_scales": list(NOISE_SCALES),
            "feature_windows": list(FEATURE_WINDOWS),
            "persistence": PERSISTENCE,
            "k_effective": K_EFFECTIVE,
            "use_rms": args.use_rms,
        },
        "scenarios": {},
    }

    rng_master = np.random.default_rng(42)
    for scenario in ("drift", "harmonic_drift"):
        delays: List[float] = []
        eff_delays: List[float] = []
        miss_count = 0
        fp_count = 0

        for _ in range(args.runs):
            rng = np.random.default_rng(rng_master.integers(0, 1_000_000_000))
            strict_delay, eff_delay, is_miss, is_fp = run_single(
                rng,
                scenario,
                rho=RHO_VALUES[0],
                noise_scale=NOISE_SCALES[0],
                slope=SLOPE,
                harmonic_amp=HARMONIC_AMP,
                harmonic_freq=HARMONIC_FREQ_HZ,
                persistence=PERSISTENCE,
                use_rms=args.use_rms,
            )
            if is_fp:
                fp_count += 1
            if is_miss:
                miss_count += 1
            delays.append(strict_delay)
            eff_delays.append(eff_delay)

        metrics = compute_metrics(delays, eff_delays, miss_count, fp_count, args.runs)
        results.append(ScenarioResult(scenario=scenario, metrics=metrics, strict_delays=delays, effective_delays=eff_delays))
        json_payload["scenarios"][scenario] = asdict(metrics)  # type: ignore[index]

    table = format_table(results)
    print(table)
    RESULT_PATH.write_text(json.dumps(json_payload, indent=2), encoding="utf-8")
    print(f"\nResults written to {RESULT_PATH}")
    print("\nDELAY BENCHMARK COMPLETE")


if __name__ == "__main__":
    main()
