"""Near-gold scripts kept for leakage/fairness cleanup."""
