"""First-alarm ownership and finite-horizon alarm statistics.

The types in this module deliberately separate two different questions:

* :class:`RunOutcome` classifies an event-bearing evaluation trace from the
  first confirmed alarm on the complete authority-bearing trace.
* :class:`FiniteHorizonAlarmStatistics` describes noise-only time-to-alarm
  observations without pretending that right-censored runs are uncensored
  average-run-length observations.

Alarm times are zero-based sample indices.  A quiet trace contributes its full
trace length to the restricted mean, preserving the scaffold's historical
finite-horizon arithmetic while making the censoring explicit.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Iterable, Iterator, Sequence


@dataclass(frozen=True)
class RunOutcome:
    """Mutually exclusive first-confirmed-alarm outcome for one trace."""

    first_alarm: int | None
    false_positive: bool
    detected: bool
    missed: bool
    delay_samples: int | None

    def __post_init__(self) -> None:
        outcome_count = sum((self.false_positive, self.detected, self.missed))
        if outcome_count != 1:
            raise ValueError("exactly one run outcome must be true")
        if self.first_alarm is not None and self.first_alarm < 0:
            raise ValueError("first_alarm must be non-negative")
        if self.missed:
            if self.first_alarm is not None or self.delay_samples is not None:
                raise ValueError("a missed run cannot have an alarm or detection delay")
        elif self.first_alarm is None:
            raise ValueError("false-positive and detected runs require a first alarm")
        if self.detected:
            if self.delay_samples is None or self.delay_samples < 0:
                raise ValueError("a detected run requires a non-negative delay")
        elif self.delay_samples is not None:
            raise ValueError("only a valid detection may have a detection delay")

    @property
    def outcome(self) -> str:
        if self.false_positive:
            return "false_positive"
        if self.detected:
            return "valid_detection"
        return "miss"

    def to_dict(self) -> dict[str, int | bool | str | None]:
        return {
            "outcome": self.outcome,
            "first_alarm": self.first_alarm,
            "false_positive": self.false_positive,
            "detected": self.detected,
            "missed": self.missed,
            "valid_detection_delay_samples": self.delay_samples,
        }


def classify_run_outcome(
    alarm_times: Iterable[int],
    *,
    onset: int,
    trace_length: int,
    warmup_samples: int,
) -> RunOutcome:
    """Classify a run from its first authority-bearing confirmed alarm.

    Confirmed alarms before ``warmup_samples`` have no external event
    authority.  Among the remaining alarms, a first alarm before ``onset`` is
    a false positive and cannot be redeemed by a later alarm.
    """

    if trace_length <= 0:
        raise ValueError("trace_length must be positive")
    if onset < 0 or onset >= trace_length:
        raise ValueError("onset must lie inside the trace")
    if warmup_samples < 0:
        raise ValueError("warmup_samples must be non-negative")

    raw = [int(value) for value in alarm_times]
    if any(value < 0 or value >= trace_length for value in raw):
        raise ValueError("alarm time lies outside the trace")
    authority_bearing = sorted(value for value in raw if value >= warmup_samples)
    if not authority_bearing:
        return RunOutcome(None, False, False, True, None)

    first = authority_bearing[0]
    if first < onset:
        return RunOutcome(first, True, False, False, None)
    return RunOutcome(first, False, True, False, first - onset)


@dataclass(frozen=True)
class FiniteHorizonAlarmStatistics:
    """Explicit right-censored time-to-first-confirmed-alarm observations."""

    calibration_horizons: tuple[int, ...]
    first_confirmed_alarm_times: tuple[int | None, ...]

    def __post_init__(self) -> None:
        if not self.calibration_horizons:
            raise ValueError("at least one calibration run is required")
        if len(self.calibration_horizons) != len(self.first_confirmed_alarm_times):
            raise ValueError("horizons and first-alarm observations must align")
        for horizon, alarm in zip(
            self.calibration_horizons,
            self.first_confirmed_alarm_times,
        ):
            if horizon <= 0:
                raise ValueError("calibration horizons must be positive")
            if alarm is not None and (alarm < 0 or alarm >= horizon):
                raise ValueError("first alarm must lie inside its calibration horizon")

    @property
    def run_count(self) -> int:
        return len(self.calibration_horizons)

    @property
    def censoring_indicators(self) -> tuple[bool, ...]:
        return tuple(alarm is None for alarm in self.first_confirmed_alarm_times)

    @property
    def censoring_count(self) -> int:
        return sum(self.censoring_indicators)

    @property
    def censoring_rate(self) -> float:
        return self.censoring_count / self.run_count

    @property
    def observed_alarm_count(self) -> int:
        return self.run_count - self.censoring_count

    @property
    def restricted_times_to_alarm(self) -> tuple[int, ...]:
        return tuple(
            horizon if alarm is None else alarm
            for horizon, alarm in zip(
                self.calibration_horizons,
                self.first_confirmed_alarm_times,
            )
        )

    @property
    def restricted_mean_time_to_alarm(self) -> float:
        values = self.restricted_times_to_alarm
        return float(sum(values) / len(values))

    @property
    def mean_observed_first_alarm_time(self) -> float | None:
        observed = [alarm for alarm in self.first_confirmed_alarm_times if alarm is not None]
        if not observed:
            return None
        return float(sum(observed) / len(observed))

    @property
    def mean_calibration_horizon(self) -> float:
        return float(sum(self.calibration_horizons) / self.run_count)

    @property
    def calibration_horizon(self) -> int | None:
        """Return the common horizon, or ``None`` for heterogeneous runs."""

        first = self.calibration_horizons[0]
        if all(horizon == first for horizon in self.calibration_horizons):
            return first
        return None

    def to_dict(self) -> dict[str, object]:
        return {
            "calibration_horizons": list(self.calibration_horizons),
            "calibration_horizon": self.calibration_horizon,
            "first_confirmed_alarm_times": list(self.first_confirmed_alarm_times),
            "censoring_indicators": list(self.censoring_indicators),
            "censoring_count": self.censoring_count,
            "censoring_rate": self.censoring_rate,
            "observed_alarm_count": self.observed_alarm_count,
            "restricted_mean_time_to_alarm": self.restricted_mean_time_to_alarm,
            "mean_observed_first_alarm_time": self.mean_observed_first_alarm_time,
            "mean_calibration_horizon": self.mean_calibration_horizon,
        }


def summarize_finite_horizon_alarms(
    first_confirmed_alarm_times: Sequence[int | None],
    calibration_horizons: Sequence[int],
) -> FiniteHorizonAlarmStatistics:
    """Build validated finite-horizon statistics from per-run observations."""

    return FiniteHorizonAlarmStatistics(
        calibration_horizons=tuple(int(value) for value in calibration_horizons),
        first_confirmed_alarm_times=tuple(
            None if value is None else int(value) for value in first_confirmed_alarm_times
        ),
    )


@dataclass(frozen=True)
class ThresholdCalibrationResult:
    """Threshold and achieved finite-horizon operating behavior."""

    threshold: float
    target_restricted_mean_time_to_alarm: float
    achieved_statistics: FiniteHorizonAlarmStatistics
    iterations: int

    def __post_init__(self) -> None:
        if not isfinite(self.threshold):
            raise ValueError("threshold must be finite")
        if (
            not isfinite(self.target_restricted_mean_time_to_alarm)
            or self.target_restricted_mean_time_to_alarm <= 0.0
        ):
            raise ValueError("target restricted mean must be finite and positive")
        if self.iterations <= 0:
            raise ValueError("iterations must be positive")

    @property
    def achieved_restricted_mean_time_to_alarm(self) -> float:
        return self.achieved_statistics.restricted_mean_time_to_alarm

    @property
    def achieved_finite_horizon_operating_value(self) -> float:
        return self.achieved_restricted_mean_time_to_alarm

    @property
    def target_deviation(self) -> float:
        return (
            self.achieved_restricted_mean_time_to_alarm
            - self.target_restricted_mean_time_to_alarm
        )

    def __iter__(self) -> Iterator[float]:
        """Preserve historical ``threshold, achieved = result`` unpacking."""

        yield self.threshold
        yield self.achieved_restricted_mean_time_to_alarm

    def to_dict(self) -> dict[str, object]:
        return {
            "threshold": self.threshold,
            "target_restricted_mean_time_to_alarm": (
                self.target_restricted_mean_time_to_alarm
            ),
            "achieved_finite_horizon_operating_value": (
                self.achieved_finite_horizon_operating_value
            ),
            "target_deviation": self.target_deviation,
            "iterations": self.iterations,
            "finite_horizon_statistics": self.achieved_statistics.to_dict(),
        }
