"""Shared evaluation contracts for claim-grade DMREDA benchmarks."""

from .alarm_metrics import (
    FiniteHorizonAlarmStatistics,
    RunOutcome,
    ThresholdCalibrationResult,
    classify_run_outcome,
    summarize_finite_horizon_alarms,
)

__all__ = [
    "FiniteHorizonAlarmStatistics",
    "RunOutcome",
    "ThresholdCalibrationResult",
    "classify_run_outcome",
    "summarize_finite_horizon_alarms",
]
