# DMREDA Core FSM Benchmarks

`fair_baseline_scaffold.py` defines the current comparison contract for the
canonical Core FSM. It calibrates RMS, two-sided CUSUM, and EWMA from a dedicated
noise-only bank. Those score baselines use one documented external
warm-up/persistence/refractory gate. The Core FSM retains its native
`D/G -> pending area/count -> confirmation -> refractory` event authority; it
must not be reduced to a raw-score threshold through the baseline gate.

The scaffold deliberately does not claim that default Core FSM profiles are
operating-risk matched. A fair experiment freezes detector parameters on a
dedicated calibration bank, measures achieved false-alarm behavior on a
separate common noise holdout, and only then opens the disjoint evaluation
bank. Fairness means matched achieved risk under native causal event semantics,
not identical gates.

Finite calibration traces are right-censored. Active output therefore records
per-run horizons and first alarms, censoring indicators/count/rate, restricted
mean time to first alarm, mean observed first-alarm time, threshold, target,
achieved value, and target deviation. Historical `ARL` parameter names are
compatibility aliases for the explicitly reported restricted mean; they do not
make the estimate an uncensored classical ARL.

Complete-trace first-event ownership is mandatory: a pre-onset first event is a
false positive and consumes the run, a first event at or after onset is a valid
detection, and no event is a miss. Conditional delay includes valid detections
only.

`dmreda_pqd16c_streaming_benchmark.py` is a compatibility wrapper for the
separate Structural Manifold Detector benchmark. It is not a Core FSM benchmark.
