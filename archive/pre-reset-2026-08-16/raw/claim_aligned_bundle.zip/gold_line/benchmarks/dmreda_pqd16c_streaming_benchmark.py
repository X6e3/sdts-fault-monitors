"""Compatibility entry point for the renamed Structural Manifold benchmark.

New code must import :mod:`gold_line.structural_manifold.pqd16c_benchmark`.
This module remains so historical commands fail neither silently nor abruptly.
"""

from gold_line.structural_manifold.pqd16c_benchmark import *  # noqa: F401,F403
from gold_line.structural_manifold.pqd16c_benchmark import main


if __name__ == "__main__":
    main()
