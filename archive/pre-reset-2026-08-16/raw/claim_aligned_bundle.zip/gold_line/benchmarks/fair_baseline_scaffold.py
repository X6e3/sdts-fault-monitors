"""Deterministic, event-level baseline scaffold for DMREDA Core FSM.

This module intentionally produces no publishable result by itself.  Score
baselines share one external warm-up/persistence/refractory gate.  DMREDA Core
retains its native FSM event authority.  Fair comparison therefore means
disjoint calibration/evaluation data and matched achieved finite-horizon
false-alarm behavior, not an identical event gate for every detector family.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import struct
from typing import Callable, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np

from gold_line.core.dmreda_reference_clean import compute_dmreda_reference
from gold_line.evaluation import (
    FiniteHorizonAlarmStatistics,
    RunOutcome,
    ThresholdCalibrationResult,
    classify_run_outcome,
    summarize_finite_horizon_alarms,
)


ScoreFunction = Callable[[np.ndarray], np.ndarray]


@dataclass(frozen=True)
class EventGateConfig:
    warmup_samples: int
    persistence: int
    refractory: int

    def validate(self) -> None:
        if self.warmup_samples < 0:
            raise ValueError("warmup_samples must be non-negative")
        if self.persistence <= 0:
            raise ValueError("persistence must be positive")
        if self.refractory < 0:
            raise ValueError("refractory must be non-negative")


@dataclass(frozen=True)
class DetectorEventContract:
    """Observable event/reset semantics for one score-based baseline."""

    warmup_samples: int
    event_mechanism: str
    reset_policy: str
    persistence_samples: int
    refractory_samples: int
    threshold_comparison: str
    refractory_boundary: str


@dataclass(frozen=True)
class DisjointBankHashes:
    """Content provenance after proving that two signal banks do not overlap."""

    calibration_bank_hash: str
    evaluation_bank_hash: str
    calibration_run_hashes: tuple[str, ...]
    evaluation_run_hashes: tuple[str, ...]


@dataclass(frozen=True)
class CalibratedBaseline:
    name: str
    threshold: float
    calibration: ThresholdCalibrationResult
    gate: EventGateConfig
    score: ScoreFunction
    event_contract: DetectorEventContract
    frozen_parameters: tuple[tuple[str, int | float], ...]
    configuration_hash: str
    calibration_bank_hash: str

    @property
    def achieved_restricted_mean_time_to_alarm(self) -> float:
        return self.calibration.achieved_restricted_mean_time_to_alarm

    @property
    def achieved_arl_samples(self) -> float:
        """Compatibility alias; the value is a finite-horizon restricted mean."""

        return self.achieved_restricted_mean_time_to_alarm


@dataclass(frozen=True)
class RunRiskCalibrationResult:
    """Exact score-derived finite-horizon run-risk operating point.

    Restricted times preserve the established convention in
    :class:`FiniteHorizonAlarmStatistics`: an observed alarm contributes its
    zero-based index, while a censored run contributes its full horizon.
    Integer counts and sums therefore own calibration decisions; floating-point
    rates and means are descriptive views only.
    """

    threshold: float
    target_false_positive_count: int
    achieved_false_positive_count: int
    target_restricted_time_sum: int
    achieved_restricted_time_sum: int
    achieved_statistics: FiniteHorizonAlarmStatistics
    candidate_count: int
    selected_candidate_index: int
    selection_objective: tuple[int, int, float]
    tie_break_path: tuple[str, ...]
    candidate_set_sha256: str
    score_trace_bank_sha256: str
    event_contract_sha256: str

    def __post_init__(self) -> None:
        if not np.isfinite(self.threshold):
            raise ValueError("threshold must be finite")
        if self.target_false_positive_count < 0:
            raise ValueError("target_false_positive_count must be non-negative")
        if self.achieved_false_positive_count < 0:
            raise ValueError("achieved_false_positive_count must be non-negative")
        if self.target_restricted_time_sum < 0:
            raise ValueError("target_restricted_time_sum must be non-negative")
        if self.achieved_restricted_time_sum < 0:
            raise ValueError("achieved_restricted_time_sum must be non-negative")
        if self.candidate_count <= 0:
            raise ValueError("candidate_count must be positive")
        if not 0 <= self.selected_candidate_index < self.candidate_count:
            raise ValueError("selected_candidate_index is outside the candidate set")
        if len(self.selection_objective) != 3:
            raise ValueError("selection_objective must contain three values")
        if self.tie_break_path != (
            "absolute_false_positive_count_deviation",
            "absolute_restricted_time_sum_deviation",
            "higher_threshold",
        ):
            raise ValueError("unexpected run-risk tie-break path")
        for name in (
            "candidate_set_sha256",
            "score_trace_bank_sha256",
            "event_contract_sha256",
        ):
            value = getattr(self, name)
            if len(value) != 64 or any(
                character not in "0123456789abcdef" for character in value
            ):
                raise ValueError(f"{name} must be a lowercase SHA-256 digest")
        if (
            self.achieved_false_positive_count
            != self.achieved_statistics.observed_alarm_count
        ):
            raise ValueError("achieved false-positive count disagrees with alarm statistics")
        if self.achieved_restricted_time_sum != sum(
            self.achieved_statistics.restricted_times_to_alarm
        ):
            raise ValueError("achieved restricted-time sum disagrees with alarm statistics")

    @property
    def target_restricted_mean_time_to_alarm(self) -> float:
        return self.target_restricted_time_sum / self.achieved_statistics.run_count

    @property
    def achieved_restricted_mean_time_to_alarm(self) -> float:
        return self.achieved_statistics.restricted_mean_time_to_alarm

    @property
    def calibration_result_sha256(self) -> str:
        return _canonical_hash(self.to_dict())

    def to_dict(self) -> dict[str, object]:
        return {
            "threshold": self.threshold,
            "target_false_positive_count": self.target_false_positive_count,
            "achieved_false_positive_count": self.achieved_false_positive_count,
            "target_restricted_time_sum": self.target_restricted_time_sum,
            "achieved_restricted_time_sum": self.achieved_restricted_time_sum,
            "target_restricted_mean_time_to_alarm": (
                self.target_restricted_mean_time_to_alarm
            ),
            "achieved_restricted_mean_time_to_alarm": (
                self.achieved_restricted_mean_time_to_alarm
            ),
            "finite_horizon_statistics": self.achieved_statistics.to_dict(),
            "candidate_count": self.candidate_count,
            "selected_candidate_index": self.selected_candidate_index,
            "selection_objective": list(self.selection_objective),
            "tie_break_path": list(self.tie_break_path),
            "candidate_set_sha256": self.candidate_set_sha256,
            "score_trace_bank_sha256": self.score_trace_bank_sha256,
            "event_contract_sha256": self.event_contract_sha256,
        }


@dataclass(frozen=True)
class RunRiskCalibratedBaseline:
    """Baseline with fixed post-affine score parameters and calibrated threshold."""

    name: str
    threshold: float
    calibration: RunRiskCalibrationResult
    gate: EventGateConfig
    score: ScoreFunction
    event_contract: DetectorEventContract
    frozen_parameters: tuple[tuple[str, int | float], ...]
    configuration_hash: str
    calibration_bank_hash: str
    score_definition_hash: str

    @property
    def achieved_restricted_mean_time_to_alarm(self) -> float:
        return self.calibration.achieved_restricted_mean_time_to_alarm

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "threshold": self.threshold,
            "calibration": self.calibration.to_dict(),
            "calibration_result_sha256": (
                self.calibration.calibration_result_sha256
            ),
            "gate": {
                "warmup_samples": self.gate.warmup_samples,
                "persistence": self.gate.persistence,
                "refractory": self.gate.refractory,
            },
            "event_contract": {
                "warmup_samples": self.event_contract.warmup_samples,
                "event_mechanism": self.event_contract.event_mechanism,
                "reset_policy": self.event_contract.reset_policy,
                "persistence_samples": self.event_contract.persistence_samples,
                "refractory_samples": self.event_contract.refractory_samples,
                "threshold_comparison": self.event_contract.threshold_comparison,
                "refractory_boundary": self.event_contract.refractory_boundary,
            },
            "frozen_parameters": dict(self.frozen_parameters),
            "configuration_hash": self.configuration_hash,
            "calibration_bank_hash": self.calibration_bank_hash,
            "score_definition_hash": self.score_definition_hash,
        }


def _as_finite_signal(signal: Sequence[float]) -> np.ndarray:
    values = np.asarray(signal, dtype=np.float64)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("signal must be a non-empty 1-D sequence")
    if not np.all(np.isfinite(values)):
        raise ValueError("signal must contain only finite samples")
    return values


def baseline_event_contract(gate: EventGateConfig) -> DetectorEventContract:
    """Return the frozen event/reset contract implemented by the score gate."""

    gate.validate()
    return DetectorEventContract(
        warmup_samples=gate.warmup_samples,
        event_mechanism="external_score_threshold_persistence_gate",
        reset_policy="score_and_gate_state_reset_at_trace_start",
        persistence_samples=gate.persistence,
        refractory_samples=gate.refractory,
        threshold_comparison="score > threshold",
        refractory_boundary=(
            "decrement_before_test; sample_is_eligible_when_counter_reaches_zero"
        ),
    )


def _signal_run_hash(signal: Sequence[float]) -> str:
    values = _as_finite_signal(signal)
    canonical = np.ascontiguousarray(values, dtype=np.dtype("<f8"))
    digest = hashlib.sha256()
    digest.update(b"dmreda-signal-run-v1\0")
    digest.update(struct.pack(">Q", int(canonical.size)))
    digest.update(canonical.tobytes(order="C"))
    return digest.hexdigest()


def signal_bank_hash(signal_bank: Sequence[Sequence[float]]) -> str:
    """Hash ordered float64 signal content with explicit run boundaries."""

    if not signal_bank:
        raise ValueError("signal_bank must not be empty")
    run_hashes = tuple(_signal_run_hash(run) for run in signal_bank)
    digest = hashlib.sha256()
    digest.update(b"dmreda-signal-bank-v1\0")
    digest.update(struct.pack(">Q", len(run_hashes)))
    for run_hash in run_hashes:
        digest.update(bytes.fromhex(run_hash))
    return digest.hexdigest()


def validate_disjoint_signal_banks(
    calibration_bank: Sequence[Sequence[float]],
    evaluation_bank: Sequence[Sequence[float]],
) -> DisjointBankHashes:
    """Return bank provenance or fail if exact signal content crosses roles."""

    if not calibration_bank or not evaluation_bank:
        raise ValueError("calibration and evaluation banks must not be empty")
    calibration_runs = tuple(_signal_run_hash(run) for run in calibration_bank)
    evaluation_runs = tuple(_signal_run_hash(run) for run in evaluation_bank)
    overlap = set(calibration_runs).intersection(evaluation_runs)
    if overlap:
        raise ValueError(
            "calibration and evaluation banks share exact signal content "
            f"({len(overlap)} overlapping run hash(es))"
        )
    return DisjointBankHashes(
        calibration_bank_hash=signal_bank_hash(calibration_bank),
        evaluation_bank_hash=signal_bank_hash(evaluation_bank),
        calibration_run_hashes=calibration_runs,
        evaluation_run_hashes=evaluation_runs,
    )


def _canonical_hash(payload: Mapping[str, object]) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _freeze_parameters(
    parameters: Mapping[str, int | float],
) -> tuple[tuple[str, int | float], ...]:
    frozen: list[tuple[str, int | float]] = []
    for name, value in sorted(parameters.items()):
        if isinstance(value, (int, np.integer)):
            frozen.append((name, int(value)))
            continue
        numeric = float(value)
        if not np.isfinite(numeric):
            raise ValueError(f"baseline parameter {name!r} must be finite")
        frozen.append((name, numeric))
    return tuple(frozen)


def _baseline_configuration_hash(
    *,
    name: str,
    threshold: float,
    parameters: tuple[tuple[str, int | float], ...],
    gate: EventGateConfig,
    event_contract: DetectorEventContract,
) -> str:
    return _canonical_hash(
        {
            "schema": "dmreda-baseline-runtime-config-v1",
            "detector": name,
            "threshold": threshold,
            "parameters": dict(parameters),
            "gate": {
                "warmup_samples": gate.warmup_samples,
                "persistence": gate.persistence,
                "refractory": gate.refractory,
            },
            "event_contract": {
                "warmup_samples": event_contract.warmup_samples,
                "event_mechanism": event_contract.event_mechanism,
                "reset_policy": event_contract.reset_policy,
                "persistence_samples": event_contract.persistence_samples,
                "refractory_samples": event_contract.refractory_samples,
                "threshold_comparison": event_contract.threshold_comparison,
                "refractory_boundary": event_contract.refractory_boundary,
            },
        }
    )


def confirmed_alarm_times(
    scores: Sequence[float],
    threshold: float,
    gate: EventGateConfig,
) -> List[int]:
    """Convert a causal score trace into confirmed event indices."""

    gate.validate()
    values = _as_finite_signal(scores)
    if not np.isfinite(threshold):
        raise ValueError("threshold must be finite")

    alarms: List[int] = []
    persistence_count = 0
    refractory_remaining = 0
    for index, score in enumerate(values):
        if index < gate.warmup_samples:
            persistence_count = 0
            continue
        if refractory_remaining > 0:
            refractory_remaining -= 1
            if refractory_remaining > 0:
                persistence_count = 0
                continue
        if score > threshold:
            persistence_count += 1
            if persistence_count >= gate.persistence:
                alarms.append(index)
                persistence_count = 0
                refractory_remaining = gate.refractory
        else:
            persistence_count = 0
    return alarms


def evaluate_alarm_times(
    alarm_times: Iterable[int],
    *,
    onset: int,
    trace_length: int,
    warmup_samples: int,
) -> RunOutcome:
    """Assign one mutually exclusive run outcome from the first valid alarm.

    A pre-onset first alarm is a false-positive run.  A later alarm in the same
    trace cannot recover detection credit, because the detector has already
    spent its event authority on the wrong event.
    """

    return classify_run_outcome(
        alarm_times,
        onset=onset,
        trace_length=trace_length,
        warmup_samples=warmup_samples,
    )


def evaluate_score_trace(
    scores: Sequence[float],
    *,
    threshold: float,
    gate: EventGateConfig,
    onset: int,
) -> RunOutcome:
    values = _as_finite_signal(scores)
    alarms = confirmed_alarm_times(values, threshold, gate)
    return evaluate_alarm_times(
        alarms,
        onset=onset,
        trace_length=values.size,
        warmup_samples=gate.warmup_samples,
    )


def finite_horizon_alarm_statistics(
    score_runs: Sequence[Sequence[float]],
    threshold: float,
    gate: EventGateConfig,
) -> FiniteHorizonAlarmStatistics:
    """Measure explicit finite-horizon first-alarm and censoring behavior."""

    if not score_runs:
        raise ValueError("score_runs must not be empty")
    first_hits: list[int | None] = []
    horizons: list[int] = []
    for run in score_runs:
        values = _as_finite_signal(run)
        alarms = confirmed_alarm_times(values, threshold, gate)
        first_hits.append(alarms[0] if alarms else None)
        horizons.append(int(values.size))
    return summarize_finite_horizon_alarms(first_hits, horizons)


def empirical_arl(
    score_runs: Sequence[Sequence[float]],
    threshold: float,
    gate: EventGateConfig,
) -> float:
    """Compatibility alias for the finite-horizon restricted mean.

    This value is not an uncensored classical ARL estimate.
    """

    return finite_horizon_alarm_statistics(
        score_runs,
        threshold,
        gate,
    ).restricted_mean_time_to_alarm


def _resolve_finite_horizon_target(
    *,
    target_restricted_mean_time_to_alarm: float | None,
    target_arl_samples: float | None,
) -> float:
    if (
        target_restricted_mean_time_to_alarm is not None
        and target_arl_samples is not None
    ):
        raise ValueError("specify only one finite-horizon operating target")
    target = (
        target_restricted_mean_time_to_alarm
        if target_restricted_mean_time_to_alarm is not None
        else target_arl_samples
    )
    if target is None or not np.isfinite(target) or target <= 0.0:
        raise ValueError("target restricted mean must be finite and positive")
    return float(target)


def calibrate_threshold(
    score_runs: Sequence[Sequence[float]],
    *,
    gate: EventGateConfig,
    target_restricted_mean_time_to_alarm: float | None = None,
    target_arl_samples: float | None = None,
    iterations: int = 48,
) -> ThresholdCalibrationResult:
    """Find the lowest threshold reaching a finite-horizon restricted mean."""

    gate.validate()
    if not score_runs:
        raise ValueError("score_runs must not be empty")
    if iterations <= 0:
        raise ValueError("iterations must be positive")
    target = _resolve_finite_horizon_target(
        target_restricted_mean_time_to_alarm=target_restricted_mean_time_to_alarm,
        target_arl_samples=target_arl_samples,
    )

    runs = [_as_finite_signal(run) for run in score_runs]
    max_observable = float(np.mean([run.size for run in runs], dtype=np.float64))
    if target > max_observable:
        raise ValueError(
            "target restricted mean exceeds the observable calibration horizon"
        )

    minimum = min(float(np.min(run)) for run in runs)
    maximum = max(float(np.max(run)) for run in runs)
    span = max(maximum - minimum, 1.0)
    low = minimum - span
    high = maximum + span
    best_threshold = high
    best_statistics = finite_horizon_alarm_statistics(runs, high, gate)

    for _ in range(iterations):
        midpoint = 0.5 * (low + high)
        statistics = finite_horizon_alarm_statistics(runs, midpoint, gate)
        if statistics.restricted_mean_time_to_alarm >= target:
            best_threshold = midpoint
            best_statistics = statistics
            high = midpoint
        else:
            low = midpoint
    return ThresholdCalibrationResult(
        threshold=float(best_threshold),
        target_restricted_mean_time_to_alarm=target,
        achieved_statistics=best_statistics,
        iterations=iterations,
    )


def _event_contract_hash(contract: DetectorEventContract) -> str:
    return _canonical_hash(
        {
            "schema": "dmreda-baseline-event-contract-v1",
            "warmup_samples": contract.warmup_samples,
            "event_mechanism": contract.event_mechanism,
            "reset_policy": contract.reset_policy,
            "persistence_samples": contract.persistence_samples,
            "refractory_samples": contract.refractory_samples,
            "threshold_comparison": contract.threshold_comparison,
            "refractory_boundary": contract.refractory_boundary,
        }
    )


def _float64_vector_hash(domain: bytes, values: np.ndarray) -> str:
    canonical = np.ascontiguousarray(values, dtype=np.dtype("<f8"))
    digest = hashlib.sha256()
    digest.update(domain)
    digest.update(struct.pack(">Q", int(canonical.size)))
    digest.update(canonical.tobytes(order="C"))
    return digest.hexdigest()


def _eligible_persistence_window_minima(
    scores: np.ndarray,
    gate: EventGateConfig,
) -> np.ndarray:
    """Return thresholds at which first-confirmation behavior can change."""

    eligible = scores[gate.warmup_samples :]
    window_count = int(eligible.size) - gate.persistence + 1
    if window_count <= 0:
        return np.empty(0, dtype=np.float64)
    minima = np.full(window_count, np.inf, dtype=np.float64)
    for offset in range(gate.persistence):
        np.minimum(
            minima,
            eligible[offset : offset + window_count],
            out=minima,
        )
    return minima


def _score_derived_run_risk_candidates(
    window_minima: Sequence[np.ndarray],
) -> np.ndarray:
    populated = [values for values in window_minima if values.size]
    if not populated:
        raise ValueError("score runs contain no eligible persistence window")
    unique_minima = np.unique(np.concatenate(populated)).astype(np.float64, copy=False)
    lower = float(np.nextafter(unique_minima[0], -np.inf))
    if not np.isfinite(lower):
        raise ValueError("cannot construct a finite lower threshold sentinel")
    return np.concatenate((np.array([lower], dtype=np.float64), unique_minima))


def calibrate_threshold_to_run_risk(
    score_runs: Sequence[Sequence[float]],
    *,
    gate: EventGateConfig,
    target_false_positive_count: int,
    target_restricted_time_sum: int,
) -> RunRiskCalibrationResult:
    """Select an exact finite-horizon operating point from observed scores.

    Candidate thresholds are the finite value immediately below the smallest
    eligible persistence-window minimum followed by every unique observed
    window minimum.  Because the gate uses ``score > threshold``, equality is
    non-triggering and the largest observed minimum represents the all-censored
    region.  The selected threshold is replayed through
    :func:`confirmed_alarm_times` before the result is returned.
    """

    gate.validate()
    if not score_runs:
        raise ValueError("score_runs must not be empty")
    if isinstance(target_false_positive_count, bool) or not isinstance(
        target_false_positive_count, (int, np.integer)
    ):
        raise TypeError("target_false_positive_count must be an integer")
    if isinstance(target_restricted_time_sum, bool) or not isinstance(
        target_restricted_time_sum, (int, np.integer)
    ):
        raise TypeError("target_restricted_time_sum must be an integer")

    runs = tuple(_as_finite_signal(run) for run in score_runs)
    target_fp = int(target_false_positive_count)
    target_sum = int(target_restricted_time_sum)
    total_horizon = sum(int(run.size) for run in runs)
    if not 0 <= target_fp <= len(runs):
        raise ValueError("target false-positive count lies outside the run count")
    if not 0 <= target_sum <= total_horizon:
        raise ValueError("target restricted-time sum lies outside the observed horizon")
    if total_horizon > np.iinfo(np.int64).max:
        raise ValueError("aggregate calibration horizon exceeds int64 capacity")

    minima_by_run = tuple(
        _eligible_persistence_window_minima(run, gate) for run in runs
    )
    candidates = _score_derived_run_risk_candidates(minima_by_run)
    false_positive_counts = np.zeros(candidates.size, dtype=np.int64)
    restricted_time_sums = np.zeros(candidates.size, dtype=np.int64)
    first_eligible_alarm = gate.warmup_samples + gate.persistence - 1

    for run, minima in zip(runs, minima_by_run):
        horizon = int(run.size)
        if minima.size == 0:
            restricted_time_sums += horizon
            continue
        prefix_maxima = np.maximum.accumulate(minima)
        positions = np.searchsorted(prefix_maxima, candidates, side="right")
        alarmed = positions < prefix_maxima.size
        false_positive_counts += alarmed.astype(np.int64)
        alarm_indices = first_eligible_alarm + positions
        restricted_time_sums += np.where(alarmed, alarm_indices, horizon)

    def objective(index: int) -> tuple[int, int, float]:
        return (
            abs(int(false_positive_counts[index]) - target_fp),
            abs(int(restricted_time_sums[index]) - target_sum),
            -float(candidates[index]),
        )

    selected_index = min(range(int(candidates.size)), key=objective)
    selected_threshold = float(candidates[selected_index])
    selected_statistics = finite_horizon_alarm_statistics(
        runs,
        selected_threshold,
        gate,
    )
    replay_count = selected_statistics.observed_alarm_count
    replay_sum = sum(selected_statistics.restricted_times_to_alarm)
    if replay_count != int(false_positive_counts[selected_index]):
        raise AssertionError("score-derived FP count failed existing-gate replay")
    if replay_sum != int(restricted_time_sums[selected_index]):
        raise AssertionError("score-derived restricted sum failed existing-gate replay")

    event_contract = baseline_event_contract(gate)
    return RunRiskCalibrationResult(
        threshold=selected_threshold,
        target_false_positive_count=target_fp,
        achieved_false_positive_count=replay_count,
        target_restricted_time_sum=target_sum,
        achieved_restricted_time_sum=replay_sum,
        achieved_statistics=selected_statistics,
        candidate_count=int(candidates.size),
        selected_candidate_index=selected_index,
        selection_objective=objective(selected_index),
        tie_break_path=(
            "absolute_false_positive_count_deviation",
            "absolute_restricted_time_sum_deviation",
            "higher_threshold",
        ),
        candidate_set_sha256=_float64_vector_hash(
            b"dmreda-run-risk-candidates-v1\0",
            candidates,
        ),
        score_trace_bank_sha256=signal_bank_hash(runs),
        event_contract_sha256=_event_contract_hash(event_contract),
    )


def trailing_rms_score(signal: Sequence[float], window: int = 32) -> np.ndarray:
    values = _as_finite_signal(signal)
    if window <= 0:
        raise ValueError("window must be positive")
    squared = values * values
    prefix = np.concatenate((np.array([0.0]), np.cumsum(squared, dtype=np.float64)))
    score = np.empty(values.size, dtype=np.float64)
    for index in range(values.size):
        start = max(0, index - window + 1)
        score[index] = np.sqrt((prefix[index + 1] - prefix[start]) / (index - start + 1))
    return score


def two_sided_cusum_score(
    signal: Sequence[float],
    *,
    center: float,
    allowance: float,
) -> np.ndarray:
    values = _as_finite_signal(signal)
    if not np.isfinite(center) or not np.isfinite(allowance) or allowance < 0.0:
        raise ValueError("center and non-negative allowance must be finite")
    positive = 0.0
    negative = 0.0
    score = np.empty(values.size, dtype=np.float64)
    for index, sample in enumerate(values):
        centered = float(sample) - center
        positive = max(0.0, positive + centered - allowance)
        negative = max(0.0, negative - centered - allowance)
        score[index] = max(positive, negative)
    return score


def ewma_mean_score(
    signal: Sequence[float],
    *,
    center: float,
    scale: float,
    alpha: float = 2.0 / 33.0,
) -> np.ndarray:
    values = _as_finite_signal(signal)
    if not np.isfinite(center) or not np.isfinite(scale) or scale <= 0.0:
        raise ValueError("center must be finite and scale must be finite and positive")
    if not np.isfinite(alpha) or not 0.0 < alpha <= 1.0:
        raise ValueError("alpha must be in (0, 1]")
    mean = center
    score = np.empty(values.size, dtype=np.float64)
    for index, sample in enumerate(values):
        mean = alpha * float(sample) + (1.0 - alpha) * mean
        score[index] = abs(mean - center) / scale
    return score


def robust_noise_location_scale(noise_bank: Sequence[Sequence[float]]) -> Tuple[float, float]:
    if not noise_bank:
        raise ValueError("noise_bank must not be empty")
    pooled = np.concatenate([_as_finite_signal(run) for run in noise_bank])
    center = float(np.median(pooled))
    mad = float(np.median(np.abs(pooled - center)))
    scale = max(1.4826 * mad, np.finfo(np.float64).eps)
    return center, scale


def _baseline_definitions(
    noise_bank: Sequence[Sequence[float]],
    *,
    rms_window: int = 32,
    cusum_allowance_sigma: float = 0.5,
    ewma_alpha: float = 2.0 / 33.0,
) -> Mapping[
    str,
    tuple[ScoreFunction, tuple[tuple[str, int | float], ...]],
]:
    """Build score functions and human-inspectable frozen parameters."""

    center, scale = robust_noise_location_scale(noise_bank)
    allowance = cusum_allowance_sigma * scale
    return {
        "rms": (
            lambda signal: trailing_rms_score(signal, rms_window),
            _freeze_parameters({"window": rms_window}),
        ),
        "cusum": (
            lambda signal: two_sided_cusum_score(
                signal,
                center=center,
                allowance=allowance,
            ),
            _freeze_parameters(
                {
                    "center": center,
                    "allowance": allowance,
                    "allowance_sigma": cusum_allowance_sigma,
                    "calibration_scale": scale,
                }
            ),
        ),
        "ewma": (
            lambda signal: ewma_mean_score(
                signal,
                center=center,
                scale=scale,
                alpha=ewma_alpha,
            ),
            _freeze_parameters(
                {
                    "center": center,
                    "scale": scale,
                    "alpha": ewma_alpha,
                }
            ),
        ),
    }


def _fixed_post_affine_baseline_definitions() -> Mapping[
    str,
    tuple[ScoreFunction, tuple[tuple[str, int | float], ...]],
]:
    """Return the Stage 3.2 score definitions with no fitted nuisance values."""

    center = 0.0
    scale = 1.0
    allowance_sigma = 0.5
    allowance = allowance_sigma * scale
    rms_window = 32
    ewma_alpha = 2.0 / 33.0
    return {
        "rms": (
            lambda signal: trailing_rms_score(signal, rms_window),
            _freeze_parameters({"window": rms_window}),
        ),
        "cusum": (
            lambda signal: two_sided_cusum_score(
                signal,
                center=center,
                allowance=allowance,
            ),
            _freeze_parameters(
                {
                    "center": center,
                    "scale": scale,
                    "allowance": allowance,
                    "allowance_sigma": allowance_sigma,
                }
            ),
        ),
        "ewma": (
            lambda signal: ewma_mean_score(
                signal,
                center=center,
                scale=scale,
                alpha=ewma_alpha,
            ),
            _freeze_parameters(
                {
                    "center": center,
                    "scale": scale,
                    "alpha": ewma_alpha,
                }
            ),
        ),
    }


def _score_definition_hash(
    name: str,
    parameters: tuple[tuple[str, int | float], ...],
) -> str:
    definition = {
        "rms": "causal_trailing_root_mean_square",
        "cusum": "causal_two_sided_cumulative_sum",
        "ewma": "causal_absolute_standardized_ewma_mean_shift",
    }[name]
    return _canonical_hash(
        {
            "schema": "dmreda-stage3-baseline-score-definition-v1",
            "detector": name,
            "definition": definition,
            "parameters": dict(parameters),
            "input_contract": "fixed_post_affine_scalar_float64",
        }
    )


def baseline_score_functions(
    noise_bank: Sequence[Sequence[float]],
    *,
    rms_window: int = 32,
    cusum_allowance_sigma: float = 0.5,
    ewma_alpha: float = 2.0 / 33.0,
) -> Mapping[str, ScoreFunction]:
    """Freeze all baseline parameters from the noise-only calibration bank."""

    definitions = _baseline_definitions(
        noise_bank,
        rms_window=rms_window,
        cusum_allowance_sigma=cusum_allowance_sigma,
        ewma_alpha=ewma_alpha,
    )
    return {name: definition[0] for name, definition in definitions.items()}


def calibrate_baseline_suite(
    noise_bank: Sequence[Sequence[float]],
    *,
    gate: EventGateConfig,
    target_restricted_mean_time_to_alarm: float | None = None,
    target_arl_samples: float | None = None,
    rms_window: int = 32,
    cusum_allowance_sigma: float = 0.5,
    ewma_alpha: float = 2.0 / 33.0,
) -> Dict[str, CalibratedBaseline]:
    """Calibrate RMS, two-sided CUSUM, and EWMA on noise-only runs."""

    signals = [_as_finite_signal(run) for run in noise_bank]
    target = _resolve_finite_horizon_target(
        target_restricted_mean_time_to_alarm=target_restricted_mean_time_to_alarm,
        target_arl_samples=target_arl_samples,
    )
    definitions = _baseline_definitions(
        signals,
        rms_window=rms_window,
        cusum_allowance_sigma=cusum_allowance_sigma,
        ewma_alpha=ewma_alpha,
    )
    calibration_bank_hash = signal_bank_hash(signals)
    event_contract = baseline_event_contract(gate)
    calibrated: Dict[str, CalibratedBaseline] = {}
    for name, (score_function, frozen_parameters) in definitions.items():
        score_runs = [score_function(run) for run in signals]
        calibration = calibrate_threshold(
            score_runs,
            gate=gate,
            target_restricted_mean_time_to_alarm=target,
        )
        calibrated[name] = CalibratedBaseline(
            name=name,
            threshold=calibration.threshold,
            calibration=calibration,
            gate=gate,
            score=score_function,
            event_contract=event_contract,
            frozen_parameters=frozen_parameters,
            configuration_hash=_baseline_configuration_hash(
                name=name,
                threshold=calibration.threshold,
                parameters=frozen_parameters,
                gate=gate,
                event_contract=event_contract,
            ),
            calibration_bank_hash=calibration_bank_hash,
        )
    return calibrated


def calibrate_baseline_suite_to_run_risk(
    noise_bank: Sequence[Sequence[float]],
    *,
    gate: EventGateConfig,
    target_false_positive_count: int,
    target_restricted_time_sum: int,
) -> Dict[str, RunRiskCalibratedBaseline]:
    """Calibrate only the scalar thresholds at an exact run-risk target.

    Inputs must already use the frozen affine scaling.  RMS, CUSUM, and EWMA
    retain fixed structural definitions: RMS window 32; CUSUM center 0, scale
    1, and allowance 0.5; EWMA center 0, scale 1, and alpha 2/33.  Unlike the
    historical suite, this path does not estimate nuisance parameters from the
    calibration bank.
    """

    gate.validate()
    signals = tuple(_as_finite_signal(run) for run in noise_bank)
    if not signals:
        raise ValueError("noise_bank must not be empty")
    definitions = _fixed_post_affine_baseline_definitions()
    calibration_bank_hash = signal_bank_hash(signals)
    event_contract = baseline_event_contract(gate)
    calibrated: Dict[str, RunRiskCalibratedBaseline] = {}
    for name, (score_function, frozen_parameters) in definitions.items():
        score_runs = tuple(score_function(run) for run in signals)
        calibration = calibrate_threshold_to_run_risk(
            score_runs,
            gate=gate,
            target_false_positive_count=target_false_positive_count,
            target_restricted_time_sum=target_restricted_time_sum,
        )
        threshold = calibration.threshold
        calibrated[name] = RunRiskCalibratedBaseline(
            name=name,
            threshold=threshold,
            calibration=calibration,
            gate=gate,
            score=score_function,
            event_contract=event_contract,
            frozen_parameters=frozen_parameters,
            configuration_hash=_baseline_configuration_hash(
                name=name,
                threshold=threshold,
                parameters=frozen_parameters,
                gate=gate,
                event_contract=event_contract,
            ),
            calibration_bank_hash=calibration_bank_hash,
            score_definition_hash=_score_definition_hash(name, frozen_parameters),
        )
    return calibrated


def evaluate_baseline_suite(
    baselines: Mapping[str, CalibratedBaseline],
    signal: Sequence[float],
    *,
    onset: int,
) -> Dict[str, RunOutcome]:
    values = _as_finite_signal(signal)
    return {
        name: evaluate_score_trace(
            baseline.score(values),
            threshold=baseline.threshold,
            gate=baseline.gate,
            onset=onset,
        )
        for name, baseline in baselines.items()
    }


def evaluate_dmreda_core_fsm(
    signal: Sequence[float],
    *,
    onset: int,
    core_kwargs: Mapping[str, object] | None = None,
) -> RunOutcome:
    """Evaluate the Core FSM's native confirmed events with first-alarm rules."""

    values = _as_finite_signal(signal)
    result = compute_dmreda_reference(values, **dict(core_kwargs or {}))
    return evaluate_alarm_times(
        result.event_times,
        onset=onset,
        trace_length=values.size,
        warmup_samples=result.warmup_samples,
    )
