"""Gold-line benchmark harnesses."""
