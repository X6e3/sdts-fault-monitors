# Gold Line

`gold_line/` contains the paths whose contracts are explicit enough to test.
Gold Line does not mean that general anomaly-detection superiority is proven.

## DMREDA Core FSM

Canonical source:

- `core/dmreda_reference_clean.py`

Supporting artifacts:

- `core/dmreda_streaming_fixed.h` and `.c` — minimal fixed-state C99 mirror
- `support/dmreda_streaming_fixed_cli.c` — parity-test transport harness
- `core/dmreda_reference.py` — preserved earlier Python reference, superseded by the clean source

The Core FSM path is causal:

```text
fixed-scaled sample
→ trailing median
→ L1 deviation
→ trailing energy
→ adaptive energy baseline
→ normalized deviation D
→ finite-lag growth G
→ regime FSM
→ pending / confirmation
→ refractory / event
```

Warm-up updates internal traces and regime state, but it grants no candidate,
pending, confirmation, or event authority before `t >= warmup_samples`.

## Structural Manifold Detector

Canonical research package:

- `structural_manifold/pqd16c_benchmark.py`
- `structural_manifold/separability_harness.c`

This is a separate family built from sliding multivariate features,
standardization, covariance inversion, Mahalanobis distance, and sequential
accumulation. It is not the DMREDA Core FSM and is not an MCU mirror. The old
benchmark and C filenames remain compatibility entry points only.

## Fair baseline scaffold

`benchmarks/fair_baseline_scaffold.py` provides:

- an independent noise-only calibration boundary;
- one documented external warm-up/persistence/refractory gate for the RMS,
  CUSUM, and EWMA score baselines;
- native Core FSM pending/confirmation/refractory authority rather than the
  baseline gate;
- finite-horizon, right-censored baseline calibration metadata and helpers for
  asserting disjoint bank identity;
- first-confirmed-alarm accounting over the complete trace;
- mutually exclusive false-positive, detection, and miss outcomes.

It is an experiment scaffold, not a result table. A pre-onset alarm consumes the
run; a later post-onset alarm cannot recover detection credit. A claim-grade
Core-versus-baseline experiment must still supply a separate common
operating-risk holdout and a disjoint disturbed-evaluation bank; the scaffold
does not execute that four-role experiment by itself.

## Claim contract

- Inputs follow `docs/INPUT_SCALING_CONTRACT.md`.
- Calibration data and evaluation data are disjoint.
- Operating points are compared by achieved noise-only false-alarm behavior or
  finite-horizon restricted time to first alarm, not by same-trial quantiles.
- Censoring, horizon, target, achieved value, and target deviation are explicit;
  the restricted mean is not presented as uncensored classical ARL.
- Warm-up, persistence, refractory, onset, and delay units are recorded.
- False positives are confirmed events, not raw threshold exceedances.
- Generated outputs live under `results/` and are not source evidence by filename alone.
- `playground/**`, `deprecated/**`, and `near_gold_todo/**` are not claim-grade.

## Validation commands

```bash
python3 -m gold_line.core.dmreda_reference_clean
python3 -m unittest discover -s tests -v
clang -std=c99 -O2 -Wall -Wextra -Werror \
  gold_line/structural_manifold/separability_harness.c -lm \
  -o /tmp/structural_manifold_separability
/tmp/structural_manifold_separability
```

The Structural Manifold PQD benchmark additionally needs NumPy, SciPy,
Matplotlib, and Kaggle only when resampling, plots, or download are requested.
