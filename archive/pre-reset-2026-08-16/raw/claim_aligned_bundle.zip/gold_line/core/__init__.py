"""Gold-line detector cores."""
