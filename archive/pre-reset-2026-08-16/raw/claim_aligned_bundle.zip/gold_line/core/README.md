# DMREDA Core FSM

`dmreda_reference_clean.py` is the canonical executable definition.

`dmreda_reference.py` is retained for provenance but is superseded. New tests,
benchmarks, and ports must target the clean reference.

The C99 files `dmreda_streaming_fixed.h/.c` mirror a deliberately bounded
subset:

- profile 0 only;
- fixed regime state 0;
- fixed `m=4` and confirmation length 20;
- float64 arithmetic;
- default warm-up 92 samples;
- full `D/G → pending → confirm → refractory` event path;
- no heap allocation and no full-signal buffer;
- a compile-time 1 KiB upper bound on the persistent runtime state structure.

The verified persistent `DmredaFixedState` structure is 984 bytes on the tested
arm64 macOS ABI. This is not total runtime RAM: it excludes stack, caller-owned
buffers, C runtime/linker overhead, and target-specific sections. The measured
configuration/output sizes, known median scratch, compiler stack estimate, and
binary sections are recorded in
`../../docs/reports/DMREDA_FIXED_MEMORY_ARM64.md`.

The subset is explicit so parity is falsifiable. The default configuration is
the claim-bearing mirror. Although the C API validates a wider bounded set of
configuration values, those combinations are experimental unless a named test
or fixture covers them. Regime transitions, adaptive `m`, adaptive confirmation
length, fixed-point arithmetic, saturation policy, target peak stack, WCET,
energy, and cycle counts remain separate porting work.

Input samples must already satisfy `../../docs/INPUT_SCALING_CONTRACT.md`.
