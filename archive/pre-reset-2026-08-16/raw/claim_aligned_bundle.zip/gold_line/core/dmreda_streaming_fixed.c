#include "dmreda_streaming_fixed.h"

#include <float.h>
#include <math.h>
#include <string.h>

/* The declared fixed mirror uses IEEE-754 binary64 arithmetic. */
typedef char DmredaFixedDoubleMustBeBinary64[
    (sizeof(double) == 8U && FLT_RADIX == 2 && DBL_MANT_DIG == 53 &&
     DBL_MIN_EXP == -1021 && DBL_MAX_EXP == 1024)
        ? 1
        : -1
];

/* Compile-time guard against accidental growth of the fixed runtime state. */
typedef char DmredaFixedStateMustRemainAtMost1KiB[
    (sizeof(DmredaFixedState) <= 1024U) ? 1 : -1
];

static double clamp_double(double value, double low, double high) {
    if (value < low) {
        return low;
    }
    if (value > high) {
        return high;
    }
    return value;
}

static double ema_update(double previous, double value, double alpha) {
    return alpha * value + (1.0 - alpha) * previous;
}

static int config_is_valid(const DmredaFixedConfig *config) {
    if (config == NULL) {
        return 0;
    }
    if (config->w1 <= 0 || config->w1 > DMREDA_FIXED_MAX_W1 || (config->w1 % 2) != 1) {
        return 0;
    }
    if (config->w2 <= 0 || config->w2 > DMREDA_FIXED_MAX_W2) {
        return 0;
    }
    if (config->m <= 0 || config->m > DMREDA_FIXED_MAX_M) {
        return 0;
    }
    if (config->confirm_len <= 0 || config->n_min <= 0 ||
        config->n_min > config->confirm_len || config->refractory < 0) {
        return 0;
    }
    if (!isfinite(config->beta) || !isfinite(config->rho) || !isfinite(config->lambda) ||
        !isfinite(config->th_d) || !isfinite(config->th_g) || !isfinite(config->th_d2) ||
        !isfinite(config->th_a) || !isfinite(config->e_floor) || !isfinite(config->g_ref) ||
        !isfinite(config->d_min) || !isfinite(config->d_max)) {
        return 0;
    }
    if (config->e_floor <= 0.0 || config->g_ref <= 0.0 || config->d_min > config->d_max) {
        return 0;
    }
    if (config->beta < 0.0 || config->beta > 1.0 || config->rho < 0.0 ||
        config->rho > 1.0 || config->lambda < 0.0 || config->lambda > 1.0) {
        return 0;
    }
    if (config->mode < DMREDA_MODE_D_ONLY || config->mode > DMREDA_MODE_D_OR_G) {
        return 0;
    }
    return 1;
}

static double trailing_median(DmredaFixedState *state, double sample) {
    double sorted[DMREDA_FIXED_MAX_W1];
    int count;
    int index;

    state->sample_ring[state->sample_ring_pos] = sample;
    state->sample_ring_pos = (state->sample_ring_pos + 1) % state->config.w1;
    if (state->sample_ring_count < state->config.w1) {
        state->sample_ring_count += 1;
    }

    count = state->sample_ring_count;
    for (index = 0; index < count; ++index) {
        int insert = index;
        double value = state->sample_ring[index];
        while (insert > 0 && sorted[insert - 1] > value) {
            sorted[insert] = sorted[insert - 1];
            insert -= 1;
        }
        sorted[insert] = value;
    }

    if ((count % 2) != 0) {
        return sorted[count / 2];
    }
    return 0.5 * (sorted[(count / 2) - 1] + sorted[count / 2]);
}

static double trailing_error_sum(DmredaFixedState *state, double error) {
    if (state->error_ring_count == state->config.w2) {
        state->e1_sum -= state->error_ring[state->error_ring_pos];
    } else {
        state->error_ring_count += 1;
    }
    state->error_ring[state->error_ring_pos] = error;
    state->error_ring_pos = (state->error_ring_pos + 1) % state->config.w2;
    state->e1_sum += error;
    return state->e1_sum;
}

static double lagged_growth(DmredaFixedState *state, double d_value) {
    double result = 0.0;
    if (state->d_ring_count == state->config.m) {
        result = d_value - state->d_ring[state->d_ring_pos];
    } else {
        state->d_ring_count += 1;
    }
    state->d_ring[state->d_ring_pos] = d_value;
    state->d_ring_pos = (state->d_ring_pos + 1) % state->config.m;
    return result;
}

static int fast_triggered(const DmredaFixedConfig *config, double d_value, double g_value) {
    if (config->mode == DMREDA_MODE_D_ONLY) {
        return d_value > config->th_d;
    }
    if (config->mode == DMREDA_MODE_G_ONLY) {
        return g_value > config->th_g;
    }
    return (d_value > config->th_d) || (g_value > config->th_g);
}

static void reset_pending(DmredaFixedState *state) {
    state->pending_active = 0;
    state->pending_elapsed = 0;
    state->pending_area = 0.0;
    state->pending_count = 0;
}

static void accumulate_pending(DmredaFixedState *state, double d_value) {
    state->pending_elapsed += 1;
    state->pending_area += fmax(0.0, d_value - state->config.th_d2);
    state->pending_count += d_value > state->config.th_d2 ? 1 : 0;
}

static int pending_is_confirmed(const DmredaFixedState *state) {
    return (state->pending_area > state->config.th_a) &&
           (state->pending_count >= state->config.n_min);
}

DmredaFixedConfig dmreda_fixed_default_config(void) {
    DmredaFixedConfig config;
    config.w1 = 7;
    config.w2 = 16;
    config.beta = 1.0 / 32.0;
    config.rho = 1.0 / 64.0;
    config.m = 4;
    config.lambda = 1.0 / 8.0;
    config.th_d = 0.35;
    config.th_g = 0.10;
    config.th_d2 = 0.20;
    config.th_a = 1.8;
    config.n_min = 6;
    config.e_floor = 2e-2;
    config.confirm_len = 20;
    config.refractory = 80;
    config.g_ref = 0.20;
    config.warmup_samples = 92U;
    config.d_min = -5.0;
    config.d_max = 5.0;
    config.mode = DMREDA_MODE_D_OR_G;
    return config;
}

int dmreda_fixed_init(DmredaFixedState *state, const DmredaFixedConfig *config) {
    if (state == NULL || !config_is_valid(config)) {
        return -1;
    }
    memset(state, 0, sizeof(*state));
    state->config = *config;
    return 0;
}

int dmreda_fixed_step(DmredaFixedState *state, double sample, DmredaFixedOutput *output) {
    const DmredaFixedConfig *config;
    size_t index;
    double d_raw;
    int event_authority_enabled;

    if (state == NULL || output == NULL || !isfinite(sample)) {
        return -1;
    }

    config = &state->config;
    index = state->sample_count;
    memset(output, 0, sizeof(*output));
    output->sample_index = index;

    output->mu = trailing_median(state, sample);
    output->e = fabs(sample - output->mu);
    output->e1 = trailing_error_sum(state, output->e);

    if (index == 0U) {
        state->e_baseline = output->e1;
        state->r = output->e;
    } else {
        state->e_baseline = ema_update(state->e_baseline, output->e1, config->beta);
        state->r = ema_update(state->r, output->e, config->rho);
    }
    output->e_baseline = state->e_baseline;
    output->e_baseline_safe = fmax(state->e_baseline, config->e_floor);
    d_raw = (output->e1 - output->e_baseline_safe) / output->e_baseline_safe;
    output->d = clamp_double(d_raw, config->d_min, config->d_max);
    output->g_raw = lagged_growth(state, output->d);
    state->g = index == 0U ? output->g_raw : ema_update(state->g, output->g_raw, config->lambda);
    output->g = state->g;
    output->r = state->r;
    output->a = clamp_double(fabs(state->g) / config->g_ref, 0.0, 1.0);

    if (state->refractory_remaining > 0) {
        state->refractory_remaining -= 1;
    }

    event_authority_enabled = index >= config->warmup_samples;
    if (event_authority_enabled) {
        if (state->pending_active) {
            output->pending = 1;
            accumulate_pending(state, output->d);
            if (pending_is_confirmed(state)) {
                output->confirmed = 1;
                output->event_active = 1;
                state->refractory_remaining = config->refractory;
                reset_pending(state);
            } else if (state->pending_elapsed >= config->confirm_len) {
                reset_pending(state);
            }
        }

        if (!output->confirmed && !state->pending_active && state->refractory_remaining == 0 &&
            fast_triggered(config, output->d, output->g)) {
            state->pending_active = 1;
            output->pending = 1;
            state->pending_elapsed = 0;
            state->pending_area = 0.0;
            state->pending_count = 0;
            accumulate_pending(state, output->d);
            if (pending_is_confirmed(state)) {
                output->confirmed = 1;
                output->event_active = 1;
                state->refractory_remaining = config->refractory;
                reset_pending(state);
            }
        }
    }

    output->state = 0;
    output->m_eff = config->m;
    output->confirm_len_eff = config->confirm_len;
    state->sample_count += 1U;
    return 0;
}
