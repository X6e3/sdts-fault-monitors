#ifndef DMREDA_STREAMING_FIXED_H
#define DMREDA_STREAMING_FIXED_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif
#define DMREDA_FIXED_MAX_W1 15
#define DMREDA_FIXED_MAX_W2 64
#define DMREDA_FIXED_MAX_M 16

typedef enum {
    DMREDA_MODE_D_ONLY = 0,
    DMREDA_MODE_G_ONLY = 1,
    DMREDA_MODE_D_OR_G = 2
} DmredaFixedMode;

typedef struct {
    int w1;
    int w2;
    double beta;
    double rho;
    int m;
    double lambda;
    double th_d;
    double th_g;
    double th_d2;
    double th_a;
    int n_min;
    double e_floor;
    int confirm_len;
    int refractory;
    double g_ref;
    size_t warmup_samples;
    double d_min;
    double d_max;
    DmredaFixedMode mode;
} DmredaFixedConfig;

typedef struct {
    size_t sample_index;
    double mu;
    double e;
    double e1;
    double e_baseline;
    double e_baseline_safe;
    double d;
    double g_raw;
    double g;
    double r;
    double a;
    int state;
    int m_eff;
    int confirm_len_eff;
    int pending;
    int confirmed;
    int event_active;
} DmredaFixedOutput;

typedef struct {
    DmredaFixedConfig config;
    size_t sample_count;
    double sample_ring[DMREDA_FIXED_MAX_W1];
    int sample_ring_count;
    int sample_ring_pos;
    double error_ring[DMREDA_FIXED_MAX_W2];
    int error_ring_count;
    int error_ring_pos;
    double e1_sum;
    double e_baseline;
    double r;
    double d_ring[DMREDA_FIXED_MAX_M];
    int d_ring_count;
    int d_ring_pos;
    double g;
    int pending_active;
    int pending_elapsed;
    double pending_area;
    int pending_count;
    int refractory_remaining;
} DmredaFixedState;

/* Default profile 0 from dmreda_reference_clean.py, with adaptation disabled. */
DmredaFixedConfig dmreda_fixed_default_config(void);

/* Returns 0 on success and -1 if the fixed-state configuration is invalid. */
int dmreda_fixed_init(DmredaFixedState *state, const DmredaFixedConfig *config);

/*
 * Consumes one already-scaled finite sample. Returns 0 on success and -1 for
 * invalid pointers or a non-finite input sample.
 */
int dmreda_fixed_step(DmredaFixedState *state, double sample, DmredaFixedOutput *output);

#ifdef __cplusplus
}
#endif

#endif
