Recovered core of DMREDA Semantic Memory Tournament V2 from ChatGPT Library.

Purpose: independent benchmark construct-validity audit in a fresh chat.

Included:
- FINAL_SCIENTIFIC_AUDIT.md
- FINAL_RESULTS.json
- TOURNAMENT_V2_PROTOCOL.md
- PRE_FINAL_TOURNAMENT_FREEZE.json
- semantic_memory_v2_gate0_corrected.py
- TRANSFER_RESULTS.json
- RESOURCE_ACCOUNTING.md
- FINAL_EXECUTION_FAILURE_AUDIT.json
- SHA256SUMS

The original SHA256SUMS lists additional tournament artifacts not included in this core bundle. All included original files were checked against the original manifest and matched their expected hashes.
