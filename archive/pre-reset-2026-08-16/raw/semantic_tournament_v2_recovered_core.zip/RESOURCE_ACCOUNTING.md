# Resource accounting — Tournament V2

All recurrence counts are source-level abstract arithmetic, **not** MCU cycles/WCET/energy/latency.

## Shared frontend
- causal trailing median width: 7
- minimum raw history: 7 fp32 = 28 B
- with explicit 32-bit circular index accounting assumption: 32 B persistent
- actual supplied generator uses NumPy batch median; hardware-comparable median operation count/cycles/WCET: **UNKNOWN**

## Method-specific recurrence
| Method | Dynamic state | Static coefficients | mul/sample | add/sub/sample | nonlinear |
|---|---:|---:|---:|---:|---:|
| C4-CASCADE | 16 B | 8 B | 8 | 4 | 0 |
| EWMA4-BANK | 16 B | 32 B | 8 | 4 | 0 |
| LSSM4 dense | 16 B | 80 B | 20 | 16 | 0 |
| NLRES4 | 16 B | 84 B | 28 | 20 | 4 tanh |

Linear 6-class head is identical: 30 parameters, 24 input-weight multiplies/inference. MLP8 is identical: 94 parameters, 80 multiplies/inference under the frozen accounting.
