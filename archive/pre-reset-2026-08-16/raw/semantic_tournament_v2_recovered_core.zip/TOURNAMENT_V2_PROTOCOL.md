# C4 vs LSSM4 Semantic Memory Tournament V2 — frozen confirmatory protocol

## Starting evidence lock
- Corrected generator source SHA-256: `d84e8f4614a0051eed448dc702d213c08af700ec39801bc1dd0e2efb460bea49`
- Corrected Gate-0 audit SHA-256: `d54b4ec4b5613fe36de41c8556b1b5c09ff73f765680f662a38aad471e408cbc`
- Gate 0 must be `GENERATOR_V2_ACCEPTED`; FINAL must not have been accessed by Gate 0.
- The generator source is imported read-only and is not modified by this tournament.

## Scientific question
Given identical causal residual input and exactly four fp32 dynamic states, which frozen recurrence preserves the most task-decodable semantic temporal history on unseen trajectory realizations?
C4 is a strict structured subset of general LSSM4; any C4 advantage is interpreted as finite-data/structured-prior behavior, never greater expressivity.

## Common frontend and nominal observation
All methods receive exactly the same generator-produced `e_t = |x_t - median(x[t-6:t])|`. Competition begins at `e_t -> S_t`.
The nominal primary observation is the generator trace end. Since BODY_STOP=832 and TRACE_LENGTH=1088, nominal class-independent post-body horizon is H=256 samples.
Shared frontend resource cost is reported separately and is never hidden from total-footprint discussion.

## Recurrence families (unchanged from Tournament V1)
1. C4-CASCADE: repeated-pole 4-stage causal cascade, one temporal parameter a.
2. EWMA4-BANK: four independent exponential memories.
3. LSSM4: stable dense `S'=A S + b e`; 63 frozen general candidates plus one preregistered exact-C4 anchor slot. The anchor slot is defined *before CAL* as "materialize the CAL-selected C4 candidate exactly". Its numeric coefficients are therefore a deterministic dependency, not a result-dependent LSSM redesign. LSSM still receives exactly 64 candidate evaluations.
4. NLRES4: bounded four-state tanh reservoir recurrence from V1.

Every primary recurrence has exactly four fp32 dynamic states = 16 B. Persistent auxiliary state is forbidden. Coefficients are static and separately charged.

## Candidate/search budget
Exactly 64 candidate slots per family. Candidate count equality is search/data-exposure equality, not degrees-of-freedom equality.
All candidate manifests, including the symbolic LSSM anchor rule, are written and hashed before any CAL accuracy is inspected. No family is regenerated after poor CAL performance.

## Heads
Primary: V1 ridge-linear one-hot 6-class readout, ridge=0.001; feature mean/std fit on TRAIN only.
Secondary: 4D -> tanh(8) -> 6 MLP using V1 discipline (`lbfgs`, alpha=1e-4, max_iter=1500, random_state=952000001). Recurrence configuration is never retuned for MLP8.
For FINAL and all transfer/retention characterization, both recurrence and readout weights/scalers are frozen from TRAIN/CAL procedure before FINAL.

## Selection
Each candidate is run on TRAIN for both co-primary tasks; an identical TRAIN-fitted linear head is evaluated on CAL. One recurrence winner per family is selected by mean CAL accuracy over Task A and Task B. No task-specific recurrence tuning.
Tie-break: higher frozen mean CAL metric; lower coefficient bytes; lower recurrence arithmetic rank; lexical candidate ID.
Standardization/readout parameters for selected winners and the secondary MLP8 heads are frozen before FINAL.

## FINAL access discipline
FINAL reserved seed range: `(940000001, 192)`. FINAL is not generated until `PRE_FINAL_TOURNAMENT_FREEZE.json` exists and validates.
A one-shot `FINAL_ACCESS_LOCK.json` is created before generating FINAL. No architecture, candidate, generator, threshold, seed, or head change is permitted after FINAL access.
Final validity audit must confirm: no label-free `(gaps,symbols)` overlap with DEV/TRAIN/CAL, no symbols-only overlap, exact Task-B reconstructed semantic correctness, and class-independent last-96 raw/residual equality. Failure invalidates the run; there is no alternate-seed retry.

## Primary statistics
For each task/method: accuracy, balanced accuracy, confusion matrix, and per-independent-seed block utility.
For all 6 unordered method pairs x 2 tasks (12 primary comparisons), a single max-statistic family-wise simultaneous 95% confidence band is computed from seed-block bootstrap (reps=30000, seed=951000001).
For C4-vs-competitor d=C4-competitor:
- meaningful C4 superiority: lower simultaneous 95% bound > +0.02;
- competitor non-inferiority to C4 at margin 0.02: upper simultaneous 95% bound < +0.02;
- competitor superiority: upper simultaneous 95% bound < 0.
Failure of superiority is not equivalence or non-inferiority.
Practical two-sided equivalence within ±0.02 requires lower>-0.02 and upper<+0.02.

## Retention curve (characterization; no retuning)
Frozen recurrence + frozen nominal head is evaluated at H=(32, 64, 96, 128, 160, 192, 256) samples after BODY_STOP. No horizon-specific refit. H=256 is nominal. Per-seed utility and C4-LSSM differences are retained.

## Predeclared destructive transfer (characterization; no retuning)
{
  "amplitude_scale_1p25": {
    "factor": 1.25,
    "kind": "amplitude_scale"
  },
  "body_shift_plus24": {
    "kind": "shift",
    "samples": 24
  },
  "common_noise_sigma_0p006": {
    "kind": "noise",
    "seed_xor": 336337654597,
    "sigma": 0.006
  },
  "event_jitter_pm1": {
    "kind": "jitter",
    "max_abs_samples": 1,
    "seed_xor": 81678807876946
  },
  "spacing_compress_0p90": {
    "factor": 0.9,
    "kind": "spacing_scale"
  },
  "spacing_dilate_1p10": {
    "factor": 1.1,
    "kind": "spacing_scale"
  }
}
Transformations preserve label/semantic trajectory order; they modify only temporal coordinates/amplitude/noise. The original generator is not changed. Same frozen recurrence and same frozen heads are used.

## Resource accounting
Method-specific source-level recurrence counts are verified against V1 equations. They are not MCU cycles, WCET, energy, or measured latency.
Shared median frontend: minimum data history is 7 fp32 raw values = 28 B, plus a streaming circular index/bookkeeping if implemented online; the supplied generator uses NumPy batch median, so a hardware-comparable median operation count/cycles/WCET is UNKNOWN rather than invented.
Scientific representation winner and engineering Pareto interpretation are reported separately.

## Interpretation
- LSSM decisive robust win -> `C4_SPECIAL_GEOMETRY_NOT_SUPPORTED`.
- C4/LSSM practically equivalent nominally with C4 lower burden and no worse transfer/retention -> `C4_STRUCTURED_PRIOR_ENGINEERING_SUPPORTED`.
- C4 decisive unseen-semantic generalization win -> `C4_STRUCTURED_PRIOR_GENERALIZATION_ADVANTAGE`, never `C4_MORE_EXPRESSIVE`.
- EWMA4 equivalence/non-inferiority is important negative evidence against special cascade chronology.
- All four methods near chance -> `FOUR_STATE_SEMANTIC_MEMORY_NOT_ESTABLISHED` (descriptive judgment, not rescued).
- Nominal-only winner that collapses on transfer is reported as possible realization/geometry specialization.

## No rescue
No post-FINAL new recurrence/state/feature/generator/search bank/head/seed fishing. Post-hoc diagnostics may not alter the frozen result and must be labeled diagnostic.
