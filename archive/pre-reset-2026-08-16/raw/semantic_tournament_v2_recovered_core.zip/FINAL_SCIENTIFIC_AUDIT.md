# Tournament V2 — final scientific audit

## Integrity status
- All **pre-FINAL scientific contracts** validated: corrected generator and Gate-0 hashes matched, candidate manifests were written/hashed before CAL inspection, generator source was not modified, one winner per family was selected from TRAIN→CAL only, and the exact C4 anchor matched C4 state bit-for-bit on TRAIN/CAL.
- FINAL validity gates passed: zero label-free `(gaps,symbols)` or symbols-only overlap with DEV/TRAIN/CAL; Task-B actual/reconstructed Kendall semantics passed with zero mismatch; last-96 raw/residual mismatch was 0.0.
- There was one **operational process defect**: the first FINAL process hit a mechanical retention-helper arity error after nominal scores existed only in memory and before any FINAL score/result artifact was emitted. The exact same reserved seeds and frozen configuration were deterministically replayed after an explicit failure audit. This violates literal one-shot execution discipline and must remain in provenance; it did not introduce an alternate seed/config/search choice.
- All eight MLP8 fits reached the frozen `max_iter=1500` limit. The secondary MLP8 numbers are therefore descriptive and optimizer-limited; the primary ridge-linear tournament is unaffected.

## Frozen selections
- C4-CASCADE: `c4_39`; tau=292.131919, a=0.996582741119
- EWMA4-BANK: `ewma_48`; taus=[64.25924145734146, 74.25878940354586, 219.72659922561348, 226.83819840949252]
- LSSM4: `lssm_non_15`; kind=nonnormal
- NLRES4: `nlres_32`; rho=0.349172, leak=0.010000, input_gain=2.044497

## Primary FINAL accuracy (chance = 16.67%)

| Method | Task A | Task B |
|---|---:|---:|
| C4-CASCADE | 20.92% | 16.84% |
| EWMA4-BANK | 18.14% | 16.93% |
| LSSM4 | 20.05% | 16.93% |
| NLRES4 | 18.14% | 16.49% |

Balanced accuracy is numerically identical here because the FINAL bank is class-balanced.

## Simultaneous family-wise 95% bounds for C4 minus comparator

| Comparison | Task | point | simultaneous 95% |
|---|---|---:|---:|
| C4 - LSSM4 | A_global_order_relation | +0.0087 | [-0.0191, +0.0365] |
| C4 - LSSM4 | B_persistence_recovery_coupling | -0.0009 | [-0.0286, +0.0269] |
| C4 - EWMA4-BANK | A_global_order_relation | +0.0278 | [+0.0000, +0.0556] |
| C4 - EWMA4-BANK | B_persistence_recovery_coupling | -0.0009 | [-0.0286, +0.0269] |
| C4 - NLRES4 | A_global_order_relation | +0.0278 | [-0.0000, +0.0556] |
| C4 - NLRES4 | B_persistence_recovery_coupling | +0.0035 | [-0.0243, +0.0312] |

No C4-vs-major-comparator comparison establishes meaningful superiority at +0.02 on both co-primary tasks. No competitor establishes the frozen 0.02 non-inferiority gate to C4 on both tasks either; the simultaneous upper bounds remain above +0.02. Thus the primary tournament has **no recurrence-form winner**.

## Secondary MLP8 characterization

| Method | Task A | Task B |
|---|---:|---:|
| C4-CASCADE | 19.36% | 19.44% |
| EWMA4-BANK | 16.41% | 16.93% |
| LSSM4 | 19.01% | 16.58% |
| NLRES4 | 17.01% | 18.06% |

All MLP8 fits hit the frozen iteration cap; do not use these figures for a superiority claim.

## Retention/transfer interpretation
- With the **same nominal-horizon head** frozen, H=32..192 performance is mostly around chance for both C4 and LSSM; at nominal H=256 Task A rises to C4 20.92% and LSSM 20.05%. Because the readout itself was fitted at H=256, this curve mixes state retention with horizon/readout alignment and is not a monotonic information-decay measurement.
- Task B remains essentially at chance across retention horizons.
- On Task A, spacing compression/dilation drops C4 by about 4.25 pp and LSSM by about 3.4 pp to roughly chance. Common noise drops C4 by 1.56 pp and LSSM by 4.17 pp. No robust transfer advantage is established.
- Task B transfer scores remain close to chance for every method; small positive/negative deltas are not evidence of semantic robustness.

## Resource view
- Shared causal median frontend: minimum 7 fp32 history = 28 B; with an explicit 32-bit circular index assumption, ~32 B persistent. Supplied NumPy median does not justify an MCU cycle/WCET/energy number.
- C4: 16 B dynamic + ~8 B coefficients; 8 mul + 4 add/sub/sample.
- EWMA4: 16 B dynamic + ~32 B coefficients; 8 mul + 4 add/sub/sample.
- LSSM4 dense: 16 B dynamic + ~80 B coefficients; 20 mul + 16 add/sub/sample.
- NLRES4: 16 B dynamic + ~84 B coefficients; 28 mul + 20 add/sub + 4 tanh/sample.

## Claim status
- `C4_STRUCTURED_PRIOR_GENERALIZATION_ADVANTAGE`: **NOT ESTABLISHED**.
- `GENERAL_LSSM4_SCIENTIFIC_WIN`: **NOT ESTABLISHED**.
- `C4_SPECIAL_GEOMETRY_SUPPORTED`: **NOT ESTABLISHED**.
- `EWMA4_NONINFERIOR_TO_C4_AT_DELTA_0p02`: **NOT ESTABLISHED** (formal NI gate fails even though point estimates are close).
- `FOUR_STATE_SEMANTIC_MEMORY_ACROSS_BOTH_CO_PRIMARY_TASKS`: **NOT ESTABLISHED**. Task A contains weak above-chance signal for C4/LSSM, but Task B is essentially chance for all four methods.
- Post-hoc seed-block chance diagnostics (not confirmatory) put C4 Task-A accuracy at 20.92% with percentile interval about [19.18%,22.66%] and LSSM at 20.05% [18.32%,21.88%], while Task-B intervals straddle chance. This does not create a method winner or rescue the co-primary claim.

## Concise scientific verdict
**On the corrected unseen-realization semantic generator, the frozen four-state recurrences do not separate decisively: C4 and LSSM are statistically indistinguishable under the preregistered simultaneous bounds, Task B is at chance for all methods, and the broader four-state semantic-memory claim is not established across both co-primary tasks.**
