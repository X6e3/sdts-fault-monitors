from __future__ import annotations

import collections
import hashlib
import itertools
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

OUT = Path('/mnt/data/c4_semantic_v2_gate0_corrected')
OUT.mkdir(parents=True, exist_ok=True)

# ----------------------------- PREDECLARED GATE-0 CONTRACT -----------------------------
SCHEMA = 'c4.semantic-memory-tournament.v2.generator-gate0.5-semantic-fix'
N_CLASSES = 6
MEDIAN_WIDTH = 7
BODY_START = 64
BODY_LENGTH = 768
BODY_STOP = BODY_START + BODY_LENGTH
TRACE_LENGTH = 1088
SUFFIX_HARD = 96
PULSE_COUNT = 96
WINDOW_WIDTHS = (8, 16, 24, 32, 48, 64, 96)
SPLITS = {
    'dev': (910_000_001, 48),
    'train': (920_000_001, 96),
    'cal': (930_000_001, 96),
    # Reserved only. Gate-0 code intentionally never generates this range.
    'final_reserved': (940_000_001, 192),
}
RIDGE = 1e-3
CHANCE = 1.0 / N_CLASSES

# Thresholds frozen before executing this source.
THRESH = {
    'ngram_linear_max': 0.35,
    'spectral_4real_max': 0.35,
    'simple_stats_max': 0.35,
    'local_window_max': {
        8: 0.35, 16: 0.35, 24: 0.35, 32: 0.35,
        48: 0.40, 64: 0.45, 96: 0.50,
    },
    # exact-signature lookup is considered dangerous only if it generalizes materially
    'signature_lookup_min_cal_coverage': 0.10,
    'signature_lookup_max_covered_accuracy': 0.80,
}

TASKS = ('A_global_order_relation', 'B_persistence_recovery_coupling')
A_NAMES = (
    'strong_concordance', 'moderate_concordance', 'weak_concordance',
    'weak_discordance', 'moderate_discordance', 'strong_discordance',
)
B_NAMES = (
    'strong_aligned_recovery', 'moderate_aligned_recovery', 'weak_aligned_recovery',
    'weak_opposed_recovery', 'moderate_opposed_recovery', 'strong_opposed_recovery',
)
# Kendall inversion-count target centers; per-realization jitter is allowed around them.
A_K_CENTERS = (85, 280, 470, 658, 848, 1043)  # max for n=48 is 1128
A_K_JITTER = 28
B_K_CENTERS = (0, 1, 2, 4, 5, 6)  # max for n=4 is 6
B_K_JITTER = 0

# Fixed numeric baseline copied from the frozen upstream generator equations.
def baseline_trace(seed: int) -> np.ndarray:
    index = np.arange(TRACE_LENGTH, dtype=np.int64)
    phase = int(seed % 53)
    triangle = 26 - np.abs(((index + phase) % 52) - 26)
    staircase = ((index + (seed % 23)) // 13) % 9
    saw = (index + (seed % 17)) % 17
    codes = 1880 + 5 * triangle + 3 * staircase + saw
    return codes.astype(np.float64) / 4096.0


def causal_median_residual_batch(raw: np.ndarray, width: int = MEDIAN_WIDTH) -> Tuple[np.ndarray, np.ndarray]:
    raw = np.asarray(raw, np.float64)
    med = np.empty_like(raw)
    for t in range(width - 1):
        med[:, t] = np.median(raw[:, :t + 1], axis=1)
    sw = sliding_window_view(raw, width, axis=1)
    med[:, width - 1:] = np.median(sw, axis=2)
    e = np.abs(raw - med)
    return med, e


def irregular_pulse_positions(seed: int) -> np.ndarray:
    # Seed changes timing itself, not only amplitudes. No fixed pulse lattice.
    rng = np.random.default_rng(int(seed) ^ 0x6C415454494345)
    gaps = rng.integers(7, 9, size=PULSE_COUNT - 1, endpoint=False, dtype=np.int64)
    span = int(np.sum(gaps))
    slack = BODY_LENGTH - span - 1
    if slack <= 0:
        raise AssertionError(('pulse span overflow', span, BODY_LENGTH))
    offset = int(rng.integers(0, slack + 1))
    pos = np.empty(PULSE_COUNT, np.int64)
    pos[0] = BODY_START + offset
    pos[1:] = pos[0] + np.cumsum(gaps)
    if pos[-1] >= BODY_STOP:
        raise AssertionError(('pulse positions overflow', pos[-1], BODY_STOP))
    return pos


def realize_group_irregular(seed: int, amplitude_rows: np.ndarray, positions: np.ndarray) -> np.ndarray:
    amp = np.asarray(amplitude_rows, np.float64)
    if amp.ndim != 2 or amp.shape[1] != PULSE_COUNT or positions.shape != (PULSE_COUNT,):
        raise ValueError('rows x PULSE_COUNT amplitudes required')
    base = baseline_trace(seed)
    # min pulse gap >= MEDIAN_WIDTH, so the previous injected pulse is never in
    # the next pulse's causal-median support. Prediction can therefore be computed
    # once from the common seed baseline and shared by every class.
    predicted = np.empty(PULSE_COUNT, np.float64)
    sentinel = np.float64(4.0)
    for j,index in enumerate(positions.tolist()):
        st=max(0,index-MEDIAN_WIDTH+1)
        predicted[j]=float(np.median(np.concatenate([base[st:index],np.asarray([sentinel])])) )
    raw=np.repeat(base[None,:],amp.shape[0],axis=0)
    raw[:,positions]=predicted[None,:]+amp
    return raw


def inversion_count(p: Sequence[int]) -> int:
    x = list(map(int, p))
    return sum(1 for i in range(len(x)) for j in range(i + 1, len(x)) if x[i] > x[j])


def permutation_with_inversions(n: int, K: int, rng: np.random.Generator) -> np.ndarray:
    maxk = n * (n - 1) // 2
    if not (0 <= K <= maxk):
        raise ValueError((n, K, maxk))
    # Random feasible Lehmer/inversion vector with exact total K.
    digits: List[int] = []
    rem = int(K)
    for i in range(n):
        cap = n - 1 - i
        future_max = (cap - 1) * cap // 2 if cap > 0 else 0
        lo = max(0, rem - future_max)
        hi = min(cap, rem)
        if lo > hi:
            raise AssertionError(('lehmer infeasible', i, rem, lo, hi))
        d = int(rng.integers(lo, hi + 1)) if hi > lo else lo
        digits.append(d)
        rem -= d
    if rem != 0:
        raise AssertionError(('lehmer remainder', rem, digits))
    items = list(range(n))
    perm: List[int] = []
    for d in digits:
        perm.append(items.pop(d))
    if inversion_count(perm) != K:
        raise AssertionError(('bad inversion construction', K, inversion_count(perm)))
    return np.asarray(perm, np.int64)


def kendall_tau_from_distance(n: int, K: int) -> float:
    pairs = n * (n - 1) / 2.0
    return float(1.0 - 2.0 * K / pairs)


def amplitude_pool(seed: int, n: int) -> np.ndarray:
    rng = np.random.default_rng(int(seed) ^ 0x414D504C49545544)
    codes = rng.choice(np.arange(384, 1408, dtype=np.int64), size=n, replace=False)
    return np.sort(codes.astype(np.float64) / 4096.0)


def rank_quartile_symbols(rank_order: np.ndarray, n_ranks: int) -> np.ndarray:
    q = np.floor(4.0 * np.asarray(rank_order, np.float64) / n_ranks).astype(np.int64)
    return np.clip(q, 0, 3)


def task_a_realization(seed: int, class_idx: int) -> Tuple[np.ndarray, np.ndarray, dict]:
    rng = np.random.default_rng((int(seed) * 0x9E3779B1 + class_idx * 0x85EBCA77 + 0xA2) & 0xFFFFFFFFFFFFFFFF)
    base_amp = amplitude_pool(seed, 48)
    p = rng.permutation(48)
    center = A_K_CENTERS[class_idx]
    jitter = int(rng.integers(-A_K_JITTER, A_K_JITTER + 1))
    K = int(np.clip(center + jitter, 0, 1128))
    rel = permutation_with_inversions(48, K, rng)
    q = p[rel]
    ranks = np.concatenate([p, q])
    amps = base_amp[ranks]
    symbols = rank_quartile_symbols(ranks, 48)
    meta = {
        'semantic': A_NAMES[class_idx],
        'kendall_distance': K,
        'kendall_tau': kendall_tau_from_distance(48, K),
        'first_perm_hash': hashlib.sha256(np.asarray(p, np.int16).tobytes()).hexdigest(),
        'second_perm_hash': hashlib.sha256(np.asarray(q, np.int16).tobytes()).hexdigest(),
    }
    return amps, symbols, meta


SUM48_PARTITIONS = tuple(c for c in itertools.combinations(range(6,25),4) if sum(c)==48)
if not SUM48_PARTITIONS:
    raise RuntimeError('sum48 partition table empty')

def seed_b_partitions(seed:int)->Tuple[np.ndarray,np.ndarray]:
    rng=np.random.default_rng(int(seed)^0x52554E50415254)
    hi=np.asarray(SUM48_PARTITIONS[int(rng.integers(0,len(SUM48_PARTITIONS)))],np.int64)
    lo=np.asarray(SUM48_PARTITIONS[int(rng.integers(0,len(SUM48_PARTITIONS)))],np.int64)
    return hi,lo


def task_b_realization(seed: int, class_idx: int) -> Tuple[np.ndarray, np.ndarray, dict]:
    rng = np.random.default_rng((int(seed) * 0xD1B54A32 + class_idx * 0x94D049BB + 0xB2) & 0xFFFFFFFFFFFFFFFF)
    high_vals, low_vals = seed_b_partitions(seed)
    high_rank_order = rng.permutation(4)
    center = B_K_CENTERS[class_idx]
    jitter = int(rng.integers(-B_K_JITTER, B_K_JITTER + 1))
    K = int(np.clip(center + jitter, 0, 6))
    rel = permutation_with_inversions(4, K, rng)
    # rel is defined in high-rank-sorted coordinates. Assign low ranks to the
    # positions obtained by sorting the actual high ranks; this guarantees that
    # the paired Kendall distance between high_lengths[i] and low_lengths[i]
    # equals inversion_count(rel).
    low_rank_order = np.empty(4, dtype=np.int64)
    high_sorted_positions = np.argsort(high_rank_order)
    low_rank_order[high_sorted_positions] = rel
    high_lengths = high_vals[high_rank_order]
    low_lengths = low_vals[low_rank_order]
    bits: List[int] = []
    for h, l in zip(high_lengths.tolist(), low_lengths.tolist(), strict=True):
        bits.extend([1] * int(h))
        bits.extend([0] * int(l))
    symbols = np.asarray(bits, np.int64)
    if symbols.shape != (96,) or int(np.sum(symbols)) != 48:
        raise AssertionError(('bad B symbolic length/count', symbols.shape, int(np.sum(symbols))))
    # The topology is defined on a cycle; randomizing the observation phase creates
    # new temporal realizations without changing the circular exposure/recovery coupling semantic.
    # This prevents the finite set of run-order constructions from recurring as exact linear codewords.
    phase = int(rng.integers(0, 96))
    symbols = np.roll(symbols, phase)
    pool = amplitude_pool(seed ^ 0x3333, 96)
    low_pool = pool[:48].copy(); high_pool = pool[48:].copy()
    # Seed-only shuffles shared by all classes: topology changes placement, not an extra class RNG channel.
    shared = np.random.default_rng(int(seed) ^ 0x42414E4B)
    shared.shuffle(low_pool); shared.shuffle(high_pool)
    li = hi = 0
    amps = np.empty(96, np.float64)
    for i, bit in enumerate(symbols.tolist()):
        if bit:
            amps[i] = high_pool[hi]; hi += 1
        else:
            amps[i] = low_pool[li]; li += 1
    meta = {
        'semantic': B_NAMES[class_idx],
        'kendall_distance': K,
        'kendall_tau': kendall_tau_from_distance(4, K),
        'high_lengths': high_lengths.tolist(),
        'low_lengths': low_lengths.tolist(),
        'high_multiset': high_vals.tolist(),
        'low_multiset': low_vals.tolist(),
        'circular_run_count': 8,
        'observation_phase': phase,
    }
    return amps, symbols, meta


def trajectory_identity(task: str, positions: np.ndarray, symbols: np.ndarray) -> str:
    # Label-free realization identity: temporal coordinate pattern + symbols only.
    # No semantic label/metric is allowed to distinguish otherwise identical trajectories.
    payload = {
        'task': task,
        'gaps': np.diff(positions).astype(int).tolist(),
        'symbols': np.asarray(symbols, np.int64).astype(int).tolist(),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def symbols_identity(task: str, symbols: np.ndarray) -> str:
    payload = {
        'task': task,
        'symbols': np.asarray(symbols, np.int64).astype(int).tolist(),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def generate_group(seed: int, task: str) -> dict:
    positions = irregular_pulse_positions(seed)
    amp_rows=[]; labels=[]; symbols=[]; metas=[]; ids=[]; symbol_ids=[]
    for c in range(N_CLASSES):
        if task == TASKS[0]:
            amps, sym, meta = task_a_realization(seed, c)
            label = A_NAMES[c]
        elif task == TASKS[1]:
            amps, sym, meta = task_b_realization(seed, c)
            label = B_NAMES[c]
        else:
            raise ValueError(task)
        amp_rows.append(amps); labels.append(label); symbols.append(sym); metas.append(meta)
        ids.append(trajectory_identity(task, positions, sym))
        symbol_ids.append(symbols_identity(task, sym))
    raw=realize_group_irregular(seed,np.stack(amp_rows),positions).astype(np.float32)
    med,e=causal_median_residual_batch(raw.astype(np.float64),MEDIAN_WIDTH)
    return {
        'raw':raw,'median':med.astype(np.float32),'e':e.astype(np.float32),
        'labels':np.asarray(labels),'symbols':symbols,'meta':metas,'trajectory_id':ids,'symbols_id':symbol_ids,
        'seed':int(seed),'positions':positions.astype(np.int64),
    }


def build_split(split: str, task: str) -> dict:
    if split == 'final_reserved':
        raise RuntimeError('Gate-0 must not generate FINAL')
    start,n=SPLITS[split]
    rr=[]; ee=[]; mm=[]; yy=[]; seeds=[]; syms=[]; metas=[]; ids=[]; symbol_ids=[]; positions=[]
    for seed in range(start,start+n):
        g=generate_group(seed,task)
        rr.append(g['raw']); ee.append(g['e']); mm.append(g['median']); yy.append(g['labels'])
        seeds.extend([seed]*N_CLASSES); syms.extend(g['symbols']); metas.extend(g['meta']); ids.extend(g['trajectory_id']); symbol_ids.extend(g['symbols_id'])
        positions.extend([g['positions']]*N_CLASSES)
    return {
        'raw':np.concatenate(rr),'e':np.concatenate(ee),'median':np.concatenate(mm),'labels':np.concatenate(yy),
        'seeds':np.asarray(seeds,np.int64),'symbols':syms,'meta':metas,'trajectory_id':np.asarray(ids),'symbols_id':np.asarray(symbol_ids),
        'positions':positions,
    }


def ridge_fit_predict(Xtr,ytr,Xev,ridge=RIDGE):
    classes=np.asarray(sorted(set(ytr.tolist()))); cmap={c:i for i,c in enumerate(classes)}
    yi=np.asarray([cmap[x] for x in ytr],np.int64)
    A=np.asarray(Xtr,np.float64); B=np.asarray(Xev,np.float64)
    mu=A.mean(0); sd=A.std(0); sd=np.where(sd<1e-12,1.0,sd)
    A=(A-mu)/sd; B=(B-mu)/sd
    Z=np.c_[A,np.ones(len(A))]; Zb=np.c_[B,np.ones(len(B))]
    Y=np.eye(len(classes))[yi]
    G=Z.T@Z + ridge*np.eye(Z.shape[1]); G[-1,-1]-=ridge
    try: W=np.linalg.solve(G,Z.T@Y)
    except np.linalg.LinAlgError: W=np.linalg.pinv(G)@(Z.T@Y)
    return classes[np.argmax(Zb@W,axis=1)]


def nearest_centroid_predict(Xtr,ytr,Xev):
    A=np.asarray(Xtr,np.float64); B=np.asarray(Xev,np.float64)
    mu=A.mean(0); sd=A.std(0); sd=np.where(sd<1e-12,1.0,sd)
    A=(A-mu)/sd; B=(B-mu)/sd
    classes=np.asarray(sorted(set(ytr.tolist())))
    cent=np.stack([A[ytr==c].mean(0) for c in classes])
    d=((B[:,None,:]-cent[None,:,:])**2).sum(2)
    return classes[np.argmin(d,axis=1)]


def hash_ngram_features(symbols: Sequence[np.ndarray], n: int, dim: int=512) -> np.ndarray:
    X=np.zeros((len(symbols),dim),np.float32)
    for row,s in enumerate(symbols):
        a=np.asarray(s,np.int64)
        for i in range(len(a)-n+1):
            ng=tuple(int(x) for x in a[i:i+n])
            h=hashlib.blake2b(repr(ng).encode(),digest_size=8,person=b'ngramv2').digest()
            idx=int.from_bytes(h,'little')%dim
            X[row,idx]+=1.0
    return X


def exact_ngram_signature(s: np.ndarray,n:int) -> Tuple[Tuple[Tuple[int,...],int],...]:
    a=np.asarray(s,np.int64); c=collections.Counter(tuple(int(x) for x in a[i:i+n]) for i in range(len(a)-n+1))
    return tuple(sorted((k,int(v)) for k,v in c.items()))


def ngram_audit(train:dict,cal:dict)->dict:
    out={}
    for n in range(1,9):
        # exact signature lookup threat
        mapping:Dict[object,List[str]]={}
        for s,y in zip(train['symbols'],train['labels'],strict=True): mapping.setdefault(exact_ngram_signature(s,n),[]).append(str(y))
        pure={k:collections.Counter(v).most_common(1)[0][0] for k,v in mapping.items()}
        covered=0; correct=0
        for s,y in zip(cal['symbols'],cal['labels'],strict=True):
            sig=exact_ngram_signature(s,n)
            if sig in pure:
                covered+=1; correct+=int(pure[sig]==str(y))
        coverage=covered/len(cal['labels']); covacc=(correct/covered if covered else None)
        # linear motif-count attack (deterministically hashed sparse-ish counts)
        Xtr=hash_ngram_features(train['symbols'],n); Xca=hash_ngram_features(cal['symbols'],n)
        pred=ridge_fit_predict(Xtr,train['labels'],Xca)
        acc=float(np.mean(pred==cal['labels']))
        dangerous_lookup=bool(coverage>=THRESH['signature_lookup_min_cal_coverage'] and covacc is not None and covacc>THRESH['signature_lookup_max_covered_accuracy'])
        out[str(n)]={'exact_signature_cal_coverage':coverage,'exact_signature_covered_accuracy':covacc,'hashed_count_linear_cal_accuracy':acc,
                     'lookup_fail':dangerous_lookup,'linear_fail':bool(acc>THRESH['ngram_linear_max'])}
    return out


def _all_start_nc_accuracies(Xfit:np.ndarray,yfit:np.ndarray,Xev:np.ndarray,yev:np.ndarray,w:int,starts:List[int])->np.ndarray:
    # Exact standardized-nearest-centroid window scores, vectorized with cumulative
    # per-time squared distances. Standardization is per absolute sample coordinate;
    # for a selected window this is identical to fitting scaling on that window.
    A=np.asarray(Xfit,np.float64); B=np.asarray(Xev,np.float64)
    mu=A.mean(0); sd=A.std(0); sd=np.where(sd<1e-12,1.0,sd)
    A=(A-mu)/sd; B=(B-mu)/sd
    classes=np.asarray(sorted(set(yfit.tolist())))
    cent=np.stack([A[yfit==c].mean(0) for c in classes])
    # ev x class x time
    sq=(B[:,None,:]-cent[None,:,:])**2
    cs=np.concatenate([np.zeros((len(B),len(classes),1)),np.cumsum(sq,axis=2)],axis=2)
    out=[]
    for st in starts:
        d=cs[:,:,st+w]-cs[:,:,st]
        pred=classes[np.argmin(d,axis=1)]
        out.append(float(np.mean(pred==yev)))
    return np.asarray(out,np.float64)

def select_and_eval_local_window(dev:dict,train:dict,cal:dict,modality:str,w:int)->dict:
    # Start location selected without CAL: fit on DEV, choose by TRAIN.
    Xd=dev[modality]; Xt=train[modality]; Xc=cal[modality]
    starts=list(range(BODY_START, BODY_STOP-w+1, 4))
    if starts[-1] != BODY_STOP-w: starts.append(BODY_STOP-w)
    scores=_all_start_nc_accuracies(Xd,dev['labels'],Xt,train['labels'],w,starts)
    bi=int(np.argmax(scores)); st=int(starts[bi]); sel=float(scores[bi])
    Xfit=np.concatenate([Xd,Xt],axis=0); yfit=np.concatenate([dev['labels'],train['labels']])
    nc=float(_all_start_nc_accuracies(Xfit,yfit,Xc,cal['labels'],w,[st])[0])
    pred_ridge=ridge_fit_predict(Xfit[:,st:st+w],yfit,Xc[:,st:st+w])
    rg=float(np.mean(pred_ridge==cal['labels']))
    return {'selected_start_by_dev_to_train_nc':st,'selection_train_accuracy':sel,'cal_nearest_centroid_accuracy':nc,
            'cal_ridge_accuracy_at_selected_start':rg,'cal_attack_accuracy':max(nc,rg),'threshold':THRESH['local_window_max'][w],
            'accepted':bool(max(nc,rg)<=THRESH['local_window_max'][w])}


def local_window_audit(dev:dict,train:dict,cal:dict)->dict:
    out={}
    for mod in ('raw','e'):
        out[mod]={}
        for w in WINDOW_WIDTHS:
            out[mod][str(w)]=select_and_eval_local_window(dev,train,cal,mod,w)
    return out


def spectral_features(data:dict, modality:str, pulse_domain:bool)->np.ndarray:
    if pulse_domain:
        rows=[]
        source=data[modality]
        for i,pos in enumerate(data['positions']): rows.append(source[i,np.asarray(pos,np.int64)])
        return np.stack(rows).astype(np.float64)
    return data[modality][:,BODY_START:BODY_STOP].astype(np.float64)


def spectral_pair_audit(dev:dict,train:dict,cal:dict,modality:str,pulse_domain:bool)->dict:
    Sd=spectral_features(dev,modality,pulse_domain); St=spectral_features(train,modality,pulse_domain); Sc=spectral_features(cal,modality,pulse_domain)
    # Remove DC; attack searches a modest low/mid frequency bank. Pair selected without CAL.
    Fd=np.fft.rfft(Sd,axis=1); Ft=np.fft.rfft(St,axis=1); Fc=np.fft.rfft(Sc,axis=1)
    maxbin=min(32,Fd.shape[1]-1); bins=list(range(1,maxbin+1))
    best=(-1.0,None)
    for k1,k2 in itertools.combinations(bins,2):
        def f(F): return np.c_[F[:,k1].real,F[:,k1].imag,F[:,k2].real,F[:,k2].imag]
        pred=nearest_centroid_predict(f(Fd),dev['labels'],f(Ft))
        acc=float(np.mean(pred==train['labels']))
        if acc>best[0]: best=(acc,(k1,k2))
    k1,k2=best[1]
    def f(F): return np.c_[F[:,k1].real,F[:,k1].imag,F[:,k2].real,F[:,k2].imag]
    Xtr=np.concatenate([f(Fd),f(Ft)]); ytr=np.concatenate([dev['labels'],train['labels']])
    pred_nc=nearest_centroid_predict(Xtr,ytr,f(Fc)); pred_rg=ridge_fit_predict(Xtr,ytr,f(Fc))
    nc=float(np.mean(pred_nc==cal['labels'])); rg=float(np.mean(pred_rg==cal['labels']))
    return {'domain':'pulse_slots' if pulse_domain else 'full_body_samples','modality':modality,'selected_bins':list(best[1]),
            'selection_train_accuracy':float(best[0]),'cal_nearest_centroid_accuracy':nc,'cal_ridge_accuracy':rg,
            'cal_attack_accuracy':max(nc,rg),'threshold':THRESH['spectral_4real_max'],'accepted':bool(max(nc,rg)<=THRESH['spectral_4real_max'])}


def symbolic_run_stats(sym:np.ndarray)->Tuple[float,float,float]:
    a=np.asarray(sym,np.int64); runs=[]; cur=1
    for x,y in zip(a[:-1],a[1:]):
        if x==y: cur+=1
        else: runs.append(cur); cur=1
    runs.append(cur)
    return float(len(runs)),float(np.mean(runs)),float(np.max(runs))


def simple_stat_features(data:dict)->np.ndarray:
    rows=[]
    for i in range(len(data['labels'])):
        e=data['e'][i,BODY_START:BODY_STOP].astype(np.float64)
        pos=np.asarray(data['positions'][i],np.int64)
        pulse=data['e'][i,pos].astype(np.float64)
        t=np.arange(len(e),dtype=np.float64)
        total=float(np.sum(e)); denom=total+1e-12
        centroid=float(np.sum(t*e)/denom)
        run_count,mean_run,max_run=symbolic_run_stats(np.asarray(data['symbols'][i],np.int64))
        # autocorrelation in pulse-slot residual domain; normalized by variance
        pc=pulse-pulse.mean(); pv=float(np.dot(pc,pc))+1e-12
        ac=[]
        for lag in (1,2,3,4,8,12,16,24,32):
            ac.append(float(np.dot(pc[:-lag],pc[lag:])/pv))
        # crude spectral energy bands in pulse-slot domain
        F=np.abs(np.fft.rfft(pc))**2
        bands=[]
        edges=np.linspace(1,len(F),7,dtype=int)
        for lo,hi in zip(edges[:-1],edges[1:]): bands.append(float(np.sum(F[lo:hi])))
        rows.append([
            total,float(np.sum(e*e)),float(np.sqrt(np.mean(e*e))),float(np.max(e)),float(np.mean(e)),float(np.var(e)),
            float(np.count_nonzero(pulse>1e-8)),centroid,run_count,mean_run,max_run,*ac,*bands
        ])
    return np.asarray(rows,np.float32)


def simple_stats_audit(train:dict,cal:dict)->dict:
    Xtr=simple_stat_features(train); Xc=simple_stat_features(cal)
    pred=ridge_fit_predict(Xtr,train['labels'],Xc); acc=float(np.mean(pred==cal['labels']))
    return {'feature_dim':int(Xtr.shape[1]),'cal_ridge_accuracy':acc,'threshold':THRESH['simple_stats_max'],'accepted':bool(acc<=THRESH['simple_stats_max'])}


def exact_identity_audit(splits:Dict[str,dict], key: str)->dict:
    names=('dev','train','cal'); sets={k:set(splits[k][key].tolist()) for k in names}
    cross={}
    for a,b in itertools.combinations(names,2): cross[f'{a}_{b}_overlap']=len(sets[a]&sets[b])
    within={}
    for k in names:
        ids=splits[k][key].tolist(); within[k]={'count':len(ids),'unique':len(set(ids)),'duplicates':len(ids)-len(set(ids))}
    return {'identity_key':key,'cross_split':cross,'within_split':within,'accepted':bool(all(v==0 for v in cross.values()) and all(v['duplicates']==0 for v in within.values()))}


def paired_kendall_distance(x: Sequence[int], y: Sequence[int]) -> int:
    xx=np.asarray(x,np.int64); yy=np.asarray(y,np.int64)
    if len(xx)!=len(yy): raise ValueError('paired lengths differ')
    K=0
    for i in range(len(xx)):
        for j in range(i+1,len(xx)):
            dx=int(xx[i]-xx[j]); dy=int(yy[i]-yy[j])
            if dx==0 or dy==0:
                raise AssertionError('Task-B run lengths must be distinct for Kendall audit')
            K += int(dx*dy < 0)
    return int(K)


def circular_high_low_runs(symbols: np.ndarray) -> Tuple[np.ndarray,np.ndarray]:
    s=np.asarray(symbols,np.int64)
    if s.ndim!=1 or len(s)==0: raise ValueError('1D symbols required')
    starts=[i for i in range(len(s)) if int(s[i])==1 and int(s[i-1])==0]
    if len(starts)!=4:
        raise AssertionError(('expected four circular high runs',len(starts)))
    r=np.roll(s,-starts[0])
    runs=[]; cur=int(r[0]); n=1
    for z in r[1:]:
        z=int(z)
        if z==cur: n+=1
        else:
            runs.append((cur,n)); cur=z; n=1
    runs.append((cur,n))
    # Because rotation starts at a 0->1 boundary, the final run is low and no end merge is needed.
    if len(runs)!=8 or any(v != (1 if i%2==0 else 0) for i,(v,_) in enumerate(runs)):
        raise AssertionError(('bad circular run decomposition',runs))
    hi=np.asarray([runs[i][1] for i in range(0,8,2)],np.int64)
    lo=np.asarray([runs[i][1] for i in range(1,8,2)],np.int64)
    return hi,lo


def task_b_semantic_construction_audit(data:dict)->dict:
    rows=[]; mismatch=0; symbol_mismatch=0; max_tau_error=0.0
    class_actual={}
    for i,m in enumerate(data['meta']):
        declared=int(m['kendall_distance'])
        K_meta=paired_kendall_distance(m['high_lengths'],m['low_lengths'])
        hi_sym,lo_sym=circular_high_low_runs(data['symbols'][i])
        K_sym=paired_kendall_distance(hi_sym,lo_sym)
        tau_decl=kendall_tau_from_distance(4,declared)
        tau_meta=kendall_tau_from_distance(4,K_meta)
        tau_sym=kendall_tau_from_distance(4,K_sym)
        mismatch += int(K_meta!=declared)
        symbol_mismatch += int(K_sym!=declared)
        max_tau_error=max(max_tau_error,abs(tau_meta-tau_decl),abs(tau_sym-tau_decl))
        lab=str(data['labels'][i]); class_actual.setdefault(lab,[]).append(K_sym)
        if len(rows)<24:
            rows.append({'seed':int(data['seeds'][i]),'label':lab,'declared_K':declared,'paired_K_meta':K_meta,'paired_K_symbols':K_sym,'declared_tau':tau_decl,'paired_tau_symbols':tau_sym,'high_lengths':list(map(int,m['high_lengths'])),'low_lengths':list(map(int,m['low_lengths']))})
    return {
        'n':len(data['meta']),
        'paired_meta_K_mismatch_count':mismatch,
        'paired_symbol_K_mismatch_count':symbol_mismatch,
        'max_abs_tau_error':float(max_tau_error),
        'actual_symbol_K_by_class':{k:{str(v):vals.count(v) for v in sorted(set(vals))} for k,vals in class_actual.items()},
        'examples':rows,
        'accepted':bool(mismatch==0 and symbol_mismatch==0 and max_tau_error==0.0),
    }


def hard_suffix_audit(data:dict)->dict:
    max_raw=max_e=0.0
    for seed in np.unique(data['seeds']):
        idx=np.where(data['seeds']==seed)[0]
        r=data['raw'][idx,-SUFFIX_HARD:].astype(np.float64); e=data['e'][idx,-SUFFIX_HARD:].astype(np.float64)
        max_raw=max(max_raw,float(np.max(np.abs(r-r[:1])))); max_e=max(max_e,float(np.max(np.abs(e-e[:1]))))
    return {'max_last96_raw_abs_mismatch':max_raw,'max_last96_residual_abs_mismatch':max_e,'accepted':bool(max_raw==0.0 and max_e==0.0)}


def class_semantic_sanity(data:dict,task:str)->dict:
    out={}
    labels=sorted(set(data['labels'].tolist()))
    for lab in labels:
        idx=np.where(data['labels']==lab)[0]
        taus=np.asarray([data['meta'][i]['kendall_tau'] for i in idx],np.float64)
        # realization diversity in symbolic pulse-slot domain
        take=idx[:min(24,len(idx))]
        d=[]
        for i,j in itertools.combinations(take,2):
            a=np.asarray(data['symbols'][i]); b=np.asarray(data['symbols'][j]); d.append(float(np.mean(a!=b)))
        out[lab]={'n':len(idx),'tau_min':float(taus.min()),'tau_mean':float(taus.mean()),'tau_max':float(taus.max()),
                  'mean_pairwise_symbol_hamming_first24':float(np.mean(d)) if d else 0.0,
                  'example_trajectory_ids':data['trajectory_id'][idx[:3]].tolist(),
                  'example_symbol_prefixes':[np.asarray(data['symbols'][i],np.int64)[:32].astype(int).tolist() for i in idx[:3]],
                  'example_meta':[data['meta'][i] for i in idx[:3]]}
    return out


def source_sha256()->str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def write_contract():
    text=f'''# Semantic Memory Tournament V2 — Generator Gate 0 Contract\n\nThis stage does NOT instantiate, calibrate, or evaluate C4/EWMA/LSSM/NLRES recurrences and MUST NOT generate the reserved FINAL seed range.\n\n## Frozen generator threat model\n- semantic identity fixed, temporal realization randomized per seed/class\n- no exact trajectory identity recurrence across DEV/TRAIN/CAL\n- n-gram attacks n=1..8\n- actual raw/residual local-window attacks w={WINDOW_WIDTHS}\n- two-frequency/four-real-coordinate DFT attacks in full-sample and pulse-slot domains\n- simple magnitude/run/autocorrelation/spectral statistics attack\n- terminal raw/residual suffix 96 exact within seed across classes\n\n## Predeclared thresholds\n```json\n{json.dumps(THRESH,indent=2,sort_keys=True)}\n```\n\n## Splits\n```json\n{json.dumps(SPLITS,indent=2,sort_keys=True)}\n```\nThe `final_reserved` range is declared only for future process discipline and is not generated by Gate 0.\n\n## Task A semantic\nEach realization contains two 48-event permutations of the same 48 amplitude ranks embedded in a seed-random irregular pulse schedule. The label is a broad bin of the global Kendall order relation between the first and second permutations. The first permutation, second realization, pulse timing, and exact inversion count are randomized per seed/class. No class owns a fixed codeword.\n\n## Task B semantic\nEach realization has four exposure runs and four recovery gaps with seed-specific distinct run-length multisets, each summing to 48 pulse slots; every run/gap is at least 6 pulse slots long. The label is a broad bin of the global Kendall rank coupling between exposure-run lengths and the following recovery-gap lengths. Run order, circular observation phase, timing, exact rank relation, and amplitude assignment vary per seed/class. Total high slots=48, low slots=48, circular run count=8, and run-length multisets are shared across classes within a seed.\n\n## No architecture access\nNo recurrence candidate list, recurrence calibration, final head, retention curve, or destructive architecture transfer is executed in this stage.\n'''
    (OUT/'GATE0_CONTRACT.md').write_text(text)


def main():
    write_contract()
    data:Dict[str,Dict[str,dict]]={s:{} for s in ('dev','train','cal')}
    for split in data:
        for task in TASKS:
            print('BUILD',split,task,flush=True)
            data[split][task]=build_split(split,task)

    audit={'schema':SCHEMA,'source_sha256':source_sha256(),'thresholds':THRESH,'splits':SPLITS,'tasks':{},'final_accessed':False}
    all_ok=True
    for task in TASKS:
        print('AUDIT',task,flush=True)
        t={}
        splitview={s:data[s][task] for s in ('dev','train','cal')}
        t['trajectory_identity']=exact_identity_audit(splitview,'trajectory_id')
        t['symbols_identity']=exact_identity_audit(splitview,'symbols_id')
        if task == TASKS[1]:
            t['semantic_construction']={s:task_b_semantic_construction_audit(data[s][task]) for s in ('dev','train','cal')}
        t['hard_suffix']={s:hard_suffix_audit(data[s][task]) for s in ('dev','train','cal')}
        t['ngram_1_to_8']=ngram_audit(data['train'][task],data['cal'][task])
        t['local_windows']=local_window_audit(data['dev'][task],data['train'][task],data['cal'][task])
        t['spectral']={}
        for mod in ('raw','e'):
            for pd in (False,True):
                key=f'{mod}_'+('pulse' if pd else 'full')
                t['spectral'][key]=spectral_pair_audit(data['dev'][task],data['train'][task],data['cal'][task],mod,pd)
        t['simple_statistics']=simple_stats_audit(data['train'][task],data['cal'][task])
        t['semantic_realization_sanity']=class_semantic_sanity(data['train'][task],task)
        failures=[]
        if not t['trajectory_identity']['accepted']: failures.append('trajectory_identity')
        if not t['symbols_identity']['accepted']: failures.append('symbols_identity')
        if task == TASKS[1] and not all(x['accepted'] for x in t['semantic_construction'].values()): failures.append('semantic_construction')
        if not all(x['accepted'] for x in t['hard_suffix'].values()): failures.append('suffix')
        if any(x['lookup_fail'] or x['linear_fail'] for x in t['ngram_1_to_8'].values()): failures.append('ngram')
        if any(not x['accepted'] for mod in t['local_windows'].values() for x in mod.values()): failures.append('local_window')
        if any(not x['accepted'] for x in t['spectral'].values()): failures.append('spectral')
        if not t['simple_statistics']['accepted']: failures.append('simple_statistics')
        t['accepted']=not failures; t['failures']=failures
        all_ok = all_ok and t['accepted']
        audit['tasks'][task]=t

    audit['generator_verdict']='GENERATOR_V2_ACCEPTED' if all_ok else 'GENERATOR_V2_REJECTED'
    audit['recurrence_tournament_started']=False
    audit['final_accessed']=False
    (OUT/'GATE0_AUDIT.json').write_text(json.dumps(audit,indent=2,sort_keys=True))
    # small human-readable summary
    lines=[f'# Gate 0 result: {audit["generator_verdict"]}','',f'Source SHA-256: `{audit["source_sha256"]}`','',
           '**FINAL was not generated or accessed. No recurrence family was calibrated or evaluated.**','']
    for task,t in audit['tasks'].items():
        lines += [f'## {task}',f'Accepted: **{t["accepted"]}**; failures: `{t["failures"]}`',
                  f"Cross-split label-free (gaps,symbols) overlaps: `{t['trajectory_identity']['cross_split']}`",
                  f"Cross-split symbols-only overlaps: `{t['symbols_identity']['cross_split']}`",
                  f"Simple-stat CAL accuracy: `{t['simple_statistics']['cal_ridge_accuracy']:.4f}`",'','N-gram CAL linear attack:']
        lines += [f"- n={n}: {v['hashed_count_linear_cal_accuracy']:.4f}; exact lookup coverage={v['exact_signature_cal_coverage']:.3f}" for n,v in t['ngram_1_to_8'].items()]
        lines += ['','Local-window CAL attack (max of NC/ridge at location selected without CAL):']
        for mod in ('raw','e'):
            lines.append(f'- {mod}: '+', '.join(f"w={w}:{t['local_windows'][mod][str(w)]['cal_attack_accuracy']:.3f}" for w in WINDOW_WIDTHS))
        lines += ['','Spectral 4-real-coordinate attacks:']
        lines += [f"- {k}: {v['cal_attack_accuracy']:.4f} bins={v['selected_bins']}" for k,v in t['spectral'].items()]
        lines += ['']
    (OUT/'GATE0_AUDIT.md').write_text('\n'.join(lines))
    print('VERDICT',audit['generator_verdict'])
    print('AUDIT',OUT/'GATE0_AUDIT.json')

if __name__=='__main__':
    main()
